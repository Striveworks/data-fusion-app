from datetime import datetime


def datetime_to_str(dt: datetime | None) -> str | None:
    if dt is not None:
        return dt.strftime("%Y-%m-%dT%H:%M:%SZ")

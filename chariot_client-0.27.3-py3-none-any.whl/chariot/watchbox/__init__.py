class SaberDependenciesNotFoundError(ModuleNotFoundError):
    def __init__(self) -> None:
        super().__init__("Please install `chariot-client[saber]` to use the watchbox sdk.")


try:
    from .models import *
    from .watchbox import *
    from .triage_event import *
    from .imagery_providers import *
except ModuleNotFoundError:
    raise SaberDependenciesNotFoundError

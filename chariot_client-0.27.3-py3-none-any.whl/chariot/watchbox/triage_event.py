from datetime import datetime
from typing import Literal

import chariot._apis
from chariot.watchbox._util import datetime_to_str
from chariot.watchbox.models import (
    DetectionVerificationStatus,
    TriageEvent,
    TriageEventReviewStatus,
)

__all__ = [
    "get_triage_events",
    "get_triage_event",
]


def get_triage_events(
    project_id: str,
    *,
    watchbox_id: str | None = None,
    review_status: TriageEventReviewStatus | None = None,
    date_captured_start: datetime | None = None,
    date_captured_end: datetime | None = None,
    date_created_start: datetime | None = None,
    date_created_end: datetime | None = None,
    detection_verification_status: DetectionVerificationStatus | None = None,
    sort: Literal["date_captured", "date_created"] | None = None,
    direction: Literal["asc", "desc"] | None = None,
    offset: int | None = None,
    limit: int | None = None,
    include_details: bool | None = None,
) -> list[TriageEvent]:
    """Get triage events.

    Parameters
    ----------
    project_id: str
        Name of the project to search
    watchbox_id: str | None
        Filter by watchbox id
    review_status: TriageEventReviewStatus | None
        Filter by triage event review status
    date_captured_start: datetime | None
        Include triage events whose imagery request's imagery_date_captured is
        more recent than this timestamp
    date_captured_end: datetime | None
        Include triage events whose imagery request's imagery_date_captured is
        less recent than this timestamp
    date_created_start: datetime | None
        Include triage events whose date_created is more recent than this timestamp
    date_created_end: datetime | None
        Include triage events whose date_created is less recent than this timestamp
    detection_verification_status: DetectionVerificationStatus | None
        Filter by detection verification status
    sort: Literal["date_captured", "date_created"] | None
        Sort by. Defaults to "date_captured"
    direction: Literal["asc", "desc"] | None
        Sort direction. Defaults to "desc"
    offset: int | None
        Pagination offset. Defaults to 0.
    limit: int | None
        Pagination limit. Defaults to 100.
    include_details: bool | None
        Hydrate the `chariot_request` and `imagery_request` fields in
        the response. Defaults to false. If false, the `chariot_request`
        and `imagery_request` fields will contain pointers (IDs) to their
        full values.

    """
    detection_verification_status = (
        DetectionVerificationStatus(detection_verification_status)
        if detection_verification_status
        else None
    )
    review_status = TriageEventReviewStatus(review_status) if review_status else None

    data = chariot._apis.watchbox.triage_events_api.v2_triage_events_get(
        project_id=project_id,
        offset=offset,
        limit=limit,
        sort=f"{sort}:{direction}",
        watch_point=watchbox_id,
        include_details=include_details,
        review_status=review_status.value if review_status else None,
        date_captured_start=datetime_to_str(date_captured_start),
        date_captured_end=datetime_to_str(date_captured_end),
        date_created_start=datetime_to_str(date_created_start),
        date_created_end=datetime_to_str(date_created_end),
        detection_verification_status=detection_verification_status.value
        if detection_verification_status
        else None,
    ).data

    return [TriageEvent.model_validate(t.model_dump(exclude_none=True)) for t in data]


def get_triage_event(id: str) -> TriageEvent:
    """Get triage event by id."""
    data = chariot._apis.watchbox.triage_events_api.v2_triage_events_id_get(id).data
    return TriageEvent.model_validate(data.model_dump(exclude_none=True))

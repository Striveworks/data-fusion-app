import chariot._apis
from chariot import mcp_setting

__all__ = [
    "retry_imagery_request",
]


@mcp_setting(mutating=True)
def retry_imagery_request(id: str) -> None:
    """
    Retry an imagery request.

    Parameters
    ----------
    id: str
        The imagery request's ID.

    Returns
    -------
    None

    """
    chariot._apis.watchbox.imagery_requests_api.v2_imagery_requests_imagery_request_id_retry_post(
        id
    )

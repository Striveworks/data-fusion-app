from datetime import datetime
from typing import Literal

import geojson

import chariot._apis
from chariot import mcp_setting
from chariot.watchbox._util import datetime_to_str
from chariot.watchbox.models import (
    Cluster,
    CreateWatchboxRequest,
    DetectionVerificationStatus,
    ProviderOption,
    TriageEventReviewStatus,
    UpdateWatchboxRequest,
    WatchBox,
    WatchboxDetection,
    WatchboxStatistics,
)

__all__ = [
    "get_watchboxes",
    "get_watchbox",
    "create_watchbox",
    "update_watchbox",
    "delete_watchbox",
    "get_watchbox_statistics",
    "get_watchbox_labels",
    "get_watchbox_detections",
    "get_provider_options",
]


def get_watchboxes(
    project_id: str,
    *,
    geojson_area: dict | str = None,
    threshold: int = None,
    name: str = None,
    sort: Literal["date_created", "date_updated", "name"] | None = None,
    direction: Literal["asc", "desc"] | None = None,
    include_triage_events: bool | None = None,
    triage_event_review_status: TriageEventReviewStatus | None = None,
) -> list[WatchBox] | list[Cluster] | None:
    """Get watchboxes.

    Parameters
    ----------
    project_id: str
        Name of the project to search
    geojson_area: dict | str
        A geojson string or object. Results will be limited to within this
        area.
    threshold: int
        Maximum number of watchboxes to return. If the number of matching
        watchboxes exceeds this threshold, then a list of Clusters will
        be returned instead. Each cluster is a pointer to a list of watchboxes.
        Default threshold is 1000.
    name: str
        Name of the watchbox (fuzzy match)
    sort: Literal["date_created", "date_updated", "name"]
        How to sort results. Defaults to date_creatd
    direction: Literal["asc", "desc"]
        Which direction to sort results. Defaults to asc.
    include_triage_events: bool
        Whether to return triage events with each watchbox. Defaults to false.
    triage_event_review_status: Literal["reviewed", "not_reviewed"]
        Only return watchboxes which have at least one triage event with this review status

    Returns
    -------
    list[Watchbox] | list[Cluster] | None

    """
    if isinstance(geojson_area, dict):
        geojson_area = geojson.dumps(geojson_area)

    triage_event_review_status = (
        TriageEventReviewStatus(triage_event_review_status)
        if triage_event_review_status is not None
        else None
    )

    if geojson_area is not None:
        geojson_obj = geojson.loads(geojson_area)
        if not geojson_obj.is_valid:
            raise ValueError(f"Invalid geojson passed: {geojson_obj.errors()}")

    data = chariot._apis.watchbox.watchboxes_api.v2_watchboxes_get(
        project_id=project_id,
        geojson_area=geojson_area,
        threshold=threshold,
        name=name,
        sort=sort,
        direction=direction,
        triage_event_review_status=triage_event_review_status,
        include_triage_events=include_triage_events,
    ).data

    if data.clusters is not None:
        return [Cluster.model_validate(c.model_dump(exclude_none=True)) for c in data.clusters]
    if data.boxes is not None:
        return [WatchBox.model_validate(b.model_dump(exclude_none=True)) for b in data.boxes]


def get_watchbox(id: str) -> WatchBox:
    """Get a watchbox by id.

    Parameters
    ----------
    id: str
        The watchbox ID

    Returns
    -------
    WatchBox

    """
    data = chariot._apis.watchbox.watchboxes_api.v2_watchboxes_id_get(id).data
    return WatchBox.model_validate(data.model_dump(exclude_none=True))


@mcp_setting(mutating=True)
def create_watchbox(request: CreateWatchboxRequest) -> str:
    """Create a watchbox.

    Parameters
    ----------
    request: CreateWatchboxRequest
        Watchbox creation parameters

    Returns
    -------
    str
        The ID of the created watchbox

    """
    data = chariot._apis.watchbox.watchboxes_api.v2_watchboxes_post(
        request.model_dump(exclude_none=True)
    ).data
    return data.id


@mcp_setting(mutating=True)
def update_watchbox(id: str, request: UpdateWatchboxRequest) -> WatchBox:
    """Update a watchbox.

    Parameters
    ----------
    id: str
        The watchbox ID to update
    request: UpdateWatchboxRequest
        Watchbox update parameters

    Returns
    -------
    WatchBox
        The updated watchbox

    """
    data = chariot._apis.watchbox.watchboxes_api.v2_watchboxes_id_patch(
        id, request.model_dump(exclude_none=True)
    ).data
    return WatchBox.model_validate(data.model_dump(exclude_none=True))


@mcp_setting(mutating=True)
def delete_watchbox(id: str) -> None:
    """Delete a watchbox by ID."""
    chariot._apis.watchbox.watchboxes_api.v2_watchboxes_id_delete(id)


def get_watchbox_statistics(id: str) -> list[WatchboxStatistics]:
    """Get statistics for a watchbox.

    Parameters
    ----------
    id: str
        The watchbox ID

    Returns
    -------
    list[WatchboxStatistics]

    """
    data = chariot._apis.watchbox.watchboxes_api.v2_watchboxes_id_statistics_get(id).data
    return [WatchboxStatistics.model_validate(s.model_dump(exclude_none=True)) for s in data]


def get_watchbox_labels(id: str) -> list[str]:
    """Get detection labels for a watchbox. These are the class labels
    of the underlying model for the watchbox.

    Parameters
    ----------
    id: str
        The watchbox ID

    Returns
    -------
    list[str]
        Available class labels for the watchbox's detection model

    """
    return chariot._apis.watchbox.watchboxes_api.v2_watchboxes_id_labels_get(id).data


def get_watchbox_detections(
    *,
    offset: int | None = None,
    limit: int | None = None,
    sort: Literal[
        "time_of_emission",
        "date_created",
        "score",
        "date_updated",
        "id",
        "classification",
        "deleted_at",
    ]
    | None = None,
    sort_direction: Literal["asc", "desc"] | None = None,
    chariot_request: str | None = None,
    triage_event_id: str | None = None,
    watchbox_id: str | None = None,
    project_id: str | None = None,
    verification_status: list[DetectionVerificationStatus] | None = None,
    class_labels: list[str] | None = None,
    geojson_area: dict | str | None = None,
    time_of_emission_start: datetime | None = None,
    time_of_emission_end: datetime | None = None,
    score_minimum: float | None = None,
    score_maximum: float | None = None,
) -> list[WatchboxDetection]:
    """Get detections found in a watchbox.

    Parameters
    ----------
    offset: int | None
        Pagination offset. Default to 0.
    limit: int | None
        Pagination limit. Default to 25.
    sort: Literal["time_of_emission", "date_created", "score", "date_updated", "id", "classification", "deleted_at"] | None = None,
        Sort field
    sort_direction: Literal["asc", "desc"] | None = None
        Sort direction
    chariot_request: str | None
        Filter by Chariot Request ID
    triage_event_id: str | None
        Filter by Triage Event ID
    watchbox_id: str | None
        Filter by Watchbox ID
    project_id: str | None
        Filter by Project ID
    verification_status: list[DetectionVerificationStatus] | None
        Filter by verification statuses (not_reviewed, needs_review, verified, rejected)
    class_labels: list[str] | None
        Filter by class labels
    geojson_area: dict | str | None
        Filter by GeoJSON area (dict will be converted to JSON string)
    time_of_emission_start: datetime | None
        Start time filter for detection emission time
    time_of_emission_end: datetime | None
        End time filter for detection emission time
    score_minimum: float | None
        Minimum detection confidence score
    score_maximum: float | None
        Maximum detection confidence score

    Returns
    -------
    list[WatchboxDetection]

    """
    if isinstance(geojson_area, dict):
        geojson_area = geojson.dumps(geojson_area)

    time_start_str = datetime_to_str(time_of_emission_start)
    time_end_str = datetime_to_str(time_of_emission_end)
    verification_status_strs = (
        [DetectionVerificationStatus(vs).value for vs in verification_status]
        if verification_status
        else None
    )

    data = chariot._apis.watchbox.watchboxes_api.v2_watchboxes_detections_get(
        offset=offset,
        limit=limit,
        sort=f"{sort}:{sort_direction}",
        chariot_request=chariot_request,
        triage_event_id=triage_event_id,
        watch_box_id=watchbox_id,
        project_id=project_id,
        verification_status=verification_status_strs,
        class_labels=class_labels,
        geojson_area=geojson_area,
        time_of_emission_start=time_start_str,
        time_of_emission_end=time_end_str,
        score_minimum=str(score_minimum) if score_minimum is not None else None,
        score_maximum=str(score_maximum) if score_maximum is not None else None,
    ).data

    return (
        [WatchboxDetection.model_validate(item.model_dump(exclude_none=True)) for item in data]
        if data is not None
        else []
    )


def get_provider_options(provider: str) -> list[ProviderOption]:
    """Get available options from a provider.

    Parameters
    ----------
    provider: str
        Provider ID (e.g., MAXAR_SOLUTIONS, GEGD, MGP, ISPY)

    Returns
    -------
    list[ProviderOption]
        List of available provider options

    """
    data = chariot._apis.watchbox.watchboxes_api.v2_watchboxes_providers_provider_options_get(
        provider
    ).data
    return (
        [
            ProviderOption.model_validate(option.model_dump(exclude_none=True))
            for option in data.options
        ]
        if data.options
        else []
    )

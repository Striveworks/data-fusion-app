from chariot.watchbox.models import ImageryProvider
import chariot._apis
from typing import Literal

__all__ = ["get_imagery_providers"]


def get_imagery_providers(
    name: str = None,
    handler_id: str = None,
    sort: Literal["name", "date_created", "handler_id"] = None,
    direction: Literal["asc", "desc"] = None,
    offset: int = None,
    limit: int = None,
) -> list[ImageryProvider]:
    """
    Get imagery providers.

    Parameters
    ----------
    name: str
        Imagery Provider Name
    handler_id: str
        Imagery Provider Handler ID
    sort: Literal["name", "date_created", "handler_id"]
        How to sort results. Defaults to "date_created".
    direction: Literal["asc", "desc"]
        Direction for sorting. Defaults to "desc"
    offset: int
        Pagination offset. Defaults to 0.
    limit: int
        Pagination limit. Defaults to 100.

    Returns
    -------
    list[ImageryProvider]
    """

    data = chariot._apis.watchbox.imagery_providers_api.v2_imagery_providers_get(
        name=name, handler_id=handler_id, sort=sort, direction=direction, offset=offset, limit=limit
    ).data

    return [ImageryProvider.model_validate(p.model_dump(exclude_none=True)) for p in data]

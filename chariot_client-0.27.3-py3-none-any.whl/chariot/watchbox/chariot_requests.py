from typing import Literal

import chariot._apis
from chariot import mcp_setting
from chariot.watchbox.models import ChariotRequest

__all__ = [
    "get_chariot_request",
    "get_chariot_requests",
    "retry_chariot_request",
]


def get_chariot_request(id: str) -> ChariotRequest:
    """Get a Chariot request by id.

    Parameters
    ----------
    id: str
        The Chariot request ID

    Returns
    -------
    ChariotRequest

    """
    resp = chariot._apis.watchbox.chariot_requests_api.v2_chariot_requests_chariot_request_id_get(
        id
    )
    if resp.data is None:
        raise ValueError(f"chariot request not found: {id}")
    return ChariotRequest.model_validate(resp.data.model_dump(exclude_none=True))


def get_chariot_requests(
    triage_event_id: str | None = None,
    sort: Literal["name", "date_created", "date_updated"] | None = None,
    direction: Literal["asc", "desc"] | None = None,
    offset: int | None = None,
    limit: int | None = None,
) -> list[ChariotRequest]:
    """Get Chariot requests.

    Parameters
    ----------
    triage_event_id: str
        Triage event to filter by
    sort: Literal["name", "date_created", "date_updated"]
        Sort by
    direction: Literal["asc", "desc"]
        Sort direction
    offset: int
        Pagination offset. Defaults to 0.
    limit: int
        Pagination limit. Defaults to 25.

    Returns
    -------
    list[ChariotRequest]

    """
    page = chariot._apis.watchbox.chariot_requests_api.v2_chariot_requests_get(
        offset=offset,
        limit=limit,
        sort=sort,
        direction=direction,
        triage_event_id=triage_event_id,
    )
    rows = page.data or []
    return [ChariotRequest.model_validate(r.model_dump(exclude_none=True)) for r in rows]


@mcp_setting(mutating=True)
def retry_chariot_request(id: str) -> None:
    """Retry a Chariot request."""
    chariot._apis.watchbox.chariot_requests_api.v2_chariot_requests_chariot_request_id_retry_post(
        id
    )

import contextlib
import io
import math
import os
import time
from collections.abc import Callable, Iterable
from dataclasses import asdict, is_dataclass
from datetime import datetime
from enum import Enum
from typing import Any, BinaryIO, Generic, TypeVar

from dateutil import parser, tz

from chariot.config import getLogger

log = getLogger(__name__)


def enum_value(obj):
    if isinstance(obj, Enum):
        return obj.value
    return obj


def convert_to_dataclass(obj, clazz):
    if isinstance(obj, clazz):
        return obj
    if is_dataclass(obj) and not isinstance(obj, type):
        obj = asdict(obj, dict_factory=dict_factory)
    elif hasattr(obj, "model_dump"):
        obj = obj.model_dump()
    if isinstance(obj, dict):
        # Proto structs use "" for unset optional fields.
        obj = {k: (None if v == "" else v) for k, v in obj.items()}
    return clazz(**obj)


def call_api(method, request=None, /, **kwargs):
    if request is not None:
        if is_dataclass(request):
            kwargs = {**asdict(request, dict_factory=dict_factory), **kwargs}
        elif isinstance(request, dict):
            kwargs = {**request, **kwargs}
        else:
            raise TypeError(f"unsupported request type: {type(request)!r}")
    return method(**kwargs)


def convert_to_dataclass_list(obj, clazz):
    return [convert_to_dataclass(c, clazz) for c in obj]


def convert_to_dataclass_dict(obj, clazz):
    return {k: convert_to_dataclass(v, clazz) for k, v in obj.items()}


def convert_from_dataclass(obj, clazz):
    if obj is None:
        return obj
    if isinstance(obj, clazz):
        return obj
    return clazz(**asdict(obj))


def convert_from_dataclass_list(obj, clazz):
    if obj is None:
        return obj
    return [convert_from_dataclass(c, clazz) for c in obj]


def convert_to_datetime(obj):
    if not obj:
        return None
    if isinstance(obj, str):
        return parser.parse(obj)
    return obj


def format_datetime_utc(dt: datetime) -> str:
    return dt.astimezone(tz.UTC).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def dict_factory(obj):
    return {k: enum_value(v) for k, v in obj}


def paginate_items(func, params, max_items: int | None = None, keyset_pagination: bool = False):
    offset = 0
    last_id = None
    while True:
        page = (
            func(**params, id_after=last_id) if keyset_pagination else func(**params, offset=offset)
        )
        for item in page:
            yield item
            offset += 1
            if max_items is not None and offset >= max_items:
                return
            if keyset_pagination:
                last_id = item.id

        if len(page) == 0:
            return


def paginate_strings(func, params, max_items: int | None = None, keyset_pagination: bool = False):
    offset = 0
    last_id = None
    while True:
        page = (
            func(**params, id_after=last_id) if keyset_pagination else func(**params, offset=offset)
        )
        for item in page:
            yield item
            offset += 1
            if max_items is not None and offset >= max_items:
                return
            if keyset_pagination:
                last_id = item

        if len(page) == 0:
            return


T = TypeVar("T")


def wait_for(
    success_condition: Callable[[], tuple[bool, T]],
    timeout_message: str,
    timeout: float,
    wait_interval: float,
) -> T:
    start_time = time.time()
    while True:
        success, resource = success_condition()
        if success:
            return resource
        if time.time() - start_time > timeout:
            raise TimeoutError(timeout_message)
        time.sleep(wait_interval)


class Base:
    def __post_init__(self):
        pass


class Path(str):
    pass


class FileChunkReader:
    _size: int
    _file: BinaryIO
    _start_offset: int
    _bytes_read: int

    def __init__(self, *, path: str, offset: int, chunk_size: int, total_size: int):
        self._size = min(chunk_size, total_size - offset)
        self._file = open(path, "rb")
        self._file.seek(offset)
        self._start_offset = offset
        self._bytes_read = 0

    def read(self, size: int = -1) -> bytes:
        bytes_left = max(0, self._size - self._bytes_read)
        if not bytes_left:
            return b""
        if size == -1:
            size = bytes_left
        else:
            size = min(size, bytes_left)
        data = self._file.read(size)
        self._bytes_read += len(data)
        return data

    def seek(self, offset: int, whence: int = os.SEEK_SET) -> int:
        if whence not in (os.SEEK_SET, os.SEEK_CUR, os.SEEK_END):
            raise ValueError(f"invalid whence `{whence}`")

        offset += self._start_offset
        if whence == os.SEEK_CUR:
            offset += self._bytes_read
        elif whence == os.SEEK_END:
            offset += self._size

        if offset < self._start_offset:
            raise ValueError("seek offset before beginning of chunk")

        self._file.seek(offset)
        self._bytes_read = offset - self._start_offset
        return self._bytes_read

    def tell(self) -> int:
        return self._bytes_read

    def close(self) -> None:
        self._file.close()

    def __enter__(self) -> Any:
        return self

    def __exit__(self, exc_type, exc_val, traceback) -> None:
        try:
            self.close()
        except:
            log.exception(f"Failed to close file {self.path}")


class ChunkedReaders(Generic[T]):
    def __init__(self, chunks: Iterable[T], stack: contextlib.ExitStack):
        self._chunks = list(chunks)
        self._context_manager = stack

    def __enter__(self) -> list[T]:
        return self._chunks

    def __exit__(self, exc_type, exc_val, traceback):
        self._context_manager.close()


def _file_chunks(num_chunks: int, total_size: int, path: str) -> ChunkedReaders[FileChunkReader]:
    chunk_size = math.ceil(total_size / num_chunks)
    chunks = []
    with contextlib.ExitStack() as stack:
        for i in range(num_chunks):
            chunk = FileChunkReader(
                offset=i * chunk_size, chunk_size=chunk_size, total_size=total_size, path=path
            )
            chunks.append(stack.enter_context(chunk))
        return ChunkedReaders(chunks, stack.pop_all())


def _data_chunks(num_chunks: int, data: bytes) -> ChunkedReaders[io.BytesIO]:
    total_size = len(data)
    chunk_size = math.ceil(total_size / num_chunks)
    chunks = []
    with contextlib.ExitStack() as stack:
        for i in range(num_chunks):
            chunk = io.BytesIO(data[i * chunk_size : min((i + 1) * chunk_size, total_size)])
            chunks.append(stack.enter_context(chunk))
        return ChunkedReaders(chunks, stack.pop_all())


def chunks(
    num_chunks: int, total_size: int, file: Path | bytes
) -> ChunkedReaders[io.BytesIO | FileChunkReader]:
    if isinstance(file, Path):
        return _file_chunks(num_chunks=num_chunks, total_size=total_size, path=file)
    else:
        return _data_chunks(num_chunks=num_chunks, data=file)

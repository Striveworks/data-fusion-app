from collections.abc import Generator
from typing import Literal, overload

from restclient_py.serialization import path_escape

from chariot import _apis, mcp_setting
from chariot.datasets import _utils, models, uploads
from chariot_api._proto.datasets_v3.datums_structs_gen import TrimVideoDatumRequest
from chariot_api._proto.datasets_v3.videos_structs_gen import (
    GetVideoReferencesRequest,
)

__all__ = [
    "get_video_reference",
    "get_video_references",
    "import_video_to_dataset",
    "import_video_to_dataset_and_wait",
    "trim_video_datum",
    "get_video_trim_request",
]


def _video_reference_from_api(data) -> models.VideoReference:
    return _utils.convert_to_dataclass(data, models.VideoReference)


def get_video_reference(id: str) -> models.VideoReference:
    """Retrieves a VideoReference record by its unique identifier.

    A VideoReference is a metadata record that tracks a specific video file's properties (e.g., FPS, resolution, duration).
    It serves as the link between the video service record and the Dataset/Datum entities that utilize the video.

    :param id: The unique identifier of the video reference.
    :type id: str
    :return: The metadata object containing video properties.
    :rtype: models.VideoReference
    """
    response = _utils.call_api(
        _apis.datasets_v3.videos_api.get_video_reference,
        video_reference_id=id,
    )
    if not response.data:
        raise RuntimeError("Received malformed response (missing `data`) from get_video_reference")
    return _video_reference_from_api(response.data)


def _range_body(value: models.Range | dict[str, float] | None) -> dict[str, float] | None:
    if value is None:
        return None
    if isinstance(value, dict):
        value = models.Range(**value)
    return value._to_post_body()


def _get_video_references(
    *,
    project_ids: list[str] | None = None,
    dataset_id: str | None = None,
    datum_id: str | None = None,
    imported_from_video_request_ids: list[str] | None = None,
    has_klv: bool | None = None,
    codec: str | None = None,
    video_container_format: str | None = None,
    duration_ms: models.Range | None = None,
    source_fps: models.Range | None = None,
    width_px: models.Range | None = None,
    height_px: models.Range | None = None,
    sort: str | None = None,
    direction: models.SortDirection | None = None,
    limit: int | None = None,
    offset: int | None = None,
) -> list[models.VideoReference]:
    request = GetVideoReferencesRequest(
        project_ids=project_ids,
        dataset_id=dataset_id,
        datum_id=datum_id,
        imported_from_video_request_ids=imported_from_video_request_ids,
        has_klv=has_klv,
        codec=codec,
        format=video_container_format,
        duration_ms=_range_body(duration_ms),
        source_fps=_range_body(source_fps),
        width_px=_range_body(width_px),
        height_px=_range_body(height_px),
        sort=sort,
        direction=_utils.enum_value(direction),
        limit=limit,
        offset=offset,
    )
    response = _utils.call_api(_apis.datasets_v3.videos_api.get_video_references, request)
    if not response.data:
        return []
    return [_video_reference_from_api(v) for v in response.data]


def get_video_references(
    *,
    project_ids: list[str] | None = None,
    dataset_id: str | None = None,
    datum_id: str | None = None,
    imported_from_video_request_ids: list[str] | None = None,
    has_klv: bool | None = None,
    codec: str | None = None,
    video_container_format: str | None = None,
    duration_ms: models.Range | None = None,
    source_fps: models.Range | None = None,
    width_px: models.Range | None = None,
    height_px: models.Range | None = None,
    sort: str | None = None,
    direction: models.SortDirection | None = None,
    max_items: int | None = None,
) -> Generator[models.VideoReference, None, None]:
    """Get video references with optional filters and sorted pagination.

    :param project_ids: Restrict to datasets in these projects
    :type project_ids: Optional[list[str]]
    :param dataset_id: Restrict to a single dataset id
    :type dataset_id: Optional[str]
    :param datum_id: Restrict to the video reference linked from this datum id
    :type datum_id: Optional[str]
    :param imported_from_video_request_ids: Filter to videos imported from these video service sessions
    :type imported_from_video_request_ids: Optional[list[str]]
    :param has_klv: Filter by presence of KLV metadata
    :type has_klv: Optional[bool]
    :param codec: Filter by codec
    :type codec: Optional[str]
    :param video_container_format: Filter by container format (for example mp4)
    :type video_container_format: Optional[str]
    :param duration_ms: Inclusive duration range in milliseconds (min, max, or both; equal values match exactly)
    :type duration_ms: Optional[models.Range]
    :param source_fps: Inclusive source FPS range (min, max, or both; equal values match exactly)
    :type source_fps: Optional[models.Range]
    :param width_px: Inclusive width range in pixels (min, max, or both; equal values match exactly)
    :type width_px: Optional[models.Range]
    :param height_px: Inclusive height range in pixels (min, max, or both; equal values match exactly)
    :type height_px: Optional[models.Range]
    :param sort: Sort column (`id` or `creation timestamp`)
    :type sort: Optional[str]
    :param direction: Sort direction
    :type direction: Optional[models.SortDirection]
    :param max_items: Maximum number of items to yield
    :type max_items: Optional[int]
    :return: Generator of video references
    :rtype: Generator[models.VideoReference, None, None]
    """
    params = {k: v for k, v in locals().items() if k != "max_items"}
    return _utils.paginate_items(_get_video_references, params, max_items)


@mcp_setting(mutating=True)
def import_video_to_dataset(
    dataset_id: str, *, video_id: str, video_request_id: str | None = None
) -> models.Upload:
    """Import a copy of a video from the video service into an image dataset as a video datum.

    The dataset gets its own copy, so later changes to the original do not affect it. Pass
    `video_request_id` to copy that session or clip. Omit it to copy the newest session that has
    written segments. The import runs as an upload job; poll it with `wait_for_upload` or call
    `import_video_to_dataset_and_wait`.

    :param dataset_id: Id of the image dataset to import into
    :type dataset_id: str
    :param video_id: Id of the video in the video service
    :type video_id: str
    :param video_request_id: Id of the session or clip to copy. Omit to use the newest session with segments.
    :type video_request_id: Optional[str]
    :return: The upload tracking the import
    :rtype: models.Upload
    :raises ApiException: 400 if the dataset is not an image dataset, the request does not belong to
        the video, or it has no segments, 403 or 404 if the dataset or video is not found or access
        is denied, 409 if the dataset is archived
    """
    response = _utils.call_api(
        _apis.datasets_v3.videos_api.add_video_to_dataset,
        dataset_id=dataset_id,
        video_id=video_id,
        video_request_id=video_request_id or "",
    )
    if not response.data:
        raise RuntimeError(
            "Received malformed response (missing `data`) from import_video_to_dataset"
        )
    return _utils.convert_to_dataclass(response.data, models.Upload)


@mcp_setting(mutating=True)
def import_video_to_dataset_and_wait(
    dataset_id: str,
    *,
    video_id: str,
    video_request_id: str | None = None,
    timeout: float = uploads.DEFAULT_UPLOAD_WAIT_TIMEOUT,
    wait_interval: float = uploads.DEFAULT_UPLOAD_WAIT_INTERVAL,
) -> models.Upload:
    """Import a copy of a video into an image dataset and wait for the import to finish.

    :param dataset_id: Id of the image dataset to import into
    :type dataset_id: str
    :param video_id: Id of the video in the video service
    :type video_id: str
    :param video_request_id: Id of the session or clip to copy. Omit to use the newest session with segments.
    :type video_request_id: Optional[str]
    :param timeout: Number of seconds to wait for the import to complete (default 3600)
    :type timeout: float
    :param wait_interval: Number of seconds between checks for completion (default 0.5)
    :type wait_interval: float
    :return: The completed upload
    :rtype: models.Upload
    :raises TimeoutError: If the timeout has been reached
    :raises exceptions.UploadUnknownError: If the import fails
    """
    upload = import_video_to_dataset(
        dataset_id, video_id=video_id, video_request_id=video_request_id
    )
    return uploads.wait_for_upload(upload.id, timeout=timeout, wait_interval=wait_interval)


@overload
def trim_video_datum(
    id: str,
    *,
    dataset_id: str | None = None,
    trim_start: int | None = None,
    trim_end: int | None = None,
    dry_run: Literal[True],
) -> models.TrimEligibility: ...


@overload
def trim_video_datum(
    id: str,
    *,
    dataset_id: str | None = None,
    trim_start: int | None = None,
    trim_end: int | None = None,
    dry_run: Literal[False] = False,
) -> models.VideoTrimSubmission: ...


@mcp_setting(mutating=True)
def trim_video_datum(
    id: str,
    *,
    dataset_id: str | None = None,
    trim_start: int | None = None,
    trim_end: int | None = None,
    dry_run: bool = False,
) -> models.TrimEligibility | models.VideoTrimSubmission:
    """Check eligibility and/or trim a video datum.

    Trims a video datum to the window `[trim_start, trim_end]`, given as nanosecond offsets from the start of the video.
    Annotations outside the window are archived and the rest are remapped onto the trimmed video's timeline.
    Set `dry_run` to true to check eligibility without performing a trim.

    Videos that have been used in a snapshot are not eligible.


    :param id: Datum id
    :param dataset_id: Optional dataset id when the datum spans datasets
    :param trim_start: Start of the kept window, in nanoseconds from the start of the video
    :param trim_end: End of the kept window, in nanoseconds from the start of the video
    :param dry_run: If true, eligibility only
    :return: TrimEligibility when dry_run is true; VideoTrimSubmission when a trim is accepted
    :raises ApiException: 400 for an invalid window, 409 if ineligible or a trim is already running
    """
    if dry_run:
        response = _utils.call_api(
            _apis.datasets_v3.datums_api.trim_video_datum,
            datum_id=id,
            dataset_id=dataset_id or "",
            dry_run=True,
            trim_start=trim_start,
            trim_end=trim_end,
        )
        if response.data is None:
            raise RuntimeError("Received malformed response (missing `data`) from trim_video_datum")
        return _utils.convert_to_dataclass(response.data, models.TrimEligibility)

    request = TrimVideoDatumRequest(
        datum_id=id,
        dataset_id=dataset_id or "",
        dry_run=False,
        trim_start=trim_start,
        trim_end=trim_end,
    )
    response = _apis.datasets_v3.datums_api._client.post(
        f"/datasets/v3/datums/{path_escape(id)}/video/trim",
        request,
    )
    data = response.get("data")
    if data is None:
        raise RuntimeError("Received malformed response (missing `data`) from trim_video_datum")
    return _utils.convert_to_dataclass(data, models.VideoTrimSubmission)


def get_video_trim_request(id: str) -> models.VideoTrimRequest:
    """Get a video trim request by id.

    Poll after `trim_video_datum` until `status` is `success` or `failed`.
    `failure_reason` classifies a failed trim without parsing `error_message`.

    :param id: Video trim request id
    :type id: str
    :return: Video trim request
    :rtype: models.VideoTrimRequest
    """
    response = _utils.call_api(
        _apis.datasets_v3.datums_api.get_video_trim_request,
        video_trim_request_id=id,
    )
    if not response.data:
        raise RuntimeError(
            "Received malformed response (missing `data`) from get_video_trim_request"
        )
    return _utils.convert_to_dataclass(response.data, models.VideoTrimRequest)

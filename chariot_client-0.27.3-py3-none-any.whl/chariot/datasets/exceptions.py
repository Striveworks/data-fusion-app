from chariot.datasets.models import UploadStatus

__all__ = [
    "UploadValidationError",
    "UploadIncompleteError",
    "UploadUnknownError",
]


class UploadValidationError(Exception):
    upload_id: str
    validation_errors: list[str]

    def __init__(self, upload_id: str, validation_errors: list[str]):
        super().__init__(f"Upload {upload_id} failed with validation errors: {validation_errors}")
        self.upload_id = upload_id
        self.validation_errors = validation_errors


class UploadIncompleteError(Exception):
    upload_id: str
    status: UploadStatus

    def __init__(self, upload_id: str, status: UploadStatus):
        super().__init__(f"Upload {upload_id} left in incomplete status {status}")
        self.upload_id = upload_id
        self.status = status


class UploadUnknownError(Exception):
    upload_id: str

    def __init__(self, upload_id: str):
        super().__init__(f"Upload {upload_id} failed")
        self.upload_id = upload_id

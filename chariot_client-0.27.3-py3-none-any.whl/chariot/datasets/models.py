"""Datasets models."""

import json
from dataclasses import dataclass
from datetime import datetime
from enum import Enum, StrEnum
from typing import Any

from chariot.datasets._utils import (
    Base,
    convert_to_dataclass,
    convert_to_dataclass_dict,
    convert_to_dataclass_list,
    convert_to_datetime,
    format_datetime_utc,
)
from chariot_api._proto.datasets_v3.shared_structs_gen import (
    Metadata as ProtoMetadata,
)
from chariot_api._proto.datasets_v3.shared_structs_gen import (
    MetadataFilter as ProtoMetadataFilter,
)
from chariot_api._proto.datasets_v3.shared_structs_gen import (
    RollingWindowConfig as ProtoRollingWindowConfig,
)
from chariot_api._proto.datasets_v3.shared_structs_gen import (
    TimeRange as ProtoTimeRange,
)
from chariot_api._proto.datasets_v3.shared_structs_gen import (
    TimestampRange as ProtoTimestampRange,
)
from chariot_api._proto.datasets_v3.shared_structs_gen import (
    VideoExtractionConfig as ProtoVideoExtractionConfig,
)

__all__ = [
    "SortDirection",
    "DatasetSortColumn",
    "DatumSortColumn",
    "SnapshotSortColumn",
    "ViewSortColumn",
    "UploadSortColumn",
    "TaskSortColumn",
    "TaskType",
    "ContextLabelFilter",
    "TaskTypeLabelFilter",
    "Range",
    "TimestampRange",
    "DatumFilter",
    "SplitName",
    "SplitConfig",
    "SplitAlgorithm",
    "SplitAlgorithmVideo",
    "RollingWindowType",
    "RollingWindowConfig",
    "VideoExtractionConfig",
    "VideoExtractionMode",
    "SnapshotStatus",
    "Snapshot",
    "GeoPoint",
    "Circle",
    "Rectangle",
    "Distribution",
    "DatumStatistics",
    "Metadata",
    "Datum",
    "DatumType",
    "Annotation",
    "Point",
    "BoundingBox",
    "OrientedBoundingBox",
    "TextClassification",
    "TokenClassification",
    "TextGeneration",
    "TextGenerationInput",
    "ApprovalStatus",
    "MigrationStatus",
    "DatasetType",
    "DatasetSummary",
    "Dataset",
    "DatasetStatistics",
    "DatasetTimelineEvent",
    "View",
    "FileType",
    "ManifestType",
    "FileFormat",
    "FileStatus",
    "JobType",
    "JobStatus",
    "UploadStatus",
    "UploadType",
    "File",
    "Job",
    "PresignedUrl",
    "Upload",
    "VideoSamplingType",
    "VideoSamplingOptions",
    "DatumTask",
    "DatasetConfig",
    "DatumConfig",
    "DatumTaskStatistics",
    "DatumTaskActivityCode",
    "DatumTaskActivity",
    "VideoReference",
    "TaskActivitySortColumn",
    "MetadataFilterOp",
    "MetadataFilter",
    "MetadataType",
    "ReviewConfig",
    "TrimIneligibleReason",
    "TrimEligibility",
    "VideoTrimRequest",
    "VideoTrimRequestStatus",
    "VideoTrimFailureReason",
    "VideoTrimSubmission",
    "TimeRange",
]


class SplitName(StrEnum):
    TRAIN = "train"
    VAL = "val"
    TEST = "test"


class SplitAlgorithm(Enum):
    RANDOM = "random"


class SplitAlgorithmVideo(Enum):
    """Split algorithm for video datums. Requires `rolling_window_config` when set to ROLLING_WINDOW."""

    ROLLING_WINDOW = "rolling_window"


class RollingWindowType(Enum):
    """Units for `window_size` and `gap_size`. DURATION is milliseconds; FRAME_COUNT is frames."""

    FRAME_COUNT = "frame_count"
    DURATION = "duration"


class VideoExtractionMode(Enum):
    """How a view materializes video: FRAMES extracts images at snapshot time; VIDEO keeps video datums."""

    FRAMES = "frames"
    VIDEO = "video"


class TrimIneligibleReason(StrEnum):
    """Reason a video datum is not eligible for trimming."""

    NOT_VIDEO = "not_video"
    ARCHIVED = "archived"
    HAS_EXTRACTED_FRAMES = "has_extracted_frames"
    USED_IN_SNAPSHOT = "used_in_snapshot"
    SNAPSHOT_IN_PROGRESS = "snapshot_in_progress"
    ANNOTATION_TASK_LOCKED = "annotation_task_locked"
    TRIM_IN_PROGRESS = "trim_in_progress"


class VideoTrimRequestStatus(StrEnum):
    """Status of a video trim request."""

    IN_PROGRESS = "in progress"
    SUCCESS = "success"
    FAILED = "failed"


class VideoTrimFailureReason(StrEnum):
    """Why a video trim request failed."""

    SERVICE_UNAVAILABLE = "video_service_unavailable"
    CLIP_FAILED = "clip_failed"
    INVALID_TRIM_WINDOW = "invalid_trim_window"
    SOURCE_VIDEO_UNAVAILABLE = "source_video_unavailable"
    NOT_PERMITTED = "not_permitted"
    INTERRUPTED = "interrupted"
    DOWNLOAD_FAILED = "download_failed"
    INTERNAL = "internal"


class MigrationStatus(Enum):
    """Status of a dataset migration."""

    IDENTIFIED = "identified"
    PLANNED = "planned"
    DOWNLOADING = "downloading"
    UPLOADING_HORIZONTALS = "uploading_horizontals"
    UPLOADING_VERTICAL = "uploading_vertical"
    CLEANUP = "cleanup"
    COMPLETE = "complete"
    EXCEPTION = "exception"
    ERROR = "error"


class DatasetType(Enum):
    IMAGE = "image"
    TEXT = "text"


class DatumType(Enum):
    """Type of datum."""

    IMAGE = "image"
    TEXT = "text"
    VIDEO = "video"


class SortDirection(Enum):
    ASCENDING = "asc"
    DESCENDING = "desc"


class DatasetSortColumn(Enum):
    ID = "id"
    NAME = "name"
    CREATION_TIMESTAMP = "creation timestamp"
    UPDATED_TIMESTAMP = "updated timestamp"
    DATUM_COUNT = "datum count"
    SIZE = "size"


class ViewSortColumn(Enum):
    NAME = "name"
    CREATION_TIMESTAMP = "creation timestamp"
    SAMPLE_COUNT = "sample count"
    ID = "id"


class DatumSortColumn(Enum):
    ID = "id"
    CREATION_TIMESTAMP = "creation timestamp"
    METADATA = "metadata"


class SnapshotSortColumn(Enum):
    NAME = "name"
    TIMESTAMP = "timestamp"
    CREATION_TIMESTAMP = "creation timestamp"
    ID = "id"


class UploadSortColumn(Enum):
    TYPE = "type"
    STATUS = "status"
    CREATION_TIMESTAMP = "creation timestamp"


class TaskSortColumn(Enum):
    NAME = "name"
    ID = "id"
    CREATION_TIMESTAMP = "creation timestamp"
    UPDATED_AT = "updated at"


class TaskActivitySortColumn(Enum):
    ACTIVITY_START_TIME = "activity start timestamp"
    ACTIVITY_END_TIME = "activity end timestamp"


class TaskType(StrEnum):
    IMAGE_CLASSIFICATION = "Image Classification"
    OBJECT_DETECTION = "Object Detection"
    ORIENTED_OBJECT_DETECTION = "Oriented Object Detection"
    IMAGE_SEGMENTATION = "Image Segmentation"
    IMAGE_TEXT_TO_TEXT = "Image Text to Text"  # only for filtering datasets or datums
    TOKEN_CLASSIFICATION = "Token Classification"
    TEXT_CLASSIFICATION = "Text Classification"
    TEXT_GENERATION = "Text Generation"


class JobType(Enum):
    DELETE_DATASET = "delete_dataset"
    UPLOAD = "upload"
    DELETE_UPLOAD = "delete_upload"
    FILE = "file"
    DELETE_FILE = "delete_file"
    SNAPSHOT = "snapshot"


class JobStatus(Enum):
    READY = "ready"
    IN_PROGRESS = "in progress"
    WAITING = "waiting"


class FileType(Enum):
    ARCHIVE = "archive"
    MANIFEST = "manifest"


class ManifestType(Enum):
    ANNOTATED = "annotated"
    ALL = "all"


class FileFormat(Enum):
    TGZ = "tgz"
    ZIP = "zip"
    GZ = "gz"


class FileStatus(Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETE = "complete"
    ERROR = "error"
    ARCHIVED = "archived"


class UploadType(Enum):
    ARCHIVE = "archive"
    VIDEO_EXTRACTION = "video_extraction"
    VIDEO_REFERENCE = "video_reference"
    DATUM = "datum"
    INFERENCE = "inference"
    VIDEO = "video"
    ANNOTATION = "annotation"
    RAIC = "raic"


class UploadStatus(Enum):
    CREATED = "created"
    PROCESSING = "processing"
    COMPLETE = "complete"
    ERROR = "error"
    CLEANUP = "cleanup"


class ApprovalStatus(StrEnum):
    """Annotation approval status."""

    NOT_REVIEWED = ""
    NEEDS_REVIEW = "needs_review"
    VERIFIED = "verified"
    REJECTED = "rejected"


class DatumTaskActivityCode(StrEnum):
    LOCKED = "locked"
    VIEWED = "viewed"
    SKIPPED = "skipped"


class MetadataFilterOp(StrEnum):
    EQUAL = "eq"
    NOT_EQUAL = "neq"
    GREATER_THAN = "gt"
    GREATER_THAN_OR_EQUAL = "gte"
    LESS_THAN = "lt"
    LESS_THAN_OR_EQUAL = "lte"
    IN = "in"
    FULL_TEXT = "full_text"


class MetadataType(StrEnum):
    BOOLEAN = "boolean"
    NUMERIC = "numeric"
    TEXT = "text"
    TIMESTAMP = "timestamp"


@dataclass
class GeoPoint(Base):
    latitude: float
    longitude: float


@dataclass
class Circle(Base):
    center: GeoPoint
    radius: float


@dataclass
class Rectangle(Base):
    p1: GeoPoint
    p2: GeoPoint


@dataclass
class Distribution(Base):
    context: str | None
    distribution: dict[str, int]


@dataclass
class Point(Base):
    x: float
    y: float


@dataclass
class BoundingBox(Base):
    xmin: float
    xmax: float
    ymin: float
    ymax: float


@dataclass
class OrientedBoundingBox(Base):
    cx: float
    cy: float
    w: float
    h: float
    r: float


@dataclass
class TextClassification(Base):
    context: str | None
    label: str


@dataclass
class TokenClassification(Base):
    label: str
    start_position: int
    end_position: int


@dataclass
class TextGeneration(Base):
    context: str | None
    context_presigned_url: str | None
    generated_text: str | None
    generated_text_presigned_url: str | None


@dataclass
class TextGenerationInput(Base):
    context: str | None
    generated_text: str | None


@dataclass
class DatumStatistics(Base):
    """Counts for datums matching a filter. `video_count` is native video datums; `frame_count` is extracted frames."""

    datum_count: int
    video_count: int
    frame_count: int
    available_datum_count: int
    new_datum_count: int
    new_frame_count: int
    skipped_frame_count: int
    annotation_count: int
    class_label_count: int
    bounding_box_count: int
    oriented_bounding_box_count: int
    contour_count: int
    text_classification_count: int
    token_classification_count: int
    text_generation_count: int
    class_label_distribution: dict[str, int] | None
    text_classification_distribution: list[Distribution] | None
    token_classification_distribution: dict[str, int] | None
    text_generation_distribution: dict[str, int] | None
    annotation_count_by_approval_status: dict[str, int] | None
    frame_count_by_video: dict[str, int] | None
    new_frame_count_by_video: dict[str, int] | None
    skipped_frame_count_by_video: dict[str, int] | None

    def __post_init__(self):
        super().__post_init__()
        if self.text_classification_distribution is not None:
            self.text_classification_distribution = convert_to_dataclass_list(
                self.text_classification_distribution, Distribution
            )


@dataclass
class DatasetSummary(DatumStatistics):
    total_datum_size: int
    largest_datum_size: int
    total_annotation_size: int
    largest_annotation_size: int
    unannotated_datum_count: int


@dataclass
class Metadata(Base):
    """Dataset metadata."""

    readme: str | None

    def _to_post_body(self) -> ProtoMetadata | None:
        if self.readme is None:
            return None
        else:
            return ProtoMetadata(readme=self.readme)


@dataclass
class Dataset(Base):
    id: str
    name: str
    type: DatasetType
    project_id: str
    is_test: bool
    delete_lock: bool
    created_at: datetime
    created_by: str
    updated_at: datetime
    updated_by: str
    description: str | None = None
    archived_at: datetime | None = None
    archived_by: str | None = None
    summary: DatasetSummary | None = None
    migration_status: MigrationStatus | None = None
    metadata: Metadata | None = None
    source_dataset_ids: list[str] | None = None
    target_dataset_ids: list[str] | None = None
    source_count: int | None = None
    target_count: int | None = None

    def __post_init__(self):
        super().__post_init__()
        self.type = DatasetType(self.type)
        self.created_at = convert_to_datetime(self.created_at)
        self.updated_at = convert_to_datetime(self.updated_at)
        self.archived_at = convert_to_datetime(self.archived_at)
        if self.summary is not None:
            self.summary = convert_to_dataclass(self.summary, DatasetSummary)
        if self.migration_status is not None:
            self.migration_status = MigrationStatus(self.migration_status)
        if self.metadata is not None:
            self.metadata = convert_to_dataclass(self.metadata, Metadata)


@dataclass
class Annotation(Base):
    id: str
    datum_id: str | None
    upload_id: str | None
    task_type: TaskType
    class_label: str | None
    contour: list[list[Point]] | None
    bbox: BoundingBox | None
    oriented_bbox: OrientedBoundingBox | None
    text_classification: TextClassification | None
    token_classification: TokenClassification | None
    text_generation: TextGeneration | None
    created_at: datetime
    updated_at: datetime
    updated_by: str
    archived_at: datetime | None
    archived_by: str | None
    archived_upload_id: str | None
    size: int | None
    approval_status: str | None
    metadata: dict[str, Any] | None = None
    previous_annotation_id: str | None = None
    datum_annotation_updated_at: str | None = None
    prev_datum_annotation_updated_at: str | None = None
    # Temporal offset from the start of a video datum, in nanoseconds.
    frame_at: int | None = None

    def __post_init__(self):
        super().__post_init__()
        self.task_type = TaskType(self.task_type)
        if self.contour is not None:
            self.contour = [convert_to_dataclass_list(points, Point) for points in self.contour]
        if self.bbox is not None:
            self.bbox = convert_to_dataclass(self.bbox, BoundingBox)
        if self.oriented_bbox is not None:
            self.oriented_bbox = convert_to_dataclass(self.oriented_bbox, OrientedBoundingBox)
        if self.text_classification is not None:
            self.text_classification = convert_to_dataclass(
                self.text_classification, TextClassification
            )
        if self.token_classification is not None:
            self.token_classification = convert_to_dataclass(
                self.token_classification, TokenClassification
            )
        if self.text_generation is not None:
            self.text_generation = convert_to_dataclass(self.text_generation, TextGeneration)
        self.created_at = convert_to_datetime(self.created_at)
        self.updated_at = convert_to_datetime(self.updated_at)
        if self.archived_at is not None:
            self.archived_at = convert_to_datetime(self.archived_at)


@dataclass
class DatumTaskActivity(Base):
    dataset_id: str | None
    datum_id: str | None
    task_id: str
    user_id: str
    activity: DatumTaskActivityCode | None
    activity_start_time: datetime | None
    activity_end_time: datetime | None

    def __post_init__(self):
        super().__post_init__()
        if self.activity is not None:
            self.activity = DatumTaskActivityCode(self.activity)
        if self.activity_start_time is not None:
            self.activity_start_time = convert_to_datetime(self.activity_start_time)
        if self.activity_end_time is not None:
            self.activity_end_time = convert_to_datetime(self.activity_end_time)


@dataclass
class VideoStreamMetadata(Base):
    codec_type: str | None = None
    index: int | None = None
    tags: dict[str, str] | None = None


@dataclass
class VideoMetadata(Base):
    streams: list[VideoStreamMetadata] | None
    tags: dict[str, str] | None

    def __post_init__(self):
        super().__post_init__()
        if self.streams is not None:
            self.streams = convert_to_dataclass_list(self.streams, VideoStreamMetadata)


@dataclass
class VideoReference(Base):
    """Metadata for a video file linked from a video datum (`datum.video_reference`)."""

    id: str | None = None
    dataset_id: str | None = None
    datum_id: str | None = None
    project_id: str | None = None
    video_id: str | None = None
    video_request_id: str | None = None
    source_fps: float | None = None
    duration_ms: int | None = None
    height_pixels: int | None = None
    width_pixels: int | None = None
    codec: str | None = None
    bitrate: int | None = None
    has_klv: bool | None = None
    playback_origin: int | None = None
    created_at: datetime | None = None
    metadata: dict[str, Any] | None = None
    thumbnail: str | None = None
    url: str | None = None
    media_created_at: str | None = None
    source_metadata: VideoMetadata | None = None
    imported_from_video_request_id: str | None = None

    def __post_init__(self):
        super().__post_init__()
        if self.created_at is not None:
            self.created_at = convert_to_datetime(self.created_at)
        if self.source_metadata is not None:
            self.source_metadata = convert_to_dataclass(self.source_metadata, VideoMetadata)


@dataclass
class Datum(Base):
    id: str
    coordinates: GeoPoint | None
    timestamp: datetime | None
    metadata: dict[str, Any] | None
    created_at: datetime
    upload_id: str
    archived_at: datetime | None
    archived_by: str | None
    dataset: Dataset | None
    annotations: list[Annotation] | None
    presigned_url: str
    signature: str
    size: int
    split: SplitName | None
    datum_annotation_updated_at: str | None = None
    task_lock_details: DatumTaskActivity | None = None
    trim_request_id: str | None = None
    preview_presigned_urls: list[str] | None = None
    datum_type: DatumType | None = None
    video_reference: VideoReference | None = None
    parent_datum_id: str | None = None
    frame_pts: int | None = None
    parent_annotations: list[Annotation] | None = None

    def __post_init__(self):
        super().__post_init__()
        if self.coordinates is not None:
            self.coordinates = convert_to_dataclass(self.coordinates, GeoPoint)
        if self.timestamp is not None:
            self.timestamp = convert_to_datetime(self.timestamp)
        self.created_at = convert_to_datetime(self.created_at)
        if self.archived_at is not None:
            self.archived_at = convert_to_datetime(self.archived_at)
        if self.dataset is not None:
            self.dataset = convert_to_dataclass(self.dataset, Dataset)
        if self.annotations is not None:
            self.annotations = convert_to_dataclass_list(self.annotations, Annotation)
        if self.split is not None:
            self.split = SplitName(self.split)
        if self.task_lock_details is not None:
            self.task_lock_details = convert_to_dataclass(self.task_lock_details, DatumTaskActivity)
        if self.datum_type == "":
            self.datum_type = None
        if self.datum_type is not None:
            self.datum_type = DatumType(self.datum_type)
        if self.video_reference is not None:
            self.video_reference = convert_to_dataclass(self.video_reference, VideoReference)
        if self.parent_annotations is not None:
            self.parent_annotations = convert_to_dataclass_list(self.parent_annotations, Annotation)


@dataclass
class ContextLabelFilter(Base):
    context: str | None = None
    labels: list[str] | None = None


@dataclass
class TaskTypeLabelFilter(Base):
    task_type: TaskType
    labels: list[str] | None = None
    contexts: list[str | None] | None = None
    context_labels: list[ContextLabelFilter] | None = None

    def __post_init__(self):
        super().__post_init__()
        self.task_type = TaskType(self.task_type)
        if self.context_labels is not None:
            self.context_labels = convert_to_dataclass_list(self.context_labels, ContextLabelFilter)


@dataclass
class Range(Base):
    """Inclusive numeric filter. Set min, max, or both. Equality is min == max."""

    min: float | None = None
    max: float | None = None

    def _to_post_body(self) -> dict[str, float]:
        body: dict[str, float] = {}
        if self.min is not None:
            body["min"] = self.min
        if self.max is not None:
            body["max"] = self.max
        return body


@dataclass
class TimestampRange(Base):
    start: datetime | None
    end: datetime | None

    def __post_init__(self):
        super().__post_init__()
        if self.start is not None:
            self.start = convert_to_datetime(self.start)
        if self.end is not None:
            self.end = convert_to_datetime(self.end)

    def _to_query_param(self) -> str:
        return f"({format_datetime_utc(self.start) if self.start else ''},{format_datetime_utc(self.end) if self.end else ''})"

    def _to_post_body(self) -> ProtoTimestampRange | None:
        return ProtoTimestampRange(
            start=format_datetime_utc(self.start) if self.start else "",
            end=format_datetime_utc(self.end) if self.end else "",
        )


@dataclass
class MetadataFilter(Base):
    key_path: list[str] | None = None
    value: str | list[str] | None = None
    operation: MetadataFilterOp | None = None

    def __post_init__(self):
        super().__post_init__()
        self.operation = MetadataFilterOp(self.operation)

    def _to_post_body(self) -> ProtoMetadataFilter | None:
        if self.value is None:
            value_str = ""
        elif isinstance(self.value, list):
            value_str = json.dumps(self.value)
        else:
            value_str = self.value

        return ProtoMetadataFilter(
            key_path=self.key_path if self.key_path else [],
            value=value_str,
            operation=self.operation.value if self.operation else "eq",
        )


@dataclass
class DatumFilter(Base):
    task_type_label_filters: list[TaskTypeLabelFilter] | None
    gps_coordinates_circle: Circle | None
    gps_coordinates_rectangle: Rectangle | None
    gps_coordinates_polygon: list[GeoPoint] | None
    capture_timestamp_range: TimestampRange | None
    metadata: dict[str, str] | None
    metadata_filters: list[MetadataFilter] | None
    asof_timestamp: datetime | None
    unannotated: bool | None
    datum_ids: list[str] | None
    approval_status: list[ApprovalStatus] | None
    annotation_metadata: dict[str, str] | None
    datum_type: DatumType | None
    parent_datum_id: str | None

    def __post_init__(self):
        super().__post_init__()
        if self.task_type_label_filters is not None:
            self.task_type_label_filters = convert_to_dataclass_list(
                self.task_type_label_filters, TaskTypeLabelFilter
            )
        if self.gps_coordinates_circle is not None:
            self.gps_coordinates_circle = convert_to_dataclass(self.gps_coordinates_circle, Circle)
        if self.gps_coordinates_rectangle is not None:
            self.gps_coordinates_rectangle = convert_to_dataclass(
                self.gps_coordinates_rectangle, Rectangle
            )
        if self.gps_coordinates_polygon is not None:
            self.gps_coordinates_polygon = convert_to_dataclass_list(
                self.gps_coordinates_polygon, GeoPoint
            )
        if self.capture_timestamp_range is not None:
            self.capture_timestamp_range = convert_to_dataclass(
                self.capture_timestamp_range, TimestampRange
            )
        if self.metadata_filters is not None:
            self.metadata_filters = convert_to_dataclass_list(self.metadata_filters, MetadataFilter)
        if self.asof_timestamp is not None:
            self.asof_timestamp = convert_to_datetime(self.asof_timestamp)


@dataclass
class DatumConfig(DatumFilter):
    @classmethod
    def from_partial(cls, **kwargs):
        fields = {f.name for f in cls.__dataclass_fields__.values()}
        return cls(**{k: kwargs.get(k, None) for k in fields})


@dataclass
class RollingWindowConfig(Base):
    """Rolling-window parameters for video splits.

    `window_size` must be greater than 0. `gap_size` must be non-negative.
    `gap_size` times the number of splits must be less than `window_size`.
    When `window_type` is DURATION, sizes are milliseconds.
    """

    window_type: RollingWindowType
    window_size: int
    gap_size: int = 0

    def __post_init__(self):
        """Run dataclass post-init, then normalize `window_type` to `RollingWindowType`."""
        super().__post_init__()
        if isinstance(self.window_type, str):
            self.window_type = RollingWindowType(self.window_type)

    def _to_post_body(self) -> ProtoRollingWindowConfig | None:
        return ProtoRollingWindowConfig(
            window_type=self.window_type.value,
            window_size=self.window_size,
            gap_size=self.gap_size,
        )


@dataclass
class SplitConfig(Base):
    """View split options.

    `split_algorithm` applies to image and text datums (default random).
    `split_algorithm_video` applies to video datums and requires `rolling_window_config`
    when set to rolling_window. Empty `splits` defaults to train=1.0 on the API.
    """

    sample_count: int | None
    split_algorithm: SplitAlgorithm | None
    apply_default_split: bool | None
    splits: dict[SplitName, float] | None
    split_algorithm_video: SplitAlgorithmVideo | None
    rolling_window_config: RollingWindowConfig | None

    def __post_init__(self):
        """Normalize `split_algorithm`, `split_algorithm_video`, and `rolling_window_config` from API values into enums/dataclasses."""
        super().__post_init__()
        if isinstance(self.split_algorithm, str):
            self.split_algorithm = SplitAlgorithm(self.split_algorithm)
        if isinstance(self.split_algorithm_video, str):
            self.split_algorithm_video = SplitAlgorithmVideo(self.split_algorithm_video)
        if self.rolling_window_config is not None and not isinstance(
            self.rolling_window_config, RollingWindowConfig
        ):
            self.rolling_window_config = convert_to_dataclass(
                self.rolling_window_config, RollingWindowConfig
            )


@dataclass
class TimeRange(Base):
    """Inclusive video interval in nanoseconds from the start of the video. Ranges must be disjoint."""

    start: int | None
    end: int | None

    def _to_post_body(self) -> ProtoTimeRange | None:
        if self.start is None and self.end is None:
            return None
        return ProtoTimeRange(
            start=self.start if self.start is not None else 0,
            end=self.end if self.end is not None else 0,
        )


@dataclass
class VideoExtractionConfig(Base):
    """How a view turns video datums into snapshot contents.

    `extraction_mode` defaults to frames. `frames_per_second`, `time_ranges`,
    `include_klv`, and `annotated_only` are valid only for frames mode.
    `annotated_only` cannot be combined with `frames_per_second`.
    """

    extraction_mode: VideoExtractionMode | None = None
    frames_per_second: float | None = None
    time_ranges: list[TimeRange] | None = None
    include_klv: bool | None = None
    annotated_only: bool | None = None

    def __post_init__(self):
        """Normalize `extraction_mode` and `time_ranges` from API values into enums/dataclasses."""
        super().__post_init__()
        if self.extraction_mode is not None and isinstance(self.extraction_mode, str):
            self.extraction_mode = VideoExtractionMode(self.extraction_mode)
        if self.time_ranges is not None:
            self.time_ranges = [convert_to_dataclass(tr, TimeRange) for tr in self.time_ranges]

    def _to_post_body(self) -> ProtoVideoExtractionConfig | None:
        d: dict[str, Any] = {}
        if self.extraction_mode is not None:
            d["extraction_mode"] = self.extraction_mode.value
        if self.frames_per_second is not None:
            d["frames_per_second"] = self.frames_per_second
        if self.time_ranges is not None:
            d["time_ranges"] = [tr._to_post_body() for tr in self.time_ranges]
        if self.include_klv is not None:
            d["include_klv"] = self.include_klv
        if self.annotated_only is not None:
            d["annotated_only"] = self.annotated_only
        return ProtoVideoExtractionConfig(**d)


@dataclass
class TrimEligibility(Base):
    """Eligibility for trimming a video datum."""

    reason: TrimIneligibleReason | None = None

    @property
    def eligible(self) -> bool:
        return self.reason is None

    def __post_init__(self):
        """Normalize `reason` from API value into enum."""
        super().__post_init__()
        if self.reason is not None:
            self.reason = TrimIneligibleReason(self.reason)


@dataclass
class VideoTrimRequest(Base):
    """A request to trim a video datum."""

    id: str
    datum_id: str
    trim_start: int
    trim_end: int
    source_video_id: str
    status: VideoTrimRequestStatus
    created_by: str
    created_at: datetime
    updated_at: datetime
    dataset: Dataset | None = None
    trimmed_video_id: str | None = None
    error_message: str | None = None
    failure_reason: VideoTrimFailureReason | None = None
    completed_at: datetime | None = None

    def __post_init__(self):
        """Normalize API values into enums/dataclasses."""
        super().__post_init__()
        self.status = VideoTrimRequestStatus(self.status)
        self.created_at = convert_to_datetime(self.created_at)
        self.updated_at = convert_to_datetime(self.updated_at)
        if self.completed_at is not None:
            self.completed_at = convert_to_datetime(self.completed_at)
        if self.dataset is not None:
            self.dataset = convert_to_dataclass(self.dataset, Dataset)
        if self.failure_reason is not None:
            self.failure_reason = VideoTrimFailureReason(self.failure_reason)


@dataclass
class VideoTrimSubmission(Base):
    """A submission to trim a video datum."""

    trim_request_id: str
    job_id: str
    datum_id: str
    source_video_id: str
    trim_start: int
    trim_end: int


@dataclass
class View(SplitConfig, DatumFilter):
    """Saved datum filter plus split and optional `video_extraction_config`."""

    id: str
    name: str
    snapshot_count: int | None
    created_at: datetime
    created_by: str
    updated_at: datetime
    updated_by: str
    archived_at: datetime | None = None
    archived_by: str | None = None
    dataset: Dataset | None = None
    video_extraction_config: VideoExtractionConfig | None = None

    def __post_init__(self):
        super().__post_init__()
        self.created_at = convert_to_datetime(self.created_at)
        self.updated_at = convert_to_datetime(self.updated_at)
        if self.archived_at is not None:
            self.archived_at = convert_to_datetime(self.archived_at)
        if self.dataset is not None:
            self.dataset = convert_to_dataclass(self.dataset, Dataset)
        if self.video_extraction_config is not None:
            self.video_extraction_config = convert_to_dataclass(
                self.video_extraction_config, VideoExtractionConfig
            )


class SnapshotStatus(Enum):
    PENDING = "pending"
    COMPLETE = "complete"
    ERROR = "error"
    PREVIEW = "preview"


class SnapshotProcessingMsgType(Enum):
    VALIDATION_ERROR = "validation error"
    WARNING = "warning"
    INTERNAL_ERROR = "internal error"


class SnapshotProcessingMsgCode(Enum):
    VIEW_FPS_EXCEEDS_SOURCE_FPS = "view_fps_exceeds_source_fps"
    NO_FRAMES_EXTRACTED = "no_frames_extracted"
    SKIPPED_ANNOTATION = "skipped_annotation"
    UNKNOWN = "unknown"


@dataclass
class SnapshotProcessingMsg(Base):
    type: SnapshotProcessingMsgType
    code: SnapshotProcessingMsgCode
    message: str
    data: Any | None


@dataclass
class Snapshot(Base):
    id: str
    view: View
    name: str
    timestamp: datetime
    summary: DatasetSummary | None
    split_summaries: dict[SplitName, DatasetSummary] | None
    status: SnapshotStatus
    created_at: datetime | None
    created_by: str
    updated_at: datetime | None
    progress_message: str | None
    processing_messages: list[SnapshotProcessingMsg] | None

    def __post_init__(self):
        self.view = convert_to_dataclass(self.view, View)
        if self.timestamp is not None:
            self.timestamp = convert_to_datetime(self.timestamp)
        if self.summary is not None:
            self.summary = convert_to_dataclass(self.summary, DatasetSummary)
        if self.split_summaries is not None:
            self.split_summaries = dict(
                (SplitName(k), convert_to_dataclass(v, DatasetSummary))
                for k, v in self.split_summaries.items()
            )
        self.status = SnapshotStatus(self.status)
        if self.created_at is not None:
            self.created_at = convert_to_datetime(self.created_at)
        if self.updated_at is not None:
            self.updated_at = convert_to_datetime(self.updated_at)
        if self.processing_messages is not None:
            self.processing_messages = convert_to_dataclass_list(
                self.processing_messages, SnapshotProcessingMsg
            )


@dataclass
class DatasetStatistics(DatumStatistics):
    dataset_count: int
    total_datum_size: int
    largest_datum_size: int
    total_annotation_size: int
    largest_annotation_size: int
    unannotated_datum_count: int


@dataclass
class DatasetTimelineEvent(Base):
    event_timestamp: datetime
    dataset_id: str
    event_associated_record_id: str | None
    event_operation: str | None
    event_user_id: str | None
    datums_created: int | None
    datums_deleted: str | None
    datums_modified: str | None
    annotations_created: str | None
    annotations_deleted: str | None
    annotations_modified: str | None
    snapshots: list[Snapshot] | None
    event_group_num_timestamps: int
    event_group_num_users: int
    event_group_start_timestamp: datetime
    event_group_description: str
    event_associated_task_id: str | None

    def __post_init__(self):
        super().__post_init__()
        self.event_timestamp = convert_to_datetime(self.event_timestamp)
        self.event_group_start_timestamp = convert_to_datetime(self.event_group_start_timestamp)
        if self.snapshots is not None:
            self.snapshots = convert_to_dataclass_list(self.snapshots, Snapshot)


@dataclass
class Job(Base):
    id: str
    type: JobType
    status: JobStatus
    progress_message: str | None
    dataset: Dataset | None
    # I don't _think_ there's anywhere in our api we would
    # actually return an upload and adding this would cause
    # a cyclical reference
    # upload: Optional[Upload]
    upload: Any | None
    file: Any | None
    view: View | None
    execution_count: int
    created_at: datetime
    updated_at: datetime
    start_after: datetime | None
    schedule_cron: str | None
    datum_id: str | None = None
    trim_request: VideoTrimRequest | None = None

    def __post_init__(self):
        """Normalize API values into enums/dataclasses."""
        super().__post_init__()
        self.type = JobType(self.type)
        self.status = JobStatus(self.status)
        if self.dataset is not None:
            self.dataset = convert_to_dataclass(self.dataset, Dataset)
        if self.file is not None:
            self.file = convert_to_dataclass(self.file, File)
        if self.view is not None:
            self.view = convert_to_dataclass(self.view, View)
        self.created_at = convert_to_datetime(self.created_at)
        self.updated_at = convert_to_datetime(self.updated_at)
        if self.start_after is not None:
            self.start_after = convert_to_datetime(self.start_after)
        if self.trim_request is not None:
            self.trim_request = convert_to_dataclass(self.trim_request, VideoTrimRequest)


@dataclass
class File(Base):
    id: str
    dataset: Dataset | None
    dataset_timestamp: datetime | None
    snapshot: Snapshot | None
    split: SplitName | None
    type: FileType
    manifest_type: ManifestType | None
    file_format: FileFormat
    presigned_url: str | None
    created_at: datetime
    created_by: str
    updated_at: datetime
    updated_by: str
    archived_at: datetime | None
    expires_at: datetime | None
    job: Job | None
    status: FileStatus | None  # TODO FEED-1156 change to required field after 0.9.0 patch

    def __post_init__(self):
        super().__post_init__()
        if self.dataset is not None:
            self.dataset = convert_to_dataclass(self.dataset, Dataset)
        if self.dataset_timestamp is not None:
            self.dataset_timestamp = convert_to_datetime(self.dataset_timestamp)
        if self.snapshot is not None:
            self.snapshot = convert_to_dataclass(self.snapshot, Snapshot)
        if self.split is not None:
            self.split = SplitName(self.split)
        self.type = FileType(self.type)
        if self.manifest_type is not None:
            self.manifest_type = ManifestType(self.manifest_type)
        self.file_format = FileFormat(self.file_format)
        self.created_at = convert_to_datetime(self.created_at)
        self.updated_at = convert_to_datetime(self.updated_at)
        if self.job is not None:
            self.job = convert_to_dataclass(self.job, Job)
        if self.status is not None:  # TODO FEED-1156 change to required field after 0.9.0 patch
            self.status = FileStatus(self.status)


@dataclass
class PresignedUrl(Base):
    method: str
    url: str


class VideoSamplingType(str, Enum):
    RATE = "rate"
    RATIO = "ratio"
    NONE = "none"


@dataclass
class VideoSamplingOptions:
    sampling_type: VideoSamplingType
    sampling_value: int
    deinterlace: bool


@dataclass
class Upload(Base):
    id: str
    job: Job | None
    type: UploadType
    is_gzipped: bool | None
    split: SplitName | None
    status: UploadStatus
    name: str | None
    filename: str | None
    size: int | None
    delete_source: bool
    max_validation_errors: int
    image_validation: bool
    validation_errors: list[str] | None
    created_at: datetime
    created_by: str
    updated_at: datetime
    completed_by: str
    data_created_at: datetime | None
    presigned_urls: list[PresignedUrl] | None
    source_urls: list[str] | None
    datum_metadata: list[dict[str, Any]] | None
    dataset: Dataset | None
    video_options: VideoSamplingOptions | None

    def __post_init__(self):
        super().__post_init__()
        if self.job is not None:
            self.job = convert_to_dataclass(self.job, Job)
        self.type = UploadType(self.type)
        if self.split is not None:
            self.split = SplitName(self.split)
        self.status = UploadStatus(self.status)
        self.created_at = convert_to_datetime(self.created_at)
        self.updated_at = convert_to_datetime(self.updated_at)
        if self.data_created_at is not None:
            self.data_created_at = convert_to_datetime(self.data_created_at)
        if self.presigned_urls is not None:
            self.presigned_urls = convert_to_dataclass_list(self.presigned_urls, PresignedUrl)
        if self.dataset is not None:
            self.dataset = convert_to_dataclass(self.dataset, Dataset)
        if self.video_options is not None:
            self.video_options = convert_to_dataclass(self.video_options, VideoSamplingOptions)


@dataclass
class DatasetConfig(Base):
    dataset_ids: list[str] | None = None
    dataset_names: list[str] | None = None
    exact_name_match: bool | None = None
    limit_to_write_access: bool | None = None
    dataset_type: str | None = None


@dataclass
class ReviewConfig(Base):
    """Review config which acts at the datum level."""

    task_type_label_filters: list[TaskTypeLabelFilter] | None = None
    approval_status: list[ApprovalStatus] | None = None
    annotation_metadata: dict[str, str] | None = None
    unannotated: bool | None = None


@dataclass
class DatumTaskStatistics(DatumStatistics):
    """Statistics for a DatumTask."""

    task_count: int
    dataset_count: int
    user_count: int
    datum_count_by_user_id: dict[str, int] | None
    activity_count: int
    datum_count_by_activity_status: dict[str, int] | None


@dataclass
class DatumTask(Base):
    id: str
    name: str
    description: str | None
    created_at: datetime
    updated_at: datetime
    archived_at: datetime | None
    created_by: str
    updated_by: str
    archived_by: str | None
    project_id: str
    dataset_config: DatasetConfig | None
    datum_config: DatumConfig | None
    review_config: ReviewConfig | None
    statistics: DatumTaskStatistics | None

    def __post_init__(self):
        super().__post_init__()
        self.created_at = convert_to_datetime(self.created_at)
        self.updated_at = convert_to_datetime(self.updated_at)
        if self.archived_at is not None:
            self.archived_at = convert_to_datetime(self.archived_at)
        if self.dataset_config is not None:
            self.dataset_config = convert_to_dataclass(self.dataset_config, DatasetConfig)
        if self.datum_config is not None:
            self.datum_config = convert_to_dataclass(self.datum_config, DatumConfig)
        if self.review_config is not None:
            self.review_config = convert_to_dataclass(self.review_config, ReviewConfig)
        if self.statistics is not None:
            self.statistics = convert_to_dataclass(self.statistics, DatumTaskStatistics)


@dataclass
class AnnotationHistoryEvent(Base):
    annotation_id: str
    datum_id: str
    dataset_id: str
    operation: str
    user_id: str
    annotation_source: str
    approval_status: str
    timestamp: datetime
    previous_annotation_id: str | None = None
    task_id: str | None = None
    upload_id: str | None = None
    metadata: dict[str, Any] | None = None

    def __post_init__(self):
        super().__post_init__()
        if self.timestamp is not None:
            self.timestamp = convert_to_datetime(self.timestamp)


@dataclass
class AnnotationHistoryDetails(Base):
    annotation_id: str
    events: list[AnnotationHistoryEvent]
    annotations: dict[str, Annotation]
    datum: Datum
    tasks: dict[str, DatumTask] | None = None
    uploads: dict[str, Upload] | None = None

    def __post_init__(self):
        super().__post_init__()
        self.events = convert_to_dataclass_list(self.events, AnnotationHistoryEvent)
        self.annotations = convert_to_dataclass_dict(self.annotations, Annotation)
        self.datum = convert_to_dataclass(self.datum, Datum)
        if self.tasks is not None:
            self.tasks = convert_to_dataclass_dict(self.tasks, DatumTask)
        if self.uploads is not None:
            self.uploads = convert_to_dataclass_dict(self.uploads, Upload)

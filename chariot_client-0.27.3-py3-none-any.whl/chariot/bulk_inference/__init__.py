from .job import *
from .models import *

# data_source for inference store inferences created from bulk inference, used in `data_source_filter`
DATA_SOURCE = "bulk-inference"

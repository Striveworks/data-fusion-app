def convert_to_dataclass(obj, c):
    if isinstance(obj, c):
        return obj
    return c(**obj)

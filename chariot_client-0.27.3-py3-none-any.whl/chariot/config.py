from chariot import __version__ as __version__
from chariot_api import Settings, getLogger
from chariot_api import chariot_dir as chariot_dir
from chariot_api.builder import get_bearer_token as gbt

log = getLogger(__name__)
settings = Settings()


def reload():
    """Reload Chariot settings."""
    new_settings = Settings()
    for key in Settings.model_fields.keys():
        if key.startswith("_"):
            continue
        value = getattr(new_settings, key)
        if callable(value):
            continue
        setattr(settings, key, value)


def get_bearer_token(refresh: bool = False):
    return gbt(settings, refresh=refresh)

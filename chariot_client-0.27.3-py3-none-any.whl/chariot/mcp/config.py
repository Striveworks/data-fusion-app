"""Configuration for MCP."""

from typing import Literal, Self

from pydantic import BaseModel, Field, model_validator

from chariot.mcp.enum import ChariotMCPPackage


class SDKConfig(BaseModel):
    include_packages: list[ChariotMCPPackage] | None = None
    exclude_packages: list[ChariotMCPPackage] | None = None
    disable_mutating_tools: bool = False
    disable_file_based_tools: bool = False
    soft_failures_enabled: bool = False

    @model_validator(mode="after")
    def validate(self) -> Self:
        if self.include_packages is not None and self.exclude_packages is not None:
            raise ValueError("Cannot specify both `include_packages` and `exclude_packages`")
        return self


class ChariotMCPConfig(BaseModel):
    transport: Literal["http", "streamable-http", "stdio", "sse"] | None = "http"
    name: str | None = "Chariot"
    sdk: SDKConfig | None = Field(default_factory=SDKConfig)

    @model_validator(mode="after")
    def rename_streamable_http(self) -> Self:
        """Handle legacy naming of `streamable-http`."""
        self.transport = "http" if self.transport == "streamable-http" else self.transport
        return self

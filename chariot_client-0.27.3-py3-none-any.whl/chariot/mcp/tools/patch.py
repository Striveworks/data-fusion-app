import zipfile

from chariot import mcp_setting
from chariot.models import Model
from chariot.models import get_models as get_models_origin
from chariot.models import get_model_by_id as get_model_by_id_origin
from chariot.models.stage import Stage
from chariot.models.stage import set_stage as set_stage_origin
from chariot.models.stage import get_active_stages as get_active_stages_origin
from chariot.models.stage import get_stage_history as get_stage_history_origin
from chariot.models.isvc_settings import EngineVersionSelector
from chariot.models.upload import import_model as import_model_origin
from chariot.models.upload import import_model_with_engine as import_model_with_engine_origin
from chariot.models.enum import TaskType, ArtifactType
from typing import List, Optional, Any
from chariot_api._openapi.models.models.output_model import OutputModel
from chariot_api._openapi.models.models.output_model_stage_history_output import (
    OutputModelStageHistoryOutput,
)
from chariot_api._openapi.models.models.output_active_model_stage_output import (
    OutputActiveModelStageOutput,
)

# Functions that have to be patched from the originals in the SDK, and where the originals don't warrant being changed.


# Changed to have serializable output
def get_models(
    project_id: Optional[str] = None,
    id: Optional[str] = None,
    model_name: Optional[str] = None,
    model_version: Optional[str] = None,
    artifact_type: Optional[str] = None,
    task_type: Optional[str] = None,
    sort: Optional[str] = None,
    class_labels: Optional[str] = None,
    architecture: Optional[str] = None,
    limit: Optional[int] = 20,
    offset: Optional[int] = 0,
) -> List[OutputModel]:
    """
    Get models from chariot. Returns metadata of all matching models.

    Parameters:
    -----------
    project_ids: str
        Project id or ids to limit search. Comma delimited if more than one project.
    id: str
        Model's id.
    model_name: str
        Name of the model (exact match)
    model_version: str
        Version of the model (exact match)
    artifact_type: str
        Artifact type of the model (e.g. `pytorch`, `chariot`, `huggingface` etc)
    task_type: str
        Task type of the model (e.g. "Object Detection", "Image Classification" etc)
    sort: str
        can sort by created_at, updated_at, name, or id followed by a direction. e.g. 'created_at:desc' or 'created_at:asc'
    class_labels: str
        Filter by class labels, pass comma seperated IDs to match mutliple labels.
    architecture: str
        Model Architecture, filter by architecture, pass comma seperated task types to match multiple architectures.
    limit: int
        Limit for pagination
    offset: int
        Offset for pagination
    """
    models = get_models_origin(
        project_id=project_id,
        model_name=model_name,
        model_version=model_version,
        artifact_type=artifact_type,
        task_type=task_type,
        sort=sort,
        class_labels=class_labels,
        architecture=architecture,
        limit=limit,
        offset=offset,
    )
    for m in models:
        m._meta.pymodel_config = None  # Save tokens
    return [m._meta for m in models]


# Changed to have serializable output
def get_model_by_id(id: str) -> OutputModel:
    """
    Get a model's metadata. This is all the information about the model that Chariot
    has, including its architecture, artifact type, class labels, and version.

    Parameters:
    -----------
    id: str
        The model's id.
    """
    return get_model_by_id_origin(id)._meta


# Changed to allow model_id as input rather than Model
@mcp_setting(mutating=True)
def set_stage(model_id: str, stage: Stage) -> None:
    """
    Set the stage of a model

    Parameters:
    -----------
    id: str
        The model id
    stage: Stage
        The stage to set
    """
    model = get_model_by_id_origin(model_id)
    return set_stage_origin(model, stage)


# Changed to allow model_id as input rather than Model
def get_active_stages(model_id: str) -> OutputActiveModelStageOutput:
    """
    Function to get the currently active model stages and a list of archived model versions

    Parameters:
    -----------
    id: str
        The model id
    """
    model = get_model_by_id_origin(model_id)
    return get_active_stages_origin(model)


# Changed to allow model_id as input rather than Model
def get_stage_history(model_id: str, offset=0, limit=10) -> OutputModelStageHistoryOutput:
    """
    Function to get a paginated history of stage changes for a given model.

    Parameters:
    -----------
    id: str
        The model id
    offset: int
        Offset for pagination
    limit: int
        Limit for pagination
    """
    model = get_model_by_id_origin(model_id)
    return get_stage_history_origin(model, offset=offset, limit=limit)


# Removed a few arguments and changed return type to be serializable
@mcp_setting(file_based=True, mutating=True)
def import_model(
    *,
    name: str,
    version: str,
    summary: str,
    artifact_type: str | ArtifactType,
    task_type: str | TaskType,
    project_id: str | None = None,
    project_name: str | None = None,
    organization_id: str | None = None,
    class_labels: dict[str, int] | None = None,
    input_info: Any | None = None,  # input_info only used for sklearn models?
    model_path: str | None = None,
    use_internal_url: bool = False,
) -> OutputModel:
    """Import a local model into Chariot.

    For a previously exported Chariot model, model_path is the local path to the gzipped tar.
    For a Huggingface model, model_path is either the local path to the directory or
    the path to a zip file containing all of the model files.
    """

    model = import_model_origin(
        name=name,
        version=version,
        summary=summary,
        artifact_type=artifact_type,
        task_type=task_type,
        project_id=project_id,
        project_name=project_name,
        organization_id=organization_id,
        class_labels=class_labels,
        input_info=input_info,
        model_path=model_path,
        use_internal_url=use_internal_url,
    )
    return model._meta


# Replaced ZipFile with a local path and changed the return type to be serializable
@mcp_setting(file_based=True, mutating=True)
def import_model_with_engine(
    *,
    name: str,
    version: str,
    project_id: str,
    task_type: str | TaskType,
    engine_version_selector: EngineVersionSelector,
    model_path: str,
    summary: str = "",
    class_labels: dict[str, int] | None = None,
) -> OutputModel:
    """Upload a model archive and associate it with an Inference Engine.

    model_path is the local path to a zip file containing the model files.
    """
    with zipfile.ZipFile(model_path) as model_data:
        model = import_model_with_engine_origin(
            name=name,
            version=version,
            project_id=project_id,
            task_type=task_type,
            engine_version_selector=engine_version_selector,
            model_data=model_data,
            summary=summary,
            class_labels=class_labels,
        )
    return model._meta


def Model_fork(
    model_id: str,
    project_id: str,
    name: str | None = None,
    summary: str | None = None,
    version: str | None = None,
) -> OutputModel:
    """
    Fork a model into a given project.

    Parameters:
    -----------
    model_id: str
        The source model id
    project_id: str
        The target project id
    name: str
        The new model's name
    summary: str
        Summary for the new model
    version: str
        Version for the new model
    """
    model = get_model_by_id_origin(model_id)
    return model.fork(project_id=project_id, name=name, summary=summary, version=version)._meta


sdk_functions_to_patch = {
    "chariot.models.model.get_models": get_models,
    "chariot.models.model.get_model_by_id": get_model_by_id,
    "chariot.models.stage.set_stage": set_stage,
    "chariot.models.stage.get_active_stages": get_active_stages,
    "chariot.models.stage.get_stage_history": get_stage_history,
    "chariot.models.upload.import_model": import_model,
    "chariot.models.upload.import_model_with_engine": import_model_with_engine,
    "chariot.models.model.Model.fork": Model_fork,
}

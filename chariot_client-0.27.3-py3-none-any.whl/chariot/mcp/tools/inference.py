from io import BytesIO
from typing import Any

import requests
from PIL import Image

from chariot.datasets import get_datum
from chariot.models import get_model_by_id
from chariot.models.inference import ACTION_DOCSTRINGS


def get_action_docstring(action: str) -> str:
    """Return the docstring for a specific inference action."""
    return ACTION_DOCSTRINGS.get(action) or ""


def perform_model_inference_on_datum(
    model_id: str,
    action: str,
    datum_id: str = None,
    kwargs: dict = {},
) -> Any:
    """Perform model inference on an image datum. Currently text datums are not supported.

    Parameters
    ----------
    model_id: str
        The id of the model
    action: str
        The inference action
    datum_id: str
        If passed, this is the id of the datum on which to perform inference.
    kwargs: dict
        Extra arguments for the inference.

    Kwargs are the extra optional inference kwargs that get passed
    in addition to the input data.

    """
    datum = get_datum(datum_id)
    sample = Image.open(BytesIO(requests.get(datum.presigned_url, timeout=(9.05, 30)).content))

    model = get_model_by_id(model_id)
    return model.infer(action, sample, **kwargs)

from typing import Callable, Optional
from chariot.mcp.enum import ChariotMCPPackage


def is_mutating(func: Callable) -> bool:
    return getattr(func, "mutating", False)


def is_file_based(func: Callable) -> bool:
    return getattr(func, "file_based", False)


def is_ignored(func: Callable) -> bool:
    return getattr(func, "ignore", False)


def get_package_prefix(package: Optional[ChariotMCPPackage]) -> str:
    if package is not None:
        return package.value.upper() + "_"
    return ""

from enum import Enum


class ChariotMCPPackage(Enum):
    """
    SDK packages supported in MCP
    """

    Datasets = "datasets"
    BulkInference = "bulk_inference"
    Models = "models"
    Training = "training_v2"
    InferenceStore = "inference_store"
    Projects = "projects"
    SystemResources = "system_resources"
    Watchbox = "watchbox"

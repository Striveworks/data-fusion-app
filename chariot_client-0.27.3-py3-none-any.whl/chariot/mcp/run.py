import logging
import os

from chariot.client import connect

from .config import ChariotMCPConfig

try:
    from fastmcp import FastMCP
    from fastmcp.tools import Tool

    from .build import build

    def run(
        config: ChariotMCPConfig | None = None,
        bearer_token: str | None = None,
        dry: bool = False,
    ):
        if config is None:
            config = ChariotMCPConfig()
        bearer_token = bearer_token or os.getenv("BEARER_TOKEN", None)

        mcp = FastMCP(config.name)
        tools = build(config.sdk)

        for tool in tools:
            try:
                mcp.add_tool(Tool.from_function(tool.fn, meta=tool.meta))
            except Exception as e:
                logging.warning(f"Unable to register tool {tool.fn.__name__}")
                if dry:
                    logging.info(e)
                    raise
                else:
                    continue
        if dry:
            return
        connect(bearer_token=bearer_token)
        mcp.run(config.transport)

except ModuleNotFoundError:

    def run(
        config: ChariotMCPConfig | None = None,
        bearer_token: str | None = None,
        dry: bool = False,
    ):
        raise ModuleNotFoundError(
            "You must have the `mcp` optional dependency installed to start a Chariot MCP server. You can install it with `pip install chariot-client[mcp]`."
        )

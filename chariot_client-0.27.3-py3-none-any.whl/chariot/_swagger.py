raise Exception("Module chariot._swagger moved to chariot_api._openapi")

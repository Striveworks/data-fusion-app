import datetime
import tempfile

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.types import PrivateKeyTypes
from cryptography.hazmat.primitives.serialization import pkcs12 as pkcslib
from cryptography.x509 import Certificate

from chariot.config import getLogger

try:
    from ssl import PROTOCOL_TLS as default_ssl_protocol
except ImportError:
    from ssl import PROTOCOL_SSLv23 as default_ssl_protocol  # noqa: F401


log = getLogger(__name__)


def check_cert_not_after(cert):
    cert_not_after = cert.not_valid_after
    if cert_not_after < datetime.datetime.utcnow():
        raise ValueError(
            "Client certificate expired: Not After: {cert_not_after:%Y-%m-%d %H:%M:%SZ}".format(
                **locals()
            )
        )


def get_cert_and_key_from_p12(
    pkcs12: str | bytes | None, pkcs12_password: str = ""
) -> tuple[str, str]:
    if not pkcs12:
        log.error("pkcs12 must be specified")
        return

    def _generate_key_and_cert_temp_files(private_key: PrivateKeyTypes, cert: Certificate):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pem") as c:
            c.write(
                private_key.private_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PrivateFormat.PKCS8,
                    encryption_algorithm=serialization.NoEncryption(),
                )
            )
            c.flush()
            c.close()
            private_key_filename = c.name

        with tempfile.NamedTemporaryFile(delete=False, suffix=".pem") as c:
            c.write(cert.public_bytes(encoding=serialization.Encoding.PEM))
            c.flush()
            c.close()
            cert_filename = c.name
        return private_key_filename, cert_filename

    if type(pkcs12) == bytes:
        private_key, cert, _ = pkcslib.load_key_and_certificates(pkcs12, pkcs12_password.encode())
        return _generate_key_and_cert_temp_files(private_key, cert)

    with open(pkcs12, "rb") as pkcs12_file:
        private_key, cert, _ = pkcslib.load_key_and_certificates(
            pkcs12_file.read(), pkcs12_password.encode()
        )
        return _generate_key_and_cert_temp_files(private_key, cert)

import math

R = 6371


def convert_to_dataclass(obj, c):
    if isinstance(obj, c):
        return obj
    return c(**obj)


def euclidean(p1: tuple[float, float], p2: tuple[float, float]):
    return math.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2)


def haversine(coord1: tuple[float, float], coord2: tuple[float, float]):
    lat1, lon1 = coord1
    lat2, lon2 = coord2
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = (
        math.sin(dphi / 2) ** 2
        + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlambda / 2) ** 2
    )
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def iou(box1: tuple[float, float, float, float], box2: tuple[float, float, float, float]):
    def to_corners(b):
        return b[0] - b[2] / 2, b[1] - b[3] / 2, b[0] + b[2] / 2, b[1] + b[3] / 2

    x1, y1, x2, y2 = to_corners(box1)
    x3, y3, x4, y4 = to_corners(box2)
    xi1, yi1 = max(x1, x3), max(y1, y3)
    xi2, yi2 = min(x2, x4), min(y2, y4)
    inter_area = max(0, xi2 - xi1) * max(0, yi2 - yi1)
    area1 = (x2 - x1) * (y2 - y1)
    area2 = (x4 - x3) * (y4 - y3)
    union = area1 + area2 - inter_area
    return inter_area / union if union > 0 else 0

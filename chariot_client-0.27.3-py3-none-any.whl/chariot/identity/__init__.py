from chariot import _apis

from .settings import *


@_apis.login_required
def whoami():
    data = _apis.identity._apis["users_api"].v2_users_me_get().data.to_dict()
    del data["access_token"]
    return data

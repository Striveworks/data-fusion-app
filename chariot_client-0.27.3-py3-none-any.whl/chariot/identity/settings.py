from chariot import _apis
from typing import List

from .model import SettingsOwner

__all__ = ["get_settings"]


@_apis.login_required
def get_settings(
    owner_type: SettingsOwner | str, owner_id: str, path: str, decrypt: bool = False
) -> List[dict] | None:
    """
    Get organization, project, or user-scoped settings. Examples of settings include: s3
    credentials, container registry credentials, and custom key/value secrets.

    Parameters
    ----------
    owner_type: SettingsOwner
        The type of owner for the setting
    owner_id: str
        The ID for the owner of the setting
    path: str
        The path for the setting(s).
    decrypt: bool
        Whether to decrypt any secrets (defaults to False). Secrets are only decrypted
        if the requesting party has proper authorization.

    Returns
    -------
    List[dict]
        Any matching secrets
    """
    owner_type = SettingsOwner(owner_type)
    result = _apis.identity._apis["settings_api"].v2_settings_owner_type_owner_id_path_get(
        owner_type=owner_type.value, owner_id=owner_id, path=path, decrypt=decrypt, sort="name"
    )
    if "data" in result:
        return result["data"]

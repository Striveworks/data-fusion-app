from enum import Enum


class SettingsOwner(str, Enum):
    Organization = "organization"
    Project = "project"
    User = "user"

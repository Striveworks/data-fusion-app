from importlib import metadata


def mcp_setting(mutating: bool = False, ignore: bool = False, file_based: bool = False):
    """Set MCP flags for SDK functions.

    Parameters
    ----------
    mutating : bool, default=False
        Set when function changes internal states within Chariot.
    ignore : bool, default=False
        Set when MCP should ignore the function.
    file_based : bool, default=False
        Set when function requires a local filesystem.

    """

    def wrapper(func):
        func.mutating = mutating
        func.ignore = ignore
        func.file_based = file_based
        return func

    return wrapper


try:
    __version__ = metadata.version("chariot-client")
except Exception:
    __version__ = "0.0.0-dev"
del metadata

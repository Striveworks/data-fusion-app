"""List and statistics helpers for AWM activity feedback."""

from collections.abc import Generator
from typing import Any

from chariot import _apis
from chariot.awm import _utils, models
from chariot_api._openapi.awm.models.model_feedback import ModelFeedback
from chariot_api._openapi.awm.models.model_feedback_statistics import ModelFeedbackStatistics

__all__ = [
    "list_feedback",
    "get_feedback_statistics",
]

_RESOURCE = "feedback"


def _to_feedback(data: ModelFeedback) -> models.Feedback:
    return models.Feedback(
        id=_utils.required_field(data.id, "id", _RESOURCE),
        activity_id=_utils.required_field(data.activity_id, "activity_id", _RESOURCE),
        activity_type=_utils.required_field(data.activity_type, "activity_type", _RESOURCE),
        session_id=_utils.required_field(data.session_id, "session_id", _RESOURCE),
        workflow_version_id=_utils.required_field(
            data.workflow_version_id, "workflow_version_id", _RESOURCE
        ),
        workflow_component_id=_utils.required_field(
            data.workflow_component_id, "workflow_component_id", _RESOURCE
        ),
        project_id=_utils.required_field(data.project_id, "project_id", _RESOURCE),
        agent=_utils.required_field(data.agent, "agent", _RESOURCE),
        session_created_by=_utils.required_field(
            data.session_created_by, "session_created_by", _RESOURCE
        ),
        created_by=_utils.required_field(data.created_by, "created_by", _RESOURCE),
        thumbs_up=_utils.required_field(data.thumbs_up, "thumbs_up", _RESOURCE),
        source=_utils.required_field(data.source, "source", _RESOURCE),
        created_at=_utils.required_datetime(data.created_at, "created_at", _RESOURCE),
        updated_at=_utils.required_datetime(data.updated_at, "updated_at", _RESOURCE),
        session_display_name=data.session_display_name,
        comment=data.comment,
    )


def _to_feedback_statistics(data: ModelFeedbackStatistics) -> models.FeedbackStatistics:
    return models.FeedbackStatistics(
        total=int(_utils.required_field(data.total, "total", _RESOURCE)),
        thumbs_up=int(_utils.required_field(data.thumbs_up, "thumbs_up", _RESOURCE)),
        thumbs_down=int(_utils.required_field(data.thumbs_down, "thumbs_down", _RESOURCE)),
        with_comments=int(_utils.required_field(data.with_comments, "with_comments", _RESOURCE)),
    )


def _feedback_api():
    return _apis.awm.feedback_api


def _feedback_filters(
    *,
    thumbs_up: bool | None,
    agents: list[str] | None,
    workflow_component_ids: list[str] | None,
    workflow_version_ids: list[str] | None,
    created_by: list[str] | None,
    has_comment: bool | None,
    project_ids: list[str] | None,
    sources: list[str] | None,
    session_ids: list[str] | None,
    session_created_by: list[str] | None,
    types: list[str] | None,
) -> dict[str, Any]:
    """Map SDK filters onto ListFeedback query parameters.

    Omitted values are left unset so the server applies its defaults. Source
    defaults to user. Reviewer rows are included only when requested and only
    for projects where the caller has AllSessions read access.
    """
    return {
        key: value
        for key, value in {
            "thumbs_up": thumbs_up,
            "agent": agents,
            "workflow_component_id": workflow_component_ids,
            "workflow_version_id": workflow_version_ids,
            "created_by": created_by,
            "has_comment": has_comment,
            "project_id": project_ids,
            "source": sources,
            "session_id": session_ids,
            "session_created_by": session_created_by,
            "type": types,
        }.items()
        if value is not None
    }


@_apis.login_required
def list_feedback(
    thumbs_up: bool | None = None,
    agents: list[str] | None = None,
    workflow_component_ids: list[str] | None = None,
    workflow_version_ids: list[str] | None = None,
    created_by: list[str] | None = None,
    has_comment: bool | None = None,
    project_ids: list[str] | None = None,
    sources: list[str] | None = None,
    session_ids: list[str] | None = None,
    session_created_by: list[str] | None = None,
    types: list[str] | None = None,
    limit: int | None = None,
    sort_order: str | None = None,
    after_key: str | None = None,
    calculate_meta: bool | None = None,
) -> Generator[models.Feedback, None, None]:
    """List feedback visible to the caller.

    Visibility matches ``GET /feedback``. When ``sources`` is omitted, the
    server defaults to user feedback. Reviewer rows require AllSessions read
    access and are returned only when ``reviewer`` is requested. A mixed
    user and reviewer query still returns user rows from the caller's own
    sessions. Session-only projects never contribute reviewer rows.

    :param thumbs_up: If true, only thumbs up. If false, only thumbs down.
    :param agents: Agent names
    :param workflow_component_ids: Workflow component IDs
    :param workflow_version_ids: Workflow version IDs
    :param created_by: Reporting user IDs
    :param has_comment: If true, only rows with comments. If false, only rows without.
    :param project_ids: Project IDs
    :param sources: Feedback sources (``user`` or ``reviewer``). Defaults to user on the server.
    :param session_ids: Session IDs
    :param session_created_by: Session owner user IDs
    :param types: Activity types
    :param limit: Maximum number of results to return
    :param sort_order: ``asc`` or ``desc``. Defaults to desc on the server.
    :param after_key: Pagination key
    :param calculate_meta: Ask the server to include page totals. This helper yields rows only.
    :rtype: Generator[models.Feedback, None, None]
    """
    params = _feedback_filters(
        thumbs_up=thumbs_up,
        agents=agents,
        workflow_component_ids=workflow_component_ids,
        workflow_version_ids=workflow_version_ids,
        created_by=created_by,
        has_comment=has_comment,
        project_ids=project_ids,
        sources=sources,
        session_ids=session_ids,
        session_created_by=session_created_by,
        types=types,
    )
    if sort_order is not None:
        params["sort_order"] = sort_order
    if calculate_meta is not None:
        params["calculate_meta"] = calculate_meta
    if limit is not None:
        params["limit"] = limit
    if after_key is not None:
        params["after_key"] = after_key

    def _paginate_fn(**params: Any) -> Any:
        return _feedback_api().list_feedback(**params)

    return _utils.paginate(
        func=_paginate_fn,
        params=params,
        transform_item=_to_feedback,
    )


@_apis.login_required
def get_feedback_statistics(
    thumbs_up: bool | None = None,
    agents: list[str] | None = None,
    workflow_component_ids: list[str] | None = None,
    workflow_version_ids: list[str] | None = None,
    created_by: list[str] | None = None,
    has_comment: bool | None = None,
    project_ids: list[str] | None = None,
    sources: list[str] | None = None,
    session_ids: list[str] | None = None,
    session_created_by: list[str] | None = None,
    types: list[str] | None = None,
) -> models.FeedbackStatistics:
    """Get feedback totals using the same filters and visibility rules as :func:`list_feedback`.

    :param thumbs_up: If true, only thumbs up. If false, only thumbs down.
    :param agents: Agent names
    :param workflow_component_ids: Workflow component IDs
    :param workflow_version_ids: Workflow version IDs
    :param created_by: Reporting user IDs
    :param has_comment: If true, only rows with comments. If false, only rows without.
    :param project_ids: Project IDs
    :param sources: Feedback sources (``user`` or ``reviewer``). Defaults to user on the server.
    :param session_ids: Session IDs
    :param session_created_by: Session owner user IDs
    :param types: Activity types
    :rtype: models.FeedbackStatistics
    """
    params = _feedback_filters(
        thumbs_up=thumbs_up,
        agents=agents,
        workflow_component_ids=workflow_component_ids,
        workflow_version_ids=workflow_version_ids,
        created_by=created_by,
        has_comment=has_comment,
        project_ids=project_ids,
        sources=sources,
        session_ids=session_ids,
        session_created_by=session_created_by,
        types=types,
    )
    response = _feedback_api().get_feedback_statistics(**params)
    if not response.data:
        raise RuntimeError(
            "Received malformed response (missing `data`) from get_feedback_statistics"
        )
    return _to_feedback_statistics(response.data)

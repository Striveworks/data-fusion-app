from datetime import datetime
from typing import Any, TypeVar

from dateutil import parser

T = TypeVar("T")

PAGINATION_PAGE_SIZE_CAP = 100


def paginate(func, params, transform_item=lambda item: item):
    request_params = dict(params)
    after_key = request_params.pop("after_key", None)
    total_limit = request_params.pop("limit", None)
    yielded = 0

    while True:
        call_params = dict(request_params)
        if total_limit is not None:
            remaining = total_limit - yielded
            if remaining <= 0:
                return
            call_params["limit"] = min(remaining, PAGINATION_PAGE_SIZE_CAP)
        else:
            call_params["limit"] = PAGINATION_PAGE_SIZE_CAP

        page = func(**call_params, after_key=after_key)
        for item in page.data:
            yield transform_item(item)
            yielded += 1
            if total_limit is not None and yielded >= total_limit:
                return
        after_key = page.after_key

        if len(page.data) == 0 or not after_key:
            return


def convert_to_datetime(obj):
    if isinstance(obj, str):
        return parser.parse(obj)
    return obj


def convert_to_dataclass(obj, clazz):
    if isinstance(obj, clazz):
        return obj
    return clazz(**obj)


def required_field(value: T | None, field: str, resource: str) -> T:
    """Return a required API field or raise when it is missing."""
    if value is not None:
        return value
    raise RuntimeError(f"Received malformed {resource} payload (missing {field})")


def required_datetime(value: Any, field: str, resource: str) -> datetime:
    """Return a required API timestamp or raise when it is missing or invalid."""
    parsed = convert_to_datetime(required_field(value, field, resource))
    if not isinstance(parsed, datetime):
        raise RuntimeError(f"Received malformed {resource} payload (invalid {field})")
    return parsed

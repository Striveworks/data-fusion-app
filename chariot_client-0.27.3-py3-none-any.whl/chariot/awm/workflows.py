from collections.abc import Generator
from typing import Any

import chariot_api._openapi.awm.models as api_models
from chariot import _apis, mcp_setting
from chariot.awm import _utils, models
from chariot_api._openapi.awm.api import WorkflowsApi

__all__ = [
    "get_workflow",
    "get_workflow_agents",
    "get_workflow_auth_providers",
    "patch_workflow_paused",
    "get_workflows",
    "get_public_setting_values",
    "patch_public_setting_values",
]


def _workflow_api() -> WorkflowsApi:
    return _apis.awm.workflows_api


@_apis.login_required
def get_workflow(workflow_id: str) -> models.Workflow:
    """Get a workflow for a project.

    :param workflow_id: Workflow id
    :type workflow_id: str
    :rtype: models.Workflow
    """
    response = _workflow_api().get_workflow(workflow_id)
    if not response.data:
        raise RuntimeError("Received malformed response (missing `data`) from get_workflow")
    return _utils.convert_to_dataclass(response.data.model_dump(), models.Workflow)


@_apis.login_required
def patch_workflow_paused(workflow_id: str, paused: bool) -> None:
    """PATCH only the ``paused`` flag without touching any other workflow fields."""
    _workflow_api().patch_workflow(
        workflow_id,
        api_models.InputPatchWorkflowRequest(paused=paused),
    )


@_apis.login_required
def get_workflow_agents(workflow_id: str) -> list[models.Agent]:
    """Get the entry agents configured for a workflow.

    :param workflow_id: Workflow id
    :type workflow_id: str
    :rtype: list[models.Agent]
    """
    response = _workflow_api().list_workflow_agents(workflow_id)
    if not response.data:
        return []
    return [
        _utils.convert_to_dataclass(a.model_dump(), models.Agent)
        for a in response.data
        if a.supported_entry_agent
    ]


@_apis.login_required
def get_workflow_auth_providers(workflow_id: str) -> list[models.WorkflowAuthProvider]:
    """Get required auth providers and their connection status for current user."""
    response = _workflow_api().get_workflow_auth_providers(workflow_id)
    if not response.data:
        return []
    return [
        _utils.convert_to_dataclass(provider.model_dump(), models.WorkflowAuthProvider)
        for provider in response.data
    ]


@_apis.login_required
def get_workflow_resources(workflow_id: str) -> models.WorkflowResourceDetails:
    """Get workflow resources for a project.

    :param workflow_id: Workflow id
    :type workflow_id: str
    :rtype: models.WorkflowResourceDetails
    """
    response = _workflow_api().get_workflow_resource_details(workflow_id)
    if not response.data:
        raise RuntimeError("Received malformed response (missing `data`) from get_workflow")
    return _utils.convert_to_dataclass(response.data.model_dump(), models.WorkflowResourceDetails)


@_apis.login_required
def get_workflows(
    name: str | None = None,
    exact_name_match: bool | None = None,
    project_ids: list[str] | None = None,
    include_deleted: bool | None = None,
    limit: int | None = None,
    after_key: str | None = None,
    permission: str | None = None,
) -> Generator[models.Workflow, None, None]:
    """List workflows matching the specified filters.

    :param name: Name filter (partial and case-insensitive by default)
    :type name: Optional[str]
    :param exact_name_match: Require name filter to match exactly (defaults to false)
    :type exact_name_match: Optional[bool]
    :param project_ids: List of project ids to filter
    :type project_ids: Optional[List[str]]
    :param include_deleted: Set to True to include deleted workflows
    :type include_deleted: Optional[bool]
    :param limit: The max total number of items to return
    :type limit: Optional[int]
    :param after_key: The pagination key to fetch more items
    :type after_key: Optional[str]
    :param permission: Permission filter (e.g. ``usage`` for workflows the caller can use)
    :type permission: Optional[str]
    :rtype: Generator[models.Workflow, None, None]
    """
    params = {
        k: v
        for k, v in {
            "name": name,
            "exact_name_match": exact_name_match,
            "project_id": project_ids,
            "include_deleted": include_deleted,
            "limit": limit,
            "after_key": after_key,
            "permission": permission,
        }.items()
        if v is not None
    }

    def _paginate_fn(**params):
        return _workflow_api().list_workflows(**params)

    def _transform_fn(item):
        return _utils.convert_to_dataclass(item.model_dump(), models.Workflow)

    return _utils.paginate(
        func=_paginate_fn,
        params=params,
        transform_item=_transform_fn,
    )


@_apis.login_required
def get_public_setting_values(workflow_id: str) -> dict[str, models.WorkflowPublicSettingValue]:
    """Get workflow public setting values.

    :param workflow_id: Workflow id
    :type workflow_id: str
    :rtype: dict[str, models.WorkflowPublicSettingValue]
    """
    response = _workflow_api().get_workflow_public_settings(workflow_id)
    if not response.data:
        return {}
    if not isinstance(response.data, dict):
        raise TypeError(
            "Received malformed response (`data` should be a dict) from get_public_setting_values"
        )
    return _to_public_setting_values(response.data)


@mcp_setting(mutating=True)
@_apis.login_required
def patch_public_setting_values(
    workflow_id: str, public_setting_values: dict[str, models.WorkflowPublicSettingValue]
) -> dict[str, models.WorkflowPublicSettingValue]:
    """Patch workflow public setting values.

    :param workflow_id: Workflow id
    :type workflow_id: str
    :param public_setting_values: The public settings with updated values
    :type public_setting_values: dict[str, models.WorkflowPublicSettingValue]
    :rtype: dict[str, models.WorkflowPublicSettingValue]
    """
    response = _workflow_api().patch_workflow_public_settings(
        workflow_id, {k: {"value": v.value} for k, v in public_setting_values.items()}
    )
    if not response.data:
        return {}
    if not isinstance(response.data, dict):
        raise TypeError(
            "Received malformed response (`data` should be a dict) from patch_public_setting_values"
        )
    return _to_public_setting_values(response.data)


def _to_public_setting_values(
    data: dict[str, dict[str, Any]],
) -> dict[str, models.WorkflowPublicSettingValue]:
    return {
        k: _utils.convert_to_dataclass(
            {
                "value": v.get("value"),
                "schema": v.get("schema"),
            },
            models.WorkflowPublicSettingValue,
        )
        for k, v in data.items()
    }

"""Session operations for AWM workflows."""

from typing import Any

import chariot_api._openapi.awm.models as api_models
from chariot import _apis
from chariot.awm import models
from chariot.awm._utils import convert_to_datetime

__all__ = [
    "get_session_configuration",
    "patch_session_display_name",
]


def _to_session_configuration(raw: dict[str, Any]) -> models.SessionConfiguration:
    return models.SessionConfiguration(
        data=raw.get("data"),
        overrides=raw.get("overrides"),
        resolved=raw.get("resolved"),
    )


def _to_session_metadata(data: api_models.ModelSessionMetadata) -> models.SessionMetadata:
    raw = data.model_dump()
    display_name = raw.get("display_name") or ""
    session_id = raw.get("session_id") or ""
    updated_at = raw.get("updated_at")
    if updated_at is None:
        raise RuntimeError("Received malformed session metadata (missing `updatedAt`)")
    return models.SessionMetadata(
        session_id=session_id,
        display_name=display_name,
        updated_at=convert_to_datetime(updated_at),
        updated_by=raw.get("updated_by") or "",
    )


@_apis.login_required
def get_session_configuration(session_id: str) -> models.SessionConfiguration:
    """Get the resolved configuration for a session.

    :param session_id: Session id
    :type session_id: str
    :rtype: models.SessionConfiguration
    """
    response = _apis.awm.sessions_api.get_session_configuration(session_id)
    return _to_session_configuration(response.model_dump(by_alias=False))


@_apis.login_required
def patch_session_display_name(session_id: str, display_name: str) -> models.SessionMetadata:
    """Update the display name for a session.

    :param session_id: Session id
    :type session_id: str
    :param display_name: New display name (1-60 characters after trim)
    :type display_name: str
    :rtype: models.SessionMetadata
    """
    response = _apis.awm.sessions_api.patch_session(
        session_id,
        api_models.InputPatchSessionRequest(display_name=display_name),
    )
    if response.data is None:
        raise RuntimeError("Received malformed response (missing `data`) from patch_session")
    return _to_session_metadata(response.data)

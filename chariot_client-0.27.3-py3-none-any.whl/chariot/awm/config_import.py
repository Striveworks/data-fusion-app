"""Batch import of v2 AWM configuration bundles."""

from __future__ import annotations

import copy
import logging
import sys
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, TextIO

import yaml

from chariot import awm
from chariot.awm import models
from chariot_api._openapi.awm.exceptions import NotFoundException

logger = logging.getLogger(__name__)

IMPORT_COMPONENT_TYPES = [
    models.COMPONENT_TYPE_SHARED,
    models.COMPONENT_TYPE_MCP_CONNECTION,
    models.COMPONENT_TYPE_EVALUATOR,
    models.COMPONENT_TYPE_TOOL_PROFILE,
    models.COMPONENT_TYPE_AGENT,
    models.COMPONENT_TYPE_WORKFLOW,
]

__all__ = [
    "IMPORT_COMPONENT_TYPES",
    "ConfigurationImportRecord",
    "ConfigurationImportResult",
    "apply_parameters",
    "import_v2_configurations",
    "print_import_result",
    "raw_config_matches",
]


@dataclass
class ConfigurationImportRecord:
    """One component outcome from a v2 configuration import."""

    component_type: str
    key: str
    version_id: str | None = None
    component_id: str | None = None
    message: str | None = None


@dataclass
class ConfigurationImportResult:
    """Aggregate results from importing a v2 configuration bundle."""

    created: list[ConfigurationImportRecord] = field(default_factory=list)
    updated: list[ConfigurationImportRecord] = field(default_factory=list)
    skipped: list[ConfigurationImportRecord] = field(default_factory=list)
    promoted: list[ConfigurationImportRecord] = field(default_factory=list)
    errors: list[ConfigurationImportRecord] = field(default_factory=list)


def _format_import_record_line(
    record: ConfigurationImportRecord,
    *,
    indent: str = "  ",
) -> str:
    suffix = f" — {record.message}" if record.message else ""
    return f"{indent}{record.component_type} / {record.key}{suffix}"


def _import_result_sections(
    result: ConfigurationImportResult,
) -> list[tuple[str, list[ConfigurationImportRecord]]]:
    """Return non-empty import outcome sections in display order."""
    return [
        (label, records)
        for label, records in (
            ("Created", result.created),
            ("Updated", result.updated),
            ("Promoted", result.promoted),
            ("Skipped", result.skipped),
            ("Errors", result.errors),
        )
        if records
    ]


def print_import_result(
    result: ConfigurationImportResult,
    *,
    file: TextIO | None = None,
    indent: str = "",
    record_indent: str = "  ",
    format_header: Callable[[str], str] | None = None,
    format_divider: Callable[[str], str] | None = None,
    format_section: Callable[[str, int], str] | None = None,
    format_record: Callable[[str], str] | None = None,
) -> None:
    """Print a human-readable summary of import outcomes."""
    output = file if file is not None else sys.stdout

    def _format(text: str, formatter: Callable[[str], str] | None) -> str:
        return formatter(text) if formatter else text

    def _writeln(text: str = "") -> None:
        print(text, file=output)

    _writeln(_format(f"{indent}Import complete", format_header))
    _writeln(_format(f"{indent}{'─' * 50}", format_divider))

    for label, records in _import_result_sections(result):
        _writeln()
        section_line = f"{indent}{label} ({len(records)})"
        if format_section is not None:
            section_line = format_section(label, len(records))
        _writeln(section_line)
        for record in records:
            record_line = _format_import_record_line(record, indent=record_indent)
            _writeln(_format(record_line, format_record))


def apply_parameters(config: dict[str, Any]) -> dict[str, Any]:
    """Substitute ``parameters`` placeholders and remove the parameters block."""
    config = copy.deepcopy(config)
    parameters = config.pop("parameters", {})
    if not parameters:
        return config
    config_str = yaml.dump(config)
    for key, value in parameters.items():
        config_str = config_str.replace(f"{{{key}}}", str(value))
    loaded = yaml.safe_load(config_str)
    if not isinstance(loaded, dict):
        raise ValueError("Parameter substitution must produce a mapping at the top level")
    return loaded


def raw_config_matches(stored: Any, candidate_yaml: str) -> bool:
    """Return whether stored raw config content matches candidate YAML."""
    if stored is None:
        return False
    if isinstance(stored, str):
        return stored == candidate_yaml
    if isinstance(stored, bytes | bytearray):
        return stored.decode("utf-8") == candidate_yaml
    if isinstance(stored, list):
        try:
            return bytes(stored).decode("utf-8") == candidate_yaml
        except (TypeError, ValueError):
            return False
    return str(stored) == candidate_yaml


def _format_log_message(message: str, **fields: Any) -> str:
    if not fields:
        return message
    suffix = " ".join(f"{key}={value}" for key, value in fields.items())
    return f"{message} | {suffix}"


def _component_api_fns(component_type: str) -> tuple[Any, Any, Any, Any, Any]:
    api_type = component_type.replace("-", "_")
    return (
        getattr(awm, f"create_{api_type}_configuration"),
        getattr(awm, f"create_{api_type}_configuration_version"),
        getattr(awm, f"create_{api_type}_configuration_stage"),
        getattr(awm, f"list_{api_type}_configuration_versions"),
        getattr(awm, f"get_{api_type}_configuration_version"),
    )


def _find_matching_version(
    component_id: str,
    component_config_yaml: str,
    description: str,
    list_versions_fn: Any,
    get_version_fn: Any,
) -> models.ConfigurationComponentVersion | None:
    for version_summary in list_versions_fn(component_id):
        version = get_version_fn(version_summary.id)
        if not raw_config_matches(version.data.raw_config, component_config_yaml):
            continue
        # The description is versioned alongside the config but is not part of raw_config,
        # so it has to be compared separately or description-only edits look unchanged.
        if (version.data.description or "") == description:
            return version.data
    return None


def import_v2_configurations(
    project_id: str,
    config: dict[str, Any],
    *,
    version_changelog: str = "import",
    promote_existing_to_production: bool = True,
) -> ConfigurationImportResult:
    """Create or version configuration components from a v2 bundle dict.

    When an existing version's raw config and description both match the import
    payload, that version is reused. If ``promote_existing_to_production`` is true and
    the match is not already staged as production, it is promoted; otherwise the
    component is skipped. A component's ``name`` lives on the component rather than the
    version, so renames in the bundle are not applied to existing components.
    """
    result = ConfigurationImportResult()
    working_config = apply_parameters(config)

    for component_type in IMPORT_COMPONENT_TYPES:
        (
            create_component_fn,
            create_version_fn,
            stage_fn,
            list_versions_fn,
            get_version_fn,
        ) = _component_api_fns(component_type)
        entries = working_config.get(component_type, [])
        if not isinstance(entries, list):
            result.errors.append(
                ConfigurationImportRecord(
                    component_type=component_type,
                    key="",
                    message=f"Expected a list for {component_type!r}, got {type(entries).__name__}",
                )
            )
            continue

        for entry in entries:
            if not isinstance(entry, dict):
                result.errors.append(
                    ConfigurationImportRecord(
                        component_type=component_type,
                        key="",
                        message=f"Expected mapping entries under {component_type!r}",
                    )
                )
                continue

            component_config = copy.deepcopy(entry)
            try:
                name = component_config.pop("name")
                key = component_config.pop("key")
                # A bundle is declarative, so a blank description is sent explicitly to
                # clear any existing one rather than omitted, which would inherit it.
                description = component_config.pop("description") or ""
            except KeyError as exc:
                result.errors.append(
                    ConfigurationImportRecord(
                        component_type=component_type,
                        key=str(entry.get("key", "")),
                        message=f"Missing required field: {exc.args[0]}",
                    )
                )
                continue

            component_config_yaml = yaml.dump(component_config)
            existing_component_id: str | None = None

            try:
                existing = awm.get_configuration_by_reference(
                    project_id, component_type, key, "latest"
                )
                existing_component_id = existing.data.component_id
            except NotFoundException:
                pass

            record = ConfigurationImportRecord(component_type=component_type, key=key)

            matching_version = None
            if existing_component_id is not None:
                matching_version = _find_matching_version(
                    existing_component_id,
                    component_config_yaml,
                    description,
                    list_versions_fn,
                    get_version_fn,
                )

            if matching_version is not None:
                record.version_id = matching_version.id
                record.component_id = matching_version.component_id
                already_production = models.STAGE_PRODUCTION in (matching_version.stages or [])
                if promote_existing_to_production and not already_production:
                    try:
                        stage_fn(matching_version.id, models.STAGE_PRODUCTION)
                    except Exception as exc:
                        record.message = str(exc)
                        result.errors.append(record)
                        continue
                    result.promoted.append(record)
                    logger.info(
                        _format_log_message(
                            "Promoted existing component version",
                            project_id=project_id,
                            component_type=component_type,
                            key=key,
                            version_id=record.version_id,
                        )
                    )
                    continue
                result.skipped.append(record)
                logger.info(
                    _format_log_message(
                        "Skipped unchanged component",
                        project_id=project_id,
                        component_type=component_type,
                        key=key,
                        version_id=record.version_id,
                    )
                )
                continue

            try:
                if existing_component_id is not None:
                    new_version = create_version_fn(
                        existing_component_id,
                        component_config_yaml,
                        version_changelog,
                        description,
                    )
                else:
                    new_version = create_component_fn(
                        project_id, name, key, description, component_config_yaml
                    )
                stage_fn(new_version.id, models.STAGE_PRODUCTION)
            except Exception as exc:
                record.message = str(exc)
                result.errors.append(record)
                logger.exception(
                    _format_log_message(
                        "Failed importing component",
                        project_id=project_id,
                        component_type=component_type,
                        key=key,
                    )
                )
                continue

            record.version_id = new_version.id
            record.component_id = new_version.component_id
            outcome = result.updated if existing_component_id is not None else result.created
            outcome.append(record)
            log_message = (
                "Updated component configuration"
                if existing_component_id is not None
                else "Created component configuration"
            )
            logger.info(
                _format_log_message(
                    log_message,
                    project_id=project_id,
                    component_type=component_type,
                    key=key,
                    version_id=record.version_id,
                    component_id=record.component_id,
                )
            )

    return result

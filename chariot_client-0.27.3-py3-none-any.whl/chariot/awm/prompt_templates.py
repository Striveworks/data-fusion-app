"""Prompt template CRUD helpers for AWM."""

from collections.abc import Generator

import chariot_api._openapi.awm.models as api_models
from chariot import _apis, mcp_setting
from chariot.awm import _utils, models
from chariot_api._openapi.awm.models.model_prompt_template import ModelPromptTemplate

__all__ = [
    "create_prompt_template",
    "update_prompt_template",
    "get_prompt_template",
    "get_prompt_templates",
    "delete_prompt_template",
]


_RESOURCE = "prompt template"


def _to_prompt_template(data: ModelPromptTemplate) -> models.PromptTemplate:
    return models.PromptTemplate(
        id=_utils.required_field(data.id, "id", _RESOURCE),
        project_id=_utils.required_field(data.project_id, "project_id", _RESOURCE),
        visibility=_utils.required_field(data.visibility, "visibility", _RESOURCE),
        scope=_utils.required_field(data.scope, "scope", _RESOURCE),
        name=_utils.required_field(data.name, "name", _RESOURCE),
        content=_utils.required_field(data.content, "content", _RESOURCE),
        enabled=_utils.required_field(data.enabled, "enabled", _RESOURCE),
        created_by=_utils.required_field(data.created_by, "created_by", _RESOURCE),
        created_at=_utils.required_datetime(data.created_at, "created_at", _RESOURCE),
        agent_id=data.agent_id,
        description=data.description,
        placeholders=data.placeholders,
    )


def _prompt_templates_api():
    return _apis.awm.prompt_templates_api


def _create_payload(
    project_id: str,
    visibility: str,
    scope: str,
    name: str,
    content: str,
    description: str | None = None,
    agent_id: str | None = None,
) -> api_models.InputCreatePromptTemplateRequest:
    return api_models.InputCreatePromptTemplateRequest(
        projectID=project_id,
        visibility=visibility,
        scope=scope,
        name=name,
        content=content,
        description=description,
        agentID=agent_id,
    )


def _validate_list_params(
    *,
    agent_id: str | None,
    visibility: str | None,
    scope: str | None,
) -> None:
    normalized_visibility = visibility.strip() if visibility else ""
    normalized_scope = scope.strip() if scope else ""
    normalized_agent_id = agent_id.strip() if agent_id else ""

    if normalized_visibility and normalized_visibility not in (
        models.PROMPT_TEMPLATE_VISIBILITY_PUBLIC,
        models.PROMPT_TEMPLATE_VISIBILITY_PRIVATE,
    ):
        raise ValueError(
            f'visibility must be one of "{models.PROMPT_TEMPLATE_VISIBILITY_PUBLIC},'
            f'{models.PROMPT_TEMPLATE_VISIBILITY_PRIVATE}"'
        )

    if normalized_scope and normalized_scope not in (
        models.PROMPT_TEMPLATE_SCOPE_AGENT,
        models.PROMPT_TEMPLATE_SCOPE_GLOBAL,
    ):
        raise ValueError(
            f'scope must be one of "{models.PROMPT_TEMPLATE_SCOPE_AGENT},'
            f'{models.PROMPT_TEMPLATE_SCOPE_GLOBAL}"'
        )

    if (
        normalized_scope == models.PROMPT_TEMPLATE_SCOPE_GLOBAL
        and normalized_visibility == models.PROMPT_TEMPLATE_VISIBILITY_PUBLIC
    ):
        raise ValueError("public templates must have scope agent")

    if (
        normalized_visibility == models.PROMPT_TEMPLATE_VISIBILITY_PUBLIC
        and not normalized_agent_id
    ):
        raise ValueError("agent_id is required")

    if (
        not normalized_scope or normalized_scope == models.PROMPT_TEMPLATE_SCOPE_AGENT
    ) and not normalized_agent_id:
        raise ValueError("agent_id is required")


def _update_payload(
    *,
    name: str | None = None,
    description: str | None = None,
    content: str | None = None,
    enabled: bool | None = None,
    visibility: str | None = None,
) -> api_models.InputUpdatePromptTemplateRequest:
    updates = {
        key: value
        for key, value in {
            "name": name,
            "description": description,
            "content": content,
            "enabled": enabled,
            "visibility": visibility,
        }.items()
        if value is not None
    }
    if not updates:
        raise ValueError(
            "at least one of name, description, content, enabled, or visibility must be provided"
        )
    if (
        "visibility" in updates
        and updates["visibility"] != models.PROMPT_TEMPLATE_VISIBILITY_PUBLIC
    ):
        raise ValueError(f'visibility must be one of "{models.PROMPT_TEMPLATE_VISIBILITY_PUBLIC}"')
    return api_models.InputUpdatePromptTemplateRequest.model_construct(
        _fields_set=set(updates),
        name=updates.get("name"),
        description=updates.get("description"),
        content=updates.get("content"),
        enabled=updates.get("enabled"),
        visibility=updates.get("visibility"),
    )


@mcp_setting(mutating=True)
@_apis.login_required
def create_prompt_template(
    project_id: str,
    visibility: str,
    scope: str,
    name: str,
    content: str,
    description: str | None = None,
    agent_id: str | None = None,
) -> models.PromptTemplate:
    """Create a prompt template in a project."""
    payload = _create_payload(
        project_id=project_id,
        visibility=visibility,
        scope=scope,
        name=name,
        content=content,
        description=description,
        agent_id=agent_id,
    )
    response = _prompt_templates_api().create_prompt_template(payload)
    if not response.data:
        raise RuntimeError(
            "Received malformed response (missing `data`) from create_prompt_template"
        )
    return _to_prompt_template(response.data)


@mcp_setting(mutating=True)
@_apis.login_required
def update_prompt_template(
    template_id: str,
    *,
    name: str | None = None,
    description: str | None = None,
    content: str | None = None,
    enabled: bool | None = None,
    visibility: str | None = None,
) -> models.PromptTemplate:
    """Update provided mutable fields on a prompt template."""
    payload = _update_payload(
        name=name,
        description=description,
        content=content,
        enabled=enabled,
        visibility=visibility,
    )
    response = _prompt_templates_api().update_prompt_template(template_id, payload)
    if not response.data:
        raise RuntimeError(
            "Received malformed response (missing `data`) from update_prompt_template"
        )
    return _to_prompt_template(response.data)


@_apis.login_required
def get_prompt_template(template_id: str) -> models.PromptTemplate:
    """Get a prompt template by id."""
    response = _prompt_templates_api().get_prompt_template(template_id)
    if not response.data:
        raise RuntimeError("Received malformed response (missing `data`) from get_prompt_template")
    return _to_prompt_template(response.data)


@mcp_setting(mutating=True)
@_apis.login_required
def delete_prompt_template(template_id: str) -> None:
    """Delete a prompt template by id."""
    _prompt_templates_api().delete_prompt_template(template_id)


@_apis.login_required
def get_prompt_templates(
    project_id: str,
    agent_id: str | None = None,
    visibility: str | None = None,
    scope: str | None = None,
    sort_type: str | None = None,
    sort_order: str | None = None,
    limit: int | None = None,
) -> Generator[models.PromptTemplate, None, None]:
    """List prompt templates matching the specified filters.

    :param project_id: Project id
    :param agent_id: Agent configuration component base id. Required unless
        ``scope`` is ``global``.
    :param visibility: Optional visibility filter (public or private)
    :param scope: Optional scope filter (agent or global). When omitted, treated
        as agent scope and ``agent_id`` is required.
    :param sort_type: Optional sort field (created_at or visibility)
    :param sort_order: Optional sort order (ASC or DESC)
    :param limit: Maximum number of results to return
    :rtype: Generator[models.PromptTemplate, None, None]
    :raises ValueError: If required filters are missing or invalid.
    """
    _validate_list_params(agent_id=agent_id, visibility=visibility, scope=scope)
    params = {
        k: v
        for k, v in {
            "project_id": project_id,
            "agent_id": agent_id,
            "visibility": visibility,
            "scope": scope,
            "sort_type": sort_type,
            "sort_order": sort_order,
        }.items()
        if v is not None
    }
    response = _prompt_templates_api().list_prompt_templates(**params)
    if not response.data:
        return

    yielded = 0
    for item in response.data:
        yield _to_prompt_template(item)
        yielded += 1
        if limit is not None and yielded >= limit:
            return

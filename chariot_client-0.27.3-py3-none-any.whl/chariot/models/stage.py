from enum import Enum

from chariot import _apis
from chariot import mcp_setting
from chariot.models import Model

from chariot_api._openapi.models.models.input_create_model_stage import InputCreateModelStage


class Stage(Enum):
    """Possible Model Stages
    These values correspond to the ones defined in models-catalog
    https://github.com/Striveworks/chariot/blob/main/go/apps/models-catalog/pkg/constants/model_stage.go#L5-L8
    # TODO consume these from json/yaml config file instead of hard coding.
    """

    STAGING = "staging"
    PRODUCTION = "production"


@_apis.login_required
def set_stage(model: Model, stage: Stage) -> None:
    """Set the stage of a given model.

    To set the model stage, an inference server must exist for the given model.

    :param model:
    :param stage:
    """
    _apis.models.models_api.projects_project_stage_put(
        project=model.project_id,
        body=InputCreateModelStage(model_id=model.id, model_stage=stage.value),
    )


@_apis.login_required
def get_active_stages(model: Model):
    """Function to get the currently active model stages and a list of archived model versions.
    :param model:
    """
    return _apis.models.models_api.projects_project_stage_name_slug_get(
        project=model.project_id, name_slug=model.name_slug
    ).data.to_dict()


@_apis.login_required
def get_stage_history(model: Model, offset=0, limit=10) -> list:
    """Function to get a paginated history or stage changes for a given model name.
    :param model:
    :param offset:
    :param limit:
    """
    res = _apis.models.models_api.projects_project_stage_name_slug_history_get(
        project=model.project_id, name_slug=model.name_slug, offset=offset, limit=limit
    )
    return [row.to_dict() for row in res.data.history]

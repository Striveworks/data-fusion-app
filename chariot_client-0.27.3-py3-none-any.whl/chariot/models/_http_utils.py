import gzip
import json
from io import BytesIO
from typing import Any

import requests
from requests.adapters import HTTPAdapter
from requests.structures import CaseInsensitiveDict
from urllib3 import Retry

from chariot.config import get_bearer_token, settings
from chariot.models.enum import ArtifactType

DEFAULT_MAX_RETRIES = 5


def join_url(*parts: str) -> str:
    """Join URL fragments without duplicating slashes."""
    if not parts:
        return ""
    result = parts[0]
    for part in parts[1:]:
        result = result.rstrip("/") + "/" + part.lstrip("/")
    return result


def _get_session(**kwargs):
    adapter = HTTPAdapter(
        max_retries=Retry(
            total=kwargs.get("max_retries", DEFAULT_MAX_RETRIES),
            connect=kwargs.get("max_retries", DEFAULT_MAX_RETRIES),
            read=kwargs.get("max_retries", DEFAULT_MAX_RETRIES),
            status=kwargs.get("max_retries", DEFAULT_MAX_RETRIES),
            allowed_methods=None,  # retry on any method
            backoff_factor=1.5,
            status_forcelist=[429, 500, 502, 503, 504],  # Target these return status calls
        )
    )

    session = requests.Session()
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    session.headers["Authorization"] = f"Bearer {get_bearer_token()}"

    return session


def _post_http_request(
    url: str, body: bytes, headers: dict[str, str] | None = None, timeout: int | None = None
):
    try:
        session = _get_session()
        response = session.post(
            url,
            verify=settings.verify_ssl,
            data=body,
            headers=headers,
            timeout=timeout,
        )
        response.raise_for_status()
        return response
    except requests.exceptions.HTTPError as e:
        raise RuntimeError(f"Inference request failed: {e} {e.response.text}")


def _post_request(
    url,
    payload,
    artifact_type: ArtifactType,
    timeout=None,
    **kwargs,
) -> tuple[Any, CaseInsensitiveDict]:
    try:
        session = _get_session(**kwargs)
        preds = session.post(url, verify=settings.verify_ssl, json=payload, timeout=timeout)
        preds.raise_for_status()
        if artifact_type == ArtifactType.HUGGINGFACE:
            try:
                buf = BytesIO(preds.content)
                gzip_f = gzip.GzipFile(fileobj=buf)
                content = gzip_f.read()
                return json.loads(content.decode()), preds.headers
            # TODO clean up when moving to teddy doing inference.
            # Right now it appers only text-classification and small token-classification don't gzip.
            except gzip.BadGzipFile:
                return preds.json(), preds.headers
        else:
            return preds.json(), preds.headers
    except requests.exceptions.HTTPError as e:
        raise RuntimeError(f"Inference request failed: {e} {e.response.text}")

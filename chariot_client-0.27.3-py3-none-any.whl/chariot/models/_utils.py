import re
from pathlib import Path
from types import TracebackType
from typing import Self

import tqdm
import urllib3
import urllib3.util.retry
from urllib3.connectionpool import ConnectionPool
from urllib3.response import BaseHTTPResponse

from chariot.config import getLogger

log = getLogger(__name__)


class LoggingRetry(urllib3.util.retry.Retry):
    def increment(
        self,
        method: str | None = None,
        url: str | None = None,
        response: BaseHTTPResponse | None = None,
        error: Exception | None = None,
        _pool: ConnectionPool | None = None,
        _stacktrace: TracebackType | None = None,
    ) -> Self:
        new_retry = super().increment(
            method=method,
            url=url,
            response=response,
            error=error,
            _pool=_pool,
            _stacktrace=_stacktrace,
        )
        attempt = len(new_retry.history)
        total = self.total
        status = getattr(response, "status", None)
        log.warning(
            f"Retrying {method} request to {url} "
            f"(attempt {attempt}/{total}) due to {error or f'status {status}'}"
        )
        return new_retry


_DEFAULT_RETRY = LoggingRetry(
    total=10,
    allowed_methods=["PUT"],
    status_forcelist=frozenset({408, 425, 429, 500, 502, 503, 504}),
    backoff_factor=0.1,
    backoff_jitter=0.1,
    backoff_max=30,
    raise_on_status=True,
)


def _upload_parts(
    file_path: str,
    signed_urls: list[str],
    part_size: int,
    retries: urllib3.util.retry.Retry | None = _DEFAULT_RETRY,
    show_progress: bool = False,
):
    pool_manager = urllib3.PoolManager(retries=retries)
    etags: list[str] = []
    if show_progress:
        iterator = tqdm.tqdm(signed_urls, "Multipart upload progress")
    else:
        iterator = signed_urls
    with open(file_path, "rb") as fp:
        for idx, url in enumerate(iterator, start=1):
            part = fp.read(part_size)
            if not part:
                break  # no more data
            resp = pool_manager.request("PUT", url, body=part)
            # grab the ETag (case‐insensitive)
            etag = resp.headers.get("etag")
            if etag is None:
                raise RuntimeError(f"No ETag returned for part {idx}")
            etags.append(etag.replace('"', ""))
    return etags


## Functions to support engine readme metadata
DEFAULT_ENGINE_README_FILENAME = "ENGINE-README.md"
DEFAULT_ENGINE_SUMMARY_MAX_BYTES = 1000
_SUMMARY_RE = re.compile(r"(?m)^##\sSummary\s*([\s\S]*?)\s*(?=#)")


def resolve_engine_readme_path(
    base_dir: str | Path,
    filename: str = DEFAULT_ENGINE_README_FILENAME,
) -> Path | None:
    base_path = Path(base_dir)
    path = base_path / filename
    if path.is_file():
        return path
    return None


def _extract_summary_from_readme(readme: str) -> str | None:
    if not readme:
        return None

    match = _SUMMARY_RE.search(readme)
    if not match:
        return None

    return match.group(1).strip()


def _normalize_summary(text: str, max_bytes: int | None) -> str | None:
    normalized = " ".join(text.split())
    if not normalized:
        return None

    if max_bytes is not None:
        encoded = normalized.encode("utf-8")
        # Truncate the summary to the maximum number of bytes
        if len(encoded) > max_bytes:
            truncated = encoded[:max_bytes]
            while truncated:
                try:
                    normalized = truncated.decode("utf-8")
                    break
                except UnicodeDecodeError:
                    truncated = truncated[:-1]
            else:
                return None

    return normalized


def extract_engine_summary(
    readme: str,
    max_bytes: int | None = DEFAULT_ENGINE_SUMMARY_MAX_BYTES,
) -> str | None:
    if summary := _extract_summary_from_readme(readme):
        return _normalize_summary(summary, max_bytes)

    return None


def load_engine_readme_metadata(
    *,
    readme_path: str | Path | None = None,
    base_dir: str | Path | None = None,
    max_summary_bytes: int | None = DEFAULT_ENGINE_SUMMARY_MAX_BYTES,
) -> tuple[str | None, str | None]:
    path: Path | None
    if readme_path is not None:
        path = Path(readme_path)
        if not path.is_file():
            raise FileNotFoundError(path)
    elif base_dir is not None:
        path = resolve_engine_readme_path(base_dir)
        if path is None:
            return None, None
    else:
        raise ValueError("Either readme_path or base_dir must be provided.")

    readme = path.read_text(encoding="utf-8")
    return readme, extract_engine_summary(readme, max_bytes=max_summary_bytes)

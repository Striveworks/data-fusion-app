import base64
import json
from enum import Enum
from typing import Any

import numpy as np
from PIL import Image

from chariot.models._serial import pil_to_bytes

# Type aliases to make the code more readable
KServeDataShape = list[int]
KServeInferenceInput = dict


class KServeDataType(Enum):
    """See: https://github.com/SeldonIO/MLServer/blob/c85b1d05589aae5fd8f4ae58d182e8b815e340cb/mlserver/codecs/numpy.py#L12"""

    BOOL = "BOOL"
    UINT8 = "UINT8"
    UINT16 = "UINT16"
    UINT32 = "UINT32"
    UINT64 = "UINT64"
    INT8 = "INT8"
    INT16 = "INT16"
    INT32 = "INT32"
    INT64 = "INT64"
    FP16 = "FP16"
    FP32 = "FP32"
    FP64 = "FP64"
    BYTES = "BYTES"


def single_kserve_input(
    name: str, datatype: KServeDataType, shape: KServeDataShape, data: Any, parameters: Any = None
) -> KServeInferenceInput:
    rval = {
        "name": name,
        "shape": shape,
        "datatype": datatype.name,
        "data": data,
    }
    if parameters is not None:
        rval["parameters"] = parameters

    return rval


class MLServerNumpyCodec:
    """Light copy of mlserver.codecs.NumpyCodec"""

    _DatatypeToNumpy = {
        KServeDataType.BOOL.name: "bool",
        KServeDataType.UINT8.name: "uint8",
        KServeDataType.UINT16.name: "uint16",
        KServeDataType.UINT32.name: "uint32",
        KServeDataType.UINT64.name: "uint64",
        KServeDataType.INT8.name: "int8",
        KServeDataType.INT16.name: "int16",
        KServeDataType.INT32.name: "int32",
        KServeDataType.INT64.name: "int64",
        KServeDataType.FP16.name: "float16",
        KServeDataType.FP32.name: "float32",
        KServeDataType.FP64.name: "float64",
        KServeDataType.BYTES.name: "bytes",
    }

    @classmethod
    def to_ndarray(cls, output: dict) -> np.ndarray:
        data = output["data"]
        dtype = cls._DatatypeToNumpy[output["datatype"]]
        return np.array(data, dtype)

    @classmethod
    def reshape_to_numpy(cls, output: dict) -> np.ndarray:
        data = cls.to_ndarray(output)
        shape = output["shape"]
        reshaped = data.reshape(shape)

        if shape[-1] == 1:
            # MLServer appears to add an extra dimension when serializing singleton arrays
            reshaped = reshaped.squeeze(-1)

        return reshaped


class HuggingfaceModelType(Enum):
    """Model types for huggingface model."""

    IMAGE = "image"  # Huggingface image model
    TEXT = "text"  # Huggingface text model


class HuggingfaceContentType(Enum):
    """Different content types for huggingface model args/kwargs.
    See: MLServer/runtimes/huggingface/mlserver_huggingface/codecs
    Each class has a ContentType attr.
    """

    HG_JSON = "hg_json"  # json object
    HG_JSONLIST = "hg_jsonlist"  # list of json objects
    PILLOW_IMAGE = "pillow_image"  # PIL.Image object
    RAW = "raw"  # raw objects (bool, float, int)
    STR = "str"  # strings


class HuggingfaceInputs:
    @classmethod
    def _get_content_type_datatype_and_shape(
        cls, sample: Any
    ) -> tuple[HuggingfaceContentType | None, KServeDataType, KServeDataShape]:
        """Return the content_type, KServeDataType, and shape for a given input.
        The content_type determines how mlserver_huggingface will deserialize
        the value.

        The cases here are not exhaustive; mlserver supports more types,
        including PIL and np.ndarray. We can implement those as necessary here.
        """
        if isinstance(sample, str):
            # Legacy behavior is to not specify content_type for string inputs
            return None, KServeDataType.BYTES, [1]
        if isinstance(sample, dict):
            return HuggingfaceContentType.HG_JSON, KServeDataType.BYTES, [1]
        if isinstance(sample, list) and len(sample) > 0:
            if isinstance(sample[0], dict):
                return HuggingfaceContentType.HG_JSONLIST, KServeDataType.BYTES, [len(sample)]
            if isinstance(sample[0], Image.Image):
                if len(sample) > 1:
                    raise ValueError(
                        "Huggingface models do not currently support image batches "
                        "of size greater than one."
                    )
                return HuggingfaceContentType.PILLOW_IMAGE, KServeDataType.BYTES, [1]
            if isinstance(sample[0], str):
                return HuggingfaceContentType.HG_JSONLIST, KServeDataType.BYTES, [len(sample)]
        if isinstance(sample, bool):
            return HuggingfaceContentType.RAW, KServeDataType.INT8, [1]
        if isinstance(sample, int):
            return HuggingfaceContentType.RAW, KServeDataType.INT64, [1]
        if isinstance(sample, float):
            return HuggingfaceContentType.RAW, KServeDataType.FP64, [1]
        if isinstance(sample, type(None)):
            return HuggingfaceContentType.RAW, KServeDataType.BYTES, [1]
        if isinstance(sample, Image.Image):
            return HuggingfaceContentType.PILLOW_IMAGE, KServeDataType.BYTES, [1]
        raise NotImplementedError(
            f"Arguments of type {type(sample)} are not yet supported for huggingface models."
        )

    @classmethod
    def _serialize_content(
        cls,
        content: Any,
        content_type: HuggingfaceContentType | None,
        model_type: HuggingfaceModelType,
    ) -> Any:
        """Serialize content based on its type. The `str` and `raw` content
        types are just passed through.
        """
        if content_type == HuggingfaceContentType.PILLOW_IMAGE:
            content_list = content if isinstance(content, list) else [content]
            return [
                base64.b64encode(pil_to_bytes(single_content)).decode()
                for single_content in content_list
            ]
        if content_type == HuggingfaceContentType.HG_JSON:
            return [json.dumps(content)]
        if content_type == HuggingfaceContentType.HG_JSONLIST:
            return [json.dumps(content)]
        if model_type == HuggingfaceModelType.IMAGE:
            with open(content, "rb") as f:
                img_bytes = f.read()
            encoded_img = base64.b64encode(img_bytes)
            return [encoded_img.decode()]
        if model_type == HuggingfaceModelType.TEXT:
            return [content]
        return [content]

    @classmethod
    def encode_inference_request(
        cls, model_type: HuggingfaceModelType, action: str | None = None, *args, **kwargs
    ):
        """Build mlserver_huggingface compatible inputs. This allows
        for passing of input types other than strings to huggingface models.

        TODO: This function should be refactored or better documented. Passing
        via args and kwargs alone is confusing.
        """
        inputs = []
        if len(args) > 1:
            raise ValueError(
                "Can only send single positional inference argument to huggingface models"
            )

        for arg in args:
            content_type, data_type, shape = cls._get_content_type_datatype_and_shape(arg)
            serialized = cls._serialize_content(
                arg, content_type=content_type, model_type=model_type
            )
            parameters = {"content_type": content_type.value} if content_type else {}
            if action is not None:
                parameters["action"] = action

            inputs.append(
                single_kserve_input(
                    name="args",
                    shape=shape,
                    datatype=data_type,
                    data=serialized,
                    parameters=parameters,
                )
            )
        for k, v in kwargs.items():
            content_type, data_type, shape = cls._get_content_type_datatype_and_shape(v)
            serialized = cls._serialize_content(v, content_type=content_type, model_type=model_type)
            parameters = {"content_type": content_type.value} if content_type else {}
            if action is not None:
                parameters["action"] = action

            inputs.append(
                single_kserve_input(
                    name=k, shape=shape, datatype=data_type, data=serialized, parameters=parameters
                )
            )
        return inputs

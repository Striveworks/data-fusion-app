from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Literal, NotRequired

from typing_extensions import TypedDict

from chariot import _apis, mcp_setting
from chariot_api._openapi.models import models as models_api
from chariot_api._openapi.models.api.inference_engine_api import InferenceEngineApi
from chariot_api._openapi.models.exceptions import NotFoundException

__all__ = [
    "EngineSelector",
    "EnvVar",
    "InferenceEngine",
    "InferenceEngineVersion",
    "ReadinessProbe",
    "EnvVarSchema",
    "add_supported_engine",
    "create_engine_version",
    "delete_engine_version",
    "get_engine_version_by_selector",
    "get_engine_versions",
    "get_engine_versions_with_count",
    "get_supported_engines",
    "patch_engine_version",
    "remove_supported_engine",
    "set_default_engine_version",
]

_MAX_ENGINE_VERSION_README_BYTES = 8 * 1024 * 1024
_MAX_ENGINE_VERSION_SUMMARY_BYTES = 1000


@dataclass
class InferenceEngine:
    """An inference engine."""

    engine_id: str
    project_id: str
    name: str


class EnvVar(TypedDict):
    """An environment variable to be set in the engine container."""

    name: str
    value: NotRequired[str]


class EnvVarSchema(TypedDict):
    """A configurable parameter for this engine."""

    name: str
    type: Literal["string", "float", "int", "bool", "secret"]
    display_text: NotRequired[str]
    enum: NotRequired[list[str]]
    default_value: NotRequired[str]
    units: NotRequired[str]
    required: NotRequired[bool]


@dataclass
class ReadinessProbe:
    """Readiness probe config."""

    path: str
    port: int
    initial_delay_seconds: int
    timeout_seconds: int
    period_seconds: int
    success_threshold: int
    failure_threshold: int


@dataclass
class InferenceEngineVersion:
    """An inference engine version."""

    engine_version_id: str
    engine_id: str
    user_id: str
    project_id: str
    created_at: datetime
    name: str
    version: str
    container_registry_secret: str
    container_image_cpu: str
    container_image_gpu: str
    entrypoint: list[str] | None
    command: list[str] | None
    env: list[EnvVar]
    predictor_env_schema: list[EnvVarSchema]
    enforce_predictor_env_schema: bool
    readme: str
    summary: str
    icon: str
    container_root_relative_base_url: str
    readiness_probe: ReadinessProbe
    is_default: bool
    inference_protocol: str | None
    container_model_mount_path: str
    supports_multi_gpu: bool = field(default=False)


@dataclass
class EngineSelector:
    """The data needed to specify a unique inference engine."""

    org_name: str
    project_name: str
    engine_name: str


def _inference_engine_api() -> InferenceEngineApi:
    return _apis.models.inference_engine_api


@mcp_setting(mutating=True)
@_apis.login_required
def create_engine_version(
    name: str,
    project_id: str,
    version: str,
    readiness_probe: ReadinessProbe,
    container_registry_secret: str | None = None,
    container_image_cpu: str | None = None,
    container_image_gpu: str | None = None,
    entrypoint: list[str] | None = None,
    command: list[str] | None = None,
    env: list[EnvVar] | None = None,
    predictor_env_schema: list[EnvVarSchema] | None = None,
    enforce_predictor_env_schema: bool = False,
    readme: str | None = None,
    summary: str | None = None,
    icon: str | None = None,
    container_root_relative_base_url: str = "/",
    inference_protocol: str | None = None,
    container_model_mount_path: str | None = None,
    is_default: bool = False,
    supports_multi_gpu: bool = False,
) -> str:
    """Create an inference engine."""
    openapi_envs = [models_api.EnvVar(**env_var) for env_var in env or []]
    openapi_predictor_env_schema = [
        models_api.EnvVarSchema(**env_schema) for env_schema in predictor_env_schema or []
    ]

    return (
        _inference_engine_api()
        .inference_engines_post(
            body=models_api.CreateEnginePostRequest(
                name=name,
                project_id=project_id,
                version=version,
                readme=readme,
                summary=summary,
                icon=icon,
                entrypoint=entrypoint,
                command=command,
                env=openapi_envs,
                container_image_cpu=container_image_cpu,
                container_image_gpu=container_image_gpu,
                container_registry_secret=container_registry_secret,
                predictor_env_schema=openapi_predictor_env_schema,
                enforce_predictor_env_schema=enforce_predictor_env_schema,
                container_root_relative_base_url=container_root_relative_base_url,
                readiness_probe=models_api.ReadinessProbe(**asdict(readiness_probe)),
                inference_protocol=inference_protocol,
                container_model_mount_path=container_model_mount_path,
                is_default=is_default,
                supports_multi_gpu=supports_multi_gpu,
            )
        )
        .data.id
    )


@mcp_setting(mutating=True)
@_apis.login_required
def delete_engine_version(engine_version_id: str) -> str:
    """Delete an inference engine."""
    return _inference_engine_api().inference_engines_engine_version_id_delete(
        engine_version_id=engine_version_id
    )


@_apis.login_required
def get_engine_versions_with_count(
    project_ids: list[str] | None = None,
    engine_names: list[str] | None = None,
    engine_ids: list[str] | None = None,
    engine_version_ids: list[str] | None = None,
    default_versions_only: bool = False,
    fuzzy_engine_version: str | None = None,
    inference_protocol: str | None = None,
    user_id: str | None = None,
    supports_multi_gpu: bool | None = None,
    limit: int = 100,
    offset: int = 0,
) -> tuple[list[InferenceEngineVersion], int]:
    """Get inference engines together with a total count."""
    response = _inference_engine_api().inference_engines_get_with_http_info(
        project_ids=",".join(project_ids) if project_ids else None,
        engine_names=",".join(engine_names) if engine_names else None,
        engine_ids=",".join(engine_ids) if engine_ids else None,
        engine_version_ids=",".join(engine_version_ids) if engine_version_ids else None,
        default_versions_only=default_versions_only,
        fuzzy_engine_version=fuzzy_engine_version,
        inference_protocol=inference_protocol,
        user_id=user_id,
        supports_multi_gpu=supports_multi_gpu,
        limit=limit,
        offset=offset,
    )
    if not response.headers:
        count = 0
    else:
        count = int(
            response.headers.get("X-Record-Count", response.headers.get("x-record-count", 0))
        )

    def make_engine_version(d):
        readiness_probe_dict = d.pop("readiness_probe", {})
        readiness_probe = ReadinessProbe(**readiness_probe_dict)
        created_at = datetime.fromisoformat(d.pop("created_at"))
        return InferenceEngineVersion(readiness_probe=readiness_probe, created_at=created_at, **d)

    return [
        make_engine_version({"inference_protocol": None, **api_engine_version.model_dump()})
        for api_engine_version in response.data.data
    ], count


@_apis.login_required
def get_engine_versions(
    project_ids: list[str] | None = None,
    engine_names: list[str] | None = None,
    engine_ids: list[str] | None = None,
    engine_version_ids: list[str] | None = None,
    default_versions_only: bool = False,
    fuzzy_engine_version: str | None = None,
    inference_protocol: str | None = None,
    user_id: str | None = None,
    supports_multi_gpu: bool | None = None,
    limit: int = 100,
    offset: int = 0,
) -> list[InferenceEngineVersion]:
    """Get inference engines."""
    engine_versions, _ = get_engine_versions_with_count(
        project_ids,
        engine_names,
        engine_ids,
        engine_version_ids,
        default_versions_only,
        fuzzy_engine_version,
        inference_protocol,
        user_id,
        supports_multi_gpu,
        limit,
        offset,
    )
    return engine_versions


@mcp_setting(mutating=True)
@_apis.login_required
def set_default_engine_version(engine_version_id: str) -> None:
    """Set or clear the default version for an engine."""
    _inference_engine_api().inference_engines_engine_version_id_default_put(
        engine_version_id=engine_version_id
    )


@mcp_setting(mutating=True)
@_apis.login_required
def add_supported_engine(
    model_id: str,
    selector: str | EngineSelector,
) -> None:
    """Add a supported inference engine to a model."""
    match selector:
        case EngineSelector(org_name=org_name, project_name=project_name, engine_name=engine_name):
            engine_id = None
        case str(engine_id):
            org_name, project_name, engine_name = None, None, None

    _inference_engine_api().models_model_id_inference_engines_post(
        model_id=model_id,
        body=models_api.AddSupportedInferenceEnginePostRequest(
            engine_id=engine_id,
            org_name=org_name,
            project_name=project_name,
            engine_name=engine_name,
        ),
    )


@mcp_setting(mutating=True)
@_apis.login_required
def remove_supported_engine(
    model_id: str,
    selector: str | EngineSelector,
) -> None:
    """Remove a supported inference engine to a model."""
    match selector:
        case EngineSelector(org_name=org_name, project_name=project_name, engine_name=engine_name):
            engine_id = None
        case str(engine_id):
            org_name, project_name, engine_name = None, None, None

    _inference_engine_api().models_model_id_inference_engines_delete(
        model_id=model_id,
        body=models_api.RemoveSupportedInferenceEngine(
            engine_id=engine_id,
            org_name=org_name,
            project_name=project_name,
            engine_name=engine_name,
        ),
    )


@_apis.login_required
def get_supported_engines(model_id: str) -> list[InferenceEngine]:
    """Get the supported inference engines for a model."""
    return [
        InferenceEngine(**engine.model_dump())
        for engine in _inference_engine_api()
        .models_model_id_inference_engines_get(model_id=model_id)
        .data
        or []
    ]


@_apis.login_required
def get_engine_version_by_selector(
    org_name: str, project_name: str, engine_name: str, version: str | None = None
) -> InferenceEngineVersion | None:
    """Resolve an engine selector."""
    try:
        engine_version = (
            _inference_engine_api()
            .inference_engines_selector_get(
                org_name=org_name,
                project_name=project_name,
                engine_name=engine_name,
                version=version,
            )
            .data
        )
    except NotFoundException:
        return None

    return InferenceEngineVersion(**engine_version.model_dump())


def _validate_patch_engine_version_lengths(summary: str | None, readme: str | None) -> None:
    if summary is not None and len(summary.encode("utf-8")) > _MAX_ENGINE_VERSION_SUMMARY_BYTES:
        raise ValueError(f"summary must be at most {_MAX_ENGINE_VERSION_SUMMARY_BYTES} bytes")

    if readme is not None and len(readme.encode("utf-8")) > _MAX_ENGINE_VERSION_README_BYTES:
        raise ValueError(f"readme must be at most {_MAX_ENGINE_VERSION_README_BYTES} bytes")


@mcp_setting(mutating=True)
@_apis.login_required
def patch_engine_version(
    engine_version_id: str,
    summary: str | None = None,
    readme: str | None = None,
    is_default: bool | None = None,
) -> None:
    """Patch an engine version."""
    if summary is None and readme is None and is_default is None:
        raise ValueError("At least one patch value must be provided.")
    _validate_patch_engine_version_lengths(summary, readme)

    _inference_engine_api().inference_engines_engine_version_id_patch(
        engine_version_id=engine_version_id,
        body=models_api.PatchEngineVersionParams(
            summary=summary,
            readme=readme,
            is_default=is_default,
        ),
    )


# For backwards compatibility:
_create_engine_version = create_engine_version
_delete_engine_version = delete_engine_version
_get_engine_versions_with_count = get_engine_versions_with_count
_get_engine_versions = get_engine_versions
_set_default_engine_version = set_default_engine_version
_add_supported_engine = add_supported_engine
_remove_supported_engine = remove_supported_engine
_get_supported_engines = get_supported_engines
_get_engine_version_by_selector = get_engine_version_by_selector
_patch_engine_version = patch_engine_version

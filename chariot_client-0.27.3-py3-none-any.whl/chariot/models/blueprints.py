from dataclasses import dataclass

from chariot import _apis, mcp_setting
from chariot_api._openapi.models import models as models_api
from chariot_api._openapi.models.api.blueprints_api import BlueprintsApi

__all__ = [
    "SupportedBlueprint",
    "add_supported_blueprint",
    "get_supported_blueprints",
    "remove_supported_blueprint",
]


@dataclass
class SupportedBlueprint:
    """The data needed to specify a training blueprint that a model has been associated with."""

    project_id: str
    name: str
    blueprint_id: str | None


def _blueprints_api() -> BlueprintsApi:
    return _apis.models.blueprints_api


@mcp_setting(mutating=True)
@_apis.login_required
def add_supported_blueprint(
    model_id: str,
    blueprint: SupportedBlueprint,
) -> None:
    """Associate a training blueprint with a model."""
    _blueprints_api().models_model_id_supported_blueprints_post(
        model_id=model_id,
        body=models_api.AddSupportedBlueprintPostRequest(
            blueprint_id=blueprint.blueprint_id,
            project_id=blueprint.project_id,
            name=blueprint.name,
        ),
    )


@mcp_setting(mutating=True)
@_apis.login_required
def remove_supported_blueprint(
    model_id: str,
    blueprint: SupportedBlueprint,
) -> None:
    """Remove a supported blueprints for a model."""
    _blueprints_api().models_model_id_supported_blueprints_delete(
        model_id=model_id,
        body=models_api.RemoveSupportedBlueprintDeleteRequest(
            blueprint_id=blueprint.blueprint_id,
            project_id=blueprint.project_id,
            name=blueprint.name,
        ),
    )


@_apis.login_required
def get_supported_blueprints(model_id: str) -> list[SupportedBlueprint]:
    """Get the supported blueprints for a model."""
    return [
        SupportedBlueprint(**blueprint.model_dump())
        for blueprint in _blueprints_api()
        .models_model_id_supported_blueprints_get(model_id=model_id)
        .data
        or []
    ]

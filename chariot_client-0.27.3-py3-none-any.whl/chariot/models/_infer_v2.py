from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any, TypeAlias, TypedDict

from PIL.Image import Image

from chariot.models._serial import pil_to_bytes
from chariot.models.enum import TaskType as ModelsTaskType
from chariot.models.inference import Action as SDKAction
from inference_protocol import (
    ChatData,
    ChatMessage,
    DataType,
    ImageData,
    InferenceRequest,
    InferenceRequestMetadata,
    ITTTData,
    Protocol,
    RequestMetadataInput,
    TextData,
    TextGenerationCompletionData,
    get_modality,
)
from inference_protocol import (
    TaskType as ProtocolTaskType,
)
from inference_protocol import (
    create_inference_request as protocol_create_inference_request,
)


class ITTTInput(TypedDict):
    image: bytes | Image
    prompts: Sequence[str]


RawInput: TypeAlias = bytes | Image | str | Mapping[str, str] | ITTTInput
RequestInput: TypeAlias = InferenceRequest | RawInput | Sequence[RawInput]


def _normalize_custom_metadata(
    input_count: int,
    custom_metadata: RequestMetadataInput | Sequence[RequestMetadataInput] | None,
) -> Sequence[RequestMetadataInput] | None:
    if custom_metadata is None:
        return None

    if isinstance(custom_metadata, InferenceRequestMetadata) or isinstance(
        custom_metadata, Mapping
    ):
        return [custom_metadata] * input_count

    metadata = list(custom_metadata)
    if len(metadata) != input_count:
        raise ValueError("custom_metadata must be a list of the same length as the inputs")

    return metadata


def _coerce_cv_input(input_: RawInput) -> ImageData:
    match input_:
        case bytes():
            return ImageData(data=input_)
        case Image():
            return ImageData(data=pil_to_bytes(input_))
        case _:
            raise TypeError(f"Unsupported input type: {type(input_)}")


def _normalize_cv_inputs(input_: RequestInput) -> list[ImageData]:
    match input_:
        case bytes() | Image():
            return [_coerce_cv_input(input_)]
        case _ if isinstance(input_, Sequence):
            return [_coerce_cv_input(raw_input) for raw_input in input_]
        case _:
            raise TypeError(f"Unsupported input type: {type(input_)}")


def _coerce_ittt_input(input_: RawInput) -> ITTTData:
    if not isinstance(input_, Mapping):
        raise TypeError(f"Unsupported image-text-to-text input type: {type(input_)}")

    image = input_.get("image")
    prompts = input_.get("prompts")
    if not isinstance(image, bytes | Image):
        raise TypeError(f"Unsupported image-text-to-text image type: {type(image)}")
    if isinstance(prompts, str | bytes) or not isinstance(prompts, Sequence):
        raise TypeError(f"Unsupported image-text-to-text prompts type: {type(prompts)}")
    if not prompts or not all(isinstance(prompt, str) for prompt in prompts):
        raise ValueError("prompts must contain at least one string")

    image_data = image if isinstance(image, bytes) else pil_to_bytes(image)
    return ITTTData(image_data=image_data, prompts=list(prompts))


def _normalize_ittt_inputs(input_: RequestInput) -> list[ITTTData]:
    if isinstance(input_, Mapping):
        return [_coerce_ittt_input(input_)]
    if isinstance(input_, str | bytes) or not isinstance(input_, Sequence):
        raise TypeError(f"Unsupported image-text-to-text input type: {type(input_)}")
    return [_coerce_ittt_input(raw_input) for raw_input in input_]


def _normalize_str_inputs(input_: RequestInput) -> list[str]:
    match input_:
        case str():
            return [input_]
        case _ if isinstance(input_, Sequence):
            text_inputs: list[str] = []
            for raw_input in input_:
                if not isinstance(raw_input, str):
                    raise TypeError(f"Unsupported text input type: {type(raw_input)}")
                text_inputs.append(raw_input)
            return text_inputs
        case _:
            raise TypeError(f"Unsupported text input type: {type(input_)}")


def _normalize_text_inputs(input_: RequestInput) -> list[TextData]:
    return [TextData(text=raw_input) for raw_input in _normalize_str_inputs(input_)]


def _normalize_openai_text_generation_inputs(
    input_: RequestInput, model_name: str | None
) -> list[TextGenerationCompletionData]:
    if model_name is None:
        raise ValueError("model_name is required for OpenAI text-generation inputs")

    return [
        TextGenerationCompletionData(model_name=model_name, text=raw_input)
        for raw_input in _normalize_str_inputs(input_)
    ]


def _coerce_chat_message(input_: RawInput) -> ChatMessage:
    if not isinstance(input_, Mapping):
        raise TypeError(f"Unsupported chat message input type: {type(input_)}")

    return ChatMessage(
        role=input_["role"], content=input_.get("content"), reasoning=input_.get("reasoning")
    )


def _normalize_openai_chat_inputs(input_: RequestInput, model_name: str | None) -> list[ChatData]:
    if model_name is None:
        raise ValueError("model_name is required for OpenAI chat inputs")
    if isinstance(input_, str | bytes) or not isinstance(input_, Sequence):
        raise TypeError(f"Unsupported chat input type: {type(input_)}")

    messages = [_coerce_chat_message(raw_input) for raw_input in input_]
    if len(messages) == 0:
        raise ValueError("expected at least one chat message")
    return [ChatData(model_name=model_name, messages=messages)]


def create_inference_request(
    protocol: Protocol,
    task: ModelsTaskType,
    action: SDKAction | str,
    input_: RequestInput,
    custom_metadata: RequestMetadataInput | Sequence[RequestMetadataInput] | None = None,
    score_threshold: float | None = None,
    model_name: str | None = None,
    **inference_kwargs: Any,
) -> InferenceRequest:
    if isinstance(input_, InferenceRequest):
        if custom_metadata is not None or score_threshold is not None or inference_kwargs:
            raise ValueError(
                "Received `input_` as an `InferenceRequest`, so `custom_metadata`, "
                "`score_threshold`, and extra request parameters cannot be provided here. "
                "Set these when constructing the `InferenceRequest`, or pass raw inputs instead."
            )
        return input_

    protocol_task = ProtocolTaskType(task)

    match get_modality(protocol_task), protocol_task, protocol:
        case _, ProtocolTaskType.IMAGE_TEXT_TO_TEXT, _:
            inputs = _normalize_ittt_inputs(input_)
        case DataType.IMAGE, _, _:
            inputs = _normalize_cv_inputs(input_)
        case (
            DataType.TEXT,
            ProtocolTaskType.CONVERSATIONAL,
            Protocol.OPENAI_V1 | Protocol.CHARIOT_V1_OPENAI,
        ):
            inputs = _normalize_openai_chat_inputs(input_, model_name)
        case (
            DataType.TEXT,
            ProtocolTaskType.TEXT_GENERATION,
            Protocol.OPENAI_V1 | Protocol.CHARIOT_V1_OPENAI,
        ):
            inputs = _normalize_openai_text_generation_inputs(input_, model_name)
        case DataType.TEXT, _, _:
            inputs = _normalize_text_inputs(input_)
        case _:
            raise TypeError(f"Unsupported input type: {type(input_)}")

    return protocol_create_inference_request(
        protocol=protocol,
        task=protocol_task,
        inputs=inputs,
        action=action,
        custom_metadata=_normalize_custom_metadata(len(inputs), custom_metadata),
        score_threshold=score_threshold,
        parameters=inference_kwargs,
    )


__all__ = [
    "RequestInput",
    "create_inference_request",
    "Protocol",
]

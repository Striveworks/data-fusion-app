"""Catalog model-conversion APIs."""

from dataclasses import dataclass
from typing import Any, Literal

from chariot import _apis, mcp_setting
from chariot_api._openapi.models import models as models_api

__all__ = [
    "ModelConversion",
    "TinnieConversionOptions",
    "convert_model",
    "get_model_conversion",
]


@dataclass
class TinnieConversionOptions:
    """Options for converting a model to the Tinnie format."""

    input_width: int | None = None
    input_height: int | None = None
    fixed_shape: bool | None = None
    opset_version: int | None = None
    sample_image: str | None = None


@dataclass
class ModelConversion:
    """A catalog model-conversion job."""

    job_id: str
    status: str | None = None
    project_id: str | None = None
    format: str | None = None
    name: str | None = None
    version: str | None = None


def _to_api_options(
    options: TinnieConversionOptions,
) -> models_api.TinnieConversionOptions:
    return models_api.TinnieConversionOptions(
        **{key: value for key, value in vars(options).items() if value is not None}
    )


def _from_api_conversion(
    conversion: models_api.ModelConversion | None,
) -> ModelConversion:
    if conversion is None or conversion.job_id is None:
        raise ValueError("Model conversion response did not include a job ID")
    return ModelConversion(
        job_id=conversion.job_id,
        status=conversion.status,
        project_id=conversion.project_id,
        format=conversion.format,
        name=conversion.name,
        version=conversion.version,
    )


@mcp_setting(mutating=True)
@_apis.login_required
def convert_model(
    source_model_id: str,
    name: str,
    *,
    target_project_id: str,
    format: Literal["tinnie"] = "tinnie",
    version: str | None = None,
    summary: str | None = None,
    options: TinnieConversionOptions | None = None,
) -> ModelConversion:
    """Submit an asynchronous catalog model conversion.

    Parameters
    ----------
    source_model_id:
        ID of the catalog model to convert.
    name:
        Name of the destination model.
    target_project_id:
        ID of the project in which to create the destination model.
    format:
        Destination model format. Currently only ``"tinnie"`` is supported.
    version:
        Optional destination model version.
    summary:
        Optional destination model summary.
    options:
        Optional Tinnie-specific conversion settings.

    Returns
    -------
    ModelConversion
        The submitted conversion job. Use :func:`get_model_conversion` to retrieve its status.

    """
    request_values: dict[str, Any] = {
        "format": format,
        "name": name,
        "project_id": target_project_id,
    }
    if version is not None:
        request_values["version"] = version
    if summary is not None:
        request_values["summary"] = summary
    if options is not None:
        request_values["options"] = _to_api_options(options)

    response = _apis.models.models_api.models_id_convert_post(
        id=source_model_id,
        body=models_api.ConvertModelRequest(**request_values),
    )
    return _from_api_conversion(response.data)


@_apis.login_required
def get_model_conversion(job_id: str) -> ModelConversion:
    """Get the current status and destination of a model conversion job."""
    response = _apis.models.models_api.models_conversions_job_id_get(job_id=job_id)
    return _from_api_conversion(response.data)

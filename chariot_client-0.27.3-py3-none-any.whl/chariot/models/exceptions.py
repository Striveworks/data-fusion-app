class ModelDoesNotExistError(Exception):
    def __init__(self, model_name: str, version: str | None = None):
        super().__init__(
            f"Model {model_name!r}{(' version ' + version) if version else ''} does not exist or you do not have access."
        )
        self.model_name = model_name
        self.version = version


class ModelUploadTimeoutError(Exception):
    pass


class ActionUnsupportedByCurrentModelError(Exception):
    pass


class NotAnImageError(Exception):
    pass


class InferenceServerFailed(Exception):
    pass


class InferenceServerNotFound(Exception):
    pass

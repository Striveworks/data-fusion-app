import base64
import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from enum import StrEnum
from typing import Any

import numpy as np
import pydantic
from PIL import Image
from requests.structures import CaseInsensitiveDict

import chariot.models._openai as openai_models
from chariot.inference_store.metadata import (
    CustomMetadata,
    map_to_inference_store_metadata,
)
from chariot.models._llm import LLMSamplingParameters
from chariot.models._mlserver import (
    HuggingfaceInputs,
    HuggingfaceModelType,
    KServeDataType,
    KServeInferenceInput,
    MLServerNumpyCodec,
    single_kserve_input,
)
from chariot.models._serial import (
    ChariotDecoder,
    bytes_to_pil,
    is_json_serializable,
    pil_to_bytes,
)
from chariot.models.enum import TaskType, TaskTypesRequirement
from chariot.models.exceptions import NotAnImageError
from chariot.models.inference import Action
from inference_protocol.headers import get_inference_base_id_header


class Protocol(StrEnum):
    CHARIOT_V1 = "chariot-v1"
    CHARIOT_V1_HUGGINGFACE = "chariot-v1-huggingface"
    CHARIOT_V1_TORCHSERVE = "chariot-v1-torchserve"
    CHARIOT_V1_SKLEARN = "chariot-v1-sklearn"
    CHARIOT_V2_KSERVE = "chariot-v2-kserve"
    OPENAI_V1 = "openai-v1"
    CHARIOT_V1_OPENAI = "chariot-v1-openai"


def _apply_labels_to_arr(arr: Any, inverse_class_labels: Mapping[int, str]):
    """Apply inverse class labels to a nested list or dict of integers."""
    if isinstance(arr, int) or isinstance(arr, np.integer):
        return inverse_class_labels[int(arr)]
    elif isinstance(arr, np.ndarray) and arr.ndim == 0:
        return inverse_class_labels[int(arr.item())]
    elif isinstance(arr, dict):
        return {inverse_class_labels[k]: v for k, v in arr.items()}
    elif isinstance(arr, list) or isinstance(arr, np.ndarray):
        return [_apply_labels_to_arr(a, inverse_class_labels) for a in arr]
    else:
        return arr


def _extract_inference_base_id(body: Any, headers: CaseInsensitiveDict) -> str | None:
    header_inference_base_id = get_inference_base_id_header(headers)
    if (
        header_inference_base_id == ""
        and body.get("inference_base_id") is None
        and body.get("id") is None
    ):
        return header_inference_base_id
    return header_inference_base_id or body.get("inference_base_id") or body.get("id")


def handle_output(
    model_name: str,
    protocol: Protocol | str | None,
    task_type: TaskType,
    action: Action,
    inverse_class_labels: Mapping[int, str],
    return_enriched_inference: bool,
    n_inputs: int,
    output: Any,
    headers: CaseInsensitiveDict | None = None,
):
    """Decode kserver output from inference server."""
    headers = headers if headers else CaseInsensitiveDict()
    inference_base_id = _extract_inference_base_id(output, headers)

    if protocol == Protocol.CHARIOT_V1:
        inference = [
            json.loads(data, cls=ChariotDecoder)
            for result in output["outputs"]
            for data in result["data"]
        ]
    else:
        inference = handle_non_chariot_output(
            model_name,
            protocol,
            task_type,
            inverse_class_labels,
            action,
            output,
            n_inputs,
        )

    if return_enriched_inference:
        enriched_inference = {
            "inference_id": inference_base_id,
            "semantic_scores": _get_semantic_scores_from_response(output),
            "inference": inference,
        }

        return enriched_inference
    else:
        return inference


def _get_semantic_scores_from_response(response_data: dict[str, Any]) -> list[float]:
    scores = []
    for o in response_data["outputs"]:
        if parameters := o.get("parameters"):
            if (score := parameters.get("semantic_score")) is not None:
                scores.append(score)
    return scores


HUGGINGFACE_CV_TASK_TYPES = {
    TaskType.IMAGE_CLASSIFICATION,
    TaskType.OBJECT_DETECTION,
    TaskType.IMAGE_SEGMENTATION,
}

LLM_TASK_TYPES = {
    TaskType.TEXT_GENERATION,
    TaskType.CONVERSATIONAL,
}

LABEL_NEEDING_TASK_TYPES = {
    TaskType.IMAGE_CLASSIFICATION,
    TaskType.IMAGE_SEGMENTATION,
    TaskType.TABULAR_CLASSIFICATION,
}

PYTORCH_CV_TASK_TYPES = {
    TaskType.IMAGE_CLASSIFICATION,
    TaskType.OBJECT_DETECTION,
    TaskType.IMAGE_SEGMENTATION,
    TaskType.ORIENTED_OBJECT_DETECTION,
}


def _try_load(data: Any):
    if not isinstance(data, str):
        return data
    try:
        return json.loads(data)
    except json.JSONDecodeError:
        return data


def handle_non_chariot_output(
    model_name: str,
    protocol: Protocol | str | None,
    task_type: TaskType,
    inverse_class_labels: Mapping[int, str],
    action: str,
    resp: Any,
    n_inputs: int,
):
    """Handle inference results from non-chariot models."""
    if protocol == Protocol.CHARIOT_V1_HUGGINGFACE and task_type in HUGGINGFACE_CV_TASK_TYPES:
        return [
            json.loads(data, cls=ChariotDecoder)
            for result in resp["outputs"]
            for data in result["data"]
        ]
    if protocol == Protocol.CHARIOT_V2_KSERVE:
        return [result["data"][0] for result in resp["outputs"]]
    if task_type in LLM_TASK_TYPES:
        return _handle_llm_output(model_name, task_type, action, resp)
    if task_type == TaskType.TEXT_EMBEDDING:
        return _handle_text_embedding_output(resp)

    # Torchserve adds an extra []. In order to match other runtimes with Object Detection
    # and Oriented Object Detection, we have to remove the outer list.
    should_unwrap_single_data_array = protocol == Protocol.CHARIOT_V1_TORCHSERVE
    results = []
    for o_raw in resp["outputs"]:
        # If not bytes, assume it is array
        if o_raw.get("datatype", "") != "BYTES":
            # MLServer returns arrays flattened, this will recover the shape.
            results.append(MLServerNumpyCodec.reshape_to_numpy(o_raw))
        else:
            raw_data = o_raw["data"]
            data = raw_data[0] if should_unwrap_single_data_array else raw_data
            results.append(_try_load(data))

    if n_inputs == 1 and not (
        protocol == Protocol.CHARIOT_V1_TORCHSERVE and task_type in PYTORCH_CV_TASK_TYPES
    ):
        results = results[0]

    # Apply class labels as necessary
    if task_type in LABEL_NEEDING_TASK_TYPES:
        results = _apply_labels_to_arr(results, inverse_class_labels)

    return results


def _handle_llm_output(model_name: str, task_type: TaskType, action: str, resp: dict):
    """Handle inference results from text generation and conversational models."""
    if action == "chat":
        try:
            # OpenAI format
            results = openai_models.ChatCompletionsOutput(**resp)
        except pydantic.ValidationError:
            # mlserver_huggingface format
            data = json.loads(resp["outputs"][0]["data"][0])
            results = openai_models.ChatCompletionsOutput(
                choices=[
                    openai_models.ChatCompletionsChoice(
                        message=openai_models.ChatMessage(role="assistant", content=t)
                    )
                    for t in data["generated_responses"]
                ],
                id=resp["id"],
                model=model_name,
            )

    elif action == "complete":
        try:
            # OpenAI format (future proofing)
            results = openai_models.CompletionsOutput(**resp)
        except pydantic.ValidationError:
            # mlserver_huggingface format
            data = json.loads(resp["outputs"][0]["data"][0])
            results = openai_models.CompletionsOutput(
                choices=[openai_models.CompletionsChoice(text=data["generated_text"])],
                id=resp["id"],
                model=model_name,
            )
    else:
        raise ValueError(f"Action {action} not supported for task type {task_type.value}")
    return results


def create_payload(
    model_id: str,
    protocol: Protocol | str | None,
    task_type: TaskType,
    sample: Any,
    action: str,
    custom_metadata: CustomMetadata | Sequence[CustomMetadata] | None = None,
    score_threshold: float | None = None,
    **kwargs,
) -> dict[str, Any]:
    """For now, only huggingface models accept inference kwargs."""
    match protocol:
        case Protocol.CHARIOT_V1_SKLEARN:
            return {"inputs": _create_structured_data_inputs(sample, action)}
        case Protocol.OPENAI_V1 | Protocol.CHARIOT_V1_OPENAI:
            return _create_openai_inputs(model_id, task_type, sample, **kwargs)
        case Protocol.CHARIOT_V1_HUGGINGFACE:
            return {"inputs": _create_huggingface_inputs(sample, task_type, action, **kwargs)}
        case Protocol.CHARIOT_V1:
            return {
                "inputs": _create_chariot_inputs(
                    task_type, sample, action, custom_metadata, score_threshold=score_threshold
                )
            }
        case Protocol.CHARIOT_V2_KSERVE:
            return {
                "inputs": _create_chariot_v2_kserve_inputs(
                    task_type, sample, action, custom_metadata, score_threshold=score_threshold
                )
            }
        case Protocol.CHARIOT_V1_TORCHSERVE:
            return {
                "inputs": _create_pytorch_inputs(
                    task_type, sample, action, custom_metadata, score_threshold=score_threshold
                )
            }
        case _:
            raise ValueError(
                f"Models using protocol {protocol} are not yet supported for inference."
            )


def _create_structured_data_inputs(sample: Any, action: str) -> list[KServeInferenceInput]:
    if not is_json_serializable(sample):
        raise ValueError(
            f"For {TaskType.TABULAR_CLASSIFICATION.value.lower()} tasks, input data must be json serializable."
        )
    inputs = [
        single_kserve_input(
            name="sample-data",
            datatype=KServeDataType.FP64,
            shape=[len(sample), len(sample[0])],
            data=sample,
            parameters={"action": action},
        )
    ]
    return inputs


def _create_huggingface_inputs(
    sample: Any, task_type: TaskType, action: str | None, **kwargs
) -> list[KServeInferenceInput]:
    """This function creates inputs for Huggingface runtime models based on task type."""
    model_type = HuggingfaceModelType(
        TaskTypesRequirement.get(task_type.value).value["input_modality"]
    )
    action = action if model_type == HuggingfaceModelType.IMAGE else None
    if task_type == TaskType.CONVERSATIONAL:
        try:
            # Validate messages input via pydantic
            chat_input = openai_models.ChatCompletionsInputs(messages=sample)
        except pydantic.ValidationError as e:
            raise ValueError(f"Received incorrect input type for chat inference: {str(e)}")

        sampling_parameters = LLMSamplingParameters(**kwargs).to_huggingface()
        conversations = [m.model_dump(exclude_none=True) for m in chat_input.messages]
        inputs = HuggingfaceInputs.encode_inference_request(
            model_type=model_type,
            action=action,
            conversations=conversations,
            **sampling_parameters,
        )
    elif task_type == TaskType.TEXT_GENERATION:
        try:
            # Validate prompt input via pydantic
            chat_input = openai_models.CompletionsInputs(prompt=sample)
        except pydantic.ValidationError as e:
            raise ValueError(f"Received incorrect input type for completion inference: {str(e)}")
        sampling_parameters = LLMSamplingParameters(**kwargs).to_huggingface()
        inputs = HuggingfaceInputs.encode_inference_request(
            model_type, action, sample, **sampling_parameters
        )
    else:
        inputs = HuggingfaceInputs.encode_inference_request(model_type, action, sample, **kwargs)

    return inputs


def _create_openai_inputs(
    model_id: str, task_type: TaskType, sample: Any, **kwargs
) -> dict[str, Any]:
    """Create inputs for openai-compatible APIs (Only Text Gen and Conversational tasks)"""
    # Validate sampling parameters
    sampling_params = LLMSamplingParameters(**kwargs).to_vllm()
    model = "model"
    if task_type == TaskType.CONVERSATIONAL:
        # Validate messages
        chat_input = openai_models.ChatCompletionsInputs(messages=sample, model=model).model_dump(
            exclude_none=True
        )
        chat_input.update(sampling_params)
        return chat_input
    if task_type == TaskType.TEXT_GENERATION:
        # Validate prompt
        prompt_input = openai_models.CompletionsInputs(prompt=sample, model=model).model_dump(
            exclude_none=True
        )
        prompt_input.update(sampling_params)
        return prompt_input
    else:
        raise ValueError(
            "Creating OpenAI inputs is only valid for Conversational and Text Generation task types"
        )


def _create_chariot_inputs(
    task_type: TaskType,
    sample: Any | list[Any],
    action: str,
    custom_metadata: CustomMetadata | Sequence[CustomMetadata] | None = None,
    score_threshold: float | None = None,
) -> list[KServeInferenceInput]:
    if (
        task_type not in [TaskType.OBJECT_DETECTION, TaskType.ORIENTED_OBJECT_DETECTION]
        and score_threshold is not None
    ):
        raise ValueError(
            "Cannot pass score threshold unless the model is an Object Detection model"
        )
    sample, parameters = _create_parameters_and_sample(
        sample,
        action=action,
        custom_metadata=custom_metadata,
        score_threshold=score_threshold,
    )
    return _create_image_inputs(sample, action, parameters=parameters)


def _create_parameters_and_sample(
    sample: Any | list[Any],
    action: str | None = None,
    custom_metadata: CustomMetadata | Sequence[CustomMetadata] | None = None,
    score_threshold: float | None = None,
) -> tuple[list[Any], list[dict[str, Any]]]:
    if not isinstance(sample, list):
        sample = [sample]

    parameters = {}
    if action is not None:
        parameters["action"] = action

    if score_threshold is not None:
        threshold = {"score_threshold": score_threshold}
        parameters.update(threshold)

        # Add score_threshold to metadata
        if isinstance(custom_metadata, Sequence):
            custom_metadata = [{**m, **threshold} for m in custom_metadata]
        elif isinstance(custom_metadata, Mapping):
            custom_metadata = {**custom_metadata, **threshold}
        else:
            custom_metadata = [threshold for _ in sample]

    parameters = [parameters for _ in sample]

    if custom_metadata is not None:
        if isinstance(custom_metadata, Sequence):
            metadata_strs = [_convert_inference_metadata(meta) for meta in custom_metadata]
        elif isinstance(custom_metadata, Mapping):
            metadata_strs = [_convert_inference_metadata(custom_metadata)]

        if len(sample) != len(metadata_strs):
            raise ValueError("`custom_metadata` must be a list of the same length as the inputs")

        parameters = [{"metadata": m, **p} for m, p in zip(metadata_strs, parameters)]

    return sample, parameters


def _convert_inference_metadata(metadata: CustomMetadata) -> str:
    """Given a dictionary of key:value pairs, return a new dictionary in
    inference store format.
    """
    if not isinstance(metadata, dict):
        return json.dumps({"standard_metadata": {}, "extended_metadata": []})
    return json.dumps(map_to_inference_store_metadata(metadata))


def _create_image_inputs(
    sample: Any | list[Any],
    action: str,
    custom_metadata: CustomMetadata | Sequence[CustomMetadata] | None = None,
    parameters: Mapping[str, Any] | Sequence[Mapping[str, Any] | None] | None = None,
) -> list[KServeInferenceInput]:
    """Chariot inputs are images or batches of images. Optionally, custom metadata
    can be mapped onto the inference inputs.

    NOTE: This function returns a list of KServeInferenceInput(s) irrespective of input batch size.
    """
    if custom_metadata:
        # Overwrites `parameters` if passed
        sample, parameters = _create_parameters_and_sample(
            sample, action=action, custom_metadata=custom_metadata
        )

    if not isinstance(sample, list):
        sample = [sample]

    if not isinstance(parameters, Sequence):
        new_parameters = [parameters for _ in sample]
    else:
        new_parameters = parameters

    return [_create_image_input(s, i=i, parameters=new_parameters[i]) for i, s in enumerate(sample)]


def _encode_image(sample: Any) -> tuple[str, int, int]:
    """Given an image path or PIL image, return the image bytes, width, and height of the image."""
    match sample:
        case str(image_path):
            try:
                with open(image_path, "rb") as f:
                    image_bytes = f.read()
            except FileNotFoundError:
                raise NotAnImageError(f"File not found: {sample}")
            image = bytes_to_pil(image_bytes)
        case Image.Image() as image:
            image_bytes = pil_to_bytes(image)
        case _:
            raise NotAnImageError(f"'sample' must be a string or a PIL Image. Got {type(sample)}.")
    encoded_image = base64.b64encode(image_bytes)
    return encoded_image.decode(), image.width, image.height


def _create_image_input(
    sample: Any,
    i: int = 0,
    parameters: Mapping[str, Any] | None = None,
) -> KServeInferenceInput:
    """Helper function to map input data into a KServeInferenceInput."""
    encoded_img, width, height = _encode_image(sample)

    # Map the data and parameters into a KServeInferenceInput
    return single_kserve_input(
        name=f"input-image-{i}",
        datatype=KServeDataType.BYTES,
        data=[encoded_img],
        # TODO(s.maddox): This is the wrong shape for KServeDataType.BYTES.
        # We can simplify `_encode_image` to not load the image using PIL.
        # See https://chatgpt.com/share/69a0aace-f224-800d-ab4d-0b329814942d
        shape=[height, width, 3],
        parameters=parameters,
    )


def _create_pytorch_inputs(
    task_type: TaskType,
    sample: Any,
    action: str,
    custom_metadata: CustomMetadata | Sequence[CustomMetadata] | None = None,
    score_threshold: float | None = None,
) -> list[KServeInferenceInput]:
    """Pytorch inputs can be arbitrary. Batching is not yet supported.

    First assumes the input is an image. If that fails, then passes the raw sample.
    """
    try:
        # If CV model, format should be the same as Chariot.
        return _create_chariot_inputs(
            task_type, sample, action, custom_metadata, score_threshold=score_threshold
        )
    except NotAnImageError:
        if not is_json_serializable(sample):
            raise ValueError(
                f"For {Protocol.CHARIOT_V1_TORCHSERVE} models, if the input is not an image then it must be json serializable."
            )
        return [
            single_kserve_input(
                name="input-data",
                datatype=KServeDataType.BYTES,
                data=[sample],
                shape=[1],
                parameters={"action": action},
            )
        ]


def _handle_text_embedding_output(resp: dict[str, Any]):
    data = json.loads(resp["outputs"][0]["data"][0])
    embeddings = data.get("embeddings")
    return embeddings


@dataclass
class ImageTextToTextInput:
    encoded_image: str
    prompts: list[str]


def _parse_image_text_to_text_inputs(sample: Any) -> ImageTextToTextInput:
    match sample:
        case {"image": image, "prompts": prompts}:
            encoded_image, width, height = _encode_image(image)
            return ImageTextToTextInput(encoded_image=encoded_image, prompts=prompts)
        case _:
            raise ValueError(
                f"{TaskType.IMAGE_TEXT_TO_TEXT} input must be a dict or list of dicts "
                '`{"image": <image path or PIL image>, "prompts": [<list of text prompts>]}` '
            )


def _create_chariot_v2_kserve_inputs(
    task_type: TaskType,
    sample: Any | list[Any],
    action: str,
    custom_metadata: CustomMetadata | Sequence[CustomMetadata] | None = None,
    score_threshold: float | None = None,
) -> list[KServeInferenceInput]:
    if (
        task_type not in [TaskType.OBJECT_DETECTION, TaskType.ORIENTED_OBJECT_DETECTION]
        and score_threshold is not None
    ):
        raise ValueError(
            "Cannot pass score threshold unless the model is an Object Detection model"
        )
    match task_type:
        case (
            TaskType.IMAGE_CLASSIFICATION
            | TaskType.OBJECT_DETECTION
            | TaskType.ORIENTED_OBJECT_DETECTION
            | TaskType.IMAGE_SEGMENTATION
        ):
            sample, parameters = _create_parameters_and_sample(
                sample,
                action=action,
                custom_metadata=custom_metadata,
                score_threshold=score_threshold,
            )
            return _create_image_inputs(sample, action, parameters=parameters)
        case TaskType.IMAGE_TEXT_TO_TEXT:
            sample, all_parameters = _create_parameters_and_sample(
                sample, action=Action.QUERY, custom_metadata=custom_metadata
            )
            ittt_inputs = [_parse_image_text_to_text_inputs(arg) for arg in sample]
            return [
                single_kserve_input(
                    name=f"input-{i}",
                    datatype=KServeDataType.BYTES,
                    data=[ittt_input.encoded_image],
                    shape=[1],
                    parameters={**parameters, "prompts": ittt_input.prompts},
                )
                for i, (ittt_input, parameters) in enumerate(zip(ittt_inputs, all_parameters))
            ]
        case _:
            raise ValueError(
                f"{Protocol.CHARIOT_V2_KSERVE} models are not supported for task type {task_type}"
            )

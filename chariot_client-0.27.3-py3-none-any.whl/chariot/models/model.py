import time
import warnings
from collections.abc import Sequence
from datetime import UTC, datetime
from enum import StrEnum
from http import HTTPStatus
from pathlib import Path
from typing import Any, Literal, Self

from deprecated import deprecated

from chariot import _apis, mcp_setting
from chariot.config import getLogger
from chariot.inference_store.metadata import CustomMetadata
from chariot.models import _kserve
from chariot.models._http_utils import _post_request, join_url
from chariot.models.conversions import (
    ModelConversion,
    TinnieConversionOptions,
    convert_model,
)
from chariot.models.enum import (
    ArtifactType,
    TaskType,
    TaskTypesInferenceMethod,
    get_task_type,
)
from chariot.models.exceptions import (
    ActionUnsupportedByCurrentModelError,
    InferenceServerFailed,
    InferenceServerNotFound,
    ModelDoesNotExistError,
    ModelUploadTimeoutError,
)
from chariot.models.inference import ACTION_DOCSTRINGS, Action
from chariot.models.inference_server import InferenceServer
from chariot.models.isvc_settings import (
    GPUDict,
    InferenceServerSettingsDict,
    get_inference_server_settings,
    set_inference_server_settings,
)
from chariot.resources import Resource
from chariot_api._openapi.models.models import CreateExportRequest, InputModel
from chariot_api._openapi.models.models.output_inference_service import (
    OutputInferenceService,
)
from chariot_api._openapi.models.models.output_model import OutputModel
from chariot_api._openapi.models.models.output_model_summary import OutputModelSummary
from chariot_api._openapi.models.rest import ApiException

__all__ = [
    "GPUDict",
    "InferenceServer",
    "InferenceServerSettingsDict",
    "InferenceServerStatus",
    "Model",
    "ModelDoesNotExistError",
    "get_catalog",
    "get_model_by_id",
    "get_models",
    "iter_models",
    "ActionUnsupportedByCurrentModelError",
]

log = getLogger(__name__)

_LEGACY_CLASS_LABELS_DEPRECATION = (
    "The `class_labels` filter is deprecated and will be removed in a future release. "
    "Use `class_label` instead. Pass a string for one label or a sequence of strings to send "
    "repeatable `class_label` query parameters."
)


class identity(dict):
    @staticmethod
    def __missing__(key):
        return key


def _normalize_class_label_filter(
    class_label: str | Sequence[str] | None,
) -> list[str] | None:
    if class_label is None:
        return None
    if isinstance(class_label, str):
        return [class_label]

    labels = list(class_label)
    if not all(isinstance(label, str) for label in labels):
        raise TypeError("class_label must be a string or a sequence of strings")
    return labels


def _warn_if_legacy_class_labels_used(class_labels: str | None) -> None:
    if class_labels is None:
        return
    warnings.warn(_LEGACY_CLASS_LABELS_DEPRECATION, DeprecationWarning, stacklevel=3)


# TODO MOD-280 these should eventually not be hard-coded (teddy knows this mapping already)
def task_from_teddy_config(model_conf: dict) -> TaskType:
    class_to_task = {
        "TorchvisionDetector": TaskType.OBJECT_DETECTION,
        "CenterNetDetector": TaskType.OBJECT_DETECTION,
        "SimpleClassImageModel": TaskType.IMAGE_CLASSIFICATION,
        "EmbedModel": TaskType.IMAGE_EMBEDDING,
        "TorchvisionSemanticSegmentationModel": TaskType.IMAGE_SEGMENTATION,
        "SemanticSegmentationModel": TaskType.IMAGE_SEGMENTATION,
        "ImageClassificationModel": TaskType.IMAGE_CLASSIFICATION,
        "RetinaFaceDetector": TaskType.OBJECT_DETECTION,
        "VariationalAutoEncoder": TaskType.IMAGE_FEATURE_EXTRACTION,
        "ClfTransformersModel": TaskType.TEXT_CLASSIFICATION,
        "NERTransformersModel": TaskType.TOKEN_CLASSIFICATION,
        "YOLO": TaskType.OBJECT_DETECTION,
    }
    return class_to_task[model_conf["#class_name"].split(".")[-1]]


# Values come directly from models-catalog.
# These should be kept in sync manually until we find a better way to handle this.
# https://github.com/Striveworks/chariot/blob/main/go/apps/models-catalog/pkg/constants/inference_server.go#L4-L11
class InferenceServerStatus(StrEnum):
    """The status of an inference server."""

    NULL = "null"  # means no inference server has been requested. This one does not exist in models-catalog.
    READY = "Ready"
    ERROR = "Error"
    SCALED_DOWN = "Scaled down"
    STARTING = "Starting"
    UPDATING = "Updating"
    NOTINITIALIZED = "Not initialized"
    PENDING = "Pending"
    UNKNOWN = "Unknown"
    MISCONFIGURED = "Misconfigured"


def create_inference_method(cls, action: str):
    """Curry of Model.infer. Used to dynamically add inference methods to Model."""

    def method(
        sample: Any,
        timeout: int = 60,
        verbose: bool = False,
        return_inference_id: bool = False,
        **inference_kwargs,
    ) -> dict:
        return cls.infer(
            action,
            sample,
            timeout=timeout,
            verbose=verbose,
            return_inference_id=return_inference_id,
            **inference_kwargs,
        )

    return method


class Model(Resource):
    task_to_method = {
        T.value: getattr(TaskTypesInferenceMethod, T.name).value
        for T in TaskType
        if T.name in TaskTypesInferenceMethod.__members__
    }
    default_action_methods = ["predict"]

    def __init__(
        self,
        project_id: str | None = None,
        id: str | None = None,
        project_name: str | None = None,
        organization_id: str | None = None,
        name: str | None = None,
        version: str | None = None,
        metadata: Any = None,
        start_server: bool = True,
    ):
        # warn about name only - if all are none, or name and id are together it creates errors later
        if id is None and name is not None and version is None and not hasattr(metadata, "id"):
            warnings.warn(
                "creating a model by name alone can result in unexpected behavior,"
                + " use get_model_by_id or provide an id or version kwarg to Model() to ensure"
                + " that you get the model you expect.",
                stacklevel=2,
            )

        super().__init__(
            project_id=project_id,
            id=id,
            project_name=project_name,
            organization_id=organization_id,
            name=name,
            version=version,
            metadata=metadata,
        )

        model_config = self._meta.pymodel_config
        self._artifact_type = self._meta.artifact_type or ""
        if not self._meta.task_type and self._artifact_type == ArtifactType.CHARIOT:
            self.task = task_from_teddy_config(model_config)
        else:
            self.task = get_task_type(self._meta.task_type or "")
        if start_server:
            self.start_inference_server()
        self._populate_class_inference_methods()  # auto-populate inference methods
        self._isvc = None
        self._use_internal_url = False  # whether to cluster DNS address
        self._internal_base_url = None
        self._external_base_url = None

    @property
    def inference_url(self) -> str | None:
        """Url to inference server inference endpoint."""
        url_suffix = "infer"
        # check inference protocol
        protocol = self.get_inference_protocol()

        if protocol in (_kserve.Protocol.OPENAI_V1, _kserve.Protocol.CHARIOT_V1_OPENAI):
            if self.task == TaskType.CONVERSATIONAL:
                url_suffix = "chat/completions"
            elif self.task == TaskType.TEXT_GENERATION:
                url_suffix = "completions"

        inference_base_url = (
            self._internal_base_url if self._use_internal_url else self._external_base_url
        )
        return join_url(inference_base_url, url_suffix) if inference_base_url else None

    @mcp_setting(ignore=True)
    def _populate_class_inference_methods(self):
        """Set the available inference methods as class methods."""
        if self.actions is None:
            log.error("Unable to set inference methods")

        for action in self.actions:
            method = create_inference_method(self, action)
            method.__doc__ = ACTION_DOCSTRINGS.get(action, f"Run `{action}` on the model")
            method.__name__ = action
            setattr(self, method.__name__, method)

    @staticmethod
    def _get_resource_meta(project_id: str, id: str) -> OutputModel:
        data = _apis.models.models_api.models_get(project_ids=project_id, id=id).data
        if len(data) == 0:
            raise ModelDoesNotExistError(project_id, id)
        return data[0]

    @staticmethod
    def _get_id_by_name_and_version(project_id: str, name: str, version: str) -> str:
        kwargs = {"project_ids": project_id, "model_name": name}
        if version is not None:
            kwargs["model_version"] = version

        models = _apis.models.models_api.models_get(**kwargs).data
        if len(models) == 0:
            raise ModelDoesNotExistError(name, version)

        return models[0].id

    @property
    def status(self):
        status, _ = self._get_inference_server_status_and_resp()
        if status is not InferenceServerStatus.READY:
            log.debug(f"Inference service is not ready yet for {self}")
        else:
            log.debug(
                f"Inference server already exists for {self} and is currently in status {status.value}."
            )
        return status

    @property
    def architecture(self):
        return self._meta.architecture

    @property
    def name(self):
        return self._meta.name

    @property
    def name_slug(self):
        return self._meta.name_slug

    @property
    def version(self):
        return self._meta.version

    @property
    def summary(self):
        """Return the model summary."""
        return self._meta.summary

    @property
    def created_at(self) -> datetime:
        return datetime.fromtimestamp(int(self._meta.created_at) / 1000, tz=UTC)

    @property
    def storage_status(self):
        return self._meta.storage_status

    @property
    def actions(self) -> list[str]:
        return self._meta.inference_methods or self.default_action_methods

    def __str__(self):
        return f"Model[{self.name} v{self.version} {self.id}]"

    @property
    def class_labels(self):
        if self._meta.class_labels is None or len(self._meta.class_labels) == 0:
            return None

        return self._meta.class_labels

    @property
    def inverse_class_labels(self):
        icl = identity()
        if self.class_labels is None or not isinstance(self.class_labels, dict):
            return icl

        icl.update({v: k for k, v in self.class_labels.items()})
        return icl

    @mcp_setting(ignore=True)
    def wait_for_upload(self, timeout=60, wait_interval=2) -> Self:
        """Wait for `timeout` seconds for this model to be uploaded.

        Parameters
        ----------
        timeout:
            Number in seconds to wait for model upload.
        wait_interval:
            How many seconds to wait after each query before trying again.

        Returns
        -------
        The Model object, for chaining

        Raises
        ------
        ModelUploadTimeoutError:
            If `storage_status` is not "uploaded" before `timeout`.

        """
        storage_status = self._meta.storage_status
        t_start = time.monotonic()
        while True:
            if storage_status == "uploaded":
                return self
            if storage_status == "failed":
                raise ModelUploadTimeoutError(
                    f"Model {self.id} has storage status 'failed', expected 'uploaded'"
                )
            if time.monotonic() > t_start + timeout:
                raise ModelUploadTimeoutError(
                    f"Model {self.id} has storage status '{storage_status}' after {timeout}s, expected 'uploaded'"
                )
            time.sleep(wait_interval)
            self._meta = self._get_resource_meta(project_id=self.project_id, id=self.id)
            storage_status = self._meta.storage_status

    @mcp_setting(mutating=True)
    def delete(self, hard_delete: bool = False) -> None:
        """Delete model."""
        _apis.models.models_api.models_id_delete(
            id=str(self._meta.id or ""), hard_delete=hard_delete
        )
        log.info(f"Deleted {self}")

    @property
    @deprecated(
        reason="The `isvc_settings` property is deprecated and will be removed in a future release. "
        "Please use the `get_inference_server_settings` method instead."
    )
    def isvc_settings(self):
        """Get the current settings for this model's inference server.

        NOTE: This property is deprecated and will be removed in a future release.
        Please use the :meth:`~chariot.models.model.Model.get_inference_server_settings` method instead.
        """
        return self.get_inference_server_settings()

    @mcp_setting(ignore=True)
    @deprecated(
        reason="The update_isvc_settings method is deprecated and will be removed in a future release. "
        "Please use the `set_inference_server_settings` method instead."
    )
    def update_isvc_settings(self, settings):
        """Updatesettings for this model's inference server.

        NOTE: This method is deprecated and will be removed in a future release.
        Please use the :meth:`~chariot.models.model.Model.set_inference_server_settings` method instead.
        """
        self.set_inference_server_settings(settings)

    # add property for status of inference server
    def _get_inference_server_status_and_resp(
        self,
    ) -> tuple[InferenceServerStatus, OutputInferenceService | None]:
        # Returns an aggregate status of all inference sever pods
        try:
            resp = _apis.models.models_api.models_id_isvc_get(id=str(self._meta.id or "")).data
        except ApiException as e:
            if e.status == 404:
                return InferenceServerStatus.NULL, None
            raise e

        self._isvc = resp
        return InferenceServerStatus(resp.inference_server_status), resp

    def get_inference_protocol(self) -> str | None:
        """Get the current inference protocol for this model's inference server.

        Returns
        -------
        str or None
            The inference protocol from this model's inference server, if no response None is returned

        Raises
        ------
        InferenceServerNotFound:
            The inference server failed to return a response.

        """
        if not hasattr(self, "_inference_protocol"):
            status, resp = self._get_inference_server_status_and_resp()
            if resp is None:
                raise InferenceServerNotFound(
                    f"Inference server for {self} did not return a response. Status: {status}."
                )
            self._inference_protocol = resp.inference_protocol
        return self._inference_protocol

    @mcp_setting(ignore=True)
    def get_inference_server_settings(self) -> InferenceServerSettingsDict:
        """Get the current settings for this model's inference server.

        Returns
        -------
        :class:`chariot.models.model.InferenceServerSettingsDict`

        """
        model_id = self._meta.id
        assert model_id
        return get_inference_server_settings(model_id)

    @mcp_setting(ignore=True)
    def set_inference_server_settings(self, settings: InferenceServerSettingsDict):
        """Set settings for this model's inference server.

        Parameters
        ----------
        settings: :class:`chariot.models.model.InferenceServerSettingsDict`
            Settings to apply to the inference server. Only keys included in
            this dictionary are updated; omitted settings remain unchanged. To
            clear a setting, include its key with the appropriate empty,
            ``None``, or default value.

        """
        model_id = self._meta.id
        assert model_id
        set_inference_server_settings(model_id, settings)

    @mcp_setting(mutating=True)
    def start_inference_server(self) -> None:
        """Create an inference server for the model object."""
        model_id = self._meta.id
        assert model_id
        status, _ = self._get_inference_server_status_and_resp()
        if status is InferenceServerStatus.NULL:
            log.info(f"Starting inference server for {self}")
            _apis.models.models_api.models_id_isvc_post(id=model_id, body={})
        else:
            log.info(
                f"Inference server already exists for {self} with status {status.value}. "
                "To update the existing inference server use `set_inference_server_settings`."
            )

    @mcp_setting(mutating=True)
    def stop_inference_server(self) -> None:
        log.info(f"Stopping inference server for {self}")
        try:
            _apis.models.models_api.models_id_isvc_delete(
                id=self._meta.id,
                _request_timeout=15,
            )
        except ApiException as e:
            if e.reason == "Not Found":
                log.error("Inference server not found")
            else:
                log.error(e)

        self._internal_base_url = self._external_base_url = None

    def wait_for_inference_server(
        self,
        timeout: int,
        verbose: bool = False,
        wait_interval: int = 1,
        internal_url: bool = False,
    ) -> InferenceServer:
        """Waits for the model's dedicated inference server to be running and ready to accept requests.
        Will scale model up if it scaled to zero.

        Parameters
        ----------
        timeout:
            Number in seconds to wait for inference server to spin up.
        verbose:
            Whether to enable more verbose logging.
        wait_interval:
            How many seconds to wait after each query of the get inference server status endpoint before trying again.
        internal_url:
            Set to `True` to use inference within cluster.

        Returns
        -------
        InferenceServer
            A handle to a running inference server

        Raises
        ------
        ApiException:
            If the call to get inference server status does not return a status code that is 2XX or 404.
        InferenceServerFailed:
            If the inference server failed to spin up or was not able to spin up within the timeout period.

        """
        start_time = time.time()
        first_iter = True

        while True:
            # _get_inference_server_status_and_resp will raise a ApiException if status code not 2XX or 404
            status, resp = self._get_inference_server_status_and_resp()
            log.debug(f"Status of inference server {status} {self}")

            match status:
                case InferenceServerStatus.NULL:
                    raise InferenceServerNotFound(f"inference server not found for {self}")
                case InferenceServerStatus.READY | InferenceServerStatus.UPDATING if (
                    resp and resp.ready
                ):
                    break
                case InferenceServerStatus.ERROR:
                    raise InferenceServerFailed(
                        f"Inference server for {self} failed with status {status}."
                    )

            # NOTE(s.maddox): call keepalive even if not scaled down, so that it won't scale down
            try:
                _apis.models.models_api.models_id_isvc_keepalive_get(self.id)
            except Exception:
                log.warning(f"failed to keep alive inference server for {self}")

            if time.time() - start_time > timeout:
                raise InferenceServerFailed(
                    f"Inference server for {self} failed to be ready within {timeout} seconds."
                )

            if verbose and first_iter:
                log.warning(
                    f"Inference server for {self} is not ready yet, "
                    f"will wait up to {timeout} seconds for it to spin up."
                )
                first_iter = False

            time.sleep(wait_interval)

        log.info(
            f"Inference server for {self} has status {status} and readiness value equal to {resp.ready}"
        )
        self._use_internal_url = internal_url
        self._internal_base_url = resp.internal_base_url
        self._external_base_url = resp.external_base_url
        self._inference_protocol = resp.inference_protocol

        if self._internal_base_url is None or self._external_base_url is None:
            raise RuntimeError("Inference server base URL not found")

        return InferenceServer(
            model_id=self.id or "",
            model_name=self.name or "",
            internal_base_url=self._internal_base_url,
            external_base_url=self._external_base_url,
            use_internal_url=self._use_internal_url,
            protocol=self._inference_protocol,
            task=self.task,
            actions=self.actions,
            class_labels=self.class_labels,
        )

    @mcp_setting(ignore=True)
    def infer(
        self,
        action: Action,
        sample: Any,
        timeout: int = 60,
        verbose: bool = False,
        url: str | None = None,
        custom_metadata: CustomMetadata | Sequence[CustomMetadata] | None = None,
        return_inference_id: bool = False,
        return_semantic_score: bool = False,
        score_threshold: float | None = None,
        **inference_kwargs,
    ) -> Any:
        """Run inference `action` on `sample`.

        This method posts data to the model's inference server and returns the results.  The
        `actions` property lists the available actions for this model.

        The inference lookup id is returned when `return_inference_id` is true. This value is the
        inference base ID, not the http tracing request ID. An inference request may or may not
        be batched, but it must contain at least one input. As such, if inference storage is
        enabled, append `-#` where `#` represents the input index. For example, if an inference
        request with a batch of two inputs is provided, append `-0` and `-1` to retrieve the
        stored rows for each input from the inference store.

        For Chariot models running on engines, this method should be considered deprecated in favor of the
        `infer` method on the Inference Server returned from `wait_for_inference_server`. The new infer mechanism
        is designed to "auto-upgrade" as new protcol support is added across the system.
        """
        if action not in self.actions:
            raise ActionUnsupportedByCurrentModelError(
                f"This model's task type '{self.task}' does not support the '{action}' action, "
                f" please use one of the following actions: {self.actions}"
            )

        # TODO MOD-321 ONNX model inference with SDK
        if self._artifact_type == ArtifactType.ONNX:
            log.warning(
                "Attention: The Chariot SDK currently provides limited support for ONNX model predictions. "
                "If you encounter any issues during this operation, it's recommended to attempt the request directly through the API."
            )

        if self._internal_base_url is None or self._external_base_url is None:
            self.wait_for_inference_server(timeout, verbose, internal_url=self._use_internal_url)

        # Here we fetch the protocol from inference server
        protocol = self.get_inference_protocol()
        artifact_type = ArtifactType.get(self._artifact_type)

        if not url:
            url = self.inference_url

        payload = _kserve.create_payload(
            self._meta.id or "",
            protocol,
            self.task,
            sample,
            action,
            custom_metadata,
            score_threshold=score_threshold,
            **inference_kwargs,
        )
        data, headers = _post_request(url, payload, artifact_type, timeout)
        return _kserve.handle_output(
            model_name=self._meta.name or "",
            protocol=protocol,
            task_type=self.task,
            action=action,
            inverse_class_labels=self.inverse_class_labels,
            return_enriched_inference=return_inference_id or return_semantic_score,
            n_inputs=len(sample) if isinstance(sample, list) else 1,
            output=data,
            headers=headers,
        )

    def exports_supported(self) -> list[str]:
        """Return supported export modes for this model"""
        result = _apis.modelexport.default_api.export_types_models_v1_projects_project_id_models_model_id_supported_exports_get(
            project_id=self.project_id, model_id=self.id
        )
        return result["data"]

    @mcp_setting(file_based=True)
    def export_onnx_model(self, tarfile: str) -> None:
        """Download ONNX representation of the model into a tarfile"""
        if not tarfile.endswith("tgz") and not tarfile.endswith(".tar.gz"):
            raise ValueError(f'Tarfile "{tarfile}" should end with tgz or tar.gz')
        with open(tarfile, "wb") as f:
            f.write(
                _apis.modelexport.default_api.download_onnx_models_v1_projects_project_id_models_model_id_onnx_get_without_preload_content(
                    project_id=self.project_id,
                    model_id=self.id,
                ).data
            )
        log.info(f"saved ONNX model to {tarfile}")

    @mcp_setting(file_based=True)
    def download_model(self, dst_path: str | Path) -> None:
        """Download the model as a `.tar.gz` or `.zip` file.

        A temporary file is used to allow restart on network failure and is cleaned up on success.
        Use `tar tzvf` or unzip to verify the file after download.
        """
        format: Literal["tgz", "zip"]
        lowercase_dst_path = str(dst_path).lower()
        if lowercase_dst_path.endswith(".tgz") or lowercase_dst_path.endswith(".tar.gz"):
            format = "tgz"
        elif lowercase_dst_path.endswith(".zip"):
            format = "zip"
        else:
            raise ValueError(
                f'dst_path must end with ".tar.gz", ".tgz", or ".zip"; got {str(dst_path)}'
            )

        dst_path = Path(dst_path)
        export_id_path = dst_path.with_suffix(".export_id")
        download_path = dst_path.with_suffix(".download")
        export_id: str | None = None
        if export_id_path.exists():
            export_id = export_id_path.read_text().strip()
            export = _apis.models.export_api.export_export_id_status_get(export_id).data
            match export.status:
                case "pending" | "running" | "completed":
                    log.info(f"resuming previous export {export_id}...")
                case _:
                    log.info(
                        f"previous export {export_id} status was {export.status!r}; re-exporting..."
                    )
                    export_id = None

        if export_id is None:
            data = _apis.models.export_api.export_post(
                CreateExportRequest(format=format, model_id=self._meta.id),
            ).data
            export_id = data.export_id
            export_id_path.write_text(export_id)
            download_path.unlink(missing_ok=True)

        # poll until the export is complete
        while True:
            export = _apis.models.export_api.export_export_id_status_get(export_id).data
            match export.status:
                case "pending" | "running":
                    log.info(
                        f"export {export_id} {export.status} ({export.progress_percent:.3f}%)..."
                    )
                    time.sleep(2)
                    continue
                case "completed":
                    log.info(f"export {export_id} completed; downloading...")
                    break
                case "failed":
                    raise RuntimeError(f"export {export_id} failed with error: {export.error}")
                case "expired", "deleted":
                    raise RuntimeError(f"export {export_id} is {export.status}")
                case _:
                    raise RuntimeError(f"unknown export {export_id} status: {export.status}")

        resume_byte_pos = download_path.stat().st_size if download_path.exists() else 0
        resume_header = {"Range": f"bytes={resume_byte_pos}-"} if resume_byte_pos else None
        mode = "ab" if resume_byte_pos else "wb"

        if resume_byte_pos == 0:
            log.info(f"saving download to working location {download_path}...")
        else:
            log.info(
                f"restarting download from {resume_byte_pos} bytes to working location {download_path}..."
            )

        resp = _apis.models.export_api.export_export_id_get_without_preload_content(
            export_id=export_id, _headers=resume_header
        )
        bytes_total = int(resp.headers["Content-Length"])
        bytes_written = 0
        progress_percent = 0.0
        start_time = time.monotonic()
        with open(download_path, mode) as fp:
            for chunk in resp.stream(1024 * 1024):  # 1MB chunks
                if chunk:
                    fp.write(chunk)
                    bytes_written += len(chunk)
                    progress_percent = bytes_written / bytes_total * 100
                if time.monotonic() - start_time > 5:
                    start_time = time.monotonic()
                    log.info(
                        f"downloaded {bytes_written}/{bytes_total} bytes ({progress_percent:.3f}%)..."
                    )

        download_path.rename(dst_path)
        export_id_path.unlink(missing_ok=True)
        log.info(f"download complete, saved model archive to {dst_path}")

    def files(self) -> list[dict]:
        """Recursive listing of all files for model, returns [{ last_modified, name, size }]"""
        return [
            {
                "last_modified": entry.last_modified,
                "name": entry.name,
                "size": entry.size,
            }
            for entry in _apis.models.models_api.models_id_files_get(
                id=self.id, _request_timeout=300, recursive=True
            ).files
        ]

    @mcp_setting(ignore=True)
    def supported_and_existing_inference_engines(self):
        return _apis.modelexport.default_api.convert_models_v1_model_id_convert_get(
            model_id=self.id,
        ).data

    @mcp_setting(mutating=True)
    def convert_inference_engine(self, inference_engine, force_overwrite=False) -> tuple[int, str]:
        get_result = _apis.modelexport.default_api.convert_models_v1_model_id_convert_get(
            model_id=self.id,
        ).data
        if inference_engine not in get_result.eligible_runtime_conversions:
            return (
                HTTPStatus.BAD_REQUEST,
                f"model {self.id} cannot be converted to {inference_engine}, "
                f"supported conversions are {get_result.eligible_runtime_conversions}",
            )
        response = _apis.modelexport.default_api.convert_models_v1_model_id_convert_post(
            model_id=self.id,
            target_framework=inference_engine,
            force_overwrite=force_overwrite,
        )
        return response.code, response.message

    @mcp_setting(mutating=True)
    @_apis.login_required
    def convert(
        self,
        name: str,
        *,
        project_id: str | None = None,
        format: Literal["tinnie"] = "tinnie",
        version: str | None = None,
        summary: str | None = None,
        options: TinnieConversionOptions | None = None,
    ) -> ModelConversion:
        """Submit an asynchronous conversion of this model.

        Parameters
        ----------
        name:
            Name of the destination model.
        project_id:
            Destination project ID. Defaults to this model's project.
        format:
            Destination model format. Currently only ``"tinnie"`` is supported.
        version:
            Destination model version. Defaults to this model's version.
        summary:
            Destination model summary. Defaults to this model's summary.
        options:
            Optional Tinnie-specific conversion settings.

        Returns
        -------
        ModelConversion
            The submitted conversion job. Use :func:`get_model_conversion` to retrieve its status.

        """
        return convert_model(
            source_model_id=self.id,
            target_project_id=project_id or self.project_id,
            name=name,
            format=format,
            version=version or self.version,
            summary=summary or self.summary,
            options=options,
        )

    @mcp_setting(mutating=True)
    @_apis.login_required
    def fork(
        self,
        project_id: str,
        *_,
        name: str | None = None,
        summary: str | None = None,
        version: str | None = None,
    ) -> "Model":
        """Fork the model.

        Parameters
        ----------
        project_id : str
            The project to fork the model into.
        name : str, optional
            Optional name override.
        summary : str, optional
            Optional summary override.
        version : str, optional
            Optional model version override.

        Returns
        -------
        Model
            The new model fork.

        """
        model_data = _apis.models.models_api.models_post(
            body=InputModel(  # pyright: ignore [reportCallIssue]
                name=name,
                version=version,
                summary=summary,
                project_id=project_id,
                fork_model_id=self.id,
            ),
        ).data
        return Model(metadata=model_data, start_server=False)


@mcp_setting(ignore=True)
@_apis.login_required
def get_catalog(
    project_id: str,
    id: str | None = None,
    model_name: str | None = None,
    model_version: str | None = None,
    task_type: str | None = None,
    sort: str | None = None,
    limit: int = 20,
    offset: int = 0,
    class_labels: str | None = None,
    artifact_type: str | None = None,
    architecture: str | None = None,
    *,
    class_label: str | Sequence[str] | None = None,
    **kwargs,
) -> list[OutputModelSummary]:
    r"""get_catalog returns the model catalog matching the supplied keyword filters.

    Params
    ------
    project_id (str) : project_id for models query
    id (str) : the model's id
    model_name (str) : the model's name, there may be multiple versions
    model_version (str) : the model's version, related to the name
    task_type (str) : what operation does this model perform
    sort (str) : the field to sort on, can sort by created_at, updated_at, or name followed by a direction. e.g. 'created_at:desc'
    limit (int) : the number of models to return
    offset (int) : the offset for the first model, used for paging with limit
    class_label (str | Sequence[str]) : class label filter. Pass a string for one label or a
        sequence of strings to send repeatable class_label query params. This preserves commas
        within each label value.
    class_labels (str) : deprecated legacy class label filter, separated by commas
    artifact_type (str) : the models artifact type (changing to engine in the future)
    architecture (str) : the models architecture (changing to engine in the future), use commas to include multiples

    See Chariot REST documentation for more details on available kwargs.

    """
    normalized_class_label = _normalize_class_label_filter(class_label)
    _warn_if_legacy_class_labels_used(class_labels)

    return _apis.models.models_api.catalog_get(
        project_ids=project_id,
        id=id,
        model_name=model_name,
        model_version=model_version,
        task_type=task_type,
        sort=sort,
        limit=limit,
        offset=offset,
        class_label=normalized_class_label,
        class_labels=class_labels,
        artifact_type=artifact_type,
        architecture=architecture,
        **kwargs,
    ).data


@_apis.login_required
def get_models(
    project_id: str | None = None,
    id: str | None = None,
    model_name: str | None = None,
    model_version: str | None = None,
    task_type: str | None = None,
    sort: str | None = None,
    limit: int = 20,
    offset: int = 0,
    class_labels: str | None = None,
    artifact_type: str | None = None,
    architecture: str | None = None,
    *,
    class_label: str | Sequence[str] | None = None,
    **kwargs,
) -> list[Model]:
    r"""get_models returns all models matching the supplied keyword filters.

    Params
    ------
    project_id (str) : project_id for models query
    id (str) : the model's id
    model_name (str) : the model's name, there may be multiple versions
    model_version (str) : the model's version, related to the name
    task_type (str) : what operation does this model perform
    sort (str) : the field to sort on, can sort by created_at, updated_at, or name followed by a direction. e.g. 'created_at:desc'
    limit (int) : the number of models to return
    offset (int) : the offset for the first model, used for paging with limit
    class_label (str | Sequence[str]) : class label filter. Pass a string for one label or a
        sequence of strings to send repeatable class_label query params. This preserves commas
        within each label value.
    class_labels (str) : deprecated legacy class label filter, separated by commas
    artifact_type (str) : the models artifact type (changing to engine in the future)
    architecture (str) : the models architecture (changing to engine in the future), use commas to include multiples


    See Chariot REST documentation for more details on available kwargs.

    """
    normalized_class_label = _normalize_class_label_filter(class_label)
    _warn_if_legacy_class_labels_used(class_labels)

    response = _apis.models.models_api.models_get(
        project_ids=project_id,
        id=id,
        model_name=model_name,
        model_version=model_version,
        task_type=task_type,
        sort=sort,
        limit=limit,
        offset=offset,
        class_label=normalized_class_label,
        class_labels=class_labels,
        artifact_type=artifact_type,
        architecture=architecture,
        **kwargs,
    )
    return [Model(metadata=m, start_server=False) for m in response.data]


@mcp_setting(ignore=True)
@_apis.login_required
def iter_models(
    **kwargs,
):
    """iter_models returns an iterator over all models matching the supplied filters.
    See Chariot REST documentation for details.
    """
    if "sort" in kwargs:
        raise ValueError("the `sort` parameter is reserved by iter_models")
    if "after" in kwargs:
        raise ValueError("the `after` parameter is reserved by iter_models")
    after_id = None
    while True:
        models = [
            Model(metadata=m, start_server=False)
            for m in _apis.models.models_api.models_get(
                sort="id:asc", after=after_id, **kwargs
            ).data
        ]
        if not models:
            break
        after_id = models[-1].id
        yield from models


@_apis.login_required
def get_model_by_id(id: str) -> Model:
    """get_model_by_id returns the model matching the supplied id."""
    models = _apis.models.models_api.models_get(
        id=id,
    ).data

    if not models or id is None:
        raise ModelDoesNotExistError(id)
    return Model(metadata=models[0], start_server=False)

import base64
import io
import json
from typing import Any

from PIL import Image


def is_json_serializable(sample: Any):
    try:
        json.dumps(sample)
        return True
    except (TypeError, OverflowError):
        return False


def bytes_to_pil(img_bytes: bytes) -> Image.Image:
    return Image.open(io.BytesIO(img_bytes))


def pil_to_bytes(img: Image.Image) -> bytes:
    b = io.BytesIO()
    exif = img.getexif()
    if img.format is not None:
        img.save(b, format=img.format, exif=exif)
    else:
        img.save(b, format="PNG", exif=exif)
    return b.getvalue()


def b64_to_image(b64str: str) -> Image.Image:
    img_bytes = base64.b64decode(b64str)
    return bytes_to_pil(img_bytes).convert("RGB")


def image_to_b64(img: Image.Image) -> str:
    bytes_ = pil_to_bytes(img)
    img_64 = base64.b64encode(bytes_)
    return img_64.decode()


class ChariotDecoder(json.JSONDecoder):
    """JSON decoder for chariot inference responses."""

    special_objects = {"B64IMAGE": b64_to_image}

    def decode(self, s):
        obj = super().decode(s)
        return self._replace_special_objects(obj)

    def _replace_special_objects(self, obj):
        """Replace special objects (e.g. b64 string -> PIL image)"""
        if type(obj) == dict:
            for key in obj:
                if key in self.special_objects:
                    return self.special_objects[key](obj[key])
                obj[key] = self._replace_special_objects(obj[key])

        if type(obj) in [tuple, list]:
            _obj = []
            for item in obj:
                _obj.append(self._replace_special_objects(item))
            obj = _obj

        return obj

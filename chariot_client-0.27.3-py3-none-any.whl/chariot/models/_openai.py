import json
from typing import Any

from pydantic import BaseModel

# Modeled after OpenAI's standard
# See: https://platform.openai.com/docs/guides/text-generation/chat-completions-api


class ChatMessage(BaseModel):
    role: str
    content: str | None = None
    reasoning: str | None = None


class OpenAIInput(BaseModel):
    """OpenAI has many optional sampling inputs, but since we don't
    support directly calling OpenAI models yet they aren't included
    here. We currently use chariot.models._llm.LLMSamplingParameters
    to validate sampling inputs for our current LLM runtimes.
    """

    model: str | None = None


class CompletionsInputs(OpenAIInput):
    prompt: str


class ChatCompletionsInputs(OpenAIInput):
    messages: list[ChatMessage]


class ChatCompletionsChoice(BaseModel):
    finish_reason: str | None = None
    index: int | None = None
    logprobs: Any | None = None
    message: ChatMessage


class CompletionsChoice(BaseModel):
    finish_reason: str | None = None
    index: int | None = None
    logprobs: Any | None = None
    text: str


class TextGenTokenUsage(BaseModel):
    completion_tokens: int | None = None
    prompt_tokens: int | None = None
    total_tokens: int | None = None


class OpenAIOutput(BaseModel):
    id: str
    model: str
    created: int | None = None
    usage: TextGenTokenUsage | None = None

    def __repr__(self):
        return json.dumps(self.model_dump(), indent=2)


class ChatCompletionsOutput(OpenAIOutput):
    choices: list[ChatCompletionsChoice]
    object: str = "chat.completion"


class CompletionsOutput(OpenAIOutput):
    choices: list[CompletionsChoice]
    object: str = "text_completion"

from typing import Self

from pydantic import BaseModel, Field, model_validator


class LLMSamplingParameters(BaseModel):
    """A non-exhaustive list of LLM generation parameters. Note that support for some parameters depends
    on the inference engine being used (vLLM vs Huggingface pipelines [mlserver huggingface]).

    This data model was created by manually going through the vLLM supported parameters:
    https://docs.vllm.ai/en/v0.5.5/dev/sampling_params.html

    and the huggingface Text Generation pipeline parameters:
    https://huggingface.co/docs/transformers/en/main_classes/text_generation#transformers.GenerationConfig

    and attempting to merge the most common options. The naming convention order of preference was
    chosen based on the following preferential order:

    OpenAI > vLLM > Huggingface

    In most cases, OpenAI and vLLM agree on naming, but there are a few exceptions.

    """

    max_completion_tokens: int | None = Field(
        None,
        description="Maximum number of new tokens for the model to generate. If using the huggingface engine, the default value is 50.",
        json_schema_extra={"vllm_alias": "max_tokens", "hf_alias": "max_new_tokens"},
    )
    min_tokens: int | None = Field(
        None,
        description="Minimum number of tokens to generate per output sequence before EOS or stop_token_ids can be generated",
        json_schema_extra={"vllm_alias": "min_tokens", "hf_alias": "min_new_tokens"},
    )
    presence_penalty: float | None = Field(
        None,
        description="Float that penalizes new tokens based on whether they appear in the generated text so far. Values > 0 encourage the model to use new tokens, while values < 0 encourage the model to repeat tokens.",
        json_schema_extra={"vllm_alias": "presence_penalty", "hf_alias": None},
    )
    frequency_penalty: float | None = Field(
        None,
        description="Float that penalizes new tokens based on their frequency in the generated text so far. Values > 0 encourage the model to use new tokens, while values < 0 encourage the model to repeat tokens.",
        json_schema_extra={"vllm_alias": "frequency_penalty", "hf_alias": None},
    )
    repetition_penalty: float | None = Field(
        None,
        description="Float that penalizes new tokens based on whether they appear in the prompt and the generated text so far. Values > 1 encourage the model to use new tokens, while values < 1 encourage the model to repeat tokens.",
        json_schema_extra={"vllm_alias": "repetition_penalty", "hf_alias": "repetition_penalty"},
    )
    temperature: float | None = Field(
        None,
        description="Float that controls the randomness of the sampling. Lower values make the model more deterministic, while higher values make the model more random. Zero means greedy sampling.",
        json_schema_extra={"vllm_alias": "temperature", "hf_alias": "temperature"},
    )
    top_p: float | None = Field(
        None,
        description="Float that controls the cumulative probability of the top tokens to consider. Must be in (0, 1]. Set to 1 to consider all tokens.",
        json_schema_extra={"vllm_alias": "top_p", "hf_alias": "top_p"},
    )
    top_k: int | None = Field(
        None,
        description="Integer that controls the number of top tokens to consider.",
        json_schema_extra={"vllm_alias": "top_k", "hf_alias": "top_k"},
    )
    min_p: float | None = Field(
        None,
        description=" Float that represents the minimum probability for a token to be considered, relative to the probability of the most likely token. Must be in [0, 1]. Set to 0 to disable this.",
        json_schema_extra={"vllm_alias": "min_p", "hf_alias": "min_p"},
    )
    seed: int | None = Field(
        None,
        description="Random seed to use for the generation.",
        json_schema_extra={"vllm_alias": "seed", "hf_alias": None},
    )
    use_beam_search: bool | None = Field(
        None,
        description="Whether to use beam search",
        json_schema_extra={"vllm_alias": "use_beam_search", "hf_alias": "use_beam_search"},
    )
    best_of: int | None = Field(
        None,
        description="Number of output sequences that are generated from the prompt. From these best_of sequences, the best sequence is returned. best_of must be greater than or equal to 1. This is treated as the beam width when use_beam_search is True. By default, best_of is set to 1.",
        json_schema_extra={"vllm_alias": "best_of", "hf_alias": "num_beams"},
    )
    length_penalty: float | None = Field(
        None,
        description="Float that penalizes sequences based on their length. Used in beam search. length_penalty > 0.0 promotes longer sequences, while length_penalty < 0.0 encourages shorter sequences.",
        json_schema_extra={"vllm_alias": "length_penalty", "hf_alias": "length_penalty"},
    )
    stop: list[str] | None = Field(
        None,
        description="List of strings that stop the generation when they are generated.",
        json_schema_extra={"vllm_alias": "stop", "hf_alias": None},
    )
    stop_token_ids: list[int] | None = Field(
        None,
        description="List of tokens that stop the generation when they are generated. The returned output will contain the stop tokens unless the stop tokens are special tokens.",
        json_schema_extra={"vllm_alias": "stop_token_ids", "hf_alias": "eos_token_id"},
    )
    include_stop_str_in_output: bool | None = Field(
        None,
        description="Whether to include the stop strings in output text. Defaults to False.",
        json_schema_extra={"vllm_alias": "include_stop_str_in_output", "hf_alias": None},
    )
    ignore_eos: bool | None = Field(
        None,
        description="Whether to ignore the EOS token and continue generating tokens after the EOS token is generated.",
        json_schema_extra={"vllm_alias": "ignore_eos", "hf_alias": None},
    )
    logprobs: bool | None = Field(
        None,
        description="Number of log probabilities to return per output token. When set to None, no probability is returned. If set to a non-None value, the result includes the log probabilities of the specified number of most likely tokens, as well as the chosen tokens.",
        json_schema_extra={"vllm_alias": "logprobs", "hf_alias": None},
    )
    top_logprobs: int | None = Field(
        None,
        description="Number of log probabilities to return per prompt token.",
        json_schema_extra={"vllm_alias": "top_logprobs", "hf_alias": None},
    )
    do_sample: bool | None = Field(
        None,
        description="Whether or not to use sampling. Only a valid option for Huggingface engine.",
        json_schema_extra={"vllm_alias": None, "hf_alias": "do_sample"},
    )

    @model_validator(mode="after")
    def max_min_tokens_valid(self) -> Self:
        if self.max_completion_tokens is None:
            return self
        if self.min_tokens is None:
            return self
        if self.max_completion_tokens < self.min_tokens:
            raise ValueError(
                "`max_completion_tokens` must be greater than or equal to `min_tokens`"
            )
        return self

    def to_vllm(self) -> dict:
        params = {}
        for field, data in self.model_fields.items():
            if getattr(self, field) is not None:
                param_name = data.json_schema_extra.get("vllm_alias")
                if param_name is None:
                    raise ValueError(
                        f"LLM inference parameter `{field}` is not supported if using the vLLM engine."
                    )
                params[param_name] = getattr(self, field)

        if params.get("logprobs") and (params.get("top_logprobs") or 0) < 1:
            raise ValueError(
                "If passing `logprobs=True`, then must pass an integer value > 0 for `top_logprobs`"
            )

        if params.get("use_beam_search") and (params.get("best_of") or 0) < 2:
            raise ValueError(
                "if using beam search, must pass a `best_of` value greater than 1, which is the beam width"
            )

        return params

    def to_huggingface(self) -> dict:
        params = {}

        for field, data in self.model_fields.items():
            if getattr(self, field) is not None:
                param_name = data.json_schema_extra.get("hf_alias")
                if param_name is None:
                    raise ValueError(
                        f"LLM inference parameter `{field}` is not supported if using the Huggingface pipelines engine."
                    )
                params[param_name] = getattr(self, field)

        if (temperature := params.get("temperature")) and temperature > 0:
            params["do_sample"] = True

        if params.get("use_beam_search"):
            if (params.get("num_beams") or 0) < 2:
                raise ValueError(
                    "if using beam search, must pass a `best_of` value greater than 1, which is the beam width"
                )
            else:
                # huggingface doesn't use this
                params.pop("use_beam_search")
                params["do_sample"] = False

        return params

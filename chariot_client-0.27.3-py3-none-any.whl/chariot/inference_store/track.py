import chariot._apis
from chariot import mcp_setting
from chariot.inference_store import _utils, models

__all__ = ["filter_tracks", "get_tracks_for_inference"]


@mcp_setting(ignore=True)
def filter_tracks(tracker_id: str, request_body: models.NewGetTracksRequest) -> list[models.Track]:
    """Get tracks for a tracker, optionally matching a series of filters.

    :param tracker_id: The tracker id.
    :type tracker_id: str
    :param request_body: The track filter to apply upon the full collection of tracks stored for the tracker.
    :type request_body: models.NewGetTracksRequest
    :return: The collection of tracks that met the filter criteria.
    :rtype: List[models.Track]
    """
    response = chariot._apis.inferencestore.track_api.track_tracker_id_post(
        tracker_id=tracker_id, body=request_body.model_dump()
    )
    if not response.data:
        return []
    return [_utils.convert_to_dataclass(d.model_dump(), models.Track) for d in response.data]


@mcp_setting(ignore=True)
def get_tracks_for_inference(tracker_id: str, inference_id: str) -> list[models.Track]:
    """Get tracks for a tracker and inference.

    :param tracker_id: The tracker id.
    :type tracker_id: str
    :param tracker_id: The inference id.
    :type tracker_id: str
    :return: The collection of tracks that met the filter criteria.
    :rtype: List[models.Track]
    """
    response = chariot._apis.inferencestore.track_api.track_tracker_id_inference_inference_id_get(
        tracker_id=tracker_id, inference_id=inference_id
    )
    if not response.data:
        return []
    return [_utils.convert_to_dataclass(d.model_dump(), models.Track) for d in response.data]

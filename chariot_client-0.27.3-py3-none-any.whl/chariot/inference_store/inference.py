"""Inference-store create/get/filter helpers."""

import json
from typing import Any

import requests

import chariot._apis
from chariot import mcp_setting
from chariot.inference_store import models
from chariot.inference_store.upload import upload_data
from chariot_api._openapi.inferencestore.exceptions import ApiException, NotFoundException

__all__ = [
    "create_inference",
    "filter_inferences",
    "count_inferences",
    "get_inference",
    "delete_inference",
    "create_inference_storage_request",
    "bulk_delete_inferences",
]


def _response_body(response) -> bytes:
    data = getattr(response, "data", None)
    if data is None and hasattr(response, "read"):
        data = response.read()
    if data is None:
        return b""
    if isinstance(data, str):
        return data.encode()
    return data


def _parse_store_json(response) -> Any:
    """Parse inference-store JSON without OpenAPI model validation.

    Contour rows are JSON arrays under image_segmentation; the generated OpenAPI
    client types that field as an object only, so typed deserialize fails.
    """
    status = getattr(response, "status", None)
    body = _response_body(response)
    text = body.decode() if isinstance(body, bytes | bytearray) else str(body)
    if status == 404:
        raise NotFoundException(status=status, reason=text)
    if status is not None and status >= 400:
        raise ApiException(status=status, reason=text)
    if not text:
        return None
    return json.loads(text)


def _inference_from_api_dict(payload: dict[str, Any] | None) -> models.Inference | None:
    if not payload:
        return None
    return models.Inference.model_validate(payload)


@mcp_setting(ignore=True)
def create_inference(
    model_id: str, request_body: models.NewInferenceStorageRequest
) -> models.Inference | None:
    """Create a new inference.

    :param model_id: The model id.
    :type model_id: str
    :param request_body: The inference and metadata.
    :type request_body: models.NewInferenceStorageRequest
    :return: The inference.
    :rtype: Optional[models.Inference]
    """
    response = (
        chariot._apis.inferencestore.inference_api.inference_model_id_post_without_preload_content(
            model_id=model_id,
            body=request_body.model_dump(),  # type: ignore[reportArgumentType]
        )
    )
    body = _parse_store_json(response)
    if not body:
        return None
    return _inference_from_api_dict(body.get("data"))


def filter_inferences(
    model_id: str, request_body: models.NewGetInferencesRequest
) -> list[models.Inference]:
    """Get inferences for a model, optionally matching a series of filters.

    Each record returned corresponds to an inference request response pair. Inference
    responses are stored in the model's native format.

    For example, a record returned might have the following inference blob:
        {"detection_boxes": [[10, 10, 20, 20], [30, 30, 40, 40]], "detection_scores": [0.9, 0.95], "detection_labels": ["cat", "dog"]}

    :param model_id: The model id.
    :type model_id: str
    :param request_body: The inference filter to apply upon the full collection of inferences stored for the model.
    :type request_body: models.NewGetInferencesRequest
    :return: The collection of inferences that met the filter criteria.
    :rtype: List[models.Inference]
    """
    response = chariot._apis.inferencestore.inference_api.inference_model_id_filter_post_without_preload_content(
        model_id=model_id,
        body=request_body.model_dump(),  # type: ignore[reportArgumentType]
    )
    body = _parse_store_json(response)
    if not body:
        return []
    rows = body.get("data") or []
    return [inf for inf in (_inference_from_api_dict(row) for row in rows) if inf is not None]


def count_inferences(model_id: str, request_body: models.NewGetInferencesRequest) -> int:
    """Get the count of all inferences for a model, optionally matching a series of filters.

    :param model_id: The model id.
    :type model_id: str
    :param request_body: The inference filter to apply upon the full collection of inferences stored for the model.
    :type request_body: models.NewGetInferencesRequest
    :return: The record count.
    :rtype: int
    """
    request_body.pagination = models.Pagination(limit=1, include_record_count=True)
    response = chariot._apis.inferencestore.inference_api.inference_model_id_filter_post_without_preload_content(
        model_id=model_id,
        body=request_body.model_dump(),  # type: ignore[reportArgumentType]
    )
    headers = getattr(response, "headers", None)
    _parse_store_json(response)
    if headers is None:
        raise Exception("unable to count inferences, empty response headers")
    return int(headers.get("X-Record-Count", 0))


def get_inference(model_id: str, inference_id: str, presign: bool = False) -> models.Inference:
    """Get details about a single inference.

    :param model_id: The model id.
    :type model_id: str
    :param inference_id: The inference id.
    :type inference_id: str
    :param presign: Whether to include a presigned url to the image/text.
    :type presign: bool
    :return: The inference.
    :rtype: Optional[models.Inference]
    """
    response = chariot._apis.inferencestore.inference_api.inference_model_id_inference_id_get_without_preload_content(
        model_id=model_id, inference_id=inference_id, presign=presign
    )
    body = _parse_store_json(response)
    inference = _inference_from_api_dict(body.get("data") if body else None)
    assert inference is not None
    return inference


@mcp_setting(mutating=True)
def delete_inference(model_id: str, inference_id: str) -> str | None:
    """Delete an inference and all associated metadata.

    :param model_id: The model id.
    :type model_id: str
    :param inference_id: The inference id.
    :type inference_id: str
    :return: The deleted inference id.
    :rtype: Optional[str]
    """
    response = chariot._apis.inferencestore.inference_api.inference_model_id_inference_id_delete(
        model_id=model_id, inference_id=inference_id
    )
    if not response.data:
        return None
    return response.data


@mcp_setting(ignore=True)
def create_inference_storage_request(
    model_id: str,
    inference_id: str,
    data: str | bytes | None,
    metadata: models.NewInferenceAndMetadataCollection,
    is_protected: bool = False,
) -> models.NewInferenceStorageRequest | None:
    """Create an inference via the API.

    This function will upload the supplied data to blob storage if the data field is
    specified.

    :param model_id: The model id.
    :type model_id: str
    :param inference_id: The inference id.
    :type inference_id: str
    :param data: Optionally, the data inferred upon.
    :type data: Optional[Union[str, bytes]]
    :param metadata: The inference and metadata.
    :type metadata: models.NewInferenceAndMetadataCollection
    :param is_protected: Whether the inference and its associated data should be protected from deletion by retention policy
    :type is_protected: bool
    :return: The inference.
    :rtype: Optional[models.NewInferenceStorageRequest]
    """
    request = models.NewInferenceStorageRequest(
        model_id=model_id,
        inference_id=inference_id,
        data=metadata,
        is_protected=is_protected,
    )

    if data is not None:
        udata = upload_data(model_id)
        if udata is None:
            raise Exception("Failed to get presigned url")
        upload_data_response = requests.put(
            url=udata.data_presigned_url, data=data, timeout=(9.05, 300)
        )
        if upload_data_response.status_code != 200:
            raise Exception(f"Unable to upload data file: {upload_data_response.text}")
        request.data_storage_key = udata.data_storage_key

    return request


@mcp_setting(mutating=True)
def bulk_delete_inferences(model_id: str, filter_: models.BaseInferenceFilter) -> list[str | None]:
    """Delete inferences and all associated metadata.

    For example, this can be used to delete all inferences for a given snapshot/split, like this::

        deleted_inference_ids = istore.bulk_delete_inferences(
            MY_MODEL_ID,
            istore.BaseInferenceFilter(
                metadata_filter=[
                    istore.MetadataFilter(
                        key="dataset_snapshot_id",
                        type=istore.MetadataFilterType.STRING,
                        operator=istore.MetadataFilterOperator.EQUAL,
                        value=MY_SNAPSHOT_ID,
                    ),
                    istore.MetadataFilter(
                        key="dataset_snapshot_split",
                        type=istore.MetadataFilterType.STRING,
                        operator=istore.MetadataFilterOperator.EQUAL,
                        value=MY_SNAPSHOT_SPLIT,
                    ),
                ]
            ),
        )

    :param model_id: The model id.
    :type model_id: str
    :param filter: A filter describing which inferences to delete.
    :type filter: models.BaseInferenceFilter
    :return: The deleted inference ids.
    :rtype: list[str | None]
    """
    deleted_inference_ids = []
    while True:
        inference_filter = models.NewGetInferencesRequest(
            filters=filter_, pagination=models.Pagination(limit=100)
        )
        try:
            data = filter_inferences(model_id=model_id, request_body=inference_filter)
        except NotFoundException:
            break

        n = len(data)
        if n == 0:
            break
        for inf in data:
            deleted_inference_id = delete_inference(
                model_id=inf.model_id, inference_id=inf.inference_id
            )
            deleted_inference_ids.append(deleted_inference_id)
    return deleted_inference_ids

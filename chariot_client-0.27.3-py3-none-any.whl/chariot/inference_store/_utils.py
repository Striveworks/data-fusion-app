from datetime import datetime

import numpy as np

DATETIME_FORMAT = "%Y-%m-%dT%H:%M:%S.%fZ"


def format_datetime(dt: datetime) -> str:
    return dt.strftime(DATETIME_FORMAT)


def datetime_from_string(dt: str) -> datetime:
    return datetime.strptime(dt, DATETIME_FORMAT)


def convert_to_dataclass(obj, c):
    if isinstance(obj, c):
        return obj
    return c(**obj)


def _prepare_arrays(a: list | np.ndarray, b: list | np.ndarray):
    if isinstance(a, list):
        a = np.array(a)
    if isinstance(b, list):
        b = np.array(b)
    return a, b


def cosine_distance(a: list | np.ndarray, b: list | np.ndarray):
    a, b = _prepare_arrays(a, b)
    cosine_similarity = np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))
    return 1 - cosine_similarity


def l2_distance(a: list | np.ndarray, b: list | np.ndarray):
    a, b = _prepare_arrays(a, b)
    return np.linalg.norm(a - b)


def negative_dot_product_distance(a: list | np.ndarray, b: list | np.ndarray):
    a, b = _prepare_arrays(a, b)
    return -1 * np.dot(a, b)

import chariot._apis
from chariot import mcp_setting
from chariot.inference_store import _utils, models

__all__ = [
    "upload_data",
    "upload_inference_and_metadata",
]


@mcp_setting(ignore=True)
def upload_data(model_id: str) -> models.DataUpload | None:
    """Get an internal storage key and presigned url in which to upload data to.

    :param model_id: The model id.
    :type model_id: str
    :return: The upload data details.
    :rtype: Optional[models.DataUpload]
    """
    response = chariot._apis.inferencestore.upload_api.upload_model_id_data_post(model_id=model_id)
    if not response.data:
        return None
    return _utils.convert_to_dataclass(response.data.model_dump(), models.DataUpload)


@mcp_setting(ignore=True)
def upload_inference_and_metadata(model_id: str) -> models.MetadataUpload | None:
    """Get an internal storage key and presigned url in which to upload metadata to.

    :param model_id: The model id.
    :type model_id: str
    :return: The upload metadata details.
    :rtype: Optional[models.MetadataUpload]
    """
    response = chariot._apis.inferencestore.upload_api.upload_model_id_metadata_post(
        model_id=model_id
    )
    if not response.data:
        return None
    return _utils.convert_to_dataclass(response.data.model_dump(), models.MetadataUpload)

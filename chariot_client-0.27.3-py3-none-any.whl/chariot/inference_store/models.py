"""Pydantic models for the inference-store SDK."""

import ast
from datetime import datetime
from enum import Enum

import numpy as np
from pydantic import BaseModel, ConfigDict, Field

from chariot.inference_store.segmentation import (
    ImageSegmentationContourContract,
    ImageSegmentationMaskResult,
)
from chariot_api._openapi.inferencestore.models import (
    ModelImageClassificationContract,
    ModelImageObjectDetectionContract,
    ModelImageOrientedObjectDetectionContract,
    ModelImageTextToTextQueryContract,
)


class PaginationSortDirection(str, Enum):
    """Defines the sort direction options."""

    ASCENDING = "asc"
    DESCENDING = "desc"


class PaginationSortField(str, Enum):
    """Defines the sort field options."""

    CREATED_AT = "created_at"


class PaginationGranularInferenceSortField(str, Enum):
    """Defines the sort field options for granular inferences."""

    CREATED_AT = "created_at"
    SCORE = "score"
    LABEL = "label"


class PaginationEmbeddingSortField(str, Enum):
    """Defines the sort field options for embedding models."""

    CREATED_AT = "created_at"
    EMBEDDING_DISTANCE = "embedding_distance"


class TaskType(str, Enum):
    """The selection of task types supported by the inference store."""

    IMAGE_CLASSIFICATION = "Image Classification"
    OBJECT_DETECTION = "Object Detection"
    ZERO_SHOT_OBJECT_DETECTION = "Zero-Shot Object Detection"
    IMAGE_SEGMENTATION = "Image Segmentation"
    ORIENTED_OBJECT_DETECTION = "Oriented Object Detection"
    IMAGE_EMBEDDING = "Image Embedding"
    TEXT_EMBEDDING = "Text Embedding"
    IMAGE_TEXT_TO_TEXT = "Image Text to Text"


class InferenceAction(str, Enum):
    """The selection of inference actions relative to task types supported by the inference store."""

    PREDICT = "predict"
    PREDICT_PROBA = "predict_proba"
    DETECT = "detect"
    EMBED = "embed"
    QUERY = "query"


class RetentionTaskState(str, Enum):
    """Defines the retention task state options."""

    PENDING = "pending"
    SCHEDULED = "scheduled"
    RUNNING = "running"
    FAILED = "failed"
    STOPPED = "stopped"
    COMPLETE = "complete"


class MetadataFilterOperator(str, Enum):
    """The selection of metadata filter operators supported by the inference store."""

    EQUAL = "="
    NOT_EQUAL = "!="
    GREATER = ">"
    LESS = "<"
    GREATER_OR_EQUAL = ">="
    LESS_OR_EQUAL = "<="
    IN = "in"


class MetadataFilterType(str, Enum):
    """The selection of metadata filter types supported by the inference store."""

    STRING = "string"
    INT = "int"
    FLOAT = "float"
    JSON_STRING = "json.string"
    JSON_INT = "json.int"
    JSON_FLOAT = "json.float"


class MetadataStatisticsType(str, Enum):
    """The selection of metadata statistics types supported by the inference store."""

    STRING = "string"
    INT = "int"
    FLOAT = "float"


class MetadataType(str, Enum):
    """The selection of metadata types supported by the inference store."""

    STRING = "string"
    INT = "int"
    FLOAT = "float"
    JSON = "json"


class DeleteAction(str, Enum):
    """The selection of delete actions."""

    SOFT = "soft"
    HARD = "hard"


class EmbeddingDistanceMetric(str, Enum):
    """The selection of distance metrics supported by the inference store."""

    L2 = "l2"
    NEGATIVE_DOT_PRODUCT = "negative_dot_product"
    COSINE = "cosine"


class Pagination(BaseModel):
    """Get inferences matching pagination constraints.

    :param direction: Direction in which to sort the 'sort' field (defaults to asc).
    :type direction: models.PaginationSortDirection
    :param limit: Limit the number of inferences returned (defaults to 50).
    :type limit: int
    :param offset: Offset the starting position of inferences to be returned (defaults to 0).
    :type offset: int
    :param sort: The column to sort by (defaults to created_at).
    :type sort: Union[models.PaginationSortField, models.PaginationEmbeddingSortField, models.PaginationGranularInferenceSortField]
    :param include_record_count: Whether to return the total record count of all inferences that match the filter criteria
    :type include_record_count: bool
    """

    direction: PaginationSortDirection | None = None
    limit: int | None = None
    offset: int | None = None
    sort: (
        PaginationSortField
        | PaginationEmbeddingSortField
        | PaginationGranularInferenceSortField
        | None
    ) = None
    include_record_count: bool = False
    model_config = ConfigDict(use_enum_values=True)


class TimeWindowFilter(BaseModel):
    """Get inferences within a time window.

    Time bounds use datetime format YYYY-MM-DDTHH:MM:SSZ. To format an existing
    datetime object: dt.strftime("%Y-%m-%dT%H:%M:%S.%fZ").

    :param start: The left time bound. Defaults to 1970-01-01T00:00:00Z if not supplied.
    :type start: Optional[str]
    :param end: The right time bound: Defaults to now if not supplied.
    :type end: Optional[str]
    """

    start: str | None = None
    end: str | None = None


class MetadataFilter(BaseModel):
    """Get inferences matching a given metadata inequality/constraint.

    :param key: The name of the metadata key. Specify json keys using dot notation. For example, in order to filter against the nested key "y" in {"x": {"y": 10, "z": 5}} -> x.y
    :type key: str
    :param operator: The equality/inequality operator in which to compare a value against (=, !=, >, <, >=, <=, in).
    :type operator: models.MetadataFilterOperator
    :param type: The metadata value type (string, int, float, json.string, json.int, json.float).
    :type type: models.MetadataFilterType
    :param value: The value the operator compares against. If using the 'in' operator, pass a list of unquoted values using brackets and comma separation, [v1, v2, ..., vn]
    :type value: str
    """

    key: str
    operator: MetadataFilterOperator
    type: MetadataFilterType
    value: str

    @staticmethod
    def form_values_for_in_operator(
        values_type: MetadataFilterType, values: list[str] | list[int] | list[float]
    ) -> str | None:
        """Format a list of values for use with the metadata 'in' operator."""
        if values_type == MetadataFilterType.STRING:
            return str(values).replace("'", "")
        elif values_type == MetadataFilterType.INT or values_type == MetadataFilterType.FLOAT:
            return str(values)
        return None

    model_config = ConfigDict(use_enum_values=True)


class EmbeddingFilter(BaseModel):
    """Get embeddings using a query embedding and distance metric.

    If `embedding_model_id` is specified reverse search is implicitly enabled.
    Internally the target model will be joined with the embedding model to perform
    the distance search.

    :param embedding_model_id: Optionally filter by embeddings produced by an embedding model associated to the inferences.
    :type embedding_model_id: str
    :param query_embedding: The query embedding to search against.
    :type query_embedding: List[float]
    :param distance_metric: The distance metric operator (defaults to cosine)
    :type end: str
    """

    embedding_model_id: str | None = None
    query_embedding: list[float] = []
    distance_metric: str | None = EmbeddingDistanceMetric.COSINE

    @staticmethod
    def form_query_embedding(embedding: list | np.ndarray) -> str:
        """Serialize a query embedding list or ndarray for the filter request."""
        if isinstance(embedding, list):
            return str(embedding)
        if isinstance(embedding, np.ndarray):
            return str(embedding.tolist())

    model_config = ConfigDict(use_enum_values=True)


class GeoPoint(BaseModel):
    """Defines a point on the globe.

    :param latitude: A latitude value in decimal format between -90 and 90.
    :type latitude: float
    :param longitude: A longitude value in decimal format between -180 and 180.
    :type longitude: float
    """

    latitude: float
    longitude: float


class GeoCircle(BaseModel):
    """Defines a circular search area using a centerpoint and radius.

    :param center: A latitude value in decimal format between -90 and 90.
    :type center: GeoPoint
    :param radius: The radius in meters to expand from the center
    :type radius: float
    """

    center: GeoPoint
    radius: float


class GeoRectangle(BaseModel):
    """Defines a rectangular search area using two points on the globe.

    :param p1: The first point on the globe.
    :type p1: GeoPoint
    :param p2: The second point on the globe.
    :type p2: GeoPoint
    """

    p1: GeoPoint
    p2: GeoPoint


class GeolocationFilter(BaseModel):
    """Defines a rectangular search area using two points on the globe.

    :param gps_coordinates_circle: The circular area on the globe to search for inferences.
    :type gps_coordinates_circle: models.GeoCircle
    :param rectangular_search_area: The rectangular area on the globe to search for inferences.
    :type rectangular_search_area: models.GeoRectangle
    """

    gps_coordinates_circle: GeoCircle | None = None
    gps_coordinates_rectangle: GeoRectangle | None = None


class DeconstructedInferenceFilter(BaseModel):
    """Helper object for filtering inferences by labels and scores.

    :param labels: The list of labels to filter on.
    :type labels: Optional[List[str]]
    :param minimum_score: The minimum confidence score.
    :type minimum_score: Optional[float]
    :param maximum_score: The maximum confidence score.
    :type maximum_score: Optional[float]
    :return_top_n: Whether to return the top N elements within an inference with the highest confidence scores
    :return_top_n: Optional[bool]
    :top_n: Defines N when return top n is requested. Defaults to 1, that is, return the element within the inference with the highest confidence score
    :top_n: Optional[int]
    :return_only_matches: Whether to return only the inference elements that match the label and score filters. Otherwise, a single match will return all inference elements
    :return_only_matches: Optional[bool]
    :return_only_null: Whether to return only null (i.e no detections, classifications, contours, etc were found) inferences. No other label or score filters can be supplied
    :return_only_null: Optional[bool]
    :return_any_matches: Whether to return only non-null (i.e has detections, classifications, contours, etc were found) inferences. No other label or score filters can be supplied
    :return_any_matches: Optional[bool]
    """

    labels: list[str] | None = None
    minimum_score: float | None = None
    maximum_score: float | None = None
    return_top_n: bool = False
    top_n: int | None = None
    return_only_matches: bool = False
    return_only_null: bool = False
    return_any_matches: bool = False


class HashComparator(BaseModel):
    """Helper object for filtering inferences by data hash distances.

    :eq: Equal to this distance value.
    :eq: Optional[int]
    :ne: Not equal to this distance value.
    :ne: Optional[int]
    :gt: Greater than this distance value.
    :gt: Optional[int]
    :ge: Greater than or equal to this distance value.
    :ge: Optional[int]
    :lt: Less than this distance value.
    :lt: Optional[int]
    :le: Less than or equal to this distance value.
    :le: Optional[int]
    """

    eq: int | None = None
    ne: int | None = None
    gt: int | None = None
    ge: int | None = None
    lt: int | None = None
    le: int | None = None


class BitHashFilter(BaseModel):
    """Helper object for filtering inferences by a particular data hash.

    :hex: Hex string of the query hash (64 hex chars for 256 bits).
    :hex: str
    :distance: Distance comparisons (Hamming distance).
    :distance: HashComparator
    """

    hex: str
    distance: HashComparator


class DataHashFilter(BaseModel):
    """Helper object for filtering inferences by one or more data hashes.

    :sha256_hash_filter: Filter by exact SHA256 hex digest of the raw image bytes.  Use when you need exact binary equality (no transformations allowed).
    :sha256_hash_filter: Optional[str]
    :average_hash_filter: Filter by average hash. This is a 256-bit perceptual hash (hash_size=16) comparing each pixel's brightness to the image's average brightness. Best for fast, rough duplicate detection when images are nearly identical and is sensitive to lighting/contrast changes.
    :average_hash_filter: Optional[BitHashFilter]
    :perceptual_hash_filter: Filter by perceptual hash. This is a 256-bit hash (hash_size=16) using the discrete cosine transform (DCT) to capture low-frequency structure. Best general purpose filter for structural similarity, robust to noise, compression, and small edits.
    :perceptual_hash_filter: Optional[BitHashFilter]
    :difference_hash_filter: Filter by difference hash. This is a 256-bit hash (hash_size=16) encoding the direction of brightness changes between adjacent pixels. Fast and good for edge/gradient matching with minor lighting change.
    :difference_hash_filter: Optional[BitHashFilter]
    :wavelet_hash_filter: Filter by wavelet hash. This is a 256-bit hash (hash_size=16) applying a Haar wavelet transform to capture multi-scale spatial and frequency details. More robust than perceptual hash to compression and lighting shifts.
    :wavelet_hash_filter: Optional[BitHashFilter]
    """

    sha256_hash_filter: str | None = None
    average_hash_filter: BitHashFilter | None = None
    perceptual_hash_filter: BitHashFilter | None = None
    difference_hash_filter: BitHashFilter | None = None
    wavelet_hash_filter: BitHashFilter | None = None


class BaseInferenceFilter(BaseModel):
    """Helper object for filtering inferences.

    :param inference_action_filter: Get inferences with a given inference action.
    :type inference_action_filter: str
    :param data_hash_filter: Get inferences matching a series of data hash filters.
    :type data_hash_filter: models.DataHashFilter
    :param data_source_filter: Get inferences with a given data source.
    :type data_source_filter: str
    :param time_window_filter: Get inferences within a time window.
    :type time_window_filter: models.TimeWindowFilter
    :param metadata_filter: Get inferences matching the intersection of one or more metadata filters.
    :type metadata_filter: List[models.MetadataFilter]
    :param location_filter: Get inferences in a circular or rectangular area on the globe.
    :type location_filter: models.GeolocationFilter
    :param deconstructed_inference_filter: Get inferences with certain labels or confidence scores.
    :type deconstructed_inference_filter: models.DeconstructedInferenceFilter
    """

    inference_action_filter: str | None = None
    data_hash_filter: DataHashFilter | None = None
    data_source_filter: str | None = None
    time_window_filter: TimeWindowFilter | None = None
    metadata_filter: list[MetadataFilter] | None = None
    location_filter: GeolocationFilter | None = None
    deconstructed_inference_filter: DeconstructedInferenceFilter | None = None


class NewRegisterModelRequest(BaseModel):
    """Helper object to register a model for inference storage.

    :param model_id: The model id.
    :type model_id: str
    :param project_id: The project id.
    :type project_id: str
    :param task_type: The model task type.
    :type task_type: TaskType
    :param embedding_size: The dimension of the embeddings produced.
    :type embedding_size: int
    """

    model_id: str
    project_id: str
    task_type: TaskType
    embedding_size: int = 0

    model_config = ConfigDict(protected_namespaces=(), use_enum_values=True)


class NewStandardMetadataRequest(BaseModel):
    """Helper object to attach standard metadata to an inference.

    Currently supported task type, inference action pairs:
        Image Classification: [predict, predict_proba, embed]
        Object Detection: [detect]
        Zero-Shot Object Detection: [detect]
        Image Segmentation: [predict, predict_proba]
        Image Embedding = [embed]

    :param data_hash: The SHA256 hexdigest of the data inferred upon. Use the helper function get_data_hash if necessary.
    :type data_hash: str
    :param data_size: The size of the input data.
    :type data_size: int
    :param task_type: The task type of the model.
    :type task_type: models.TaskType
    :param inference_action: The inference action passed to the inference server.
    :type inference_action: models.InferenceAction
    :param data_source: An optional field to express the origin of the inference data.
    :type data_source: Optional[str]
    :param latitude: An optional field to store the latitude the inference data was captured at.
    :type latitude: Optional[float]
    :param longitude: An optional field to store the longitude the inference data was captured at.
    :type longitude: Optional[float]
    :param parent_model_id: The id of the upstream model that initiated or orchestrated this inference call. This is typically used in multi-model workflows. For example, when an embedding model is used to generate embeddings for drift detection, the parent_model_id will reference the original model that handled the inference request. This allows linking downstream inferences (like embeddings) back to their originating model, enabling use cases such as reverse image search or analyzing inference chains in production workflows
    :type parent_model_id: Optional[str]
    :param parent_inference_id: The id of the specific upstream inference request/response that triggered this inference call. This enables traceability from a downstream inference back to the original inference request that produced it within the broader workflow.
    :type parent_inference_id: Optional[str]
    :param average_hash: The average hash compares each pixel's brightness to the image's average brightness to capture overall luminance patterns (using hash_size=16).
    :type average_hash: Optional[str]
    :param perceptual_hash: The perceptual hash uses the discrete cosine transform to capture low-frequency structural information robust to minor noise and compression (using hash_size=16).
    :type perceptual_hash: Optional[str]
    :param difference_hash: The difference hash encodes the direction of brightness changes between adjacent pixels to capture edge structure (using hash_size=16).
    :type difference_hash: Optional[str]
    :param wavelet_hash: The wavelet hash applies a wavelet transform to capture multi-scale spatial and frequency details in the image (using hash_size=16).
    :type wavelet_hash: Optional[str]
    """

    data_hash: str
    data_size: int
    task_type: TaskType
    inference_action: InferenceAction
    data_source: str | None = None
    latitude: float | None = None
    longitude: float | None = None
    parent_model_id: str | None = None
    parent_inference_id: str | None = None
    average_hash: str | None = None
    perceptual_hash: str | None = None
    difference_hash: str | None = None
    wavelet_hash: str | None = None
    model_config = ConfigDict(use_enum_values=True)


class NewExtendedMetadataRequest(BaseModel):
    """Helper object to attach extended/custom metadata to an inference.

    :param key: The name of the metadata key.
    :type key: str
    :param type: The metadata value type (string, int, float, json).
    :type type: models.MetadataType
    :param value: The metadata value.
    :type value: str
    """

    key: str
    type: MetadataType
    value: str
    model_config = ConfigDict(use_enum_values=True)


class NewMetadataCollectionRequest(BaseModel):
    """Helper object to collect standard and extended metadata for an inference.

    Call _encode_ for the ability to upload the corresponding json data to blob storage.

    :param standard_metadata: The standard metadata.
    :type standard_metadata: models.NewStandardMetadataRequest
    :param extended_metadata: The extended metadata. Defaults to an empty list.
    :type extended_metadata: List[models.NewExtendedMetadataRequest]
    """

    standard_metadata: NewStandardMetadataRequest
    extended_metadata: list[NewExtendedMetadataRequest] = []


class NewInferenceAndMetadataCollection(BaseModel):
    """Helper object to collect inference, standard and extended metadata.

    The inference-store stores the inference in whatever format the model/inference
    server natively returns. In order to facilitate label search, filter by confidence
    score, and standardize region/geometry related elements, the deconstructed_inference
    field must be specified. If not specified, the inference will still be stored, but
    the inference will not be retrievable by the before mentioned filters.

    For example, an object detection inference might be returned in the following format:

    .. code-block:: python

        {
            "detection_boxes": [[10.0, 10.0, 20.0, 20.0], [30.0, 30.0, 40.0, 40.0]],
            "detection_classes": ["car", "truck"],
            "detection_scores": [0.9, 0.95]
        }

    Another, equally well trained model might return a very similar result but in the following format:

    .. code-block:: python

        [
            {"bounding_box": [10.0, 10.0, 20.0, 20.0], "score": 0.9, "label": "car"}
            {"bounding_box": [30.0, 30.0, 40.0, 40.0], "score": 0.95, "label": "truck"}
        ]

    Thus, a standard task-type conditional structure is needed so models with different output formats
    can speak the same language.

    Call the encode method for the ability to upload the corresponding json data to blob storage.

    :param image_classification: The collection of image classification inferences
    :type image_classification: List[dict]
    :param object_detection: The collection of object detection inferences
    :type object_detection: List[dict]
    :param image_segmentation: Contour segmentation write payload (list of contour contracts)
    :type image_segmentation: list[dict] | None
        :param image_segmentation_mask: Mask segmentation write payload ({labels, mask, ...}).
        The store assigns the blob key; clients must not set mask_storage_key.
        :type image_segmentation_mask: dict | None
    :param oriented_object_detection: The collection of oriented object detection inferences
    :type oriented_object_detection: List[dict]
    :param embedding: A embedding
    :type embedding: List[float]
    :param metadata: The collection of metadata associated to the inference.
    :type metadata: models.NewMetadataCollectionRequest

    """

    image_classification: list[dict] | None = None
    object_detection: list[dict] | None = None
    image_segmentation: list[dict] | None = None
    image_segmentation_mask: dict | None = None
    oriented_object_detection: list[dict] | None = None
    embedding: list[float] | None = None
    image_text_to_text: list[dict] | None = None
    metadata: NewMetadataCollectionRequest

    def encode(self):
        """Serialize this collection to JSON for upload."""
        return self.json()


class NewInferenceStorageRequest(BaseModel):
    """Helper object to store an inference.

    :param model_id: The id of the model.
    :type model_id: str
    :param inference_id: The id of the inference.
    :type inference_id: str
    :param data: The collection of inference and metadata.
    :type data: models.NewInferenceAndMetadataCollection
    :param data_storage_key: An optional data storage key returned from the upload.upload_data function.
    :type data_storage_key: str
    :param is_protected: Whether the inference and its associated data should be protected from deletion by retention policy
    :type is_protected: bool
    """

    model_id: str
    inference_id: str
    data: NewInferenceAndMetadataCollection
    data_storage_key: str | None = None
    is_protected: bool = False

    model_config = ConfigDict(protected_namespaces=())


class NewGetInferencesRequest(BaseModel):
    """Get inferences matching a series of filters.

    :param filters: A collection of filters.
    :type filters: models.BaseInferenceFilter
    :param embedding_filters: An extended set of filters for embedding models.
    :type embedding_filters: models.EmbeddingFilter
    :param pagination: Get inferences matching pagination constraints.
    :type pagination: models.Pagination
    :param presign: Whether to presign data_storage_key(s).
    :type presign: bool
    """

    filters: BaseInferenceFilter = BaseInferenceFilter()
    embedding_filters: EmbeddingFilter | None = None
    pagination: Pagination | None = None
    presign: bool = False


class NewGetMetadataStatisticsRequest(BaseModel):
    """Helper object to get metadata statistics.

    :param filters: A collection of filters.
    :type filters: models.BaseInferenceFilter
    :param key: Filter by metadata key.
    :type key: str
    :param type: Filter by metadata type.
    :type type: models.MetadataStatisticsType
    :param distribution_bin_count: Number of bins in the distribution. Defaults to producing 10 bins if not specified.
    :type distribution_bin_count: int
    :param distribution_bin_width: Width of a bin within the distribution. Both count and width cannot be specified jointly.
    :type distribution_bin_width: float
    :param distribution_minimum_value: The minimum value in which binning begins. Defaults to the minimum value within the time window specified.
    :type distribution_minimum_value: float
    :param distribution_maximum_value: The maximum value in which binning ends. Defaults to the maximum value within the time window specified.
    :type distribution_maximum_value: float
    """

    filters: BaseInferenceFilter | None = None
    key: str
    type: MetadataStatisticsType
    distribution_bin_count: int | None = None
    distribution_bin_width: float | None = None
    distribution_maximum_value: float | None = None
    distribution_minimum_value: float | None = None
    model_config = ConfigDict(use_enum_values=True)


class NewRetentionTaskRequest(BaseModel):
    """Helper object to create a retention task.

    :param dry_run: If true, returns the number of inferences that would be deleted if the retention policy was fully executed.
    :type dry_run: bool
    :param retention_policy_id: The id of the retention policy to run.
    :type retention_policy_id: str
    """

    dry_run: bool
    retention_policy_id: str


class NewGetRetentionTasksRequest(BaseModel):
    """Helper object to filter retention tasks.

    :param retention_policy_id: Filter by retention policy id.
    :type retention_policy_id: str
    :param state_filter: Filter by retention task state.
    :type state_filter: models.RetentionTaskState
    :param time_window_filter: Get retention tasks within a time window.
    :type time_window_filter: models.TimeWindowFilter
    :param pagination: Get retention tasks matching pagination constraints.
    :type pagination: models.Pagination
    """

    retention_policy_id: str | None = None
    state_filter: RetentionTaskState | None = None
    time_window_filter: TimeWindowFilter | None = None
    pagination: Pagination | None = None
    model_config = ConfigDict(use_enum_values=True)


class NewRetentionPolicyRequest(BaseModel):
    """Helper object to create a retention policy.

    A value of -1 for maximum_record_age indicates that inferences should never be
    deleted. The maximum_blob_age must be greater than or equal to 0. The
    maximum_blob_age must also be equal to or less than the maximum_record_age.

    :param automated_interval: Interval to automatically run retention policy in hours. Set to 0 if manual executions are desired.
    :type automated_interval: int
    :param maximum_record_age: The maximum age (in hours) since now in which an inference and its associated data is safe from deletion.
    :type maximum_record_age: int
    :param maximum_blob_age: The maximum age (in hours) since now in which a blob is safe from deletion.
    :type maximum_blob_age: int
    :param delete_action: Whether to 'soft' or 'hard' delete the database records
    :type delete_action: models.DeleteAction
    """

    automated_interval: int
    maximum_record_age: int
    maximum_blob_age: int
    delete_action: DeleteAction = DeleteAction.SOFT
    model_config = ConfigDict(use_enum_values=True)


class NewExportTaskRequest(BaseModel):
    """Helper object to create a retention task.

    :param filters: A collection of filters.
    :type filters: models.BaseInferenceFilter
    :param include_inference_ids: The list of additional inference ids to include.
    :type include_inference_ids: list[str]
    :param exclude_inference_ids: The list of additional inference ids to exclude.
    :type exclude_inference_ids: list[str]
    :param include_inferences_as_annotations: Whether to include the inferences as annotations (only eligible for version=v2 inferences)".
    :type include_inferences_as_annotations: bool
    :param include_custom_metadata: Whether to include custom metadata attached to the inference.
    :type include_custom_metadata: bool
    """

    filters: BaseInferenceFilter = BaseInferenceFilter()
    include_inference_ids: list[str] = Field(default_factory=list)
    exclude_inference_ids: list[str] = Field(default_factory=list)
    include_inferences_as_annotations: bool = False
    include_custom_metadata: bool = False


class Model(BaseModel):
    """Defines an inference store model resource.

    :param model_id: The model id.
    :type model_id: str
    :param created_at: A timestamp of when the model was created
    :type created_at: datetime
    :param updated_at: A timestamp of when the model was updated
    :type updated_at: datetime
    :param embedding_size: The dimension of the embeddings produced.
    :type embedding_size: int
    """

    model_id: str
    created_at: datetime
    updated_at: datetime
    embedding_size: int

    model_config = ConfigDict(protected_namespaces=())


class Metadata(BaseModel):
    """Defines an inference store metadata resource.

    :param key: The name of the metadata key.
    :type key: str
    :param type: The metadata value type (string, int, float, json).
    :type type: str
    :param value: The metadata value.
    :type value: str
    """

    key: str
    type: str
    value: str


class MetadataStatistics(BaseModel):
    """Defines an inference store metadata statistics resource.

    :param count: The number of observations given the request filters.
    :type count: int
    :param distribution: The distribution of values.
    :type distribution: Dict[str, int]
    :param histogram: Histogram of numeric values.
    :type histogram: list[dict[str, int | float]]
    :param min: The minimum value in the set of metadata values
    :type min: int
    :param max: The maximum value in the set of metadata values
    :type max: int
    """

    count: int | None = None
    distribution: dict[str, int] | None = None
    histogram: list[dict[str, int | float]] | None = None
    min: float | None = None
    max: float | None = None


class MetadataKeyTypeCounts(BaseModel):
    """Defines an inference store metadata key type count resource.

    :param counts: The count of each metadata key, type pair.
    :type counts: Dict[str, Dict[str, int]]
    """

    counts: dict[str, dict[str, int]]


class Inference(BaseModel):
    """Defines an inference store inference resource.

    :param model_id: The model id.
    :type model_id: str
    :param inference_id: The inference id.
    :type inference_id: str
    :param created_at: A timestamp of when the inference was created
    :type created_at: datetime
    :param updated_at: A timestamp of when the inference was updated
    :type updated_at: datetime
    :param inference_action: The inference action.
    :type inference_action: str
    :param data: The inference data. Returned as an arbitrary string when the associated model is not registered as an embedding model.
    :type data: Optional[str]
    :param embedding_distance: The embedding distance from a query embedding.
    :type embedding_distance: Optional[float]
    :param metadata: The collection of metadata associated to the inference.
    :type metadata: Optional[List[Metadata]]
    :param data_hash: The hash of the inference input data.
    :type data_hash: str
    :param data_source: The data source of the inference.
    :type data_source: Optional[str]
    :param data_coordinates: A set of geospatial coordinates defining where the inference occurred.
    :type data_coordinates: Optional[GeoPoint]
    :param data_storage_key: The internal data storage key for the inference input data.
    :type data_storage_key: Optional[str]
    :param presigned_url: A presigned url to download the inference input data.
    :type presigned_url: Optional[str]
    :param is_protected: Whether the inference and its associated data should be protected from deletion by retention policy
    :type is_protected: bool
    :param version: The inference version.
    :type version: str
    :param image_classification: The list of image classification results.
    :type image_classification: Optional[list[ModelImageClassificationContract]]
    :param object_detection: The list of object detection results.
    :type object_detection: Optional[list[ModelImageObjectDetectionContract]]
    :param oriented_object_detection: The list of oriented object detection results (with rotated bounding boxes).
    :type oriented_object_detection: Optional[list[ModelImageOrientedObjectDetectionContract]]
    :param image_segmentation: Contour array under image_segmentation. Null for mask-only inferences.
    :type image_segmentation: Optional[list[ImageSegmentationContourContract]]
    :param image_segmentation_mask: Mask segmentation results. Null for contour-only inferences.
    :type image_segmentation_mask: Optional[ImageSegmentationMaskResult]
    :param embedding: The embedding vector associated with the inference.
    :type embedding: Optional[list[float]]
    :param image_text_to_text: The list of image text to text results.
    :type image_text_to_text: Optional[list[ModelImageTextToTextQueryContract]]
    """

    model_id: str
    inference_id: str
    created_at: datetime
    updated_at: datetime
    inference_action: str
    data: str | None = None
    embedding_distance: float | None = None
    metadata: list[Metadata] | None = None
    data_hash: str
    data_source: str | None = None
    data_coordinates: GeoPoint | None = None
    data_storage_key: str | None = None
    presigned_url: str | None = None
    is_protected: bool = False
    version: str
    image_classification: list[ModelImageClassificationContract] | None = None
    object_detection: list[ModelImageObjectDetectionContract] | None = None
    oriented_object_detection: list[ModelImageOrientedObjectDetectionContract] | None = None
    image_segmentation: list[ImageSegmentationContourContract] | None = None
    image_segmentation_mask: ImageSegmentationMaskResult | None = None
    embedding: list[float] | None = None
    image_text_to_text: list[ModelImageTextToTextQueryContract] | None = None

    model_config = ConfigDict(protected_namespaces=())

    @property
    def structured_embedding(self) -> list[int | float] | None:
        """Parse the embedding payload into a numeric list when present."""
        if self.data is None:
            return []
        return ast.literal_eval(self.data)


class RawInferenceMetadata(BaseModel):
    """Defines raw inference metadata.

    :param inference_base_id: The inference base id.
    :type inference_base_id: str
    :param request_id: The original request id, if present.
    :type request_id: Optional[str]
    :param model_id: The model id.
    :type model_id: str
    :param project_id: The project id.
    :type project_id: str
    :param user_id: The user id.
    :type user_id: str
    :param task_type: The task type.
    :type task_type: str
    :param inference_protocol: The inference protocol.
    :type inference_protocol: str
    :param engine_version_id: The engine version id.
    :type engine_version_id: str
    :param request_method: The HTTP request method.
    :type request_method: str
    :param request_url_suffix: The URL suffix sent to the inference server.
    :type request_url_suffix: str
    :param request_headers: The raw request headers.
    :type request_headers: Optional[dict[str, list[str]]]
    :param response_status_code: The HTTP response status code.
    :type response_status_code: int
    :param response_headers: The raw response headers.
    :type response_headers: Optional[dict[str, list[str]]]
    :param request_received_at: When the inference proxy accepted the request.
    :type request_received_at: datetime
    :param request_forwarded_at: When the inference proxy forwarded the request.
    :type request_forwarded_at: datetime
    :param request_responded_at: When the inference server response was returned to the proxy.
    :type request_responded_at: datetime
    :param created_at: When the raw inference was captured.
    :type created_at: datetime
    :param parsed_at: When the raw inference was parsed, if available.
    :type parsed_at: Optional[datetime]
    """

    inference_base_id: str
    request_id: str | None = None
    model_id: str
    project_id: str
    user_id: str
    task_type: str
    inference_protocol: str
    engine_version_id: str
    request_method: str
    request_url_suffix: str
    request_headers: dict[str, list[str]] | None = None
    response_status_code: int
    response_headers: dict[str, list[str]] | None = None
    request_received_at: datetime
    request_forwarded_at: datetime
    request_responded_at: datetime
    created_at: datetime
    parsed_at: datetime | None = None


class RawInferenceMetadataPage(BaseModel):
    """Defines a page of raw inference metadata."""

    items: list[RawInferenceMetadata]
    cursor: str | None = None


class RetentionTask(BaseModel):
    """Defines an inference store retentiont task resource.

    :param id: The retention task id.
    :type id: str
    :param retention_policy_id: The retention policy id.
    :type retention_policy_id: str
    :param deleted_record_count: The count of all records currently deleted.
    :type deleted_record_count: int
    :param deleted_blob_count: The count of all blobs currently deleted.
    :type deleted_blob_count: int
    :param total_record_count: The expected total count of all records to be deleted.
    :type total_record_count: int
    :param total_blob_count: The expected total count of all blobs to be deleted.
    :type total_blob_count: int
    :param state: The state of the retention task.
    :type state: str
    :param maximum_record_age_limit: The timestamp in which records are safe from deletion.
    :type maximum_record_age_limit: datetime
    :param maximum_blob_age_limit: The timestamp in which blobs are safe from deletion.
    :type maximum_blob_age_limit: datetime
    """

    id: str
    retention_policy_id: str
    deleted_record_count: int
    deleted_blob_count: int
    total_record_count: int
    total_blob_count: int
    state: str
    maximum_record_age_limit: datetime
    maximum_blob_age_limit: datetime


class RetentionPolicy(BaseModel):
    """Defines an inference store retention policy resource.

    :param id: The retention policy id.
    :type id: str
    :param model_id: The model id.
    :type model_id: str
    :param delete_action: Whether records are soft deleted or hard deleted.
    :type delete_action: bool
    :param maximum_record_age: The maximum age (in hours) in which an inference and its associated data is safe from deletion.
    :type maximum_record_age: int
    :param maximum_blob_age: The maximum age (in hours) in which a blob is safe from deletion.
    :type maximum_blob_age: int
    :param automated_interval: The interval (in hours) in which this retention policy will be automatically run.
    :type automated_interval: int
    :param last_scheduled_at: The last time a retention task for this retention policy was run.
    :type last_scheduled_at: datetime
    """

    id: str
    model_id: str
    delete_action: str
    maximum_record_age: int
    maximum_blob_age: int
    automated_interval: int | None = None
    last_scheduled_at: datetime | None = None

    model_config = ConfigDict(protected_namespaces=())


class ExportTask(BaseModel):
    """Defines an inference store retentiont task resource.

    :param id: The export task id.
    :type id: str
    :param progress_count: The current number of inferences added to the archive file.
    :type progress_count: int
    :param expected_count: The expected number of inferences to be added to archive file.
    :type expected_count: int
    :param state: The export task state.
    :type state: str
    :param presigned_url: A presigned url to the archive if the export task is complete.
    :type presigned_url: Optional[str]
    """

    id: str
    progress_count: int
    expected_count: int
    state: str
    presigned_url: str | None = None


class DataUpload(BaseModel):
    """Defines an inference store data upload resource.

    :param data_presigned_url: A presigned url to upload the inference input data to.
    :type data_presigned_url: str
    :param data_storage_key: The internal storage key to the inference input data.
    :type data_storage_key: str
    """

    data_presigned_url: str
    data_storage_key: str


class MetadataUpload(BaseModel):
    """Defines an inference store metadata upload resource.

    :param metadata_presigned_url: A presigned url to upload the inference and metadata to.
    :type metadata_presigned_url: str
    :param metadata_storage_key: The internal storage key to the inference and metadata.
    :type metadata_storage_key: str
    """

    metadata_presigned_url: str
    metadata_storage_key: str


class OrdinalFilter(BaseModel):
    """A left-bounded and/or right-bounded numeric filter.

    :param start: The left bounded number, otherwise unbounded.
    :type start: int | None
    :param end: The right bounded number, otherwise unbounded.
    :type end: int | None
    """

    start: int | None
    end: int | None


class SourceFilter(BaseModel):
    """Filter tracks by source.

    :param sources: The set of sources
    :type sources: Optional[list[str]]
    """

    sources: list[str] | None = None


class TrackFilterGroup(BaseModel):
    """Collection of filters for querying tracks.

    :param time_window_filter: Filter inferences within a time window.
    :type time_window_filter: Optional[TimeWindowFilter]
    :param sequence_number_filter: Filter tracks by sequence number.
    :type sequence_number_filter: Optional[OrdinalFilter]
    :param lifetime_filter: Filter tracks by lifetime.
    :type lifetime_filter: Optional[OrdinalFilter]
    :param total_updates_filter: Filter tracks by total updates.
    :type total_updates_filter: Optional[OrdinalFilter]
    :param total_missed_updates_filter: Filter tracks by total missed updates.
    :type total_missed_updates_filter: Optional[OrdinalFilter]
    :param consecutive_updates_filter: Filter tracks by consecutive updates.
    :type consecutive_updates_filter: Optional[OrdinalFilter]
    :param consecutive_missed_updates_filter: Filter tracks by consecutive missed updates.
    :type consecutive_missed_updates_filter: Optional[OrdinalFilter]
    :param status_filter: Filter tracks by status.
    :type status_filter: Optional[list[str]]
    :param location_filter: Filter tracks by location.
    :type location_filter: Optional[LocationFilter]
    :param source_filter: Filter tracks by source.
    :type source_filter: Optional[SourceFilter]
    """

    time_window_filter: TimeWindowFilter | None = None
    sequence_number_filter: OrdinalFilter | None = None
    lifetime_filter: OrdinalFilter | None = None
    total_updates_filter: OrdinalFilter | None = None
    total_missed_updates_filter: OrdinalFilter | None = None
    consecutive_updates_filter: OrdinalFilter | None = None
    consecutive_missed_updates_filter: OrdinalFilter | None = None
    status_filter: list[str] | None = None
    location_filter: GeolocationFilter | None = None
    source_filter: SourceFilter | None = None


class NewGetTracksRequest(BaseModel):
    """Get tracks matching a series of filters.

    :param filters: Additional data filters.
    :type filters: Optional[TrackFilterGroup]
    :param pagination: Paginate through inferences. If not supplied a default limit of 50 is applied, with offset 0.
    :type pagination: Optional[Pagination]
    """

    filters: TrackFilterGroup | None = None
    pagination: Pagination | None = None


class Track(BaseModel):
    """Get tracks matching a series of filters.

    :param track_id: The reference ID for the track.
    :type track_id: Optional[str]
    :param tracker_id: The ID of the tracker.
    :type tracker_id: Optional[str]
    :param tracker_kind: The kind/type of the tracker.
    :type tracker_kind: Optional[str]
    :param created_at: A timestamp of when the inference was created.
    :type created_at: Optional[str]
    :param updated_at: A timestamp of when the inference was last updated.
    :type updated_at: Optional[str]
    :param ts: When the frame/packet/entity was seen/occurred.
    :type ts: Optional[str]
    :param sequence_number: The ordinal number of the camera/video frame.
    :type sequence_number: Optional[int]
    :param source: The source identifier that uniquely specifies where the tracked objects originate from.
    :type source: Optional[str]
    :param model_id: The ID of the model that produced the inference used to create or update tracks.
    :type model_id: Optional[str]
    :param inference_id: The ID returned by the inference server/process used to create or update tracks.
    :type inference_id: Optional[str]
    :param measurement_id: The measurement/detection level ID within the inference response.
    :type measurement_id: Optional[str]
    :param lifetime: The count of frames the track has been alive for.
    :type lifetime: Optional[int]
    :param consecutive_updates: The count of consecutive updates via measurement.
    :type consecutive_updates: Optional[int]
    :param consecutive_missed_updates: The count of consecutive missed updates. If this exceeds the tracker's max_missed_updates, the track status should be "lost".
    :type consecutive_missed_updates: Optional[int]
    :param status: The track status: [new, active, lost].
    :type status: Optional[str]
    :param label: The track class label.
    :type label: Optional[str]
    :param measurement: The measurement used to update the tracker.
    :type measurement: Optional[dict]
    :param measurement_uncertainty: The measurement uncertainty used to update the tracker.
    :type measurement_uncertainty: Optional[list[list[float]]]
    :param predicted_state_estimate: The track's predicted estimate position/state before a potential measurement assignment
    :type predicted_state_estimate: Optional[dict]
    :param state_estimate: The track's updated estimate position/state after a potential measurement assignment
    :type state_estimate: Optional[dict]
    :param state_estimate_uncertainty: The track's state estimate uncertainty
    :type state_estimate_uncertainty: Optional[list[list[float]]]
    :param cost: The cost value from the assignment function.
    :type cost: Optional[float]
    :param coordinate: The coordinate associated with the track.
    :type coordinate: Optional[GeoPoint]
    """

    track_id: str | None
    tracker_id: str | None
    tracker_kind: str | None
    created_at: datetime | None
    updated_at: datetime | None
    ts: datetime | None
    sequence_number: int | None
    source: str | None
    model_id: str | None
    inference_id: str | None
    measurement_id: str | None = None
    lifetime: int | None
    consecutive_updates: int | None
    consecutive_missed_updates: int | None
    status: str | None
    label: str | None
    measurement: dict | None
    measurement_uncertainty: list[list[float]] | None
    predicted_state_estimate: dict | None
    state_estimate: dict | None
    state_estimate_uncertainty: list[list[float]] | None
    cost: float | None
    coordinate: GeoPoint | None = None

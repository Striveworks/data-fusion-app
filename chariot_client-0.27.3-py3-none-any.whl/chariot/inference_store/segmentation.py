"""Helpers for inference-store image segmentation reads."""

from pydantic import BaseModel, ConfigDict


class ImageSegmentationPoint(BaseModel):
    """A single point in a segmentation contour."""

    x: float
    y: float


class ImageSegmentationContourContract(BaseModel):
    """Contour-shaped segmentation item (legacy store rows and contour writes)."""

    id: str | None = None
    label: str
    score: float = 1.0
    contour: list[list[ImageSegmentationPoint]]


class ImageSegmentationMask(BaseModel):
    """Mask-shaped segmentation payload from inference-store / inference-storage."""

    labels: dict[str, str]
    format: str | None = None
    height: int | None = None
    width: int | None = None
    encoding: str | None = None
    mask: list[list[int]] | None = None

    model_config = ConfigDict(extra="ignore")


class ImageSegmentationClass(BaseModel):
    """Class record stored for a mask inference. No contour."""

    id: str | None = None
    label: str
    score: float = 0.0

    model_config = ConfigDict(extra="ignore")


class ImageSegmentationMaskResult(BaseModel):
    """Read model for image_segmentation_mask.

    List responses set mask_available and omit mask. A single GET includes mask
    when pixels were read.
    """

    class_labels: list[ImageSegmentationClass] = []
    mask_available: bool = False
    mask: ImageSegmentationMask | None = None

    model_config = ConfigDict(extra="ignore")

    def has_mask(self) -> bool:
        """Return True when a mask object is present."""
        return self.mask is not None

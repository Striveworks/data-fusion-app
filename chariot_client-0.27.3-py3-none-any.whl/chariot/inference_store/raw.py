from typing import Any

import chariot._apis
from chariot.inference_store import models

__all__ = [
    "get_raw_metadata",
    "list_raw_metadata",
    "get_raw_request_body",
    "get_raw_response_body",
]


def get_raw_metadata(model_id: str, inference_base_id: str) -> models.RawInferenceMetadata | None:
    """Get raw inference metadata for a single inference base id."""
    response = chariot._apis.inferencestore.raw_api.raw_metadata_model_id_get(
        model_id=model_id,
        inference_base_id=inference_base_id,
    )
    if response.data is None:
        return None
    data: dict[str, Any] = response.data
    return models.RawInferenceMetadata.model_validate(data)


def list_raw_metadata(
    model_id: str, cursor: str | None = None
) -> models.RawInferenceMetadataPage | None:
    """List raw inference metadata for a model."""
    response = chariot._apis.inferencestore.raw_api.raw_metadata_model_id_get(
        model_id=model_id,
        cursor=cursor,
    )
    if response.data is None:
        return None
    data: dict[str, Any] = response.data
    return models.RawInferenceMetadataPage.model_validate(data)


def get_raw_request_body(model_id: str, inference_base_id: str) -> bytes:
    """Get raw request body bytes."""
    response = chariot._apis.inferencestore.raw_api.raw_request_body_model_id_inference_base_id_get(
        model_id=model_id,
        inference_base_id=inference_base_id,
    )
    return bytes(response)


def get_raw_response_body(model_id: str, inference_base_id: str) -> bytes:
    """Get raw response body bytes."""
    response = (
        chariot._apis.inferencestore.raw_api.raw_response_body_model_id_inference_base_id_get(
            model_id=model_id,
            inference_base_id=inference_base_id,
        )
    )
    return bytes(response)

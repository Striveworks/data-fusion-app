import chariot._apis
from chariot import mcp_setting
from chariot.inference_store import _utils, models


@mcp_setting(mutating=True)
def create_export_task(
    model_id: str, request_body: models.NewExportTaskRequest
) -> models.ExportTask | None:
    """Create an export task to get data and inferences, and optionally
    annotations and metadata.

    :param model_id: The model id.
    :type model_id: str
    :param request_body: The export task to execute.
    :type request_body: models.NewExportTaskRequest
    :return: The export task.
    :rtype: Optional[models.ExportTask]
    """
    response = chariot._apis.inferencestore.export_task_api.export_task_model_id_post(
        model_id=model_id, body=request_body.model_dump()
    )
    if not response.data:
        return None
    return _utils.convert_to_dataclass(response.data.model_dump(), models.ExportTask)


def get_export_task(model_id: str, export_task_id: str) -> models.ExportTask | None:
    """Get a export task.

    :param model_id: The model id.
    :type model_id: str
    :param export_task_id: The export task id.
    :type export_task_id: str
    :return: The export task.
    :rtype: Optional[models.ExportTask]
    """
    response = chariot._apis.inferencestore.export_task_api.export_task_model_id_task_id_get(
        model_id=model_id, task_id=export_task_id
    )
    if not response.data:
        return None
    return _utils.convert_to_dataclass(response.data.model_dump(), models.ExportTask)

from pydantic import BaseModel

BaseModel.model_config["protected_namespaces"] = ()

from ._types import *
from .monitor import *
from .representer import *
from .embed import *

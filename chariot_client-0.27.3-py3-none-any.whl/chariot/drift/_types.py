# ------------------------------------------------------------------------------
# Copyright Striveworks, Inc.
# All rights reserved.
# ------------------------------------------------------------------------------
# fmt:off

from datetime import datetime
from enum import Enum
from typing import Any, NewType

from pydantic import BaseModel, ConfigDict, Field

__all__ = [
    "Check",
    "CheckID",
    "CheckJob",
    "CheckPoint",
    "CheckStatus",
    "DetectorJob",
    "DetectorJobState",
    "DriftMetric",
    "DriftAlert",
    "DriftError",
    "EmbeddingJob",
    "EmbeddingJobState",
    "JobID",
    "ModelID",
    "MonitorStatus",
    "Monitor"
]


CheckID = NewType("CheckID", str)
ModelID = NewType("ModelID", str)


class DriftError(Exception):
    ...


class DriftMetric(str, Enum):
    SEMANTIC = "semantic"
    KOLMOGOROV_SMIRNOV = "kolmogorov-smirnov"
    CRAMER_VON_MISES = "cramer-von-mises"


class CheckStatus(str, Enum):
    DRIFT_NONE = "drift-none"
    DRIFT_DETECTED = "drift-detected"
    DRIFT_ERROR = "drift-error"
    DRIFT_NOT_ENOUGH_INFERENCES = "drift-not-enough-inferences"
    DRIFT_FAILED_OOD_COMPUTATION = "drift-failed-ood-computation"


class DriftAlert(str, Enum):
    NOTIFY = "notify"
    SILENT = "silent"


class MonitorStatus(str, Enum):
    ENABLED = "enabled"
    DISABLED = "disabled"


class Record(BaseModel):
    """Base class for all record."""

    time_create: datetime = Field(default_factory=datetime.utcnow)
    time_modify: datetime = Field(default_factory=datetime.utcnow)
    time_delete: datetime | None = None


class Monitor(Record):
    monitor_status: MonitorStatus = MonitorStatus.DISABLED
    model_id: ModelID
    drift_alert: DriftAlert = DriftAlert.SILENT
    drift_metric: DriftMetric
    data_source: str = "*"
    window_seconds: int
    current_workflow: str | None = None
    last_run: datetime | None = None
    minimum_cardinality: int | None = None
    maximum_cardinality: int | None = None


class Check(Record):
    check_id: CheckID
    model_id: ModelID
    check_status: CheckStatus = CheckStatus.DRIFT_NONE
    window_begin: datetime
    window_end: datetime
    metric: DriftMetric
    data_source: str = "*"
    attributes: dict[str, Any] = Field(default_factory=dict)


class CheckPoint(BaseModel):
    time: datetime
    drift: float


class EmbeddingJobState(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    ABORTED = "aborted"


class DetectorJobState(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    ABORTED = "aborted"


class EmbeddingJob(BaseModel):
    generated_id: str
    project_id: str | None = None
    dataset_id: str | None = None
    dataset_version_id: str | None = None
    snapshot_id: str | None = None
    split: str | None = None
    embedding_model_id: str
    workflow_id: str | None = None
    job_state: EmbeddingJobState
    attributes: dict


class DetectorJob(Record):
    generated_id: str
    project_id: str
    model_id: str
    metric: DriftMetric
    workflow_id: str | None = None
    job_state: DetectorJobState
    storage_url: str | None = None
    attributes: dict


class JobID(str):
    """
    """


class CheckJob(BaseModel):
    """
    """

    job_id: JobID

    model_config = ConfigDict(
        arbitrary_types_allowed=True # since pydantic sees JobID as an arbitrary type
    )

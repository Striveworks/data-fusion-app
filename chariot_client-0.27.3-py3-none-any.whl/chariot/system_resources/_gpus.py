from chariot import _apis

__all__ = [
    "get_available_multi_gpu_node_groups",
    "get_available_system_gpus",
    "get_running_system_gpus",
]


@_apis.login_required
def get_available_system_gpus() -> list:
    response = _apis.resources.gpus_api.v2_gpus_get().to_dict()
    available_gpus = response["data"]["available"]

    resources_list = []
    for gpu in available_gpus:
        if product := gpu.get("product"):
            resources_list.append(product)

    return resources_list


@_apis.login_required
def get_available_multi_gpu_node_groups(min_gpu_capacity: int = 2) -> list[str]:
    """Return node group labels that can schedule multi-GPU workloads.

    Uses v2/gpus available node groups and returns product labels with gpu count equal to or greater than the requested minimum capacity.
    """
    avail = _apis.resources.gpus_api.v2_gpus_get().to_dict()["data"].get("available", [])

    return list(
        set(
            entry["product"]
            for entry in avail
            if entry.get("product") and entry.get("count", 0) >= min_gpu_capacity
        )
    )


@_apis.login_required
def get_running_system_gpus(min_count: int = 1):
    """Get nvidia.com/gpu.product values for GPUs on running nodes.

    These are hardware product names (e.g. NVIDIA-A10G), not node group labels
    (e.g. AMPERE-A10G-x4). Prefer get_available_multi_gpu_node_groups for scheduling.
    """
    response = _apis.resources.gpus_api.v2_gpus_get().to_dict()
    running_gpus = response["data"]["running"]

    resources_list = []
    for gpu in running_gpus:
        if gpu.get("count") >= min_count:
            if product := gpu.get("product"):
                resources_list.append(product)

    return resources_list

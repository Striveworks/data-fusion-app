"""The Chariot Command Line Interface (CLI)."""

from .main import root as main

__all__ = ["main"]

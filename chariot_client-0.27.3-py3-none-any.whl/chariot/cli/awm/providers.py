"""Ensure workflow auth providers are connected before Chat."""

from __future__ import annotations

import time
from collections.abc import Sequence
from urllib.parse import urljoin

import click
import questionary
import requests

from chariot import awm
from chariot.cli.awm.common import _BACK, _select
from chariot.config import get_bearer_token, settings

_PROVIDER_POLL_INTERVAL = 3.0
_PROVIDER_POLL_TIMEOUT = 300.0
_MAX_PROVIDER_SIGNIN_ATTEMPTS = 3

_CONNECT = "__awm_connect_providers__"
_BYPASS = "__awm_bypass_providers__"

_INCOMPLETE_PROVIDERS_WARNING = (
    "Some agent features and connected tool calls may fail if you proceed without authentication."
)


def _missing_provider_names(
    providers: Sequence[awm.models.WorkflowAuthProvider],
) -> list[str]:
    return [provider.name for provider in providers if not provider.connected]


def _absolute_url(href: str) -> str:
    if href.startswith("http://") or href.startswith("https://"):
        return href
    base = settings.base_url.rstrip("/") + "/"
    return urljoin(base, href.lstrip("/"))


def _warn_incomplete_providers(provider_names: Sequence[str]) -> None:
    names = ", ".join(provider_names)
    click.echo(
        click.style(
            f"  Warning: {_INCOMPLETE_PROVIDERS_WARNING}",
            fg="yellow",
        )
    )
    if names:
        click.echo(click.style(f"  Disconnected: {names}", fg="yellow"))


def _provider_signin_url(provider_name: str) -> str:
    """Resolve the provider's signin href from GET /auth/v1/providers."""
    base = settings.base_url.rstrip("/")
    response = requests.get(
        f"{base}/auth/v1/providers/",
        params={"name": provider_name},
        headers={"Authorization": f"Bearer {get_bearer_token()}"},
        timeout=30,
    )
    response.raise_for_status()
    payload = response.json()
    providers = payload.get("data") or []
    for provider in providers:
        if provider.get("name") != provider_name:
            continue
        for action in provider.get("_actions") or []:
            if action.get("tag") == "signin" and action.get("href"):
                return _absolute_url(action["href"])
        raise RuntimeError(
            f"Provider '{provider_name}' has no signin action in /auth/v1/providers/"
        )
    raise RuntimeError(f"Provider '{provider_name}' not found in /auth/v1/providers/")


def _poll_provider_connected(workflow_id: str, provider_name: str) -> bool:
    deadline = time.monotonic() + _PROVIDER_POLL_TIMEOUT
    while True:
        providers = awm.workflows.get_workflow_auth_providers(workflow_id)
        for provider in providers:
            if provider.name == provider_name and provider.connected:
                return True
        if time.monotonic() >= deadline:
            return False
        time.sleep(_PROVIDER_POLL_INTERVAL)


def _prompt_provider_connection_action(missing: Sequence[str]) -> str | None:
    """Ask whether to connect missing providers, bypass, or cancel chat."""
    return _select(
        f"Provider(s) required: {', '.join(missing)}",
        choices=[
            questionary.Choice(title="Connect providers", value=_CONNECT),
            questionary.Choice(title="Continue without connecting", value=_BYPASS),
            questionary.Choice(title="↩ Cancel", value=_BACK),
        ],
    )


def ensure_workflow_auth_providers_ready(workflow_id: str) -> bool:
    """Confirm required auth providers are connected; open signin for any that are missing.

    Uses GET /auth/v1/providers/?name=… signin href (not a hardcoded protocol path).
    This opens normal provider login and polls AWM until connected.

    Returns True when chat may proceed (including after bypass or circuit-breaker
    with a warning). Returns False only when the user cancels.
    """
    while True:
        providers = awm.workflows.get_workflow_auth_providers(workflow_id)
        missing = _missing_provider_names(providers)
        if not missing:
            return True

        action = _prompt_provider_connection_action(missing)
        if action is None or action == _BACK:
            return False
        if action == _BYPASS:
            _warn_incomplete_providers(missing)
            return True

        still_missing: list[str] = []
        interrupted = False
        for provider_name in missing:
            connected = False
            for attempt in range(1, _MAX_PROVIDER_SIGNIN_ATTEMPTS + 1):
                click.echo(
                    f"  Connecting provider '{provider_name}' "
                    f"(attempt {attempt}/{_MAX_PROVIDER_SIGNIN_ATTEMPTS})…"
                )
                try:
                    signin_url = _provider_signin_url(provider_name)
                except Exception as exc:  # noqa: BLE001 - surface failures to CLI user
                    click.echo(
                        click.style(
                            f"  Failed to resolve signin URL for '{provider_name}': {exc}",
                            fg="red",
                        )
                    )
                    break

                click.echo(
                    f"  Click the link below to signin for '{provider_name}'…\n\n  {signin_url}"
                )
                click.echo("  Waiting for provider connection…")
                try:
                    connected_now = _poll_provider_connected(workflow_id, provider_name)
                except KeyboardInterrupt:
                    click.echo()
                    interrupted = True
                    break

                if connected_now:
                    click.echo(click.style(f"  Provider '{provider_name}' connected.", fg="green"))
                    connected = True
                    break

                if attempt < _MAX_PROVIDER_SIGNIN_ATTEMPTS:
                    click.echo(
                        click.style(
                            f"  Provider '{provider_name}' still not connected; retrying…",
                            fg="yellow",
                        )
                    )

            if interrupted:
                break

            if not connected:
                click.echo(
                    click.style(
                        f"  Could not confirm provider '{provider_name}' after "
                        f"{_MAX_PROVIDER_SIGNIN_ATTEMPTS} attempt(s).",
                        fg="yellow",
                    )
                )
                still_missing.append(provider_name)

        if interrupted:
            continue

        remaining = _missing_provider_names(awm.workflows.get_workflow_auth_providers(workflow_id))
        incomplete = list(dict.fromkeys([*still_missing, *remaining]))
        if incomplete:
            _warn_incomplete_providers(incomplete)
        return True

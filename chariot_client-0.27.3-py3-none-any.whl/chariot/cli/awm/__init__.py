"""AWM (Agentic Workflow Manager) CLI commands."""

from chariot.cli.awm.menus import awm_group

__all__ = ["awm_group"]

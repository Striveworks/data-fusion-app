"""Configuration component menus for the AWM CLI."""

import itertools
import json

import click
import questionary

from chariot import awm
from chariot.cli.awm.common import (
    _BACK,
    _NEW,
    _QUESTIONARY_STYLE,
    _column_header,
    _edit_json,
    _flush_stdin,
    _run_menu_action,
    _select,
    _Spinner,
)
from chariot.cli.awm.config_import import import_configurations_from_file

_COMPONENT_TYPE_LABELS = {
    awm.models.COMPONENT_TYPE_WORKFLOW: "Workflow",
    awm.models.COMPONENT_TYPE_AGENT: "Agent",
    awm.models.COMPONENT_TYPE_TOOL_PROFILE: "Tool Use Profile",
    awm.models.COMPONENT_TYPE_EVALUATOR: "Evaluator",
    awm.models.COMPONENT_TYPE_MCP_CONNECTION: "MCP Connection",
    awm.models.COMPONENT_TYPE_SHARED: "Shared",
}

_LIST_COMPONENTS_FN = {
    awm.models.COMPONENT_TYPE_AGENT: awm.list_agent_configuration_components,
    awm.models.COMPONENT_TYPE_WORKFLOW: awm.list_workflow_configuration_components,
    awm.models.COMPONENT_TYPE_TOOL_PROFILE: awm.list_tool_profile_configuration_components,
    awm.models.COMPONENT_TYPE_MCP_CONNECTION: awm.list_mcp_connection_configuration_components,
    awm.models.COMPONENT_TYPE_EVALUATOR: awm.list_evaluator_configuration_components,
    awm.models.COMPONENT_TYPE_SHARED: awm.list_shared_configuration_components,
}

_LIST_VERSIONS_FN = {
    awm.models.COMPONENT_TYPE_AGENT: awm.list_agent_configuration_versions,
    awm.models.COMPONENT_TYPE_WORKFLOW: awm.list_workflow_configuration_versions,
    awm.models.COMPONENT_TYPE_TOOL_PROFILE: awm.list_tool_profile_configuration_versions,
    awm.models.COMPONENT_TYPE_MCP_CONNECTION: awm.list_mcp_connection_configuration_versions,
    awm.models.COMPONENT_TYPE_EVALUATOR: awm.list_evaluator_configuration_versions,
    awm.models.COMPONENT_TYPE_SHARED: awm.list_shared_configuration_versions,
}

_GET_VERSION_FN = {
    awm.models.COMPONENT_TYPE_AGENT: awm.get_agent_configuration_version,
    awm.models.COMPONENT_TYPE_WORKFLOW: awm.get_workflow_configuration_version,
    awm.models.COMPONENT_TYPE_TOOL_PROFILE: awm.get_tool_profile_configuration_version,
    awm.models.COMPONENT_TYPE_MCP_CONNECTION: awm.get_mcp_connection_configuration_version,
    awm.models.COMPONENT_TYPE_EVALUATOR: awm.get_evaluator_configuration_version,
    awm.models.COMPONENT_TYPE_SHARED: awm.get_shared_configuration_version,
}

_CREATE_FN = {
    awm.models.COMPONENT_TYPE_AGENT: awm.create_agent_configuration,
    awm.models.COMPONENT_TYPE_WORKFLOW: awm.create_workflow_configuration,
    awm.models.COMPONENT_TYPE_TOOL_PROFILE: awm.create_tool_profile_configuration,
    awm.models.COMPONENT_TYPE_MCP_CONNECTION: awm.create_mcp_connection_configuration,
    awm.models.COMPONENT_TYPE_EVALUATOR: awm.create_evaluator_configuration,
    awm.models.COMPONENT_TYPE_SHARED: awm.create_shared_configuration,
}

_CREATE_VERSION_FN = {
    awm.models.COMPONENT_TYPE_AGENT: awm.create_agent_configuration_version,
    awm.models.COMPONENT_TYPE_WORKFLOW: awm.create_workflow_configuration_version,
    awm.models.COMPONENT_TYPE_TOOL_PROFILE: awm.create_tool_profile_configuration_version,
    awm.models.COMPONENT_TYPE_MCP_CONNECTION: awm.create_mcp_connection_configuration_version,
    awm.models.COMPONENT_TYPE_EVALUATOR: awm.create_evaluator_configuration_version,
    awm.models.COMPONENT_TYPE_SHARED: awm.create_shared_configuration_version,
}

_DELETE_VERSION_FN = {
    awm.models.COMPONENT_TYPE_AGENT: awm.delete_agent_configuration_version,
    awm.models.COMPONENT_TYPE_WORKFLOW: awm.delete_workflow_configuration_version,
    awm.models.COMPONENT_TYPE_TOOL_PROFILE: awm.delete_tool_profile_configuration_version,
    awm.models.COMPONENT_TYPE_MCP_CONNECTION: awm.delete_mcp_connection_configuration_version,
    awm.models.COMPONENT_TYPE_EVALUATOR: awm.delete_evaluator_configuration_version,
    awm.models.COMPONENT_TYPE_SHARED: awm.delete_shared_configuration_version,
}

_DELETE_COMPONENT_FN = {
    awm.models.COMPONENT_TYPE_AGENT: awm.delete_agent_configuration_component,
    awm.models.COMPONENT_TYPE_WORKFLOW: awm.delete_workflow_configuration_component,
    awm.models.COMPONENT_TYPE_TOOL_PROFILE: awm.delete_tool_profile_configuration_component,
    awm.models.COMPONENT_TYPE_MCP_CONNECTION: awm.delete_mcp_connection_configuration_component,
    awm.models.COMPONENT_TYPE_EVALUATOR: awm.delete_evaluator_configuration_component,
    awm.models.COMPONENT_TYPE_SHARED: awm.delete_shared_configuration_component,
}

_CREATE_STAGE_FN = {
    awm.models.COMPONENT_TYPE_AGENT: awm.create_agent_configuration_stage,
    awm.models.COMPONENT_TYPE_WORKFLOW: awm.create_workflow_configuration_stage,
    awm.models.COMPONENT_TYPE_TOOL_PROFILE: awm.create_tool_profile_configuration_stage,
    awm.models.COMPONENT_TYPE_MCP_CONNECTION: awm.create_mcp_connection_configuration_stage,
    awm.models.COMPONENT_TYPE_EVALUATOR: awm.create_evaluator_configuration_stage,
    awm.models.COMPONENT_TYPE_SHARED: awm.create_shared_configuration_stage,
}

_PAGE_SIZE = 20

# ---------------------------------------------------------------------------
# Per-type create templates (JSONC — // lines are stripped before parsing)
# ---------------------------------------------------------------------------

_COMPONENT_TEMPLATES: dict[str, dict] = {
    awm.models.COMPONENT_TYPE_WORKFLOW: {
        "name": "",
        "key": "",
        "description": "",
        "paused": False,
        "config": {
            "agent_graph": {
                "mode": "single_agent",
                "agent_refs": [{"id": "my-agent", "ref": "::agent::my-agent-key::production"}],
                "supported_entry_agents": [],
                "delegation_permissions": {},
            },
        },
    },
    awm.models.COMPONENT_TYPE_AGENT: {
        "name": "",
        "key": "",
        "description": "",
        "config": {
            "model_settings": {"name": "", "ai_provider": ""},
            "system_prompt": "",
            "tool_profiles": [],
        },
    },
    awm.models.COMPONENT_TYPE_TOOL_PROFILE: {
        "name": "",
        "key": "",
        "description": "",
        "config": {
            "mcp_tools": [],
            "local_tools": {"include": [], "exclude": []},
            "retries": 0,
            "timeout_seconds": 30.0,
        },
    },
    awm.models.COMPONENT_TYPE_MCP_CONNECTION: {
        "name": "",
        "key": "",
        "description": "",
        "config": {
            "transport": "streamable_http",
            "endpoint": "",
            "auth": {},
        },
    },
    awm.models.COMPONENT_TYPE_EVALUATOR: {
        "name": "",
        "key": "",
        "description": "",
        "config": {
            "evaluator_type": "llm_judge",
            "llm_judge": {
                "model_settings": {"name": "", "ai_provider": ""},
                "prompt": "",
                "rubric": {},
            },
        },
    },
    awm.models.COMPONENT_TYPE_SHARED: {
        "name": "",
        "key": "",
        "description": "",
        "config": {"data": {}},
    },
}

_COMPONENT_TEMPLATE_TEXT: dict[str, str] = {
    awm.models.COMPONENT_TYPE_WORKFLOW: """\
{
  "name": "",
  "key": "",
  "description": "",
  "config": {
    "agent_graph": {
      // "single_agent" or "delegation".
      "mode": "single_agent",
      // Agents that participate in this workflow. ref format: ::agent::<key>::<version_or_stage>
      "agent_refs": [
        { "id": "my-agent", "ref": "::agent::my-agent-key::production" }
      ],
      // Optional. Agent IDs (from agent_refs) that may be selected as the
      // entry point for a session. Omit to allow any agent.
      "supported_entry_agents": [],
      // Optional. Used when mode=delegation. 
      // Maps agent ID -> list of agent IDs it is allowed to delegate to.
      // Using "*" allows delegation to all other agents.
      "delegation_permissions": {}
    }
  }
}""",
    awm.models.COMPONENT_TYPE_AGENT: """\
{
  "name": "",
  "key": "",
  "description": "",
  "config": {
    "model_settings": {
      "name": "",
      "ai_provider": ""
    },
    // Plain string, or a PromptConfig object:
    // { "prompt": { "section_type": "markdown", "content": ["..."] } }
    "system_prompt": "",
    // Optional. Shown at the start of every new chat session.
    // "introduction": "Hi — I can help with …",
    // Optional. List of tool-profile refs (::tool-profile::key::version_or_stage).
    "tool_profiles": []
  }
}""",
    awm.models.COMPONENT_TYPE_TOOL_PROFILE: """\
{
  "name": "",
  "key": "",
  "description": "",
  "config": {
    // Optional. MCP servers to expose to the agent.
    "mcp_tools": [
      // Each entry references an MCP connection component and filters its tools.
      // { "mcp_connection": "::mcp-connection::key::production",
      //   "tools": { "include": [], "exclude": [] } }
    ],
    "retries": 0,
    "timeout_seconds": 30.0
  }
}""",
    awm.models.COMPONENT_TYPE_MCP_CONNECTION: """\
{
  "name": "",
  "key": "",
  "description": "",
  "config": {
    "transport": "streamable_http",
    "endpoint": "https://example.com/mcp",
    // Optional. Auth headers sent with every request, e.g. {"Authorization": "Bearer <token>"}.
    "auth": {}
  }
}""",
    awm.models.COMPONENT_TYPE_EVALUATOR: """\
{
  "name": "",
  "key": "",
  "description": "",
  "config": {
    // "llm_judge" (LLM-based scoring) or "python_code" (custom script).
    "evaluator_type": "llm_judge",

    // --- llm_judge fields (used when evaluator_type == "llm_judge") ---
    "llm_judge": {
      "model_settings": {
        "name": "claude-sonnet-4-5",
        "ai_provider": "anthropic"
      },
      "prompt": "",
      // Optional. Rubric / scoring schema returned by the model.
      "rubric": {}
    }

    // --- python_code fields (used when evaluator_type == "python_code") ---
    // "python_code": {
    //   "inline": "def evaluate(inputs):\n    return {\"score\": 1.0}"
    // }
  }
}""",
    awm.models.COMPONENT_TYPE_SHARED: """\
{
  "name": "",
  "key": "",
  "description": "",
  "config": {
    // Arbitrary key-value data shared across components via ::shared::key::version.
    "data": {}
  }
}""",
}


# ---------------------------------------------------------------------------
# Top-level type selector
# ---------------------------------------------------------------------------


def browse_configurations(project) -> None:
    """Type selector — entry point from the project action menu."""
    while True:
        _flush_stdin()
        component_type = _select(
            f"Configurations — {project.name} - please select a component type",
            choices=[
                *[
                    questionary.Choice(title=label, value=ct)
                    for ct, label in _COMPONENT_TYPE_LABELS.items()
                ],
                questionary.Separator(),
                questionary.Choice(title="Import from file", value="__import__"),
                questionary.Choice(title="↩ Back", value=_BACK),
            ],
        )

        if component_type is None or component_type == _BACK:
            return

        if component_type == "__import__":
            _run_menu_action(
                lambda: import_configurations_from_file(project),
                action_label="import configurations from file",
                fallback=None,
            )
            continue

        _run_menu_action(
            lambda ct=component_type: _list_components_for_type(project, ct),
            action_label=f"list {_COMPONENT_TYPE_LABELS[component_type]} components",
            fallback=None,
        )


# ---------------------------------------------------------------------------
# Component list (paginated)
# ---------------------------------------------------------------------------


def _list_components_for_type(project, component_type: str) -> None:
    label = _COMPONENT_TYPE_LABELS[component_type]
    page = 1

    def _make_gen():
        return _LIST_COMPONENTS_FN[component_type](project_ids=[project.id])

    gen = _make_gen()
    all_components: list[awm.models.ConfigurationComponent] = []
    exhausted = False

    def _fetch_through(n: int) -> None:
        nonlocal exhausted
        needed = n - len(all_components)
        if needed <= 0 or exhausted:
            return
        batch = list(itertools.islice(gen, needed))
        all_components.extend(batch)
        if len(batch) < needed:
            exhausted = True

    with _Spinner(f"Loading {label} components"):
        _fetch_through(_PAGE_SIZE)

    while True:
        offset = (page - 1) * _PAGE_SIZE
        page_items = all_components[offset : offset + _PAGE_SIZE]

        name_w = max((len(c.name) for c in all_components), default=20)
        key_w = max((len(c.key) for c in all_components), default=12)

        choices = []
        if page_items:
            choices.append(_column_header(f"{'Name'.ljust(name_w)}  {'Key'.ljust(key_w)}"))
            choices.append(questionary.Separator())
            for comp in page_items:
                choices.append(
                    questionary.Choice(
                        title=f"{comp.name.ljust(name_w)}  {comp.key.ljust(key_w)}",
                        value=comp,
                    )
                )
            choices.append(questionary.Separator())
        else:
            choices.append(
                questionary.Choice(
                    title=f"(no {label} components found)",
                    value=None,
                    disabled=" ",
                )
            )
            choices.append(questionary.Separator())

        has_next = len(all_components) > offset + _PAGE_SIZE or (
            not exhausted and len(page_items) == _PAGE_SIZE
        )
        choices.append(questionary.Separator(f"Page {page}"))
        if has_next:
            choices.append(questionary.Choice(title="Next page", value="__next__"))
        if page > 1:
            choices.append(questionary.Choice(title="Previous page", value="__prev__"))
        choices.append(questionary.Choice(title=f"+ Create new {label}", value=_NEW))
        choices.append(questionary.Choice(title="↩ Back", value=_BACK))

        _flush_stdin()
        selected = _select(
            f"{label} components",
            choices=choices,
        )

        if selected is None or selected == _BACK:
            return
        if selected == "__next__":
            with _Spinner(f"Loading {label} components"):
                _fetch_through(offset + _PAGE_SIZE * 2)
            if len(all_components) > offset + _PAGE_SIZE:
                page += 1
            continue
        if selected == "__prev__":
            page = max(1, page - 1)
            continue
        if selected == _NEW:
            _run_menu_action(
                lambda: _create_component(project, component_type),
                action_label=f"create {label} component",
                fallback=None,
            )
            gen = _make_gen()
            all_components.clear()
            exhausted = False
            page = 1
            with _Spinner(f"Loading {label} components"):
                _fetch_through(_PAGE_SIZE)
            continue
        if isinstance(selected, awm.models.ConfigurationComponent):
            deleted = _run_menu_action(
                lambda c=selected: _component_action_menu(c, component_type),
                action_label=f"open {label} component '{selected.name}'",
                fallback=False,
            )
            if deleted:
                gen = _make_gen()
                all_components.clear()
                exhausted = False
                page = 1
                with _Spinner(f"Loading {label} components"):
                    _fetch_through(_PAGE_SIZE)
            continue


_VERSION_DESCRIPTION_MAX_LEN = 60


def _format_version_choice_title(version, *, name_width: int) -> str:
    """Render a version-list row: version, name, stages, timestamp, then description."""
    stages_str = ", ".join(version.stages) if version.stages else "—"
    created = version.created_at.strftime("%Y-%m-%d %H:%M")
    title = f"{version.version}  {version.name.ljust(name_width)}  [{stages_str}]  {created}"
    description = " ".join((version.description or "").split())
    if not description:
        return title
    if len(description) > _VERSION_DESCRIPTION_MAX_LEN:
        description = description[: _VERSION_DESCRIPTION_MAX_LEN - 3] + "..."
    return f"{title}  {description}"


# ---------------------------------------------------------------------------
# Component menu (details + version list)
# ---------------------------------------------------------------------------


def _print_component_detail(component: awm.models.ConfigurationComponent) -> None:
    label_w = 12
    click.echo()
    click.echo(
        click.style("  Component", bold=True)
        + "  "
        + click.style(component.name, fg="cyan", bold=True)
    )
    click.echo(click.style("  " + "─" * 50, dim=True))

    def _row(label: str, value: str) -> None:
        click.echo("  " + click.style(label.ljust(label_w), fg="bright_black") + value)

    _row("ID", component.id)
    _row("Key", component.key)
    _row("Type", component.component_type)
    _row("Project ID", component.project_id)
    click.echo()


def _component_action_menu(
    component: awm.models.ConfigurationComponent,
    component_type: str,
) -> bool:
    label = _COMPONENT_TYPE_LABELS[component_type]
    _print_component_detail(component)

    while True:

        def _load_versions():
            with _Spinner("Loading versions"):
                return list(
                    itertools.islice(
                        _LIST_VERSIONS_FN[component_type](component.id, sort_order="desc"),
                        100,
                    )
                )

        versions = _run_menu_action(
            _load_versions,
            action_label=f"list versions for '{component.name}'",
            fallback=None,
        )
        if versions is None:
            return False

        choices = []
        if versions:
            name_w = max((len(vs.name) for vs in versions), default=20)
            for vs in versions:
                choices.append(
                    questionary.Choice(
                        title=_format_version_choice_title(vs, name_width=name_w),
                        value=vs,
                    )
                )
            choices.append(questionary.Separator())
        else:
            choices.append(
                questionary.Choice(title="(no versions found)", value=None, disabled=" ")
            )
            choices.append(questionary.Separator())

        choices.extend(
            [
                questionary.Choice(title="+ Create new version", value=_NEW),
                questionary.Choice(title="Delete component (all versions)", value="delete"),
                questionary.Choice(title="↩ Back", value=_BACK),
            ]
        )

        _flush_stdin()
        selected = _select(
            f"{label}: {component.name}",
            choices=choices,
        )

        if selected is None or selected == _BACK:
            return False
        if selected == _NEW:
            _run_menu_action(
                lambda vs=versions: _create_component_version(component, component_type, vs),
                action_label="create new version",
                fallback=None,
            )
            continue
        if selected == "delete":
            deleted = _run_menu_action(
                lambda: _delete_component(component, component_type),
                action_label=f"delete {label} component '{component.name}'",
                fallback=False,
            )
            if deleted:
                return True
            continue
        if isinstance(selected, awm.models.ConfigurationComponentVersionSummary):
            _run_menu_action(
                lambda vs=selected: _version_action_menu(vs, component_type),
                action_label=f"open version {selected.version}",
                fallback=None,
            )


# ---------------------------------------------------------------------------
# Version action menu
# ---------------------------------------------------------------------------


def _version_action_menu(
    version_summary: awm.models.ConfigurationComponentVersionSummary,
    component_type: str,
) -> None:
    while True:
        _flush_stdin()
        action = _select(
            f"{version_summary.version} — {version_summary.name}",
            choices=[
                questionary.Choice(title="View config", value="view"),
                questionary.Choice(title="Stage", value="stage"),
                questionary.Choice(title="Delete", value="delete"),
                questionary.Choice(title="↩ Back", value=_BACK),
            ],
        )
        if action is None or action == _BACK:
            return
        if action == "view":
            _run_menu_action(
                lambda: _print_version_config(version_summary, component_type),
                action_label=f"fetch config for version {version_summary.version}",
                fallback=None,
            )
        elif action == "stage":
            _run_menu_action(
                lambda: _stage_version(version_summary, component_type),
                action_label=f"stage version {version_summary.version}",
                fallback=None,
            )
        elif action == "delete":
            deleted = _run_menu_action(
                lambda: _delete_version(version_summary, component_type),
                action_label=f"delete version {version_summary.version}",
                fallback=False,
            )
            if deleted:
                return


def _print_version_config(
    version_summary: awm.models.ConfigurationComponentVersionSummary,
    component_type: str,
) -> None:
    with _Spinner("Fetching version config"):
        response = _GET_VERSION_FN[component_type](version_summary.id, resolved=True)
    config = response.data.config
    resolved = response.resolved

    click.echo()
    click.echo(
        click.style(f"  {version_summary.version}", bold=True)
        + "  "
        + click.style(version_summary.name, fg="cyan", bold=True)
    )
    click.echo(click.style("  " + "─" * 50, dim=True))
    if version_summary.description:
        click.echo(
            "  "
            + click.style("Description".ljust(12), fg="bright_black")
            + version_summary.description
        )
        click.echo()
    click.echo(json.dumps(config, indent=2) if config else "(no config)")
    click.echo()
    if resolved:
        click.echo(click.style("  Resolved", fg="cyan", bold=True))
        click.echo(click.style("  " + "─" * 50, dim=True))
        click.echo(json.dumps(resolved, indent=2) if resolved else "")
        click.echo()


def _stage_version(
    version_summary: awm.models.ConfigurationComponentVersionSummary,
    component_type: str,
) -> None:
    _flush_stdin()
    stage = _select(
        f"Stage version {version_summary.version} as:",
        choices=[
            questionary.Choice(title="Development", value=awm.models.STAGE_DEVELOPMENT),
            questionary.Choice(title="Staging", value=awm.models.STAGE_STAGING),
            questionary.Choice(title="Production", value=awm.models.STAGE_PRODUCTION),
            questionary.Choice(title="↩ Cancel", value=_BACK),
        ],
    )
    if stage is None or stage == _BACK:
        return
    _CREATE_STAGE_FN[component_type](version_summary.id, stage)
    click.echo(
        click.style(
            f"  Version {version_summary.version} staged as {stage}.",
            fg="green",
        )
    )


def _delete_version(
    version_summary: awm.models.ConfigurationComponentVersionSummary,
    component_type: str,
) -> bool:
    confirmed = questionary.confirm(
        f"Delete version {version_summary.version} of '{version_summary.name}'? This cannot be undone.",
        default=False,
        style=_QUESTIONARY_STYLE,
    ).ask()
    if not confirmed:
        return False
    _DELETE_VERSION_FN[component_type](version_summary.id)
    click.echo(click.style(f"  Version {version_summary.version} deleted.", fg="green"))
    return True


def _delete_component(
    component: awm.models.ConfigurationComponent,
    component_type: str,
) -> bool:
    confirmed = questionary.confirm(
        f"Delete component '{component.name}' and all of its versions? This cannot be undone.",
        default=False,
        style=_QUESTIONARY_STYLE,
    ).ask()
    if not confirmed:
        return False
    _DELETE_COMPONENT_FN[component_type](component.id)
    click.echo(click.style(f"  Component '{component.name}' deleted.", fg="green"))
    return True


# ---------------------------------------------------------------------------
# Create component
# ---------------------------------------------------------------------------


def _create_component(project, component_type: str) -> None:
    label = _COMPONENT_TYPE_LABELS[component_type]
    initial = _COMPONENT_TEMPLATES[component_type]

    edited = _edit_json(initial, initial_text=_COMPONENT_TEMPLATE_TEXT[component_type])
    if edited is None:
        _flush_stdin()
        use_template = questionary.confirm(
            "No changes detected. Create component using this template?",
            default=False,
            style=_QUESTIONARY_STYLE,
        ).ask()
        if not use_template:
            click.echo(click.style(f"  Aborted — no {label} component created.", dim=True))
            return
        edited = dict(initial)

    while edited is not None:
        missing = [k for k in ("name", "key") if not str(edited.get(k, "")).strip()]
        if missing:
            click.echo(click.style(f"  Required fields missing: {', '.join(missing)}", fg="red"))
            _flush_stdin()
            retry = questionary.confirm(
                "Reopen editor to fix payload?",
                default=True,
                style=_QUESTIONARY_STYLE,
            ).ask()
            if not retry:
                click.echo(click.style(f"  Aborted — no {label} component created.", dim=True))
                return
            edited = _edit_json(edited)
            continue

        result = _run_menu_action(
            lambda e=edited: _CREATE_FN[component_type](
                project.id,
                str(e["name"]).strip(),
                str(e["key"]).strip(),
                str(e.get("description") or ""),
                e.get("config", {}),
                **(
                    {"paused": e.get("paused")}
                    if component_type == awm.models.COMPONENT_TYPE_WORKFLOW and "paused" in e
                    else {}
                ),
            ),
            action_label=f"create {label} component",
            fallback=None,
        )
        if result is not None:
            click.echo(
                click.style(
                    f"  {label} component '{result.name}' created (version {result.version}).",
                    fg="green",
                )
            )
            return

        _flush_stdin()
        retry = questionary.confirm(
            "Reopen editor to fix payload?",
            default=True,
            style=_QUESTIONARY_STYLE,
        ).ask()
        if not retry:
            click.echo(click.style(f"  Aborted — no {label} component created.", dim=True))
            return
        edited = _edit_json(edited)

    click.echo(click.style(f"  Aborted — no {label} component created.", dim=True))


# ---------------------------------------------------------------------------
# Create version
# ---------------------------------------------------------------------------


def _create_component_version(
    component: awm.models.ConfigurationComponent,
    component_type: str,
    versions: list[awm.models.ConfigurationComponentVersionSummary],
) -> None:
    latest_config: dict = {}
    latest_description: str | None = None
    if versions:
        try:
            with _Spinner("Fetching latest version config"):
                resolved = _GET_VERSION_FN[component_type](versions[0].id)
            latest_config = resolved.data.config or {}
            latest_description = resolved.data.description or ""
        except Exception:
            click.echo(click.style("  Warning — unable to fetch latest version config", fg="red"))
            latest_config = {}

    initial = {
        "config": latest_config,
        "version_changelog": "",
        "description": latest_description,
    }
    if component_type == awm.models.COMPONENT_TYPE_WORKFLOW:
        initial["paused"] = None
    edited = _edit_json(initial)
    if edited is None:
        click.echo(click.style("  Aborted — no version created.", dim=True))
        return

    result = _run_menu_action(
        lambda e=edited: _CREATE_VERSION_FN[component_type](
            component.id,
            e.get("config", {}),
            str(e.get("version_changelog") or ""),
            # Prefilled with the current description, so an emptied string clears it while
            # null keeps whatever the previous version had.
            None if e.get("description") is None else str(e["description"]),
            **(
                {"paused": e.get("paused")}
                if component_type == awm.models.COMPONENT_TYPE_WORKFLOW
                and e.get("paused") is not None
                else {}
            ),
        ),
        action_label="create new version",
        fallback=None,
    )
    if result is not None:
        click.echo(
            click.style(
                f"  Version {result.version} created for '{component.name}'.",
                fg="green",
            )
        )

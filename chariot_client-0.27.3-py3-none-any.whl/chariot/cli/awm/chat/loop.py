"""Interactive chat loop for AWM CLI."""

import json
import shlex
from pathlib import Path

import click
import questionary

from chariot import awm
from chariot.cli.awm.chat.approvals import (
    _extract_tool_call_requests,
    _handle_tool_call_approvals,
)
from chariot.cli.awm.chat.notifications import (
    _ActivityStream,
    _is_terminal_activity,
    _unseen_activities,
)
from chariot.cli.awm.chat.render import (
    _render_agent_activities,
    _render_agent_introduction,
    _render_session_configuration,
    _render_session_history,
)
from chariot.cli.awm.chat.sessions import (
    _agent_introduction,
    _fetch_session_history,
    _list_user_sessions,
    _normalize_display_name,
    _parse_rename_args,
    _session_column_widths,
    _session_label,
    _session_label_from_id,
    _session_row_title,
)
from chariot.cli.awm.common import _BACK, _NEW, _column_header, _select, _Spinner
from chariot.cli.awm.providers import ensure_workflow_auth_providers_ready


def _run_chat_loop(
    workflow: awm.models.Workflow,
    agent_name: str,
    session_id: str | None,
    session_display_name: str | None = None,
) -> None:
    click.echo()
    click.echo(click.style("  ╔══════════════════════════════════════════════╗", fg="cyan"))
    click.echo(
        click.style("  ║  ", fg="cyan")
        + click.style("Chariot AWM Chat", bold=True)
        + click.style("                            ║", fg="cyan")
    )
    click.echo(click.style("  ╚══════════════════════════════════════════════╝", fg="cyan"))
    click.echo()
    click.echo(
        "  Workflow  "
        + click.style(workflow.name, fg="cyan", bold=True)
        + "  "
        + click.style(f"({workflow.id})", dim=True)
    )
    click.echo("  Agent     " + click.style(agent_name, fg="cyan"))
    if session_id:
        label = _session_label_from_id(session_id, session_display_name)
        click.echo("  Session   " + click.style(label, dim=True))
        if session_display_name and session_display_name.strip():
            click.echo("            " + click.style(f"id: {session_id}", dim=True))
    else:
        click.echo(
            "  Session   " + click.style("new session will be created on first message", dim=True)
        )
    click.echo()
    help_text = (
        "  Type /exit to quit, /clear to reset context, /sessions to switch session, "
        "/rename to rename session, /config to view session configuration, "
        "/auth to connect missing auth providers. "
        "Use /schema <file.json> for a structured response to your next message, "
        "/schema to view it, or /schema off to cancel."
    )
    click.echo(click.style(help_text, dim=True))
    click.echo()

    if not session_id:
        _render_agent_introduction(agent_name, _agent_introduction(workflow.id, agent_name))

    current_session_id = session_id
    current_session_display_name = (
        session_display_name.strip()
        if session_display_name and session_display_name.strip()
        else None
    )
    handled_request_activity_ids: set[str] = set()
    handled_tool_call_ids: set[str] = set()

    response_stream = _ActivityStream()
    try:
        try:
            with _Spinner("Connecting to activity stream"):
                response_stream.start()
        except Exception as exc:
            click.echo(click.style(f"  Error connecting to activity stream: {exc}", fg="red"))
            return
        _run_chat_turns(
            workflow,
            agent_name,
            response_stream,
            current_session_id,
            current_session_display_name,
            handled_request_activity_ids,
            handled_tool_call_ids,
        )
    finally:
        response_stream.close()


def _run_chat_turns(
    workflow: awm.models.Workflow,
    agent_name: str,
    response_stream: _ActivityStream,
    current_session_id: str | None,
    current_session_display_name: str | None,
    handled_request_activity_ids: set[str],
    handled_tool_call_ids: set[str],
) -> None:
    output_schema: dict | None = None
    while True:
        try:
            user_input = input(
                click.style(
                    "  You [JSON]" if output_schema is not None else "  You",
                    fg="cyan",
                    bold=True,
                )
                + click.style(" > ", fg="bright_black")
            )
        except (EOFError, KeyboardInterrupt):
            click.echo()
            click.echo(click.style("\n  Goodbye.", dim=True))
            break

        user_input = user_input.strip()
        if not user_input:
            continue

        if user_input in ("/exit", "/quit"):
            click.echo(click.style("\n  Goodbye.", dim=True))
            break

        if user_input == "/schema" or user_input.startswith("/schema "):
            argument = user_input[len("/schema") :].strip()
            if not argument:
                if output_schema is None:
                    click.echo(
                        "  No output schema set. Use /schema <file.json> for the next message."
                    )
                else:
                    click.echo("  Output schema for the next message:")
                    click.echo(json.dumps(output_schema, indent=2, ensure_ascii=False))
                continue
            if argument == "off":
                output_schema = None
                click.echo("  Output schema cleared. Responses will use plain text.")
                continue
            try:
                paths = shlex.split(argument)
                if len(paths) != 1:
                    raise ValueError("Use /schema <file.json>; quote paths containing spaces.")
                schema = json.loads(Path(paths[0]).expanduser().read_text(encoding="utf-8"))
                if not isinstance(schema, dict) or schema.get("type") != "object":
                    raise ValueError('Schema must be a JSON object with "type": "object".')
            except (OSError, ValueError) as exc:
                click.echo(click.style(f"  Could not load output schema: {exc}", fg="red"))
                continue
            output_schema = schema
            click.echo("  Output schema set for the next message only. Use /schema off to cancel.")
            continue

        if user_input == "/clear":
            if not current_session_id:
                click.echo(click.style("  No active session to clear.", fg="yellow"))
                continue
            try:
                awm.activity.send_clear_context(workflow.id, agent_name, current_session_id)
                click.echo(click.style("  Context cleared.", fg="green"))
            except Exception as exc:
                click.echo(click.style(f"  Error: {exc}", fg="red"))
            continue

        if user_input == "/config":
            if not current_session_id:
                click.echo(
                    click.style("  No active session yet. Send a message first.", fg="yellow")
                )
                continue
            try:
                with _Spinner("Fetching session configuration"):
                    config = awm.get_session_configuration(current_session_id)
                _render_session_configuration(config)
            except Exception as exc:
                click.echo(click.style(f"  Error: {exc}", fg="red"))
            continue

        if user_input == "/auth":
            ensure_workflow_auth_providers_ready(workflow.id)
            continue

        if user_input == "/rename" or user_input.startswith("/rename "):
            if not current_session_id:
                click.echo(
                    click.style("  No active session yet. Send a message first.", fg="yellow")
                )
                continue
            new_name = _parse_rename_args(user_input)
            if new_name is None:
                click.echo(click.style("  Rename cancelled.", dim=True))
                continue
            new_name = _normalize_display_name(new_name)
            if not new_name:
                click.echo(click.style("  Session name cannot be empty.", fg="yellow"))
                continue
            try:
                metadata = awm.patch_session_display_name(current_session_id, new_name)
                current_session_display_name = metadata.display_name
                click.echo(
                    click.style(
                        f"  Session renamed to {current_session_display_name}",
                        fg="green",
                    )
                )
            except Exception as exc:
                click.echo(click.style(f"  Error renaming session: {exc}", fg="red"))
            continue

        if user_input == "/sessions":
            try:
                sessions = _list_user_sessions(workflow.id, agent_name=agent_name)
            except Exception as exc:
                click.echo(click.style(f"  Error listing sessions: {exc}", fg="red"))
                continue
            if not sessions:
                click.echo(click.style("  No previous sessions found for your account.", dim=True))
                continue
            time_w, id_w, count_w = _session_column_widths(sessions)
            choices = (
                [
                    _column_header(
                        f"{'Session Time'.ljust(time_w)}  {'Session'.ljust(id_w)}  {'Msgs'.rjust(count_w)}"
                    ),
                    questionary.Separator(),
                ]
                + [
                    questionary.Choice(
                        title=_session_row_title(
                            session, time_w=time_w, id_w=id_w, count_w=count_w
                        ),
                        value=session,
                    )
                    for session in sessions
                ]
                + [
                    questionary.Choice(title="Start new session", value=_NEW),
                    questionary.Choice(title="↩ Keep current session", value=_BACK),
                ]
            )
            chosen = _select("Switch to session:", choices=choices)
            if chosen == _NEW:
                current_session_id = None
                current_session_display_name = None
                handled_request_activity_ids.clear()
                handled_tool_call_ids.clear()
                click.echo(click.style("  Next message will start a new session.", fg="green"))
                _render_agent_introduction(agent_name, _agent_introduction(workflow.id, agent_name))
                continue
            if chosen and chosen != _BACK:
                session: awm.models.SessionDetails = chosen
                current_session_id = session.session_id
                current_session_display_name = (
                    session.display_name.strip()
                    if session.display_name and session.display_name.strip()
                    else None
                )
                handled_request_activity_ids.clear()
                handled_tool_call_ids.clear()
                click.echo(
                    click.style(
                        f"  Switched to session {_session_label(session)}",
                        fg="green",
                    )
                )
                try:
                    history = _fetch_session_history(workflow.id, current_session_id)
                    _render_session_history(history, agent_name)
                except Exception as exc:
                    click.echo(click.style(f"  Error loading session history: {exc}", fg="red"))
            continue

        # Send the message.
        message_body: dict = {"message": user_input}
        if output_schema is not None:
            message_body["outputSchema"] = output_schema
        try:
            activity = awm.activity.send_message(
                workflow.id, agent_name, message_body, session_id=current_session_id
            )
            output_schema = None
            if not current_session_id:
                current_session_id = activity.session_id
                label = _session_label_from_id(current_session_id, current_session_display_name)
                click.echo(click.style(f"  Session   {label}", dim=True))
                click.echo()
        except Exception as exc:
            click.echo(click.style(f"  Error sending message: {exc}", fg="red"))
            continue

        if not current_session_id:
            click.echo(click.style("  Error: missing session id after sending message.", fg="red"))
            continue

        after_sequence = activity.sequence
        printed_ids: set[str] = {activity.id}
        got_final = False
        while not got_final:
            response_activities: list[awm.models.Activity] = []
            with _Spinner("Thinking"):
                try:
                    response_activities = response_stream.wait_for_response(
                        workflow.id, current_session_id, after_sequence, printed_ids
                    )
                except Exception as exc:
                    click.echo(
                        click.style(f"  Error waiting for activity notification: {exc}", fg="red")
                    )
                    continue

            new_activities = _unseen_activities(response_activities, printed_ids)
            if not new_activities:
                continue

            for activity in new_activities:
                printed_ids.add(activity.id)

            for activity in new_activities:
                if activity.type == "tool_call_requests":
                    if activity.id in handled_request_activity_ids:
                        continue
                    requests = _extract_tool_call_requests(activity)
                    pending_requests = []
                    for request in requests:
                        request_id = request.get("agentToolCallID")
                        if (
                            isinstance(request_id, str)
                            and request_id
                            and request_id in handled_tool_call_ids
                        ):
                            continue
                        pending_requests.append(request)
                    if not pending_requests:
                        handled_request_activity_ids.add(activity.id)
                        continue

                    sent, handled_ids = _handle_tool_call_approvals(
                        workflow, agent_name, current_session_id, activity.id, pending_requests
                    )
                    handled_request_activity_ids.add(activity.id)
                    handled_tool_call_ids.update(handled_ids)
                    if sent:
                        click.echo(
                            click.style(
                                "  Approval submitted. Waiting for agent output...",
                                fg="bright_black",
                            )
                        )

            _render_agent_activities(new_activities, agent_name)
            got_final = any(_is_terminal_activity(activity) for activity in new_activities)

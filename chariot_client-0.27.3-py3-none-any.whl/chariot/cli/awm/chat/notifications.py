"""Notification websocket helpers for chat activity streams."""

import json
import queue
import ssl
import threading
import time
from typing import Any
from urllib.parse import urlsplit, urlunsplit

import websocket

from chariot import awm
from chariot.config import get_bearer_token, settings

_ACTIVITY_PAYLOAD_TYPE = "AgenticActivity"
_ACTIVITY_ENTITY_TYPE = "agentic_workflow"
_ACTIVITY_TYPES = {
    "agent_to_user_message",
    "error",
    "tool_call_requests",
    "tool_call_responses",
    "thinking",
}
_CONNECT_TIMEOUT = 10.0
_RECONNECT_DELAY = 5
_WEBSOCKET_PATH = "/api/websockets/v2/ws"


def _websocket_url() -> str:
    base_url = settings.base_url
    if not base_url:
        raise RuntimeError("Cannot connect to notifications: Chariot base URL is not configured")

    parsed = urlsplit(base_url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise RuntimeError(f"Cannot connect to notifications: invalid Chariot URL {base_url!r}")

    scheme = "wss" if parsed.scheme == "https" else "ws"
    return urlunsplit((scheme, parsed.netloc, _WEBSOCKET_PATH, "", ""))


def _ssl_options() -> dict[str, Any]:
    options: dict[str, Any] = {
        "cert_reqs": ssl.CERT_REQUIRED if settings.verify_ssl else ssl.CERT_NONE,
    }
    if settings.cert_filename:
        options["certfile"] = settings.cert_filename
    if settings.key_filename:
        options["keyfile"] = settings.key_filename
    return options


def _activity_from_notification(
    raw_message: str | bytes,
    workflow_id: str,
    session_id: str,
    after_sequence: int,
) -> awm.models.Activity | None:
    try:
        decoded = raw_message.decode("utf-8") if isinstance(raw_message, bytes) else raw_message
        envelope = json.loads(decoded)
    except (UnicodeDecodeError, json.JSONDecodeError, TypeError):
        return None

    if not isinstance(envelope, dict):
        return None
    event = envelope.get("Message", envelope)
    if (
        not isinstance(event, dict)
        or event.get("entity_type") != _ACTIVITY_ENTITY_TYPE
        or event.get("payload_type") != _ACTIVITY_PAYLOAD_TYPE
    ):
        return None

    payload = event.get("payload")
    if not isinstance(payload, dict):
        return None
    if payload.get("workflowID") != workflow_id:
        return None
    if payload.get("sessionID") != session_id:
        return None
    if payload.get("type") not in _ACTIVITY_TYPES:
        return None

    try:
        activity = awm.activity._to_activity(payload)
        if activity.sequence <= after_sequence:
            return None
    except (KeyError, TypeError, ValueError):
        return None
    return activity


def _backfill_activities(
    workflow_id: str,
    session_id: str,
    after_sequence: int,
) -> list[awm.models.Activity]:
    """Fetch activities missed while the websocket was disconnected."""
    return list(
        awm.activity.get_activities(
            workflow_id,
            session_id=session_id,
            types=list(_ACTIVITY_TYPES),
            sort_by="sequence",
            after_sequence=after_sequence,
            sort_order="asc",
        )
    )


def _unseen_activities(
    activities: list[awm.models.Activity],
    seen_ids: set[str],
) -> list[awm.models.Activity]:
    return [activity for activity in activities if activity.id not in seen_ids]


class _ActivityStream:
    def __init__(self) -> None:
        self._messages: queue.Queue[str | bytes] = queue.Queue()
        self._connected = threading.Event()
        self._needs_backfill = threading.Event()
        self._reconnects = 0
        self._error: Exception | None = None
        self._socket: websocket.WebSocketApp | None = None
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        self._error = None
        self._connected.clear()
        self._needs_backfill.clear()
        self._socket = websocket.WebSocketApp(
            _websocket_url(),
            header={"Authorization": f"Bearer {get_bearer_token()}"},
            on_open=lambda _socket: self._connected.set(),
            on_message=lambda _socket, message: self._messages.put(message),
            on_reconnect=lambda _socket: self._mark_reconnected(),
            on_error=self._on_error,
        )
        self._thread = threading.Thread(
            target=self._socket.run_forever,
            kwargs={
                "ping_interval": 30,
                "ping_timeout": 10,
                "reconnect": _RECONNECT_DELAY,
                "sslopt": _ssl_options(),
            },
            daemon=True,
        )
        self._thread.start()

        deadline = time.monotonic() + _CONNECT_TIMEOUT
        while not self._connected.wait(timeout=0.05):
            if self._error is not None:
                self.close()
                raise RuntimeError(
                    f"Could not connect to the notifications websocket: {self._error}"
                ) from self._error
            if time.monotonic() >= deadline:
                self.close()
                raise TimeoutError("Timed out connecting to the notifications websocket")

    def close(self) -> None:
        if self._socket is not None:
            self._socket.close()
        if self._thread is not None and self._thread is not threading.current_thread():
            self._thread.join(timeout=1)
        self._socket = None
        self._thread = None
        self._connected.clear()

    def wait_for_response(
        self,
        workflow_id: str,
        session_id: str,
        after_sequence: int,
        seen_ids: set[str] | None = None,
    ) -> list[awm.models.Activity]:
        seen = seen_ids or set()
        attempted_reconnects = -1
        while True:
            backfilled: list[awm.models.Activity] = []
            reconnects = self._reconnects
            if self._needs_backfill.is_set() and reconnects != attempted_reconnects:
                attempted_reconnects = reconnects
                try:
                    backfilled = _unseen_activities(
                        self._consume_backfill(workflow_id, session_id, after_sequence),
                        seen,
                    )
                except Exception:
                    # Keep receiving from the restored socket. The backfill remains
                    # pending and retries on the next reconnect.
                    pass
            if backfilled:
                return backfilled
            try:
                raw_message = self._messages.get(timeout=0.5)
            except queue.Empty:
                continue
            activity = _activity_from_notification(
                raw_message, workflow_id, session_id, after_sequence
            )
            if activity is not None and activity.id not in seen:
                return [activity]

    def _consume_backfill(
        self,
        workflow_id: str,
        session_id: str,
        after_sequence: int,
    ) -> list[awm.models.Activity]:
        if not self._needs_backfill.is_set():
            return []
        reconnects = self._reconnects
        activities = _backfill_activities(workflow_id, session_id, after_sequence)
        if reconnects == self._reconnects:
            # A reconnect during the fetch has its own gap to cover, so leave the
            # flag set for it.
            self._needs_backfill.clear()
        return activities

    def _mark_reconnected(self) -> None:
        self._reconnects += 1
        self._needs_backfill.set()

    def _on_error(self, _socket: websocket.WebSocketApp, error: object) -> None:
        self._error = error if isinstance(error, Exception) else RuntimeError(str(error))


def _is_terminal_activity(activity: awm.models.Activity) -> bool:
    """Activities that should return control to user input."""
    return activity.type in {"agent_to_user_message", "error"} and bool(activity.final)

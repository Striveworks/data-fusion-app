"""Session and agent selection helpers for AWM chat."""

import click
import questionary

from chariot import awm
from chariot.cli.awm.common import (
    _BACK,
    _flush_stdin,
    _select,
)
from chariot.identity import whoami

_MAX_SESSION_DISPLAY_NAME_LENGTH = 60


def _current_user_id() -> str:
    """Fetch the authenticated user id from identity `/users/me`."""
    user_id = whoami().get("id")
    if not user_id:
        raise click.ClickException("Could not determine current user ID from identity API.")
    return str(user_id).strip()


def _session_schedule_indicator(session: awm.models.SessionDetails) -> str:
    if not session.schedule_id:
        return ""
    return "  [scheduled]"


def _session_timestamp(session: awm.models.SessionDetails) -> str:
    return session.created_at.strftime("%Y-%m-%d %H:%M")


def _session_label(session: awm.models.SessionDetails) -> str:
    """Prefer display name, fall back to session id."""
    if session.display_name and session.display_name.strip():
        return session.display_name.strip()
    return session.session_id


def _session_label_from_id(session_id: str | None, display_name: str | None = None) -> str:
    if display_name and display_name.strip():
        return display_name.strip()
    return session_id or ""


def _session_row_title(
    session: awm.models.SessionDetails,
    *,
    time_w: int,
    id_w: int,
    count_w: int,
    include_agents: bool = False,
) -> str:
    row = (
        f"{_session_timestamp(session).ljust(time_w)}  "
        f"{_session_label(session).ljust(id_w)}  "
        f"{str(session.user_activity_count).rjust(count_w)}"
    )
    if include_agents:
        agents = ", ".join(session.agents) if session.agents else "—"
        row += f"  {agents}"
    return row + _session_schedule_indicator(session)


def _session_column_widths(sessions: list[awm.models.SessionDetails]) -> tuple[int, int, int]:
    time_w = max(
        16, len("Session Time"), max((len(_session_timestamp(s)) for s in sessions), default=0)
    )
    id_w = max(28, len("Session"), max((len(_session_label(s)) for s in sessions), default=0))
    count_w = max(
        4, len("Msgs"), max((len(str(s.user_activity_count)) for s in sessions), default=0)
    )
    return time_w, id_w, count_w


def _list_user_sessions(
    workflow_id: str, agent_name: str | None = None
) -> list[awm.models.SessionDetails]:
    current_user_id = _current_user_id()
    return list(
        awm.activity.get_sessions(
            workflow_id,
            user_ids=[current_user_id],
            agents=[agent_name] if agent_name else None,
        )
    )


def _fetch_session_history(workflow_id: str, session_id: str) -> list[awm.models.Activity]:
    types = [
        "user_to_agent_message",
        "agent_to_user_message",
        "error",
        "thinking",
        "tool_call_requests",
        "tool_call_responses",
        "clear_context",
        "tool_call_approvals",
    ]
    # TODO(https://striveworks.atlassian.net/browse/FORGE-15) allow loading older activities.
    history = list(
        awm.activity.get_activities(
            workflow_id,
            session_id=session_id,
            types=types,
            sort_order="desc",
            sort_by="sequence",
            limit=100,
        )
    )
    history.reverse()
    return history


def _pick_agent(workflow: awm.models.Workflow) -> str | None:
    """Prompt the user to select an agent for the workflow."""
    agents = awm.workflows.get_workflow_agents(workflow.id)

    if not agents:
        click.echo(click.style("  No agents found for this workflow.", fg="red"))
        return None

    if len(agents) == 1:
        return agents[0].name

    _flush_stdin()
    agent_name = _select(
        "Select agent:",
        choices=[questionary.Choice(title=agent.name, value=agent.name) for agent in agents]
        + [questionary.Choice(title="↩ Cancel", value=_BACK)],
    )
    return None if (agent_name is None or agent_name == _BACK) else agent_name


def _agent_introduction(workflow_id: str, agent_name: str) -> str | None:
    """Return the configured introduction for an entry agent, if any."""
    try:
        agents = awm.workflows.get_workflow_agents(workflow_id)
    except Exception:
        return None
    for agent in agents:
        if agent.name == agent_name:
            return agent.introduction
    return None


def _parse_rename_args(user_input: str) -> str | None:
    """Parse `/rename` or `/rename <name>` into a display name, or None if cancelled/empty."""
    parts = user_input.split(maxsplit=1)
    if len(parts) > 1 and parts[1].strip():
        return parts[1].strip()
    try:
        name = input(click.style("  New session name > ", fg="bright_black")).strip()
    except (EOFError, KeyboardInterrupt):
        click.echo()
        return None
    return name or None


def _normalize_display_name(name: str) -> str:
    cleaned = " ".join(name.split()).strip()
    if len(cleaned) > _MAX_SESSION_DISPLAY_NAME_LENGTH:
        cleaned = cleaned[:_MAX_SESSION_DISPLAY_NAME_LENGTH].rstrip()
    return cleaned

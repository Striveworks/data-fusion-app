"""Chat activity rendering helpers."""

import json

import click

from chariot import awm


def _render_agent_introduction(agent_name: str, introduction: str | None) -> None:
    """Render a static agent introduction for a new chat session."""
    if not introduction or not introduction.strip():
        return
    click.echo(
        "  "
        + click.style(agent_name, fg="green", bold=True)
        + click.style(" > ", fg="bright_black")
    )
    for line in introduction.splitlines():
        click.echo("    " + line)
    click.echo()


def _render_agent_activities(activities: list[awm.models.Activity], agent_name: str) -> None:
    if not activities:
        return
    click.echo()
    for activity in activities:
        if activity.type == "tool_call_requests":
            continue
        if activity.type == "thinking":
            click.echo(
                "  "
                + click.style(activity.from_agent or agent_name, fg="bright_black")
                + click.style(" > ", fg="bright_black")
                + click.style("(thinking)", dim=True)
            )
            continue
        if activity.type == "tool_call_responses":
            click.echo(
                "  "
                + click.style(activity.from_agent or agent_name, fg="bright_black")
                + click.style(" > ", fg="bright_black")
                + click.style("Tool call(s) completed.", dim=True)
            )
            continue
        if activity.type == "error":
            body_str = str(activity.body) if activity.body is not None else "unknown error"
            hint = ""
            if "connection refused" in body_str or "dial tcp" in body_str:
                hint = "\n    Hint: the agent process pod may not be running — try `chariot awm` and inspect workflow status."
            elif "401" in body_str or "403" in body_str:
                hint = "\n    Hint: check your credentials with `chariot token`."
            click.echo(
                "  "
                + click.style("Error", fg="red", bold=True)
                + click.style(" > ", fg="bright_black")
                + click.style(body_str + hint, fg="red")
            )
            continue

        body = activity.body
        if activity.type == "agent_to_user_message":
            parts = []
            if body.get("message"):
                parts.append(body["message"])
            if body.get("output") is not None:
                parts.append(json.dumps(body["output"], indent=2, ensure_ascii=False))
            body = "\n".join(parts)
            if not body:
                continue

        agent_label = activity.from_agent or agent_name
        click.echo(
            "  "
            + click.style(agent_label, fg="green", bold=True)
            + click.style(" > ", fg="bright_black")
        )
        body_text = body if isinstance(body, str) else json.dumps(body, indent=2)
        for line in body_text.splitlines():
            click.echo("    " + line)
    click.echo()


def _render_session_history(
    activities: list[awm.models.Activity], fallback_agent_name: str
) -> None:
    click.echo()
    click.echo(click.style("  Previous session history", fg="bright_black"))
    if not activities:
        click.echo(click.style("  (no activity found in this session)", dim=True))
        click.echo()
        return

    for activity in activities:
        if activity.type == "user_to_agent_message":
            click.echo(
                "  "
                + click.style("You", fg="cyan", bold=True)
                + click.style(" > ", fg="bright_black")
            )
            body_text = (
                activity.body.get("message", "")
                if isinstance(activity.body, dict)
                else str(activity.body)
            )
            for line in body_text.splitlines():
                click.echo("    " + line)
            continue
        if activity.type in {
            "agent_to_user_message",
            "error",
            "thinking",
            "tool_call_responses",
        }:
            _render_agent_activities([activity], fallback_agent_name)
            continue
        if activity.type == "clear_context":
            click.echo("  " + click.style("(context cleared)", dim=True))
            continue
        if activity.type in {"tool_call_requests", "tool_call_approvals"}:
            click.echo("  " + click.style(f"({activity.type.replace('_', ' ')})", dim=True))

    click.echo()


def _format_config_section(value: object) -> str:
    if value is None or value == {}:
        return "(none)"
    return json.dumps(value, indent=2)


def _render_session_configuration(config: awm.models.SessionConfiguration) -> None:
    click.echo()
    click.echo(click.style("  Session configuration", bold=True))
    click.echo(click.style("  " + "─" * 60, dim=True))
    click.echo()
    click.echo("  " + click.style("overrides", fg="cyan", bold=True))
    for line in _format_config_section(config.overrides).splitlines():
        click.echo("  " + line)
    click.echo()
    click.echo("  " + click.style("resolved", fg="cyan", bold=True))
    for line in _format_config_section(config.resolved).splitlines():
        click.echo("  " + line)
    click.echo()

"""Tool-call approval handling for the AWM chat loop."""

import click
import questionary

from chariot import awm
from chariot.cli.awm.common import _QUESTIONARY_STYLE, _flush_stdin


def _extract_tool_call_requests(activity: awm.models.Activity) -> list[dict]:
    if not isinstance(activity.body, dict):
        return []
    requests = activity.body.get("requests")
    if not isinstance(requests, list):
        return []
    return [request for request in requests if isinstance(request, dict)]


def _needs_approval(tool_request: dict) -> bool:
    return bool(tool_request.get("requiresApproval"))


def _tool_approval_prompt(tool_request: dict) -> tuple[bool, str | None]:
    tool_name = str(tool_request.get("toolName", "unknown_tool"))
    artifact = "yes" if bool(tool_request.get("isArtifact")) else "no"
    click.echo()
    click.echo(click.style("  Tool approval required", fg="yellow", bold=True))
    click.echo(f"  Tool name      {click.style(tool_name, fg='cyan')}")
    click.echo(f"  Artifact tool  {artifact}")
    call_id = tool_request.get("agentToolCallID")
    if call_id:
        click.echo(f"  Tool call ID   {click.style(str(call_id), dim=True)}")

    _flush_stdin()
    decision = questionary.select(
        "Approve this tool call?",
        choices=[
            questionary.Choice(title="Approve", value=True),
            questionary.Choice(title="Deny", value=False),
        ],
        style=_QUESTIONARY_STYLE,
    ).ask()
    if decision is None:
        decision = False

    user_response: str | None = None
    if not decision:
        _flush_stdin()
        user_response = questionary.text(
            "Reason (optional):",
            default="",
            style=_QUESTIONARY_STYLE,
        ).ask()
        if user_response is not None:
            user_response = user_response.strip() or None
    return bool(decision), user_response


def _handle_tool_call_approvals(
    workflow: awm.models.Workflow,
    agent_name: str,
    session_id: str,
    request_activity_id: str,
    requests: list[dict],
) -> tuple[bool, set[str]]:
    requests_requiring_approval = [request for request in requests if _needs_approval(request)]
    if not requests_requiring_approval:
        return False, set()

    click.echo()
    click.echo(
        click.style("  Received tool call request(s) awaiting approval.", fg="yellow", bold=True)
    )

    approvals: list[dict] = []
    handled_tool_call_ids: set[str] = set()
    for request in requests_requiring_approval:
        approved, user_response = _tool_approval_prompt(request)
        approval: dict = {
            "toolCallRequest": request,
            "approved": approved,
        }
        request_id = request.get("agentToolCallID")
        if isinstance(request_id, str) and request_id:
            handled_tool_call_ids.add(request_id)
        if user_response:
            approval["userResponse"] = user_response
        approvals.append(approval)

    try:
        awm.activity.send_tool_call_approvals(
            workflow_id=workflow.id,
            agent_name=agent_name,
            session_id=session_id,
            request_activity_id=request_activity_id,
            approvals=approvals,
        )
        click.echo(click.style("  Approval response sent.", fg="green"))
        return True, handled_tool_call_ids
    except Exception as exc:
        click.echo(click.style(f"  Error sending approval response: {exc}", fg="red"))
        return False, set()

"""Workflow status resolution and display helpers."""

import json

import click

from chariot import awm


def _fmt_id(workflow_id: str) -> str:
    return click.style(f"({workflow_id})", dim=True)


def _pod_status_text(pod: object) -> str:
    if isinstance(pod, dict):
        status = pod.get("status")
    else:
        status = getattr(pod, "status", None)
    return str(status or "unknown").lower()


def _map_workflow_status(resources: awm.models.WorkflowResourceDetails | None) -> str:
    if resources is None or not resources.pods:
        return "PAUSED"
    if not resources.valid:
        return "FAILED"

    pod_statuses = {_pod_status_text(pod) for pod in resources.pods}
    failed_states = {
        "failed",
        "error",
        "crashloopbackoff",
        "imagepullbackoff",
        "errimagepull",
        "oomkilled",
    }
    pending_states = {
        "pending",
        "containercreating",
        "podinitializing",
        "init",
        "unknown",
    }
    if any(state in failed_states for state in pod_statuses):
        return "FAILED"
    if all(state == "running" for state in pod_statuses):
        return "RUNNING"
    # Succeeded is a terminal K8s phase (containers exited 0). An AP Deployment
    # should stay Running; treat Succeeded like paused/not ready so status and
    # pause inference agree and chat stays blocked.
    if all(state == "succeeded" for state in pod_statuses):
        return "PAUSED"
    if any(state in pending_states for state in pod_statuses):
        return "PENDING"
    if any(state == "running" for state in pod_statuses):
        return "PENDING"
    return "PENDING"


def _infer_workflow_paused_state(
    resources: awm.models.WorkflowResourceDetails | None,
) -> bool | None:
    # Treat workflow as active if any pod is in a non-terminal active lifecycle.
    # NOTE: do not rely on resources.valid here; valid can be false in states
    # where a workflow still has active pods and should offer "Pause".
    pods = resources.pods if resources is not None else None
    if not pods:
        return True

    active_pod_states = {
        "running",
        "pending",
        "containercreating",
        "podinitializing",
        "init",
    }
    statuses = {_pod_status_text(p) for p in pods}
    is_active = any(state in active_pod_states for state in statuses)
    return not is_active


def _get_workflow_runtime_state(workflow_id: str) -> tuple[str, bool | None]:
    resources = awm.workflows.get_workflow_resources(workflow_id)
    status = _map_workflow_status(resources)
    paused = _infer_workflow_paused_state(resources)
    return status, paused


def _get_workflow_paused_state(workflow_id: str) -> bool | None:
    # TODO: switch back to using GET workflow `paused` once the API reliably
    # returns it. For now we infer pause state from runtime resources only.
    # https://striveworks.atlassian.net/browse/AF2-397
    _, paused = _get_workflow_runtime_state(workflow_id)
    return paused


def _is_workflow_ready_for_chat(status: str) -> bool:
    return status == "RUNNING"


def _chat_disabled_reason(status: str) -> str | None:
    if status == "RUNNING":
        return None
    if status == "PAUSED":
        return "paused"
    if status == "PENDING":
        return "starting"
    if status == "FAILED":
        return "failed"
    return status.lower()


def _chat_blocked_message(status: str) -> str:
    if status == "PAUSED":
        return "Workflow is paused. Resume it first before starting a chat session."
    if status == "PENDING":
        return (
            "Workflow is starting up. Wait until the agent process is running "
            "before starting a chat session."
        )
    if status == "FAILED":
        return (
            "Workflow agent process is unhealthy. Inspect workflow status "
            "before starting a chat session."
        )
    return f"Workflow status is {status}. Chat is available only when status is RUNNING."


def _get_workflow_state_label(workflow: awm.models.Workflow) -> str:
    status, _ = _get_workflow_runtime_state(workflow.id)
    return status


def _print_workflow_detail(
    workflow: awm.models.Workflow,
    resources: awm.models.WorkflowResourceDetails | None = None,
) -> None:
    w = click.style
    label_w = 16

    click.echo()
    click.echo(
        w("  Workflow", bold=True)
        + "  "
        + w(workflow.name, fg="cyan", bold=True)
        + "  "
        + _fmt_id(workflow.id)
    )
    click.echo(w("  " + "─" * 60, dim=True))

    def _row(label: str, value: str) -> None:
        click.echo("  " + w(label.ljust(label_w), fg="bright_black") + value)

    _row("Description", workflow.description or "—")
    _row("Project ID", workflow.project_id)
    _row("Component ID", workflow.component_id or "—")
    _row("Key", workflow.key or "—")
    _row("Created by", workflow.created_by)
    _row("Created at", workflow.created_at.strftime("%Y-%m-%d %H:%M UTC"))
    _row("Updated at", workflow.updated_at.strftime("%Y-%m-%d %H:%M UTC"))

    if resources is not None:
        status = _map_workflow_status(resources)
        status_styled = (
            click.style(status, fg="green", bold=True)
            if status == "RUNNING"
            else click.style(status, fg="yellow")
            if status == "PENDING"
            else click.style(status, fg="red")
            if status == "FAILED"
            else click.style(status, fg="bright_blue")
        )
        _row("Status", status_styled)
    else:
        fallback_status = _map_workflow_status(None)
        _row(
            "Status",
            click.style(
                fallback_status,
                fg="bright_blue" if fallback_status == "PAUSED" else "yellow",
            ),
        )

    if resources is not None:
        _row("Runtime", "active" if resources.valid else "degraded")
        _row("Deployment", resources.deployment or "—")
        if resources.pods:
            _row("Processes", str(len(resources.pods)))
            counts: dict[str, int] = {}
            for p in resources.pods:
                key = _pod_status_text(p).upper()
                counts[key] = counts.get(key, 0) + 1
            summary = ", ".join(f"{count} {state}" for state, count in sorted(counts.items()))
            _row("Process states", summary)
        else:
            _row("Processes", "none")

    if workflow.config:
        click.echo()
        click.echo("  " + w("Config", bold=True))
        config_str = json.dumps(workflow.config, indent=4)
        for line in config_str.splitlines():
            click.echo("    " + line)

    click.echo()

"""Interactive v2 configuration import for the AWM CLI."""

import os
from pathlib import Path
from typing import Any

import click
import questionary
import yaml
from prompt_toolkit.shortcuts import CompleteStyle

from chariot.awm.config_import import (
    IMPORT_COMPONENT_TYPES,
    ConfigurationImportResult,
    apply_parameters,
    import_v2_configurations,
    print_import_result,
)
from chariot.cli.awm.common import (
    _QUESTIONARY_STYLE,
    _flush_stdin,
    _run_menu_action,
    _Spinner,
)


def _expand_path(path: str) -> Path:
    return Path(os.path.expanduser(path.strip())).resolve()


def _suggest_import_path(path: str) -> bool:
    """Keep directories and YAML files in the import path completer."""
    return os.path.isdir(path) or path.lower().endswith((".yaml", ".yml"))


def load_v2_configuration_file(path: Path) -> dict[str, Any]:
    """Load and validate a v2 configuration bundle from a YAML file."""
    if not path.is_file():
        raise click.ClickException(f"File not found: {path}")
    try:
        raw = yaml.safe_load(path.read_text())
    except yaml.YAMLError as exc:
        raise click.ClickException(f"Invalid YAML in {path}: {exc}") from exc
    if not isinstance(raw, dict):
        raise click.ClickException(
            "Configuration file must contain a YAML mapping at the top level"
        )
    return raw


def summarize_import_config(config: dict[str, Any]) -> str:
    """Return a human-readable summary of component counts in a bundle."""
    lines: list[str] = []
    for component_type in IMPORT_COMPONENT_TYPES:
        entries = config.get(component_type, [])
        if isinstance(entries, list) and entries:
            lines.append(f"  {component_type}: {len(entries)}")
    if not lines:
        return "  (no component entries found)"
    return "\n".join(lines)


_CLI_IMPORT_SECTION_COLORS = {
    "Created": "green",
    "Updated": "yellow",
    "Promoted": "cyan",
    "Skipped": "bright_black",
    "Errors": "red",
}


def _print_import_result(result: ConfigurationImportResult) -> None:
    click.echo()
    print_import_result(
        result,
        indent="  ",
        record_indent="    ",
        format_header=lambda text: click.style(text, bold=True),
        format_divider=lambda text: click.style(text, dim=True),
        format_section=lambda label, count: click.style(
            f"  {label} ({count})",
            fg=_CLI_IMPORT_SECTION_COLORS[label],
            bold=True,
        ),
    )
    click.echo()


def import_configurations_from_file(project) -> None:
    """Prompt for a v2 configuration bundle and import it into the project."""
    _flush_stdin()
    file_path = questionary.path(
        "Path to v2 configuration YAML file:",
        style=_QUESTIONARY_STYLE,
        file_filter=_suggest_import_path,
        # First Tab fills the shared prefix. A second Tab lists every match.
        complete_style=CompleteStyle.READLINE_LIKE,
    ).ask()
    if not file_path or not file_path.strip():
        click.echo(click.style("  Import cancelled.", dim=True))
        return

    try:
        path = _expand_path(file_path)
        raw_config = load_v2_configuration_file(path)
        config = apply_parameters(raw_config)
    except click.ClickException as exc:
        click.echo(click.style(f"  {exc.message}", fg="red"))
        return
    except ValueError as exc:
        click.echo(click.style(f"  {str(exc)}", fg="red"))
        return

    click.echo()
    click.echo(click.style("  Components to import:", bold=True))
    click.echo(summarize_import_config(config))
    click.echo()

    _flush_stdin()
    confirmed = questionary.confirm(
        f"Import configurations into project '{project.name}'?",
        default=False,
        style=_QUESTIONARY_STYLE,
    ).ask()
    if not confirmed:
        click.echo(click.style("  Import cancelled.", dim=True))
        return

    def _run_import() -> ConfigurationImportResult:
        with _Spinner("Importing configurations"):
            return import_v2_configurations(
                project.id,
                config,
                version_changelog="CLI import",
                promote_existing_to_production=True,
            )

    result = _run_menu_action(
        _run_import,
        action_label="import configurations from file",
        fallback=ConfigurationImportResult(),
    )
    _print_import_result(result)

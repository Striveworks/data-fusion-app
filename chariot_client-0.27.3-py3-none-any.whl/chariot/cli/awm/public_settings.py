"""Public settings (overrides) menus for the AWM CLI."""

import json
from typing import Any

import click
import questionary

from chariot import awm
from chariot.cli.awm.common import (
    _BACK,
    _edit_json,
    _flush_stdin,
    _run_menu_action,
    _select,
    _Spinner,
)

_REFINED_GUIDANCE_KEY = "refined_guidance"
_AUTONOMY_LEVELS = frozenset({"low", "medium", "high"})
_V2_DEFAULT_KEYS = frozenset({"autonomy", _REFINED_GUIDANCE_KEY})


def settings_to_edit_dict(
    settings: dict[str, awm.models.WorkflowPublicSettingValue],
) -> dict[str, dict[str, object]]:
    """Convert public settings to an editor-friendly values-only dict."""
    return {key: {"value": setting.value} for key, setting in settings.items()}


def _flatten_setting_for_display(key: str, value: object) -> list[tuple[str, str]]:
    if isinstance(value, dict):
        rows: list[tuple[str, str]] = []
        for sub_key, sub_value in sorted(value.items()):
            rows.extend(_flatten_setting_for_display(f"{key}.{sub_key}", sub_value))
        return rows

    if isinstance(value, list):
        if all(isinstance(item, str) for item in value):
            return [(key, "\n".join(value) if value else "—")]
        return [(key, json.dumps(value))]

    if value is None:
        return [(key, "—")]
    return [(key, str(value))]


def settings_to_display_rows(
    settings: dict[str, awm.models.WorkflowPublicSettingValue],
) -> list[tuple[str, str]]:
    """Flatten public settings into display rows with dot-path keys."""
    rows: list[tuple[str, str]] = []
    for key, setting in sorted(settings.items()):
        rows.extend(_flatten_setting_for_display(key, setting.value))
    return rows


def _validate_setting_entry(key: str, entry: object) -> object:
    if not isinstance(entry, dict) or "value" not in entry or len(entry) != 1:
        raise click.ClickException(
            f'Public setting "{key}" must be an object with a single "value" field'
        )
    value = entry["value"]

    if key == "autonomy":
        if not isinstance(value, str) or value not in _AUTONOMY_LEVELS:
            raise click.ClickException(
                f"autonomy.value must be one of: {', '.join(sorted(_AUTONOMY_LEVELS))}"
            )
        return value

    if key == _REFINED_GUIDANCE_KEY:
        if not isinstance(value, dict) or not all(
            isinstance(agent_value, str) for agent_value in value.values()
        ):
            raise click.ClickException(
                "refined_guidance.value must be an object mapping agent names to strings"
            )
        return value

    return value


def _values_equal(left: object, right: object) -> bool:
    return json.dumps(left, sort_keys=True) == json.dumps(right, sort_keys=True)


def edit_dict_to_patch(
    original: dict[str, awm.models.WorkflowPublicSettingValue],
    edited: dict[str, Any],
    *,
    allowed_keys: frozenset[str] | None = None,
) -> dict[str, awm.models.WorkflowPublicSettingValue]:
    """Build a patch dict from edited public settings, validating changes."""
    if not isinstance(edited, dict):
        raise click.ClickException("Public settings must be a JSON object")

    if allowed_keys is not None:
        known_keys = allowed_keys
    elif original:
        known_keys = frozenset(original)
    else:
        known_keys = _V2_DEFAULT_KEYS

    unknown_keys = set(edited) - known_keys
    if unknown_keys:
        raise click.ClickException(
            "Unknown public setting keys: "
            + ", ".join(sorted(unknown_keys))
            + ". Only existing settings can be edited."
        )

    patch: dict[str, awm.models.WorkflowPublicSettingValue] = {}
    for key, entry in edited.items():
        validated_value = _validate_setting_entry(key, entry)
        original_value = original[key].value if key in original else None
        if not _values_equal(original_value, validated_value):
            patch[key] = awm.models.WorkflowPublicSettingValue(value=validated_value)
    return patch


def edit_template_text(settings: dict[str, awm.models.WorkflowPublicSettingValue]) -> str:
    """Return JSONC editor template text for the active public settings schema."""
    payload = settings_to_edit_dict(settings)

    autonomy = payload.get("autonomy", {"value": "medium"})
    refined_guidance = payload.get("refined_guidance", {"value": {}})
    autonomy_json = json.dumps(autonomy, indent=2).replace("\n", "\n  ")
    refined_json = json.dumps(refined_guidance, indent=2).replace("\n", "\n  ")
    return f"""{{
  // v2 workflow overrides. Only edit "value" fields.
  // autonomy: "low", "medium", or "high"
  // refined_guidance.value: agent display name -> guidance text
  "autonomy": {autonomy_json},
  "refined_guidance": {refined_json}
}}"""


def manage_public_settings(workflow: awm.models.Workflow) -> None:
    """Entry point from the workflow action menu."""
    _public_settings_action_menu(workflow)


def _print_public_settings_detail(
    settings: dict[str, awm.models.WorkflowPublicSettingValue],
) -> None:
    click.echo()
    click.echo(click.style("  Public settings", bold=True))
    click.echo(click.style("  " + "─" * 60, dim=True))

    rows = settings_to_display_rows(settings)
    if not rows:
        click.echo(click.style("  (no public settings defined)", dim=True))
        click.echo()
        return

    for key, value in rows:
        click.echo(f"  {click.style(key, fg='cyan')}: {value}")
    click.echo()


def _fetch_public_settings(workflow_id: str) -> dict[str, awm.models.WorkflowPublicSettingValue]:
    with _Spinner("Loading public settings"):
        return awm.get_public_setting_values(workflow_id)


def _allowed_setting_keys(
    workflow: awm.models.Workflow,
    settings: dict[str, awm.models.WorkflowPublicSettingValue],
) -> frozenset[str] | None:
    if settings:
        return frozenset(settings)
    if workflow.public_settings:
        return frozenset(workflow.public_settings)
    return None


def _edit_public_settings(workflow: awm.models.Workflow) -> None:
    settings = _fetch_public_settings(workflow.id)
    if not settings:
        click.echo(click.style("  No public settings returned.", dim=True))

    initial = settings_to_edit_dict(settings)
    edited = _edit_json(initial, initial_text=edit_template_text(settings))
    if edited is None:
        click.echo(click.style("  No changes made.", dim=True))
        return

    try:
        patch = edit_dict_to_patch(
            settings,
            edited,
            allowed_keys=_allowed_setting_keys(workflow, settings),
        )
    except click.ClickException as exc:
        click.echo(click.style(f"  {exc.message}", fg="red"))
        return

    if not patch:
        click.echo(click.style("  No changes made.", dim=True))
        return

    with _Spinner("Updating public settings"):
        awm.patch_public_setting_values(workflow.id, patch)
    click.echo(click.style("  Public settings updated.", fg="green"))


def _public_settings_action_menu(workflow: awm.models.Workflow) -> None:
    while True:
        _flush_stdin()
        action = _select(
            f"{workflow.name} — Public settings",
            choices=[
                questionary.Choice(title="View details", value="view"),
                questionary.Choice(title="Edit", value="edit"),
                questionary.Choice(title="↩ Back", value=_BACK),
            ],
        )
        if action is None or action == _BACK:
            return
        if action == "view":
            _run_menu_action(
                lambda: _print_public_settings_detail(_fetch_public_settings(workflow.id)),
                action_label=f"view public settings for workflow '{workflow.name}'",
                fallback=None,
            )
            continue
        if action == "edit":
            _run_menu_action(
                lambda: _edit_public_settings(workflow),
                action_label=f"edit public settings for workflow '{workflow.name}'",
                fallback=None,
            )

"""Prompt template menus for the AWM CLI."""

import itertools
import json

import click
import questionary

from chariot import awm
from chariot.cli.awm.common import (
    _BACK,
    _NEW,
    _QUESTIONARY_STYLE,
    _column_header,
    _edit_json,
    _flush_stdin,
    _run_menu_action,
    _select,
    _Spinner,
)
from chariot.cli.awm.status import _fmt_id

_INITIAL_CREATE_TEMPLATE = {
    "visibility": awm.models.PROMPT_TEMPLATE_VISIBILITY_PRIVATE,
    "scope": awm.models.PROMPT_TEMPLATE_SCOPE_AGENT,
    "agentID": "",
    "name": "",
    "description": "",
    "content": "",
}


def _create_template_text(payload: dict) -> str:
    return f"""{{
  // "public" or "private". Public templates are visible to all project users.
  "visibility": {json.dumps(payload["visibility"])},
  // "agent" or "global". Public templates must use scope "agent".
  "scope": {json.dumps(payload["scope"])},
  // Required when scope is "agent". Agent configuration component base ID.
  "agentID": {json.dumps(payload["agentID"])},
  "name": {json.dumps(payload["name"])},
  "description": {json.dumps(payload["description"])},
  "content": {json.dumps(payload["content"])}
}}"""


def browse_prompt_templates(project) -> None:
    """Entry point from the project action menu."""
    filters = _default_list_filters()
    while True:
        selected = _run_menu_action(
            lambda: _prompt_template_list_menu(project, filters),
            action_label="list prompt templates",
            fallback=_BACK,
        )
        if selected is None or selected == _BACK:
            return
        if selected == _NEW:
            _run_menu_action(
                lambda: _create_prompt_template(project, filters),
                action_label="create prompt template",
                fallback=None,
            )
            continue
        if isinstance(selected, awm.models.PromptTemplate):
            _run_menu_action(
                lambda template=selected: _prompt_template_action_menu(template),
                action_label=f"manage prompt template '{selected.name}'",
                fallback=None,
            )


def _default_list_filters() -> dict[str, str | None]:
    return {
        "agent_id": None,
        "visibility": None,
        "scope": awm.models.PROMPT_TEMPLATE_SCOPE_AGENT,
    }


def _list_agent_components(project) -> list[awm.models.ConfigurationComponent]:
    return list(
        itertools.islice(
            awm.list_agent_configuration_components(project_ids=[project.id]),
            100,
        )
    )


def _select_agent_component(
    project,
    *,
    prompt: str,
    allow_back: bool = True,
) -> awm.models.ConfigurationComponent | str | None:
    agents = _list_agent_components(project)
    if not agents:
        click.echo(
            click.style("  No agent configuration components found in this project.", fg="red")
        )
        return _BACK if allow_back else None

    name_w = max((len(agent.name) for agent in agents), default=20)
    key_w = max((len(agent.key) for agent in agents), default=12)
    choices: list[questionary.Choice] = [
        _column_header(f"{'Name'.ljust(name_w)}  {'Key'.ljust(key_w)}"),
        questionary.Separator(),
    ]
    for agent in agents:
        choices.append(
            questionary.Choice(
                title=f"{agent.name.ljust(name_w)}  {agent.key.ljust(key_w)}",
                value=agent,
            )
        )
    choices.append(questionary.Separator())
    if allow_back:
        choices.append(questionary.Choice(title="↩ Back", value=_BACK))

    _flush_stdin()
    selected = _select(prompt, choices=choices)
    if selected is None or selected == _BACK:
        return _BACK if allow_back else None
    if isinstance(selected, awm.models.ConfigurationComponent):
        return selected
    return _BACK if allow_back else None


def _configure_list_filters(project, filters: dict[str, str | None]) -> dict[str, str | None]:
    while True:
        scope_label = filters.get("scope") or "agent"
        visibility_label = filters.get("visibility") or "any"
        agent_label = filters.get("agent_id") or "(not set)"
        _flush_stdin()
        action = _select(
            "Prompt template filters",
            choices=[
                questionary.Choice(title=f"Scope: {scope_label}", value="scope"),
                questionary.Choice(
                    title=f"Visibility: {visibility_label}",
                    value="visibility",
                ),
                questionary.Choice(title=f"Agent ID: {agent_label}", value="agent"),
                questionary.Choice(title="Apply filters", value="apply"),
                questionary.Choice(title="↩ Back", value=_BACK),
            ],
        )
        if action is None or action == _BACK:
            return filters
        if action == "apply":
            return filters
        if action == "scope":
            _flush_stdin()
            scope = _select(
                "Template scope",
                choices=[
                    questionary.Choice(
                        title="Agent",
                        value=awm.models.PROMPT_TEMPLATE_SCOPE_AGENT,
                    ),
                    questionary.Choice(
                        title="Global",
                        value=awm.models.PROMPT_TEMPLATE_SCOPE_GLOBAL,
                    ),
                    questionary.Choice(title="↩ Back", value=_BACK),
                ],
            )
            if scope is None or scope == _BACK:
                continue
            filters["scope"] = scope
            if scope == awm.models.PROMPT_TEMPLATE_SCOPE_GLOBAL:
                filters["agent_id"] = None
                if filters.get("visibility") == awm.models.PROMPT_TEMPLATE_VISIBILITY_PUBLIC:
                    filters["visibility"] = None
            continue
        if action == "visibility":
            _flush_stdin()
            visibility = _select(
                "Template visibility",
                choices=[
                    questionary.Choice(title="Any", value=None),
                    questionary.Choice(
                        title="Public",
                        value=awm.models.PROMPT_TEMPLATE_VISIBILITY_PUBLIC,
                    ),
                    questionary.Choice(
                        title="Private",
                        value=awm.models.PROMPT_TEMPLATE_VISIBILITY_PRIVATE,
                    ),
                    questionary.Choice(title="↩ Back", value=_BACK),
                ],
            )
            if visibility == _BACK:
                continue
            if visibility == awm.models.PROMPT_TEMPLATE_VISIBILITY_PUBLIC:
                filters["scope"] = awm.models.PROMPT_TEMPLATE_SCOPE_AGENT
            filters["visibility"] = visibility
            continue
        if action == "agent":
            if filters.get("scope") == awm.models.PROMPT_TEMPLATE_SCOPE_GLOBAL:
                click.echo(
                    click.style(
                        "  Agent filter is not used when scope is global.",
                        dim=True,
                    )
                )
                continue
            selected = _select_agent_component(
                project,
                prompt="Select agent for template list",
            )
            if selected == _BACK or selected is None:
                continue
            if isinstance(selected, awm.models.ConfigurationComponent):
                filters["agent_id"] = selected.id


def _list_prompt_templates(
    project,
    filters: dict[str, str | None],
) -> list[awm.models.PromptTemplate]:
    scope = filters.get("scope")
    agent_id = filters.get("agent_id")
    visibility = filters.get("visibility")

    if scope != awm.models.PROMPT_TEMPLATE_SCOPE_GLOBAL and not agent_id:
        selected = _select_agent_component(
            project,
            prompt="Select agent to list prompt templates",
            allow_back=False,
        )
        if not isinstance(selected, awm.models.ConfigurationComponent):
            return []
        agent_id = selected.id
        filters["agent_id"] = agent_id

    kwargs = {
        "project_id": project.id,
        "sort_type": awm.models.PROMPT_TEMPLATE_SORT_CREATED_AT,
        "sort_order": "DESC",
        "limit": 100,
    }
    if agent_id:
        kwargs["agent_id"] = agent_id
    if visibility:
        kwargs["visibility"] = visibility
    if scope:
        kwargs["scope"] = scope

    return list(awm.get_prompt_templates(**kwargs))


def _filter_summary(filters: dict[str, str | None]) -> str:
    parts = [f"scope={filters.get('scope') or 'agent'}"]
    if filters.get("visibility"):
        parts.append(f"visibility={filters['visibility']}")
    if filters.get("agent_id"):
        parts.append(f"agent={filters['agent_id']}")
    return ", ".join(parts)


def _template_summary(template: awm.models.PromptTemplate) -> str:
    visibility = template.visibility.upper()
    scope = template.scope
    preview = template.content[:40] + "..." if len(template.content) > 40 else template.content
    return f"{template.name}  [{visibility}/{scope}]  {preview}"


def _print_prompt_template_detail(template: awm.models.PromptTemplate) -> None:
    label_w = 14
    click.echo()
    click.echo(
        click.style("  Prompt template", bold=True)
        + "  "
        + click.style(template.name, fg="cyan", bold=True)
        + "  "
        + _fmt_id(template.id)
    )
    click.echo(click.style("  " + "─" * 60, dim=True))

    def _row(label: str, value: str) -> None:
        click.echo("  " + click.style(label.ljust(label_w), fg="bright_black") + value)

    _row("Project ID", template.project_id)
    _row("Visibility", template.visibility)
    _row("Enabled", "true" if template.enabled else "false")
    _row("Scope", template.scope)
    _row("Agent ID", template.agent_id or "—")
    _row("Created by", template.created_by)
    _row("Created at", template.created_at.strftime("%Y-%m-%d %H:%M UTC"))
    if template.description:
        _row("Description", template.description)
    if template.placeholders:
        _row("Placeholders", ", ".join(template.placeholders))
    click.echo()
    click.echo("  " + click.style("Content", bold=True))
    for line in template.content.splitlines():
        click.echo(f"    {line}")
    click.echo()


def _to_optional_str(value: object) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _validate_create_payload(payload: dict) -> None:
    if not _to_optional_str(payload.get("name")):
        raise click.ClickException("Required field missing: name")
    if not _to_optional_str(payload.get("content")):
        raise click.ClickException("Required field missing: content")

    visibility = _to_optional_str(payload.get("visibility"))
    if visibility not in (
        awm.models.PROMPT_TEMPLATE_VISIBILITY_PUBLIC,
        awm.models.PROMPT_TEMPLATE_VISIBILITY_PRIVATE,
    ):
        raise click.ClickException("visibility must be 'public' or 'private'")

    scope = _to_optional_str(payload.get("scope"))
    if scope not in (
        awm.models.PROMPT_TEMPLATE_SCOPE_AGENT,
        awm.models.PROMPT_TEMPLATE_SCOPE_GLOBAL,
    ):
        raise click.ClickException("scope must be 'agent' or 'global'")

    agent_id = _to_optional_str(payload.get("agentID"))

    if visibility == awm.models.PROMPT_TEMPLATE_VISIBILITY_PUBLIC:
        if scope != awm.models.PROMPT_TEMPLATE_SCOPE_AGENT:
            raise click.ClickException("public templates must have scope agent")
        if not agent_id:
            raise click.ClickException("Required field missing: agentID")

    if (
        visibility == awm.models.PROMPT_TEMPLATE_VISIBILITY_PRIVATE
        and scope == awm.models.PROMPT_TEMPLATE_SCOPE_GLOBAL
        and agent_id
    ):
        raise click.ClickException("agentID must be omitted when scope is global")

    if scope == awm.models.PROMPT_TEMPLATE_SCOPE_AGENT and not agent_id:
        raise click.ClickException("Required field missing: agentID")

    if scope == awm.models.PROMPT_TEMPLATE_SCOPE_GLOBAL and agent_id:
        raise click.ClickException("agentID must be omitted when scope is global")


def _validate_update_payload(payload: dict) -> None:
    updates = {
        key: payload.get(key)
        for key in ("name", "description", "content", "enabled", "visibility")
        if payload.get(key) is not None
    }
    if not updates:
        raise click.ClickException(
            "at least one of name, description, content, enabled, or visibility must be provided"
        )
    if "name" in updates and not _to_optional_str(updates["name"]):
        raise click.ClickException("name cannot be empty")
    if "content" in updates and not _to_optional_str(updates["content"]):
        raise click.ClickException("content cannot be empty")
    if "enabled" in updates and not isinstance(updates["enabled"], bool):
        raise click.ClickException("enabled must be a boolean")
    if "visibility" in updates:
        visibility = _to_optional_str(updates["visibility"])
        if visibility not in (
            awm.models.PROMPT_TEMPLATE_VISIBILITY_PUBLIC,
            awm.models.PROMPT_TEMPLATE_VISIBILITY_PRIVATE,
        ):
            raise click.ClickException("visibility must be 'public' or 'private'")


def _initial_create_payload(filters: dict[str, str | None]) -> dict:
    initial = dict(_INITIAL_CREATE_TEMPLATE)
    if filters.get("agent_id"):
        initial["agentID"] = filters["agent_id"]
    if filters.get("scope"):
        initial["scope"] = filters["scope"]
    if filters.get("visibility"):
        initial["visibility"] = filters["visibility"]
    return initial


def _create_prompt_template(project, filters: dict[str, str | None]) -> None:
    initial = _initial_create_payload(filters)
    edited = _edit_json(
        initial,
        initial_text=_create_template_text(initial),
    )
    if edited is None:
        click.echo(click.style("  Aborted — no prompt template created.", dim=True))
        return

    try:
        _validate_create_payload(edited)
    except click.ClickException as exc:
        click.echo(click.style(f"  {exc.message}", fg="red"))
        return

    agent_id = _to_optional_str(edited.get("agentID"))
    template = awm.create_prompt_template(
        project_id=project.id,
        visibility=str(edited["visibility"]),
        scope=str(edited["scope"]),
        name=str(edited["name"]).strip(),
        content=str(edited["content"]).strip(),
        description=_to_optional_str(edited.get("description")),
        agent_id=agent_id,
    )
    click.echo(
        click.style("  Prompt template created: ", fg="green")
        + click.style(template.name, fg="green", bold=True)
        + " "
        + _fmt_id(template.id)
    )


def _edit_prompt_template(template: awm.models.PromptTemplate) -> awm.models.PromptTemplate:
    initial = {
        "name": template.name,
        "description": template.description,
        "content": template.content,
        "enabled": template.enabled,
        "visibility": template.visibility,
    }
    edited = _edit_json(initial)
    if edited is None:
        click.echo(click.style("  No changes made.", dim=True))
        return template

    try:
        _validate_update_payload(edited)
    except click.ClickException as exc:
        click.echo(click.style(f"  {exc.message}", fg="red"))
        return template

    visibility = _to_optional_str(edited.get("visibility"))
    visibility_update: str | None = None
    if visibility is not None and visibility != template.visibility:
        if visibility != awm.models.PROMPT_TEMPLATE_VISIBILITY_PUBLIC:
            click.echo(
                click.style(
                    '  visibility can only be promoted to "public"',
                    fg="red",
                )
            )
            return template
        visibility_update = visibility

    enabled = edited.get("enabled")
    enabled_update = enabled if isinstance(enabled, bool) else None

    updated = awm.update_prompt_template(
        template.id,
        name=_to_optional_str(edited.get("name")),
        description=edited.get("description"),
        content=_to_optional_str(edited.get("content")),
        enabled=enabled_update,
        visibility=visibility_update,
    )
    click.echo(click.style("  Prompt template updated.", fg="green"))
    return updated


def _delete_prompt_template(template: awm.models.PromptTemplate) -> bool:
    confirmed = questionary.confirm(
        f"Delete prompt template '{template.name}'? This cannot be undone.",
        default=False,
        style=_QUESTIONARY_STYLE,
    ).ask()
    if not confirmed:
        return False

    awm.delete_prompt_template(template.id)
    click.echo(click.style("  Prompt template deleted.", fg="green"))
    return True


def _prompt_template_action_menu(template: awm.models.PromptTemplate) -> None:
    selected = template
    while True:
        _flush_stdin()
        action = _select(
            selected.name,
            choices=[
                questionary.Choice(title="View details", value="view"),
                questionary.Choice(title="Edit", value="edit"),
                questionary.Choice(title="Delete", value="delete"),
                questionary.Choice(title="↩ Back", value=_BACK),
            ],
        )
        if action is None or action == _BACK:
            return
        if action == "view":
            _print_prompt_template_detail(selected)
            continue
        if action == "edit":
            selected = _run_menu_action(
                lambda: _edit_prompt_template(selected),
                action_label="update prompt template",
                fallback=selected,
            )
            continue
        if action == "delete":
            deleted = _run_menu_action(
                lambda: _delete_prompt_template(selected),
                action_label="delete prompt template",
                fallback=False,
            )
            if deleted:
                return


def _prompt_template_list_menu(
    project,
    filters: dict[str, str | None],
) -> awm.models.PromptTemplate | str | None:
    while True:
        with _Spinner("Loading prompt templates"):
            templates = _list_prompt_templates(project, filters)

        choices: list[questionary.Choice] = []
        if templates:
            for template in templates:
                choices.append(
                    questionary.Choice(title=_template_summary(template), value=template)
                )
            choices.append(questionary.Separator())
        else:
            choices.append(
                questionary.Choice(title="(no prompt templates found)", value=None, disabled=" ")
            )
            choices.append(questionary.Separator())

        choices.extend(
            [
                questionary.Choice(title="Change filters", value="__filters__"),
                questionary.Choice(title="Create prompt template", value=_NEW),
                questionary.Choice(title="↩ Back", value=_BACK),
            ]
        )

        _flush_stdin()
        selected = _select(
            f"Prompt templates ({project.name}) [{_filter_summary(filters)}]",
            choices=choices,
        )

        if selected is None or selected == _BACK:
            return _BACK
        if selected == "__filters__":
            filters.update(_configure_list_filters(project, filters))
            continue
        if selected == _NEW:
            return _NEW
        if isinstance(selected, awm.models.PromptTemplate):
            return selected

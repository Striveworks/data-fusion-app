"""Shared constants, styles, and interactive CLI helpers."""

import itertools
import json
import os
import sys
import termios
import threading
import time
from collections.abc import Callable, Sequence
from typing import TypeVar

import click
import questionary
from questionary import Style

from chariot.client import connect

_QUESTIONARY_STYLE = Style(
    [
        ("qmark", "fg:#5f87d7 bold"),
        ("question", "bold"),
        ("answer", "fg:#5f87d7 bold"),
        ("pointer", "fg:#5f87d7 bold"),
        ("highlighted", "fg:#5f87d7"),
        ("selected", "fg:#5f87d7"),
        ("separator", "fg:#6c6c6c"),
        ("instruction", "fg:#6c6c6c"),
    ]
)

# Sentinel strings for questionary choices — avoids the ambiguity of value=None
# (which questionary also returns on Ctrl+C / interrupted prompts).
_BACK = "__cli_back__"
_EXIT = "__cli_exit__"
_NEW = "__cli_new__"

_TReturn = TypeVar("_TReturn")
_AUTO_Q_BACK = object()


# ---------------------------------------------------------------------------
# Terminal helpers
# ---------------------------------------------------------------------------


def _flush_stdin() -> None:
    """Discard any buffered keystrokes left over from the previous prompt.

    Without this, the Enter key that confirmed the last questionary selection
    can be immediately consumed by the *next* prompt, causing it to fire
    before the user has a chance to interact.
    """
    termios.tcflush(sys.stdin, termios.TCIFLUSH)
    # Give prompt_toolkit's internal event loop a moment to fully settle.
    time.sleep(0.05)


def _column_header(title: str) -> questionary.Separator:
    """Build a table header row that the cursor skips over.

    A separator is used rather than a disabled choice because questionary
    prefixes disabled choices with ``- ``, which would break column alignment
    with the rows beneath the header.
    """
    return questionary.Separator(title)


def _auto_q_back_value(choices: Sequence[object]) -> object | None:
    for choice in choices:
        if (
            isinstance(choice, questionary.Choice)
            and not choice.disabled
            and choice.value in (_BACK, _EXIT)
        ):
            return choice.value
        if (
            isinstance(choice, dict)
            and not choice.get("disabled")
            and choice.get("value") in (_BACK, _EXIT)
        ):
            return choice.get("value")
    return None


def _make_select_question(
    message: str,
    choices: Sequence[object],
    *,
    q_value: object | None = _AUTO_Q_BACK,
    style: Style | None = _QUESTIONARY_STYLE,
    **kwargs,
):
    resolved_q_value = _auto_q_back_value(choices) if q_value is _AUTO_Q_BACK else q_value
    if resolved_q_value is not None:
        kwargs.setdefault("instruction", "(Use arrow keys, q to go back)")

    question = questionary.select(message, choices=choices, style=style, **kwargs)

    if resolved_q_value is not None:

        @question.application.key_bindings.add("q", eager=True)
        def _go_back(event):
            event.app.exit(result=resolved_q_value)

    return question


def _select(
    message: str,
    choices: Sequence[object],
    *,
    q_value: object | None = _AUTO_Q_BACK,
    style: Style | None = _QUESTIONARY_STYLE,
    **kwargs,
):
    return _make_select_question(
        message,
        choices,
        q_value=q_value,
        style=style,
        **kwargs,
    ).ask()


# ---------------------------------------------------------------------------
# Spinner
# ---------------------------------------------------------------------------


class _Spinner:
    _FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]

    def __init__(self, message: str = "Thinking") -> None:
        self._message = message
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._spin, daemon=True)

    def _spin(self) -> None:
        for frame in itertools.cycle(self._FRAMES):
            if self._stop.is_set():
                break
            sys.stdout.write(f"\r  {click.style(frame, fg='cyan')} {self._message}...")
            sys.stdout.flush()
            time.sleep(0.1)
        sys.stdout.write("\r" + " " * (len(self._message) + 10) + "\r")
        sys.stdout.flush()

    def __enter__(self):
        self._thread.start()
        return self

    def __exit__(self, *_):
        self._stop.set()
        self._thread.join()


# ---------------------------------------------------------------------------
# JSON editor helpers
# ---------------------------------------------------------------------------

_EDITOR_HEADER = """\
// Chariot CLI JSON payload — edit below, then save and close.
// Lines beginning with // are stripped before parsing.
"""


def _with_header(content: str) -> str:
    return _EDITOR_HEADER + content


def _without_header(content: str) -> str:
    header_lines = _EDITOR_HEADER.rstrip("\n").splitlines()
    body_lines = content.splitlines()
    if body_lines[: len(header_lines)] == header_lines:
        body_lines = body_lines[len(header_lines) :]
    return "\n".join(body_lines).lstrip("\n")


def _editor_for_json() -> str | None:
    """Prefer vi when no editor is explicitly configured by the user."""
    if sys.platform.startswith("win"):
        return None
    if os.environ.get("CHARIOT_AWM_EDITOR"):
        return os.environ["CHARIOT_AWM_EDITOR"]
    if os.environ.get("VISUAL") or os.environ.get("EDITOR"):
        return None
    return "vi"


def _strip_comments(text: str) -> str:
    lines = [line for line in text.splitlines() if not line.lstrip().startswith("//")]
    return "\n".join(lines)


def _edit_json(initial: dict, *, initial_text: str | None = None) -> dict | None:
    """Open an editor with JSON content and retry until valid or discarded.

    :param initial: The default dict used as the "no changes" fallback value.
    :param initial_text: Optional JSONC string (may include ``//`` comments) to
        display instead of the JSON-serialized *initial* dict.  Comments are
        stripped before the equality comparison, so the user sees guidance but
        saving unchanged still counts as "no changes".
    """
    if initial_text is None:
        initial_text = json.dumps(initial, indent=2)
    canonical = _strip_comments(initial_text).strip()
    current_text = initial_text

    while True:
        edited = click.edit(
            _with_header(current_text),
            extension=".json",
            editor=_editor_for_json(),
        )
        if edited is None:
            return None

        current_text = _without_header(edited)
        cleaned = _strip_comments(current_text).strip()
        if not cleaned or cleaned == canonical:
            return None

        try:
            parsed = json.loads(cleaned)
        except json.JSONDecodeError as exc:
            click.echo(
                click.style(
                    f"  Invalid JSON: {exc.msg} (line {exc.lineno}, column {exc.colno})",
                    fg="red",
                )
            )
            _flush_stdin()
            next_action = _select(
                "Fix JSON and try saving again?",
                choices=[
                    questionary.Choice(title="Reopen editor", value="retry"),
                    questionary.Choice(title="Discard changes", value="discard"),
                ],
            )
            if next_action != "retry":
                return None
            continue

        if not isinstance(parsed, dict):
            click.echo(click.style("  JSON must be an object at the top level.", fg="red"))
            _flush_stdin()
            next_action = _select(
                "Fix JSON and try saving again?",
                choices=[
                    questionary.Choice(title="Reopen editor", value="retry"),
                    questionary.Choice(title="Discard changes", value="discard"),
                ],
            )
            if next_action != "retry":
                return None
            continue

        return parsed


# ---------------------------------------------------------------------------
# Connection / error helpers
# ---------------------------------------------------------------------------


def _ensure_connected() -> None:
    """Call connect() using stored context credentials, with a helpful error."""
    try:
        with _Spinner("Connecting to Chariot"):
            connect()
    except Exception as exc:
        raise click.ClickException(
            f"Could not connect to Chariot: {exc}\n"
            "Run `chariot init` or `chariot use-context <ctx>` to configure credentials."
        ) from exc


def _run_menu_action(
    action: Callable[[], _TReturn],
    *,
    action_label: str,
    fallback: _TReturn,
) -> _TReturn:
    """Execute an interactive menu action without breaking the current menu on errors."""
    try:
        return action()
    except Exception as exc:
        click.echo(click.style(f"  Failed to {action_label}: {exc}", fg="red"))
        return fallback

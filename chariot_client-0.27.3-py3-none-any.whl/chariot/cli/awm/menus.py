"""Click command group, project/workflow/configurations/prompt template menus and actions."""

import itertools

import click
import questionary

from chariot import awm
from chariot.cli.awm.chat import do_chat_from_menu
from chariot.cli.awm.common import (
    _BACK,
    _EXIT,
    _NEW,
    _QUESTIONARY_STYLE,
    _column_header,
    _edit_json,
    _ensure_connected,
    _flush_stdin,
    _run_menu_action,
    _select,
    _Spinner,
)
from chariot.cli.awm.configurations import browse_configurations
from chariot.cli.awm.prompt_templates import browse_prompt_templates
from chariot.cli.awm.public_settings import manage_public_settings
from chariot.cli.awm.status import (
    _chat_disabled_reason,
    _fmt_id,
    _get_workflow_paused_state,
    _get_workflow_runtime_state,
    _get_workflow_state_label,
    _print_workflow_detail,
)
from chariot.projects import get_projects

# ---------------------------------------------------------------------------
# Click command group
# ---------------------------------------------------------------------------


@click.group("awm", invoke_without_command=True)
@click.pass_context
def awm_group(ctx: click.Context):
    """Interact with Agentic Workflow Manager (AWM) workflows."""
    if ctx.invoked_subcommand is not None:
        raise click.UsageError("AWM is interactive-only. Run `chariot awm` with no subcommands.")
    _ensure_connected()
    _browse_projects()


# ---------------------------------------------------------------------------
# Project browser
# ---------------------------------------------------------------------------


def _build_project_choices(
    projects: list, page: int, search: str | None
) -> list[questionary.Choice]:
    name_w = max((len(p.name) for p in projects), default=20)
    id_w = max((len(p.id) for p in projects), default=16)
    search_suffix = f"  [search: {search}]" if search else ""
    choices = [
        _column_header(f"{'Project Name'.ljust(name_w)}  {'Project ID'.ljust(id_w)}"),
        questionary.Separator(),
    ] + [
        questionary.Choice(
            title=f"{p.name.ljust(name_w)}  {p.id.ljust(id_w)}",
            value=("project", p),
        )
        for p in projects
    ]
    choices.append(questionary.Separator())
    choices.append(questionary.Separator(f"Page {page}"))
    choices.append(questionary.Choice(title="Next page", value=("next", None)))
    if page > 1:
        choices.append(questionary.Choice(title="Previous page", value=("prev", None)))
    choices.append(
        questionary.Choice(title=f"Search projects{search_suffix}", value=("search", None))
    )
    if search:
        choices.append(questionary.Choice(title="Clear search", value=("clear_search", None)))
    choices.append(questionary.Choice(title="Exit", value=("exit", None)))
    return choices


def _browse_projects() -> None:
    limit = 15
    page = 1
    search: str | None = None

    while True:
        offset = (page - 1) * limit
        kwargs = {"name": search} if search else {}

        def _load_projects():
            with _Spinner("Loading projects"):
                return get_projects(limit=limit, offset=offset, **kwargs)

        projects = _run_menu_action(
            _load_projects,
            action_label="list projects",
            fallback=None,
        )
        if projects is None:
            return

        if not projects and page > 1:
            page -= 1
            continue

        prompt = f"Select project (page {page})"
        choices = _build_project_choices(projects, page, search)
        _flush_stdin()
        answer = _select(prompt, choices=choices, q_value=("exit", None))
        if answer is None:
            return

        action, payload = answer
        if action == "project":
            _project_action_menu(payload)
        elif action == "next":
            page += 1
        elif action == "prev":
            page = max(1, page - 1)
        elif action == "search":
            _flush_stdin()
            query = questionary.text(
                "Search project name (partial match):",
                default=search or "",
                style=_QUESTIONARY_STYLE,
            ).ask()
            if query is None:
                continue
            search = query.strip() or None
            page = 1
        elif action == "clear_search":
            search = None
            page = 1
        elif action == "exit":
            return


# ---------------------------------------------------------------------------
# Project action menu
# ---------------------------------------------------------------------------


def _project_action_menu(project) -> None:
    while True:
        _flush_stdin()
        action = _select(
            f"Project: {project.name}",
            choices=[
                questionary.Choice(title="List workflows", value="list"),
                questionary.Choice(title="Configurations", value="configurations"),
                questionary.Choice(title="Prompt templates", value="prompt_templates"),
                questionary.Choice(title="Back to projects", value=_BACK),
            ],
        )
        if action is None or action == _BACK:
            return

        if action == "list":
            _run_menu_action(
                lambda: _list_workflows_in_project(project),
                action_label=f"list workflows for project '{project.name}'",
                fallback=None,
            )
        elif action == "configurations":
            _run_menu_action(
                lambda: browse_configurations(project),
                action_label=f"manage configurations for project '{project.name}",
                fallback=None,
            )
        elif action == "prompt_templates":
            _run_menu_action(
                lambda: browse_prompt_templates(project),
                action_label=f"manage prompt templates for project '{project.name}'",
                fallback=None,
            )


# ---------------------------------------------------------------------------
# Workflow list / picker
# ---------------------------------------------------------------------------


def _list_workflows_in_project(project) -> None:
    workflows = list(
        itertools.islice(awm.get_workflows(project_ids=[project.id], permission="usage"), 100)
    )
    if not workflows:
        click.echo(click.style(f"  No workflows found in {project.name}.", dim=True))
        return
    _show_workflow_picker(workflows, project)


def _build_workflow_choices(
    workflows: list[awm.models.Workflow],
    name_w: int,
    id_w: int,
    status_by_id: dict[str, str],
) -> list[questionary.Choice]:
    status_w = 8
    header = _column_header(
        f"{'Workflow Name'.ljust(name_w)}  {'Workflow ID'.ljust(id_w)}  {'Status'.ljust(status_w)}"
    )
    rows = [
        questionary.Choice(
            title=w.name.ljust(name_w)
            + "  "
            + w.id.ljust(id_w)
            + "  "
            + status_by_id.get(w.id, "UNKNOWN").ljust(status_w),
            value=w,
        )
        for w in workflows
    ]
    return [
        header,
        questionary.Separator(),
        *rows,
        questionary.Separator(),
        questionary.Choice(title="↩ Back", value=_EXIT),
    ]


def _show_workflow_picker(workflows: list[awm.models.Workflow], project) -> None:
    with _Spinner("Loading workflow status"):
        status_by_id = {w.id: _get_workflow_state_label(w) for w in workflows}
    name_w = max((len(w.name) for w in workflows), default=20)
    id_w = max((len(w.id) for w in workflows), default=16)
    choices = _build_workflow_choices(workflows, name_w, id_w, status_by_id)

    while True:
        _flush_stdin()
        answer = _select(
            "Workflows",
            choices=choices,
        )

        # None means Ctrl+C; _EXIT means user selected the exit option
        if answer is None or answer == _EXIT:
            return

        refreshed_workflow = _show_action_menu(answer)
        workflows = [refreshed_workflow if w.id == answer.id else w for w in workflows]

        # Workflow may have changed state (pause/resume/edit), so refresh status.
        with _Spinner("Refreshing workflow status"):
            status_by_id[answer.id] = _get_workflow_state_label(refreshed_workflow)
        name_w = max((len(w.name) for w in workflows), default=20)
        id_w = max((len(w.id) for w in workflows), default=16)
        choices = _build_workflow_choices(workflows, name_w, id_w, status_by_id)


# ---------------------------------------------------------------------------
# Workflow action menu
# ---------------------------------------------------------------------------


def _show_action_menu(workflow: awm.models.Workflow) -> awm.models.Workflow:
    """Show a workflow's actions and return its latest details."""
    while True:
        workflow = _run_menu_action(
            lambda: awm.workflows.get_workflow(workflow.id),
            action_label=f"refresh workflow '{workflow.name}'",
            fallback=workflow,
        )
        status, paused_state = _run_menu_action(
            lambda: _get_workflow_runtime_state(workflow.id),
            action_label=f"get workflow status for workflow '{workflow.name}'",
            fallback=(None, None),
        )
        chat_disabled = (
            _chat_disabled_reason(status)
            if status is not None
            else ("paused" if paused_state is True else None)
        )
        _flush_stdin()
        choices = [
            questionary.Choice(title="View details", value="get"),
            questionary.Choice(title="Scheduled tasks", value="schedules"),
            questionary.Choice(title="Public settings", value="public_settings"),
            questionary.Choice(
                title="Chat",
                value="chat",
                disabled=chat_disabled,
            ),
            questionary.Choice(title="Resume" if paused_state is True else "Pause", value="toggle"),
            questionary.Choice(title="↩ Back", value=_BACK),
        ]
        action = _select(
            workflow.name,
            choices=choices,
        )

        # None = Ctrl+C; _BACK = user selected Back
        if action is None or action == _BACK:
            return workflow

        if action == "get":
            _run_menu_action(
                lambda: _do_get(workflow),
                action_label=f"view workflow details for '{workflow.name}'",
                fallback=None,
            )
        elif action == "schedules":
            _run_menu_action(
                lambda: _manage_schedules(workflow),
                action_label=f"manage schedules for workflow '{workflow.name}'",
                fallback=None,
            )
        elif action == "public_settings":
            _run_menu_action(
                lambda: manage_public_settings(workflow),
                action_label=f"manage public settings for workflow '{workflow.name}'",
                fallback=None,
            )
        elif action == "chat":
            do_chat_from_menu(workflow)
        elif action == "toggle":
            _run_menu_action(
                lambda: _do_toggle(workflow, paused_state),
                action_label=f"toggle paused state for workflow '{workflow.name}'",
                fallback=None,
            )


# ---------------------------------------------------------------------------
# Workflow CRUD actions
# ---------------------------------------------------------------------------


def _do_get(workflow: awm.models.Workflow) -> None:
    resources = awm.workflows.get_workflow_resources(workflow.id)
    _print_workflow_detail(workflow, resources)


def _do_toggle(workflow: awm.models.Workflow, paused_state: bool | None = None) -> None:
    if paused_state is None:
        paused_state = _get_workflow_paused_state(workflow.id)
    if paused_state is None:
        paused_state = False

    target_paused = not paused_state
    action_label = "Pause" if target_paused else "Resume"
    confirmed = questionary.confirm(
        f"{action_label} workflow '{workflow.name}'?",
        style=_QUESTIONARY_STYLE,
    ).ask()
    if not confirmed:
        return
    awm.workflows.patch_workflow_paused(workflow.id, paused=target_paused)
    verb = "Paused" if target_paused else "Resumed"
    click.echo(click.style(f"  {verb} '{workflow.name}'.", fg="green"))


# ---------------------------------------------------------------------------
# Scheduled tasks
# ---------------------------------------------------------------------------


def _list_all_schedules(workflow_id: str, page_limit: int = 100) -> list[awm.models.Schedule]:
    return list(awm.get_schedules(workflow_id=workflow_id, limit=page_limit))


def _schedule_summary(schedule: awm.models.Schedule) -> str:
    name = schedule.name or "(unnamed)"
    status = "ACTIVE" if schedule.active else "PAUSED"
    prompt_preview = (
        schedule.prompt[:36] + "..."
        if schedule.prompt and len(schedule.prompt) > 36
        else (schedule.prompt or "")
    )
    return f"{name}  [{status}]  {schedule.to_agent}  {prompt_preview}"


def _print_schedule_detail(schedule: awm.models.Schedule) -> None:
    label_w = 14
    click.echo()
    click.echo(
        click.style("  Schedule", bold=True)
        + "  "
        + click.style(schedule.name or "(unnamed)", fg="cyan", bold=True)
        + "  "
        + _fmt_id(schedule.id)
    )
    click.echo(click.style("  " + "─" * 60, dim=True))

    def _row(label: str, value: str) -> None:
        click.echo("  " + click.style(label.ljust(label_w), fg="bright_black") + value)

    _row("Workflow ID", schedule.workflow_id)
    _row("Agent", schedule.to_agent)
    _row("Active", "yes" if schedule.active else "no")
    _row("Interval", schedule.schedule)
    _row("Created by", schedule.created_by)
    _row("Created at", schedule.created_at.strftime("%Y-%m-%d %H:%M UTC"))
    expires_text = (
        schedule.expires_at.strftime("%Y-%m-%d %H:%M UTC")
        if schedule.expires_at is not None
        else (schedule.expires_in or "none")
    )
    _row("Expires", expires_text)
    click.echo()
    click.echo("  " + click.style("Prompt", bold=True))
    for line in (schedule.prompt or "").splitlines():
        click.echo(f"    {line}")
    click.echo()


def _to_optional_str(value: object) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _validate_schedule_payload(payload: dict) -> None:
    missing_fields = []
    for key in ("toAgent", "prompt", "schedule"):
        if not _to_optional_str(payload.get(key)):
            missing_fields.append(key)
    if missing_fields:
        raise click.ClickException(f"Required fields missing: {', '.join(missing_fields)}")

    if bool(payload.get("active")) and not (
        _to_optional_str(payload.get("expiresIn")) or _to_optional_str(payload.get("expiresAt"))
    ):
        raise click.ClickException("Active schedules require either `expiresIn` or `expiresAt`.")


def _initial_schedule_payload(workflow: awm.models.Workflow) -> dict:
    to_agent = ""
    try:
        agents = awm.workflows.get_workflow_agents(workflow.id)
        to_agent = agents[0].name if agents else ""
    except Exception:
        to_agent = ""

    return {
        "name": "",
        "toAgent": to_agent,
        "prompt": "",
        "active": True,
        "schedule": "24h",
        "expiresIn": "720h",
        "expiresAt": None,
    }


def _edit_schedule_payload(initial: dict) -> dict | None:
    return _edit_json(initial)


def _create_schedule(workflow: awm.models.Workflow) -> None:
    edited = _edit_schedule_payload(_initial_schedule_payload(workflow))
    if edited is None:
        click.echo(click.style("  Aborted - no schedule created.", dim=True))
        return

    try:
        _validate_schedule_payload(edited)
    except click.ClickException as exc:
        click.echo(click.style(f"  {exc.message}", fg="red"))
        return
    schedule = awm.create_schedule(
        workflow_id=workflow.id,
        name=_to_optional_str(edited.get("name")),
        to_agent=str(edited["toAgent"]),
        prompt=str(edited["prompt"]),
        active=bool(edited.get("active", False)),
        schedule=str(edited["schedule"]),
        expires_in=_to_optional_str(edited.get("expiresIn")),
        expires_at=_to_optional_str(edited.get("expiresAt")),
    )

    click.echo(
        click.style("  Schedule created: ", fg="green")
        + click.style(schedule.name or "(unnamed)", fg="green", bold=True)
        + " "
        + _fmt_id(schedule.id)
    )


def _edit_schedule(schedule: awm.models.Schedule) -> awm.models.Schedule:
    initial = {
        "name": schedule.name,
        "toAgent": schedule.to_agent,
        "prompt": schedule.prompt,
        "active": schedule.active,
        "schedule": schedule.schedule,
        "expiresIn": schedule.expires_in,
        "expiresAt": schedule.expires_at.isoformat() if schedule.expires_at else None,
    }
    edited = _edit_schedule_payload(initial)
    if edited is None:
        click.echo(click.style("  No changes made.", dim=True))
        return schedule

    try:
        _validate_schedule_payload(edited)
    except click.ClickException as exc:
        click.echo(click.style(f"  {exc.message}", fg="red"))
        return schedule
    updated = awm.update_schedule(
        schedule_id=schedule.id,
        name=_to_optional_str(edited.get("name")),
        to_agent=str(edited["toAgent"]),
        prompt=str(edited["prompt"]),
        active=bool(edited.get("active", False)),
        schedule=str(edited["schedule"]),
        expires_in=_to_optional_str(edited.get("expiresIn")),
        expires_at=_to_optional_str(edited.get("expiresAt")),
    )

    click.echo(click.style("  Schedule updated.", fg="green"))
    return updated


def _delete_schedule(schedule: awm.models.Schedule) -> bool:
    confirmed = questionary.confirm(
        f"Delete schedule '{schedule.name or schedule.id}'? This cannot be undone.",
        default=False,
        style=_QUESTIONARY_STYLE,
    ).ask()
    if not confirmed:
        return False

    awm.delete_schedule(schedule.id)

    click.echo(click.style("  Schedule deleted.", fg="green"))
    return True


def _schedule_action_menu(schedule: awm.models.Schedule) -> None:
    selected = schedule
    while True:
        _flush_stdin()
        action = _select(
            selected.name or selected.id,
            choices=[
                questionary.Choice(title="View details", value="view"),
                questionary.Choice(title="Edit", value="edit"),
                questionary.Choice(title="Delete", value="delete"),
                questionary.Choice(title="↩ Back", value=_BACK),
            ],
        )
        if action is None or action == _BACK:
            return
        if action == "view":
            _print_schedule_detail(selected)
            continue
        if action == "edit":
            selected = _run_menu_action(
                lambda: _edit_schedule(selected),
                action_label="update schedule",
                fallback=selected,
            )
            continue
        if action == "delete":
            deleted = _run_menu_action(
                lambda: _delete_schedule(selected),
                action_label="delete schedule",
                fallback=False,
            )
            if deleted:
                return


def _manage_schedules(workflow: awm.models.Workflow) -> None:
    while True:

        def _load_schedules():
            with _Spinner("Loading schedules"):
                return _list_all_schedules(workflow.id)

        schedules = _run_menu_action(
            _load_schedules,
            action_label=f"list schedules for workflow '{workflow.name}'",
            fallback=None,
        )
        if schedules is None:
            return

        choices: list[questionary.Choice] = []
        if schedules:
            for schedule in schedules:
                choices.append(
                    questionary.Choice(title=_schedule_summary(schedule), value=schedule)
                )
            choices.append(questionary.Separator())
        else:
            choices.append(
                questionary.Choice(title="(no schedules found)", value=None, disabled=" ")
            )
            choices.append(questionary.Separator())

        choices.extend(
            [
                questionary.Choice(title="Create scheduled task", value=_NEW),
                questionary.Choice(title="↩ Back", value=_BACK),
            ]
        )

        _flush_stdin()
        selected = _select(
            f"Scheduled tasks ({workflow.name})",
            choices=choices,
        )

        if selected is None or selected == _BACK:
            return
        if selected == _NEW:
            _run_menu_action(
                lambda: _create_schedule(workflow),
                action_label="create schedule",
                fallback=None,
            )
            continue
        if isinstance(selected, awm.models.Schedule):
            _run_menu_action(
                lambda: _schedule_action_menu(selected),
                action_label=f"manage schedule '{selected.name or selected.id}'",
                fallback=None,
            )

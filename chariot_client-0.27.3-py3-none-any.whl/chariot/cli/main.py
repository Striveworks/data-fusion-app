#!/usr/bin/env python
import json
import logging
import os

import click
from pydantic import SecretStr

import chariot.context as ctx
from chariot import __version__
from chariot.client import get_version
from chariot.config import get_bearer_token, settings
from chariot.mcp import ChariotMCPConfig, ChariotMCPPackage


def _build_awm_unavailable_command(import_error: ModuleNotFoundError) -> click.Command:
    @click.command(
        "awm",
        context_settings={"ignore_unknown_options": True, "allow_extra_args": True},
    )
    @click.pass_context
    def _awm_unavailable(_ctx):
        raise click.ClickException(
            f"AWM commands are unavailable in this environment ({import_error})."
        )

    return _awm_unavailable


class _ChariotRootGroup(click.Group):
    def list_commands(self, ctx):
        commands = super().list_commands(ctx)
        if "awm" not in commands:
            commands.append("awm")
        return sorted(commands)

    def get_command(self, ctx, cmd_name):
        if cmd_name == "awm":
            try:
                from chariot.cli.awm import awm_group

                return awm_group
            except ModuleNotFoundError as exc:
                return _build_awm_unavailable_command(exc)
        return super().get_command(ctx, cmd_name)


@click.group(cls=_ChariotRootGroup)
@click.version_option(__version__)
def root():
    """Command-line interface to manage Chariot"""
    pass


@root.command("version")
def version():
    """Display local and remote Chariot versions"""
    get_version()


@root.command("get-contexts")
def get_contexts():
    """Display defined Chariot contexts"""
    envs = ctx.get_contexts(detailed=True)
    if not envs:
        click.echo("You have no contexts.")
        return
    max_len = max(len(e["name"]) for e in envs)
    current_context = ctx.current_context()
    click.echo(
        click.style(
            "  ".join(
                [
                    "  ",
                    "CONTEXT".ljust(max_len),
                    "ROLE".ljust(7),
                    "CLIENT_ID".ljust(36),
                    "BASE_URL",
                ]
            ),
            bold=True,
        )
    )
    for env in sorted(envs, key=lambda x: x["name"]):
        click.echo(
            "  ".join(
                [
                    "* " if env["name"] == current_context else "  ",
                    env["name"].ljust(max_len),
                    env["CLIENT_SCOPE"].ljust(7),
                    env["CLIENT_ID"].ljust(36),
                    env["BASE_URL"],
                ]
            )
        )


def _warn_if_token_env_set() -> None:
    if os.environ.get("TOKEN"):
        click.echo(
            click.style(
                "Warning: TOKEN environment variable is set; "
                "it will override the client secret for authentication.",
                fg="yellow",
            ),
            err=True,
        )


def _make_config(context, config_file=None):
    _warn_if_token_env_set()
    context_env_file, context_secret_file = ctx.get_conf_files_from_context(context)
    if os.path.exists(context_env_file):
        click.confirm(
            f"context '{context}' already exists, do you want to override it?",
            abort=True,
        )

    config = (
        json.loads(open(config_file).read())
        if config_file
        else {
            "client_id": click.prompt("client id"),
            "secret": click.prompt("client secret", hide_input=True),
            "scope": click.prompt("client scope", default=""),
            "url": click.prompt("url", default=settings.base_url),
            "tls_verify": click.prompt("tls_verify", default=settings.verify_ssl),
        }
    )

    ctx.create_context(context, **config, overwrite=True)


@root.command("create-context")
@click.argument("context")
@click.option("--credentials", required=False, help="optional credentials.json file")
def create_context(context, credentials):
    """Create a new Chariot context"""
    _make_config(context, credentials)
    ctx.use_context(context)
    click.echo(f"context '{context}' created and activated.")


@root.command("delete-context")
@click.argument("context")
def delete_context(context):
    """Delete a Chariot context"""
    if (
        click.prompt(f"Are you sure you want to delete context '{context}'? (YES to confirm)")
        != "YES"
    ):
        click.echo(f"Not deleting '{context}' unless you type 'YES'")
        return
    ctx.delete_context(context)
    click.echo(f"context '{context}' deleted.")


@root.command("use-context")
@click.argument("context")
def use_context(context):
    """Set the current-context"""
    _warn_if_token_env_set()
    contexts = ctx.get_contexts()
    if context not in contexts:
        click.echo(
            f"Error: The context '{context}' does not exist. Available contexts are: {contexts}"
        )
        return
    ctx.use_context(context)
    click.echo(f"Switched to context '{context}'")


@root.command("current-context")
def current_context():
    """Display the current-context"""
    context = ctx.current_context()
    click.echo(f"Currently using context {click.style(context, bold=True)}.")


@root.command("show")
@click.argument("field", required=False)
def show_context(field):
    """Display configuration of the current-context"""
    _warn_if_token_env_set()
    as_dict = {}
    for key in dir(settings):
        if key.startswith("_"):
            continue
        value = getattr(settings, key)
        if callable(value):
            continue
        as_dict[key] = value
    strlen = max(len(k) for k in as_dict.keys())

    if field:
        value = as_dict[field]
        if isinstance(value, SecretStr):
            click.echo(value.get_secret_value())
        else:
            click.echo(as_dict[field])
        return

    def _pp(k, v):
        return (
            "\t"
            + click.style(k.ljust(strlen + 1), fg="cyan")
            + click.style(" = ", fg="bright_black")
            + click.style(v)
        )

    excluded_fields = [
        "model_config",
        "model_computed_fields",
        "model_fields",
        "model_extra",
        "model_fields_set",
    ]

    click.echo(
        "\n".join(
            [_pp("current-context", ctx.current_context())]
            + [""]
            + [
                _pp(k, v)
                for k, v in as_dict.items()
                if not k.endswith("url") and k not in excluded_fields
            ]
            + [""]
            + [
                _pp(k, v)
                for k, v in as_dict.items()
                if k.endswith("url") and k not in excluded_fields
            ]
        )
    )


@root.command("set")
@click.argument("key")
@click.argument("value")
def set(key, value):
    """Temporarily set a key-value configuration in the current context.
    This value does not persist through calls to use-context
    """
    with open(ctx.env_file) as f:
        lines = f.readlines()
    with open(ctx.env_file, "w") as f:
        for line in lines:
            if line.split("=")[0].lower() != key.lower():
                f.write(line)
        f.write(f"{key.upper()}={value}\n")


@root.command("delete")
@click.argument("key")
def delete(key):
    """Delete a configuration value from the current context.
    This may not persist through calls to use-context if the key was not temporarily set
    """
    if not hasattr(settings, key):
        click.echo(
            click.style("Invalid key ", fg="red")
            + click.style(key, bold=True, fg="red")
            + click.style(" not present in configuration", fg="red"),
            err=True,
        )
    with open(ctx.env_file) as f:
        lines = f.readlines()
    with open(ctx.env_file, "w") as f:
        for line in lines:
            if line.split("=")[0].lower() != key.lower():
                f.write(line)


@root.command("reset")
def reset():
    """Unset all temporary configuration"""
    ctx.use_context(ctx.current_context())


@root.command("token")
@click.option("--debug", is_flag=True, default=False, required=False, help="print debug messages")
def token(debug):
    """Return a Chariot bearer token"""
    if debug:
        logging.basicConfig(level=logging.DEBUG)
        click.echo(f"Using client-id: {settings.client_id}")
    click.echo(get_bearer_token())


@root.command("init")
@click.option("--credentials", required=False, help="optional credentials.json file")
def init_config(credentials):
    """Initialize configuration for the chariot client"""
    if not credentials:
        click.echo("Initializing Chariot Config 🚀")
    _make_config("default", credentials)
    ctx.use_context("default")
    if credentials:
        click.echo(f"Successfully loaded credentials from {credentials}")


@root.command("mcp")
@click.option("--config", "config_path", help="Path to a Chariot MCP config file")
@click.option(
    "--transport",
    default="stdio",
    help="Transport of the MCP server",
    type=click.Choice(["stdio", "http", "streamable-http", "sse"]),
)
@click.option("--name", default="Chariot", help="Name of the MCP server")
@click.option(
    "--include-packages",
    multiple=True,
    type=click.Choice([p.value for p in ChariotMCPPackage]),
    help="SDK packages to register as tools (defaults to all)",
)
@click.option(
    "--exclude-packages",
    multiple=True,
    type=click.Choice([p.value for p in ChariotMCPPackage]),
    help="SDK packages to exclude",
)
@click.option(
    "--disable",
    "disabled_tools",
    multiple=True,
    type=click.Choice(["mutating-tools", "file-based-tools"]),
    help="Features to disable (can be used multiple times)",
)
@click.option(
    "--token",
    help="Optional provided token to use for tool authentication (will use default creds otherwise)",
)
@click.option(
    "--soft",
    is_flag=True,
    default=False,
    help="Ensures all tools can only soft fail, meaning any exceptions are caught and the error is returned as a string",
)
@click.option(
    "--dry",
    is_flag=True,
    default=False,
    help="Build the server but don't start it. For debugging",
)
def start_mcp(
    config_path,
    transport,
    name,
    include_packages,
    exclude_packages,
    disabled_tools,
    token,
    soft,
    dry,
):
    # Import here to avoid expensive load for other CLI commands
    from chariot.mcp.run import run

    if config_path:
        config = ChariotMCPConfig.model_validate(json.load(open(config_path)))
    else:
        config = ChariotMCPConfig.model_validate(
            {
                "transport": transport,
                "name": name,
                "sdk": {
                    "include_packages": include_packages or None,
                    "exclude_packages": exclude_packages or None,
                    "disable_mutating_tools": "mutating-tools" in disabled_tools,
                    "disable_file_based_tools": "file-based-tools" in disabled_tools,
                    "soft_failures_enabled": soft,
                },
            }
        )
    run(config, bearer_token=token, dry=dry)


if __name__ == "__main__":
    root()

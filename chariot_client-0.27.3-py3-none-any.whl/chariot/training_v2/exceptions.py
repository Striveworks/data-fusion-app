from chariot_api._openapi.training_v2 import ApiException
from chariot_api._openapi.training_v2.models.field_errors_response import FieldError

__all__ = [
    "BlueprintDoesNotExistError",
    "RunDoesNotExistError",
    "ValidationError",
    "ApiException",
]


class BlueprintDoesNotExistError(Exception):
    def __init__(
        self,
        id: str | None = None,
        name: str | None = None,
        version_ilike: str | None = None,
    ):
        self.id = id
        self.name = name
        self.version_ilike = version_ilike

    def __str__(self) -> str:
        msg = "Blueprint does not exist."
        if self.id:
            msg += f" {self.id=}"

        if self.name:
            msg += f" {self.name=}"

        if self.version_ilike:
            msg += f" {self.version_ilike=}"
        return msg


class RunDoesNotExistError(Exception):
    def __init__(self, run_id: str | None = None):
        self.run_id = run_id

    def __str__(self) -> str:
        return f"Run with ID '{self.run_id}' does not exist."


class ValidationError(Exception):
    def __init__(self, errors: list[FieldError]):
        self.errors = errors

    def __str__(self) -> str:
        return "\n\nValidation failed:\n" + "\n".join(
            [f"  Field: {error.field}, Message: {error.message}" for error in self.errors]
        )

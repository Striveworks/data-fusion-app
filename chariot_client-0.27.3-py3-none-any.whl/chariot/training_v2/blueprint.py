"""Chariot Training Blueprints API."""

from typing import Any

from pydantic import StrictBool, StrictInt, StrictStr

from chariot import _apis
from chariot.config import getLogger
from chariot.training_v2._common import BaseModelWithDatetime
from chariot.training_v2.exceptions import BlueprintDoesNotExistError

__all__ = ["lookup_blueprint_id", "get_blueprint", "Blueprint"]

log = getLogger(__name__)


class EnvVar(BaseModelWithDatetime):
    """Env var in a blueprint"""

    name: StrictStr
    value: StrictStr | None = None


class Blueprint(BaseModelWithDatetime):
    """Blueprint"""

    command: list[StrictStr] | None = None
    config_json_schema: dict[str, Any] | None = None
    container_registry_secret: StrictStr | None = None
    created_at: StrictInt | None = None
    description: StrictStr | None = None
    entrypoint: list[StrictStr] | None = None
    env: list[EnvVar] | None = None
    icon: StrictStr | None = None
    id: StrictStr | None = None
    image: StrictStr | None = None
    name: StrictStr | None = None
    project_id: StrictStr | None = None
    repository: StrictStr | None = None
    summary: StrictStr | None = None
    supported_task_types: list[StrictStr] | None = None
    user_id: StrictStr | None = None
    version: StrictStr | None = None
    mutable: StrictBool | None = None
    supports_multi_gpu: StrictBool | None = None


def get_blueprint(id: str) -> Blueprint:
    """Get a blueprint.

    Parameters
    ----------
    id: str
        ID of the blueprint

    Returns
    -------
    Blueprint : The blueprint

    Raises
    ------
    BlueprintDoesNotExistError
        If the blueprint does not
        exist or has been deleted,
        this will be raised.

    APIException
        If api communication fails, request is
        unauthorized or is unauthenticated.


    """
    blueprint = _apis.training_v2.v2_blueprints_api.v2_blueprints_id_get(
        id=id,
    ).data
    return Blueprint.model_validate(blueprint.model_dump(exclude_none=True))


def lookup_blueprint_id(
    name: str,
    version_ilike: str | None = None,
) -> str:
    """Returns the id of the blueprint specified by the arguments

    Parameters
    ----------
    name : str
        name of the blueprint. if `version_ilike` is
        not provided, then the latest version of the blueprint
        with this name will be used.
    version_ilike : str
        this parameter accepts a SQL ILIKE pattern for matching
        a blueprint version. If multiple blueprints match
        the given version, the most recent one will be used.

    Returns
    -------
    str : id of the blueprint

    Raises
    ------
    BlueprintDoesNotExistError
        If the blueprint does not
        exist or has been deleted,
        this will be raised.

    ValueError
        If `name` is not provided.

    APIException
        If api communication fails, request is
        unauthorized or is unauthenticated.

    """
    if not name:
        raise ValueError("Missing name argument.")

    if not version_ilike:
        blueprints = _apis.training_v2.v2_blueprints_api.v2_blueprints_get(
            name=[name],
            sort=["created_at:desc"],
            select=["id"],
        ).data
    else:
        blueprints = _apis.training_v2.v2_blueprints_api.v2_blueprints_get(
            name=[name],
            version_ilike=[version_ilike],
            select=["id"],
            sort=["created_at:desc"],
        ).data

    if len(blueprints) == 0:
        raise BlueprintDoesNotExistError(
            name=name,
            version_ilike=version_ilike,
        )
    log.debug(
        f"Found {len(blueprints)} blueprints named='{name}' "
        f"version_ilike='{version_ilike}' returning blueprint={{{blueprints[0]}}}"
    )
    return blueprints[0].id

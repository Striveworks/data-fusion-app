from collections.abc import Callable
from datetime import datetime
from typing import Any, Self
import typing
import types

from chariot import mcp_setting
from pydantic import BaseModel, field_validator, model_serializer, SerializationInfo

_MILLISECONDS_PER_SECOND = 1000.0


@mcp_setting(ignore=True)
def _validate_datetime(json_value: object) -> datetime | None:
    if json_value is None:
        return None
    # This should never get hit during __init__ after calling the API,
    # but could get hit during assignment by a user in the SDK,
    # if they assign using a datetime instead of an epoch
    if isinstance(json_value, datetime):
        return json_value
    try:
        return datetime.fromtimestamp(int(json_value) / _MILLISECONDS_PER_SECOND)
    except ValueError:
        return None


def _get_epoch_validator(field_name: str) -> field_validator:
    return field_validator(field_name)(_validate_datetime)


def _datetime_to_epoch(dt: datetime) -> int:
    return int(dt.timestamp() * _MILLISECONDS_PER_SECOND)


def _has_datetime_annotation(annotation):
    """Check if annotation contains datetime.datetime type"""
    if annotation == datetime:
        return True

    origin = typing.get_origin(annotation)
    if origin is types.UnionType or origin is typing.Union:
        return datetime in typing.get_args(annotation)

    return False


# In order to parse datetimes correctly during an assignment
# (instead of during __init__), must pass validate_assignment=True
class BaseModelWithDatetime(BaseModel, validate_assignment=True):
    @model_serializer(mode="wrap")
    def ser_model(self, original_serializer: Callable[[Self], dict[str, Any]]) -> dict[str, Any]:
        datetime_fields = [
            field
            for field, info in self.model_fields.items()
            if _has_datetime_annotation(info.annotation)
        ]

        result = original_serializer(self)
        for field in datetime_fields:
            value = getattr(self, field)
            if isinstance(value, datetime):
                result[field] = _datetime_to_epoch(value)

        return result

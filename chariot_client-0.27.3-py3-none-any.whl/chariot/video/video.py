"""Chariot Video API."""

import datetime
import json
import os
import time
from pathlib import Path
from typing import Any

import urllib3

from chariot import _apis
from chariot.config import getLogger
from chariot.models._utils import _upload_parts
from chariot_api._openapi.video.models import (
    InputCompleteUploadRequest,
    InputCreateDownloadRequestRequest,
    InputCreateExtractionRequestRequest,
    InputCreateTrackerRequestRequest,
    InputCreateUploadRequest,
    InputCreateVideoRequest,
    InputCreateVideoRequestRequest,
    ModelTimeRange,
    OutputDeleteTrackerRequestResponse,
    OutputExtractionRequestIDResponse,
    OutputGetDownloadRequestResponse,
    OutputGetExtractionRequestResponse,
    OutputGetVideoRequestResponse,
    OutputGetVideoResponse,
    OutputTrackerRequestResponse,
    OutputVideoIDResponse,
    OutputVideoRequestIDResponse,
)

__all__ = [
    "get_video",
    "get_videos",
    "delete_video",
    "upload_video",
    "wait_for_stream_connection",
    "stream_video",
    "process_video",
    "create_video_request",
    "get_video_request",
    "get_video_requests",
    "wait_for_video_request",
    "delete_video_request",
    "create_tracker_request",
    "get_tracker_request",
    "wait_for_tracker_request",
    "delete_tracker_request",
    "get_video_asset",
    "create_extraction_request",
    "get_extraction_request",
    "wait_for_extraction_request",
    "delete_extraction_request",
    "create_download_request",
    "get_download_request",
    "wait_for_download_request",
    "get_presigned_download_request_url",
    "get_presigned_extraction_request_url",
]

# defined in go/apps/video/internal/app/upload.go
PART_SIZE = 100 * 1024 * 1024

log = getLogger(__name__)


def _video_upload_mime_type(video_file: str) -> str:
    # Integration fixtures use a trailing underscore (e.g. mini_truck.mp4_).
    lower_name = Path(video_file).name.lower().rstrip("_")
    if lower_name.endswith(".mp4"):
        return "video/mp4"
    if lower_name.endswith(".ts"):
        return "video/mp2t"
    raise ValueError(f"Unsupported video format: {video_file}")


def get_video(video_id: str) -> OutputGetVideoResponse | None:
    """Get a video."""
    response = _apis.video.videos_api.api_videos_v1_videos_video_id_get(video_id=video_id)
    if response.error:
        raise Exception("unable to get video")
    return response.data


def get_videos(
    *, project_id: str, to_dict: bool = False, **kwargs
) -> list[dict[str, Any]] | list[OutputGetVideoResponse]:
    """Get videos returns all videos within a project."""
    response = _apis.video.videos_api.api_videos_v1_videos_get(project_id=project_id, **kwargs)
    if response.error:
        raise Exception("unable to get videos")
    data = response.data
    if not data:
        return []
    return [v.to_dict() for v in data] if to_dict else data


def delete_video(video_id: str) -> OutputVideoIDResponse | None:
    """Delete a video."""
    response = _apis.video.videos_api.api_videos_v1_videos_video_id_delete(video_id=video_id)
    if response.error:
        raise Exception("unable to delete video")
    return response.data


def upload_video(
    *, project_id: str, name: str, description: str, video_file: str | Path, **kwargs
) -> OutputGetVideoResponse | None:
    """Upload a local video."""
    if project_id == "":
        raise ValueError("unable to create static video, project id is empty")
    if name == "":
        raise ValueError("unable to create static video, name is empty")
    if description == "":
        raise ValueError("unable to create static video, description is empty")
    if isinstance(video_file, Path):
        video_file = str(video_file)
    if video_file == "":
        raise ValueError("unable to create static video, video file is empty")
    body = {
        "project_id": project_id,
        "name": name,
        "description": description,
        "video_file": video_file,
        "video_type": "upload",
        **kwargs,
    }

    request_body = InputCreateVideoRequest.from_dict(body)
    if request_body is None:
        raise Exception("unable to create static video, request body is invalid")

    response = _apis.video.videos_api.api_videos_v1_videos_post(video=request_body)
    if response.data is None or response.data.id is None:
        raise Exception("unable to create static video, empty response")

    video_id = response.data.id
    mime_type = _video_upload_mime_type(video_file)
    upload = _apis.video.uploads_api.api_videos_v1_videos_video_id_uploads_post(
        video_id=video_id,
        upload=InputCreateUploadRequest(
            size=os.path.getsize(video_file),
            mime_type=mime_type,
        ),
    )
    upload_id = upload.upload_id
    if upload_id is None:
        raise Exception("unable to create static video, empty upload id")
    upload_urls = upload.urls
    if upload_urls is None:
        raise Exception("unable to create static video, empty upload urls")

    log.debug(
        f"created upload {upload_id} for video {video_id} with {len(upload_urls)} parts and part_size={PART_SIZE}"
    )

    signed_urls: list[str] = [u.url for u in upload_urls if u.url is not None]
    if signed_urls is None:
        raise Exception("unable to create static video, empty signed upload urls")
    etags = _upload_parts(video_file, signed_urls, PART_SIZE)
    log.debug(f"upload contained the following etags: {etags}")

    _apis.video.uploads_api.api_videos_v1_uploads_upload_id_complete_post(
        upload_id=upload_id,
        request=InputCompleteUploadRequest(
            video_id=video_id,
            mime_type=mime_type,
            parts=[{"etag": etag, "part_number": idx + 1} for idx, etag in enumerate(etags)],
        ),
    )

    return _apis.video.videos_api.api_videos_v1_videos_video_id_get(video_id=video_id).data


def wait_for_stream_connection(
    address: str, max_attempts: int = 6, wait_interval: int = 10
) -> bool:
    """Wait for a stream to be available."""
    for attempt in range(max_attempts):
        connection_response = (
            _apis.video.h_l_s_api.api_videos_v1_hls_check_get_without_preload_content(address)
        )
        if connection_response.status == 200:
            log.info(f"stream found {address} to be connectable")
            return True
        log.debug(
            f"unable to connect to stream at {address}, attempt ({attempt + 1}/{max_attempts})"
        )
        time.sleep(wait_interval)
    return False


def stream_video(
    *, project_id: str, name: str, description: str, url: str, **kwargs
) -> OutputGetVideoResponse | None:
    """Create a streaming video."""
    if project_id == "":
        raise ValueError("unable to create streaming video, project id is empty")
    if name == "":
        raise ValueError("unable to create streaming video, name is empty")
    if description == "":
        raise ValueError("unable to create streaming video, description is empty")
    if url == "":
        raise ValueError("unable to create streaming video, url is empty")
    body = {
        "project_id": project_id,
        "name": name,
        "description": description,
        "url": url,
        "video_type": "stream",
        **kwargs,
    }

    request_body = InputCreateVideoRequest.from_dict(body)
    if request_body is None:
        raise Exception("unable to create streaming video, request body is invalid")

    response = _apis.video.videos_api.api_videos_v1_videos_post(video=request_body)
    if response.data is None or response.data.id is None:
        raise Exception("unable to create streaming video, empty response")

    video_id = str(response.data.id)
    return _apis.video.videos_api.api_videos_v1_videos_video_id_get(video_id=video_id).data


def create_video_request(video_id: str, **kwargs) -> OutputGetVideoRequestResponse | None:
    """Create a video request."""
    body = {"video_id": video_id, **kwargs}
    request_body = InputCreateVideoRequestRequest.from_dict(body)
    if request_body is None:
        raise Exception("unable to process video, request body is invalid")
    response = _apis.video.video_requests_api.api_videos_v1_video_requests_post(
        request_body=request_body,
    )
    if response.data is None or response.data.id is None:
        raise Exception("unable to process video, empty response")
    video_request_id = response.data.id
    return get_video_request(video_request_id)


# Function alias to support backward compatibility
process_video = create_video_request


def get_video_requests(
    *, project_id: str, video_id: str
) -> list[OutputGetVideoRequestResponse] | None:
    """Get video requests within a project or associated to a video."""
    if (not project_id or project_id == "") and (not video_id or video_id == ""):
        raise ValueError("unable to get video requests, project id or video id must be provided")
    if not project_id or project_id == "":
        project_id = _apis.video.videos_api.api_videos_v1_videos_video_id_get(
            video_id
        ).data.project_id
    response = _apis.video.video_requests_api.api_videos_v1_video_requests_get(
        project_id=project_id, video_id=video_id
    )
    return response.data


def get_video_request(video_request_id: str) -> OutputGetVideoRequestResponse | None:
    """Get a video request by id."""
    if video_request_id == "":
        raise ValueError("unable to get video request, video request id is empty")
    response = _apis.video.video_requests_api.api_videos_v1_video_requests_video_request_id_get(
        video_request_id=video_request_id
    )
    return response.data


def delete_video_request(video_request_id: str) -> OutputVideoRequestIDResponse | None:
    """Delete a video request by id."""
    if video_request_id == "":
        raise ValueError("unable to get video request, video request id is empty")
    response = _apis.video.video_requests_api.api_videos_v1_video_requests_video_request_id_delete(
        video_request_id=video_request_id
    )
    return response.data


def create_tracker_request(video_request_id: str, **kwargs) -> OutputTrackerRequestResponse | None:
    """Create a tracker request."""
    body = {"video_request_id": video_request_id, **kwargs}
    request_body = InputCreateTrackerRequestRequest.from_dict(body)
    if request_body is None:
        raise Exception("unable to create tracker request, request body is invalid")
    response = _apis.video.tracker_requests_api.api_videos_v1_tracker_request_post(
        request_body=request_body
    )
    return response.data


def get_tracker_request(tracker_request_id: str) -> OutputTrackerRequestResponse | None:
    """Get a tracker request."""
    if tracker_request_id == "":
        raise ValueError("unable to get tracker request, tracker request id is empty")
    response = (
        _apis.video.tracker_requests_api.api_videos_v1_tracker_requests_tracker_request_id_get(
            tracker_request_id=tracker_request_id
        )
    )
    return response.data


def delete_tracker_request(tracker_request_id: str) -> OutputDeleteTrackerRequestResponse | None:
    """Delete a tracker request."""
    if tracker_request_id == "":
        raise ValueError("unable to delete tracker request, tracker request id is empty")
    response = (
        _apis.video.tracker_requests_api.api_videos_v1_tracker_request_tracker_request_id_delete(
            tracker_request_id=tracker_request_id
        )
    )
    return response.data


def get_video_asset(key: str) -> urllib3.HTTPResponse:
    """Get a video asset."""
    return _apis.video.h_l_s_api.api_videos_v1_hls_key_get_without_preload_content(key)


def create_extraction_request(
    video_request_id: str,
    dataset_id: str,
    frames_per_second: float,
    use_source_frames_per_second: bool,
    time_ranges: list[ModelTimeRange],
    include_klv: bool,
    **kwargs,
) -> OutputExtractionRequestIDResponse | None:
    """Create an extraction request."""
    body = {
        "video_request_id": video_request_id,
        "dataset_id": dataset_id,
        "frames_per_second": frames_per_second,
        "use_source_frames_per_second": use_source_frames_per_second,
        "time_ranges": time_ranges,
        "include_klv": include_klv,
        **kwargs,
    }
    request_body = InputCreateExtractionRequestRequest.from_dict(body)
    if request_body is None:
        raise Exception("unable to create extraction request, request body is invalid")
    response = _apis.video.extraction_requests_api.api_videos_v1_extraction_requests_post(
        request_body=request_body
    )
    return response.data


def get_extraction_request(extraction_request_id: str) -> OutputGetExtractionRequestResponse | None:
    """Get an extraction request."""
    if extraction_request_id == "":
        raise ValueError("unable to get extraction request, extraction request id is empty")
    response = _apis.video.extraction_requests_api.api_videos_v1_extraction_requests_extraction_request_id_get(
        extraction_request_id=extraction_request_id
    )
    return response.data


def delete_extraction_request(
    extraction_request_id: str,
) -> OutputExtractionRequestIDResponse | None:
    """Delete an extraction request."""
    if extraction_request_id == "":
        raise ValueError("unable to delete extraction request, extraction request id is empty")
    response = _apis.video.extraction_requests_api.api_videos_v1_extraction_requests_extraction_request_id_delete(
        extraction_request_id=extraction_request_id
    )
    return response.data


def create_download_request(video_request_id: str, **kwargs):
    """Create a download request."""
    body = {"video_request_id": video_request_id, **kwargs}
    request_body = InputCreateDownloadRequestRequest.from_dict(body)
    if request_body is None:
        raise Exception("unable to create download request, request body is invalid")
    response = _apis.video.download_requests_api.api_videos_v1_download_requests_post(
        request_body=request_body
    )
    return response.data


def get_download_request(download_request_id: str):
    """Get a download request."""
    if download_request_id == "":
        raise ValueError("unable to get download request, download request id is empty")
    response = (
        _apis.video.download_requests_api.api_videos_v1_download_requests_download_request_id_get(
            download_request_id=download_request_id
        )
    )
    return response.data


def _parse_presigned_http_request(body):
    return json.loads(body.dict()["raw_data"])["data"]["URL"]


def get_presigned_download_request_url(download_request_id: str) -> str | None:
    """Presign a download request."""
    if download_request_id == "":
        raise ValueError("unable to presign download request, download request id is empty")
    response = _apis.video.download_requests_api.api_videos_v1_download_requests_download_request_id_presign_get_with_http_info(
        download_request_id=download_request_id
    )
    if response.status_code == 200:
        return _parse_presigned_http_request(response)
    raise Exception(
        f"unable to presign download request, invalid status code ({response.status_code})"
    )


def get_presigned_extraction_request_url(extraction_request_id: str) -> str | None:
    """Presign an extraction request."""
    if extraction_request_id == "":
        raise ValueError("unable to presign extraction request, extraction request id is empty")
    response = _apis.video.extraction_requests_api.api_videos_v1_extraction_requests_extraction_request_id_presign_get_with_http_info(
        extraction_request_id=extraction_request_id
    )
    if response.status_code == 200:
        return _parse_presigned_http_request(response)
    raise Exception(
        f"unable to presign extraction request, invalid status code ({response.status_code})"
    )


def _get_request(
    request_id: str, request_type: str
) -> (
    OutputGetVideoRequestResponse
    | OutputTrackerRequestResponse
    | OutputGetExtractionRequestResponse
    | OutputGetDownloadRequestResponse
    | None
):
    match request_type:
        case "process":
            request = get_video_request(video_request_id=request_id)
        case "tracker":
            request = get_tracker_request(tracker_request_id=request_id)
        case "extract":
            request = get_extraction_request(extraction_request_id=request_id)
        case "download":
            request = get_download_request(download_request_id=request_id)
        case _:
            raise Exception(f"unable to wait for request, invalid request type ({request_type})")
    return request


def _wait_for_request(
    *,
    request_id: str,
    request_type: str,
    wait_interval: int = 5,
    timeout: int = 60,
    statuses: list[str] = ["success"],
) -> (
    OutputGetVideoRequestResponse
    | OutputTrackerRequestResponse
    | OutputGetExtractionRequestResponse
    | OutputGetDownloadRequestResponse
    | None
):
    """Periodically check if a request has achieved one of statuses provided."""
    if request_id == "":
        raise ValueError(f"unable to wait for {request_type} request, request id is empty")
    if len(statuses) <= 0:
        raise Exception(f"unable to wait for {request_type} request, no statuses provided")
    start = datetime.datetime.now()
    try:
        request = _get_request(request_id=request_id, request_type=request_type)
        if request is None:
            raise Exception(
                f"unable to wait for {request_type} request, unable to get {request_type} request"
            )
    except Exception as e:
        raise e
    while request.status not in statuses:
        if (datetime.datetime.now() - start).total_seconds() > timeout:
            raise TimeoutError(
                f"{request_type} request {request_id!r} did not achieve one of the provided statuses within {timeout} seconds"
            )
        time.sleep(wait_interval)
        try:
            request = _get_request(request_id=request_id, request_type=request_type)
            if request is None:
                raise Exception(
                    f"unable to wait for {request_type} request, unable to get {request_type} request"
                )
        except Exception as e:
            raise e
    return request


def wait_for_video_request(
    *,
    video_request_id: str,
    wait_interval: int = 5,
    timeout: int = 60,
    statuses: list[str] = ["success"],
):
    """Periodically check if a video request has achieved one of statuses provided."""
    return _wait_for_request(
        request_id=video_request_id,
        request_type="process",
        wait_interval=wait_interval,
        timeout=timeout,
        statuses=statuses,
    )


def wait_for_tracker_request(
    tracker_request_id: str,
    wait_interval: int = 5,
    timeout: int = 60,
    statuses: list[str] = ["success"],
):
    """Periodically check if a tracker request has achieved one of statuses provided."""
    return _wait_for_request(
        request_id=tracker_request_id,
        request_type="tracker",
        wait_interval=wait_interval,
        timeout=timeout,
        statuses=statuses,
    )


def wait_for_extraction_request(
    extraction_request_id: str,
    wait_interval: int = 5,
    timeout: int = 60,
    statuses: list[str] = ["success"],
):
    """Periodically check if an extraction request has achieved one of statuses provided."""
    return _wait_for_request(
        request_id=extraction_request_id,
        request_type="extract",
        wait_interval=wait_interval,
        timeout=timeout,
        statuses=statuses,
    )


def wait_for_download_request(
    download_request_id: str,
    wait_interval: int = 5,
    timeout: int = 60,
    statuses: list[str] = ["success"],
):
    """Periodically check if a download request has achieved one of statuses provided."""
    return _wait_for_request(
        request_id=download_request_id,
        request_type="download",
        wait_interval=wait_interval,
        timeout=timeout,
        statuses=statuses,
    )

"""The Chariot API interface.

This interface file exists to list the APIs made available through runtime magic
at `chariot._apis`.  If you add a new swagger API or sub-API, please update this
file so that LSP, type checking, and static analysis works.
"""

from collections.abc import Callable
from typing import ParamSpec, TypeVar

from chariot_api import Settings
from chariot_api._openapi.awm import api as awm_api
from chariot_api._proto.datasets_v3.annotations_httpcalls_gen import AnnotationsApiAdapter
from chariot_api._proto.datasets_v3.datasets_httpcalls_gen import DatasetsApiAdapter
from chariot_api._proto.datasets_v3.datums_httpcalls_gen import DatumsApiAdapter
from chariot_api._proto.datasets_v3.files_httpcalls_gen import FilesApiAdapter
from chariot_api._proto.datasets_v3.jobs_httpcalls_gen import JobsApiAdapter
from chariot_api._proto.datasets_v3.snapshots_httpcalls_gen import SnapshotsApiAdapter
from chariot_api._proto.datasets_v3.tasks_httpcalls_gen import TasksApiAdapter
from chariot_api._proto.datasets_v3.uploads_httpcalls_gen import UploadsApiAdapter
from chariot_api._proto.datasets_v3.views_httpcalls_gen import ViewsApiAdapter
from chariot_api._proto.datasets_v3.videos_httpcalls_gen import VideosApiAdapter
from chariot_api._openapi.evaluation import api as evaluation_api
from chariot_api._openapi.identity import api as identity_api
from chariot_api._openapi.inferencestore import api as inferencestore_api
from chariot_api._openapi.model_drift import api as model_drift_api
from chariot_api._openapi.modelexport import api as modelexport_api
from chariot_api._openapi.models import api as models_api
from chariot_api._openapi.representer import api as representer_api
from chariot_api._openapi.resources import api as resources_api
from chariot_api._openapi.trackproducer import api as trackproducer_api
from chariot_api._openapi.training_v2 import api as training_v2_api
from chariot_api._openapi.video import api as video_api
from chariot_api._openapi.watchbox import api as watchbox_api

_P = ParamSpec("_P")
_RT = TypeVar("_RT")

def build_apis(settings: Settings) -> None: ...
def get_version(settings: Settings) -> str: ...
def login_required(func: Callable[_P, _RT]) -> Callable[_P, _RT]: ...
def set_bearer_token(token: str) -> None: ...

class DatasetsV3API:
    annotations_api: AnnotationsApiAdapter
    datasets_api: DatasetsApiAdapter
    datums_api: DatumsApiAdapter
    files_api: FilesApiAdapter
    jobs_api: JobsApiAdapter
    snapshots_api: SnapshotsApiAdapter
    tasks_api: TasksApiAdapter
    uploads_api: UploadsApiAdapter
    views_api: ViewsApiAdapter
    videos_api: VideosApiAdapter

class EvaluationAPI:
    evaluation_api: evaluation_api.EvaluationApi
    v2_api: evaluation_api.V2Api

class IdentityAPI:
    authz_api: identity_api.AuthzApi
    clients_api: identity_api.ClientsApi
    default_api: identity_api.DefaultApi
    entity_types_api: identity_api.EntityTypesApi
    namespaces_api: identity_api.NamespacesApi
    organizations_api: identity_api.OrganizationsApi
    permissions_api: identity_api.PermissionsApi
    projects_api: identity_api.ProjectsApi
    roles_api: identity_api.RolesApi
    roles_permissions_api: identity_api.RolesPermissionsApi
    settings_api: identity_api.SettingsApi
    tags_api: identity_api.TagsApi
    users_api: identity_api.UsersApi

class InferencestoreAPI:
    export_api: inferencestore_api.ExportApi
    export_task_api: inferencestore_api.ExportTaskApi
    inference_api: inferencestore_api.InferenceApi
    metadata_api: inferencestore_api.MetadataApi
    register_api: inferencestore_api.RegisterApi
    raw_api: inferencestore_api.RawApi
    resource_usage_api: inferencestore_api.ResourceUsageApi
    retention_policy_api: inferencestore_api.RetentionPolicyApi
    retention_task_api: inferencestore_api.RetentionTaskApi
    track_api: inferencestore_api.TrackApi
    tracker_api: inferencestore_api.TrackerApi
    upload_api: inferencestore_api.UploadApi

class ModelDriftAPI:
    check_api: model_drift_api.CheckApi
    drift_api: model_drift_api.DriftApi
    health_api: model_drift_api.HealthApi
    monitor_api: model_drift_api.MonitorApi

class ModelexportAPI:
    default_api: modelexport_api.DefaultApi
    health_api: modelexport_api.HealthApi

class ModelsAPI:
    blueprints_api: models_api.BlueprintsApi
    bulk_inference_api: models_api.BulkInferenceApi
    drift_api: models_api.DriftApi
    enums_api: models_api.EnumsApi
    evaluation_api: models_api.EvaluationApi
    export_api: models_api.ExportApi
    import_api: models_api.ImportApi
    inference_api: models_api.InferenceApi
    inference_engine_api: models_api.InferenceEngineApi
    inference_server_settings_api: models_api.InferenceServerSettingsApi
    licenses_api: models_api.LicensesApi
    models_api: models_api.ModelsApi
    tracker_api: models_api.TrackerApi

class RepresenterAPI:
    detector_api: representer_api.DetectorApi
    embedding_api: representer_api.EmbeddingApi
    health_api: representer_api.HealthApi
    internal_api: representer_api.InternalApi
    registry_api: representer_api.RegistryApi
    validation_api: representer_api.ValidationApi

class ResourcesAPI:
    capacities_api: resources_api.CapacitiesApi
    gpus_api: resources_api.GpusApi
    nodes_api: resources_api.NodesApi
    pod_statuses_api: resources_api.PodStatusesApi
    pods_api: resources_api.PodsApi
    suggestions_api: resources_api.SuggestionsApi
    validations_api: resources_api.ValidationsApi
    versions_api: resources_api.VersionsApi

class TrackproducerAPI:
    tracker_api: trackproducer_api.TrackerApi

class TrainingV2API:
    v2_blueprints_api: training_v2_api.V2BlueprintsApi
    v2_checkpoints_api: training_v2_api.V2CheckpointsApi
    v2_metrics_api: training_v2_api.V2MetricsApi
    v2_runs_api: training_v2_api.V2RunsApi

class VideoAPI:
    download_requests_api: video_api.DownloadRequestsApi
    extraction_requests_api: video_api.ExtractionRequestsApi
    h_l_s_api: video_api.HLSApi
    system_api: video_api.SystemApi
    tracker_requests_api: video_api.TrackerRequestsApi
    uploads_api: video_api.UploadsApi
    video_requests_api: video_api.VideoRequestsApi
    videos_api: video_api.VideosApi

class WatchboxAPI:
    chariot_requests_api: watchbox_api.ChariotRequestsApi
    chipped_images_api: watchbox_api.ChippedImagesApi
    e_l_i_n_t_api: watchbox_api.ELINTApi
    entity_api: watchbox_api.EntityApi
    feature_flags_api: watchbox_api.FeatureFlagsApi
    groups_api: watchbox_api.GroupsApi
    health_api: watchbox_api.HealthApi
    high_priority_targets_api: watchbox_api.HighPriorityTargetsApi
    i_spy_requests_api: watchbox_api.ISpyRequestsApi
    imagery_providers_api: watchbox_api.ImageryProvidersApi
    imagery_requests_api: watchbox_api.ImageryRequestsApi
    lattice_api: watchbox_api.LatticeApi
    o_g_c_proxy_api: watchbox_api.OGCProxyApi
    saber_version_api: watchbox_api.SaberVersionApi
    target_workbench_api: watchbox_api.TargetWorkbenchApi
    tip_and_cue_api: watchbox_api.TipAndCueApi
    triage_events_api: watchbox_api.TriageEventsApi
    watchboxes_api: watchbox_api.WatchboxesApi

class AgenticWorkflowManagerAPI:
    activity_api: awm_api.ActivityApi
    artifact_api: awm_api.ArtifactApi
    configuration_api: awm_api.ConfigurationApi
    evaluator_api: awm_api.EvaluatorApi
    feedback_api: awm_api.FeedbackApi
    prompt_templates_api: awm_api.PromptTemplatesApi
    feedback_api: awm_api.FeedbackApi
    m_c_p_api: awm_api.MCPApi
    schedules_api: awm_api.SchedulesApi
    sessions_api: awm_api.SessionsApi
    work_api: awm_api.WorkApi
    workflows_api: awm_api.WorkflowsApi

datasets_v3: DatasetsV3API
evaluation: EvaluationAPI
identity: IdentityAPI
inferencestore: InferencestoreAPI
model_drift: ModelDriftAPI
modelexport: ModelexportAPI
models: ModelsAPI
representer: RepresenterAPI
resources: ResourcesAPI
trackproducer: TrackproducerAPI
training_v2: TrainingV2API
video: VideoAPI
watchbox: WatchboxAPI
awm: AgenticWorkflowManagerAPI

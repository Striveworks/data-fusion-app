import functools
import os
import sys
import warnings

import chariot_api
import chariot_api._auth
import chariot_api.builder
import platform

##
## NOTE: if you edit this file, please make corresponding changes to `__init__.pyi`
##

_connection_message = "please create a connection by calling: chariot.client.connect()"


class Wrapped:
    def __init__(self, mod):
        self._mod = mod

    def __getattr__(self, name):
        if not hasattr(self._mod, name) and not hasattr(self._mod, "identity"):
            raise RuntimeError(_connection_message)
        return getattr(self._mod, name)


_module = sys.modules[__name__]
sys.modules[__name__] = Wrapped(_module)


def apis():
    return chariot_api.apis


def get_version(settings):
    return chariot_api._auth.get_version(settings)


def _build_apis(settings):
    chariot_api.builder.build_apis(settings)
    for api in chariot_api.apis:
        setattr(_module, api, getattr(chariot_api, api))


def build_apis(settings):
    # NOTE(s.maddox): On subprocess fork, rebuild the clients with the same settings.
    #                 This is necessary because the clients are not fork-safe.
    if hasattr(os, "register_at_fork"):
        os.register_at_fork(after_in_child=lambda: _build_apis(settings))
    elif platform.system() != "Windows":
        # NOTE(s.maddox): On Windows, this should not be an issue, since
        # sockets are not shared when "forking"/calling CreateProcess
        warnings.warning("register_at_fork is not available. forking API clients may cause issues")
    # NOTE(s.maddox): Build the clients for the first time.
    _build_apis(settings)


def set_bearer_token(token):
    chariot_api._auth.set_bearer_token(token)


def login_required(func):
    """Decorator to check if user is logged in."""

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        if hasattr(_module, "identity"):
            return func(*args, **kwargs)
        if not hasattr(chariot_api, "identity"):
            raise RuntimeError(_connection_message)

    return wrapper


def _logout():
    if hasattr(_module, "identity"):
        for api in chariot_api.apis:
            delattr(_module, api)

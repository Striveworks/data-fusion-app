import os
from pydantic import SecretStr
import chariot_api.builder as builder
from chariot_api._settings import Settings
from chariot_api._auth import set_bearer_token


def connect(host="", **kwargs) -> Settings:
    settings = Settings() 
    base_url = host or getattr(settings, 'base_url')
    if not base_url and 'CHARIOT_DOMAIN' in os.environ:
        base_url = f"https://{os.environ['CHARIOT_DOMAIN']}"
    setattr(settings, 'base_url', base_url)
    for k, v in kwargs.items():
        if k == "client_secret":
            setattr(settings, k, SecretStr(v))
        else:
            setattr(settings, k, v)
    bearer_token = settings.bearer_token or os.environ.get('access_token')
    if bearer_token:
        set_bearer_token(bearer_token)
    builder.build_apis(settings)
    settings.bearer_token = builder.get_bearer_token(settings)
    return settings

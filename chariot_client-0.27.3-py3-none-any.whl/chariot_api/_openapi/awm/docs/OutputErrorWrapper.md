# OutputErrorWrapper


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_error_wrapper import OutputErrorWrapper

# TODO update the JSON string below
json = "{}"
# create an instance of OutputErrorWrapper from a JSON string
output_error_wrapper_instance = OutputErrorWrapper.from_json(json)
# print the JSON string representation of the object
print(OutputErrorWrapper.to_json())

# convert the object into a dict
output_error_wrapper_dict = output_error_wrapper_instance.to_dict()
# create an instance of OutputErrorWrapper from a dict
output_error_wrapper_from_dict = OutputErrorWrapper.from_dict(output_error_wrapper_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# ModelToolApprovalPolicy


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**when** | [**ModelWhen**](ModelWhen.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_tool_approval_policy import ModelToolApprovalPolicy

# TODO update the JSON string below
json = "{}"
# create an instance of ModelToolApprovalPolicy from a JSON string
model_tool_approval_policy_instance = ModelToolApprovalPolicy.from_json(json)
# print the JSON string representation of the object
print(ModelToolApprovalPolicy.to_json())

# convert the object into a dict
model_tool_approval_policy_dict = model_tool_approval_policy_instance.to_dict()
# create an instance of ModelToolApprovalPolicy from a dict
model_tool_approval_policy_from_dict = ModelToolApprovalPolicy.from_dict(model_tool_approval_policy_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



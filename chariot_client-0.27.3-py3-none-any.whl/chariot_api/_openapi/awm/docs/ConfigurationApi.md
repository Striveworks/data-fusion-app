# chariot_api._openapi.awm.ConfigurationApi

All URIs are relative to */api/awm/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create_agent_configuration**](ConfigurationApi.md#create_agent_configuration) | **POST** /configurations/agent | Creates Agent Configuration Components
[**create_agent_configuration_stage**](ConfigurationApi.md#create_agent_configuration_stage) | **POST** /configurations/agent/versions/{versionID}/stages | Creates a stage for an Agent Configuration Component version
[**create_agent_configuration_version**](ConfigurationApi.md#create_agent_configuration_version) | **POST** /configurations/agent/{componentID}/versions | Creates a new version of an Agent Configuration Component
[**create_evaluator_configuration**](ConfigurationApi.md#create_evaluator_configuration) | **POST** /configurations/evaluator | Creates Evaluator Configuration Components
[**create_evaluator_configuration_stage**](ConfigurationApi.md#create_evaluator_configuration_stage) | **POST** /configurations/evaluator/versions/{versionID}/stages | Creates a stage for an Evaluator Configuration Component version
[**create_evaluator_configuration_version**](ConfigurationApi.md#create_evaluator_configuration_version) | **POST** /configurations/evaluator/{componentID}/versions | Creates a new version of an Evaluator Configuration Component
[**create_mcp_connection_configuration**](ConfigurationApi.md#create_mcp_connection_configuration) | **POST** /configurations/mcp-connection | Creates MCP Connection Configuration Components
[**create_mcp_connection_configuration_stage**](ConfigurationApi.md#create_mcp_connection_configuration_stage) | **POST** /configurations/mcp-connection/versions/{versionID}/stages | Creates a stage for an MCP Connection Configuration Component version
[**create_mcp_connection_configuration_version**](ConfigurationApi.md#create_mcp_connection_configuration_version) | **POST** /configurations/mcp-connection/{componentID}/versions | Creates a new version of an MCP Connection Configuration Component
[**create_shared_configuration**](ConfigurationApi.md#create_shared_configuration) | **POST** /configurations/shared | Creates Shared Configuration Components
[**create_shared_configuration_stage**](ConfigurationApi.md#create_shared_configuration_stage) | **POST** /configurations/shared/versions/{versionID}/stages | Creates a stage for a Shared Configuration Component version
[**create_shared_configuration_version**](ConfigurationApi.md#create_shared_configuration_version) | **POST** /configurations/shared/{componentID}/versions | Creates a new version of a Shared Configuration Component
[**create_tool_profile_configuration**](ConfigurationApi.md#create_tool_profile_configuration) | **POST** /configurations/tool-profile | Creates Tool Profile Configuration Components
[**create_tool_profile_configuration_stage**](ConfigurationApi.md#create_tool_profile_configuration_stage) | **POST** /configurations/tool-profile/versions/{versionID}/stages | Creates a stage for a Tool Profile Configuration Component version
[**create_tool_profile_configuration_version**](ConfigurationApi.md#create_tool_profile_configuration_version) | **POST** /configurations/tool-profile/{componentID}/versions | Creates a new version of a Tool Profile Configuration Component
[**create_workflow_configuration**](ConfigurationApi.md#create_workflow_configuration) | **POST** /configurations/workflow | Creates Workflow Configuration Components
[**create_workflow_configuration_stage**](ConfigurationApi.md#create_workflow_configuration_stage) | **POST** /configurations/workflow/versions/{versionID}/stages | Creates a stage for a Workflow Configuration Component version
[**create_workflow_configuration_version**](ConfigurationApi.md#create_workflow_configuration_version) | **POST** /configurations/workflow/{componentID}/versions | Creates a new version of a Workflow Configuration Component
[**delete_agent_configuration_component**](ConfigurationApi.md#delete_agent_configuration_component) | **DELETE** /configurations/agent/{componentID} | Deletes an Agent Configuration Component
[**delete_agent_configuration_version**](ConfigurationApi.md#delete_agent_configuration_version) | **DELETE** /configurations/agent/versions/{versionID} | Deletes an Agent Configuration Component version
[**delete_evaluator_configuration_component**](ConfigurationApi.md#delete_evaluator_configuration_component) | **DELETE** /configurations/evaluator/{componentID} | Deletes an Evaluator Configuration Component
[**delete_evaluator_configuration_version**](ConfigurationApi.md#delete_evaluator_configuration_version) | **DELETE** /configurations/evaluator/versions/{versionID} | Deletes an Evaluator Configuration Component version
[**delete_mcp_connection_configuration_component**](ConfigurationApi.md#delete_mcp_connection_configuration_component) | **DELETE** /configurations/mcp-connection/{componentID} | Deletes an MCP Connection Configuration Component
[**delete_mcp_connection_configuration_version**](ConfigurationApi.md#delete_mcp_connection_configuration_version) | **DELETE** /configurations/mcp-connection/versions/{versionID} | Deletes an MCP Connection Configuration Component version
[**delete_shared_configuration_component**](ConfigurationApi.md#delete_shared_configuration_component) | **DELETE** /configurations/shared/{componentID} | Deletes a Shared Configuration Component
[**delete_shared_configuration_version**](ConfigurationApi.md#delete_shared_configuration_version) | **DELETE** /configurations/shared/versions/{versionID} | Deletes a Shared Configuration Component version
[**delete_tool_profile_configuration_component**](ConfigurationApi.md#delete_tool_profile_configuration_component) | **DELETE** /configurations/tool-profile/{componentID} | Deletes a Tool Profile Configuration Component
[**delete_tool_profile_configuration_version**](ConfigurationApi.md#delete_tool_profile_configuration_version) | **DELETE** /configurations/tool-profile/versions/{versionID} | Deletes a Tool Profile Configuration Component version
[**delete_workflow_configuration_component**](ConfigurationApi.md#delete_workflow_configuration_component) | **DELETE** /configurations/workflow/{componentID} | Deletes a Workflow Configuration Component
[**delete_workflow_configuration_version**](ConfigurationApi.md#delete_workflow_configuration_version) | **DELETE** /configurations/workflow/versions/{versionID} | Deletes a Workflow Configuration Component version
[**get_agent_configuration_version**](ConfigurationApi.md#get_agent_configuration_version) | **GET** /configurations/agent/versions/{versionID} | Gets an Agent Configuration Component version
[**get_component_by_reference**](ConfigurationApi.md#get_component_by_reference) | **GET** /configurations/component/{componentID}/{versionOrStage} | Gets a Configuration Component by component ID
[**get_configuration_by_reference**](ConfigurationApi.md#get_configuration_by_reference) | **GET** /configurations/{projectID}/{componentType}/{key}/{versionOrStage} | Gets a Configuration Component by reference
[**get_evaluator_configuration_version**](ConfigurationApi.md#get_evaluator_configuration_version) | **GET** /configurations/evaluator/versions/{versionID} | Gets an Evaluator Configuration Component version
[**get_mcp_connection_configuration_version**](ConfigurationApi.md#get_mcp_connection_configuration_version) | **GET** /configurations/mcp-connection/versions/{versionID} | Gets an MCP Connection Configuration Component version
[**get_shared_configuration_version**](ConfigurationApi.md#get_shared_configuration_version) | **GET** /configurations/shared/versions/{versionID} | Gets a Shared Configuration Component version
[**get_tool_profile_configuration_version**](ConfigurationApi.md#get_tool_profile_configuration_version) | **GET** /configurations/tool-profile/versions/{versionID} | Gets a Tool Profile Configuration Component version
[**get_workflow_configuration_version**](ConfigurationApi.md#get_workflow_configuration_version) | **GET** /configurations/workflow/versions/{versionID} | Gets a Workflow Configuration Component version
[**list_agent_configuration_components**](ConfigurationApi.md#list_agent_configuration_components) | **GET** /configurations/agent | Lists Agent Configuration Components
[**list_agent_configuration_versions**](ConfigurationApi.md#list_agent_configuration_versions) | **GET** /configurations/agent/{componentID}/versions | Lists Agent Configuration Component versions
[**list_evaluator_configuration_components**](ConfigurationApi.md#list_evaluator_configuration_components) | **GET** /configurations/evaluator | Lists Evaluator Configuration Components
[**list_evaluator_configuration_versions**](ConfigurationApi.md#list_evaluator_configuration_versions) | **GET** /configurations/evaluator/{componentID}/versions | Lists Evaluator Configuration Component versions
[**list_mcp_connection_configuration_components**](ConfigurationApi.md#list_mcp_connection_configuration_components) | **GET** /configurations/mcp-connection | Lists MCP Connection Configuration Components
[**list_mcp_connection_configuration_versions**](ConfigurationApi.md#list_mcp_connection_configuration_versions) | **GET** /configurations/mcp-connection/{componentID}/versions | Lists MCP Connection Configuration Component versions
[**list_shared_configuration_components**](ConfigurationApi.md#list_shared_configuration_components) | **GET** /configurations/shared | Lists Shared Configuration Components
[**list_shared_configuration_versions**](ConfigurationApi.md#list_shared_configuration_versions) | **GET** /configurations/shared/{componentID}/versions | Lists Shared Configuration Component versions
[**list_tool_profile_configuration_components**](ConfigurationApi.md#list_tool_profile_configuration_components) | **GET** /configurations/tool-profile | Lists Tool Profile Configuration Components
[**list_tool_profile_configuration_versions**](ConfigurationApi.md#list_tool_profile_configuration_versions) | **GET** /configurations/tool-profile/{componentID}/versions | Lists Tool Profile Configuration Component versions
[**list_workflow_configuration_components**](ConfigurationApi.md#list_workflow_configuration_components) | **GET** /configurations/workflow | Lists Workflow Configuration Components
[**list_workflow_configuration_versions**](ConfigurationApi.md#list_workflow_configuration_versions) | **GET** /configurations/workflow/{componentID}/versions | Lists Workflow Configuration Component versions
[**test_mcp_configuration_connection_from_version**](ConfigurationApi.md#test_mcp_configuration_connection_from_version) | **POST** /configurations/mcp-connection/versions/{versionID}/test | Test MCP Configuration Connection
[**update_agent_configuration_component**](ConfigurationApi.md#update_agent_configuration_component) | **PATCH** /configurations/agent/{componentID} | Updates an Agent Configuration Component
[**update_evaluator_configuration_component**](ConfigurationApi.md#update_evaluator_configuration_component) | **PATCH** /configurations/evaluator/{componentID} | Updates an Evaluator Configuration Component
[**update_mcp_connection_configuration_component**](ConfigurationApi.md#update_mcp_connection_configuration_component) | **PATCH** /configurations/mcp-connection/{componentID} | Updates an MCP Connection Configuration Component
[**update_shared_configuration_component**](ConfigurationApi.md#update_shared_configuration_component) | **PATCH** /configurations/shared/{componentID} | Updates a Shared Configuration Component
[**update_tool_profile_configuration_component**](ConfigurationApi.md#update_tool_profile_configuration_component) | **PATCH** /configurations/tool-profile/{componentID} | Updates a Tool Profile Configuration Component
[**update_workflow_configuration_component**](ConfigurationApi.md#update_workflow_configuration_component) | **PATCH** /configurations/workflow/{componentID} | Updates a Workflow Configuration Component


# **create_agent_configuration**
> OutputResponseModelConfigurationComponentVersionModelAgentConfiguration create_agent_configuration(body)

Creates Agent Configuration Components

Creates Agent Configuration Components

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_create_configuration_request_model_agent_configuration import InputCreateConfigurationRequestModelAgentConfiguration
from chariot_api._openapi.awm.models.output_response_model_configuration_component_version_model_agent_configuration import OutputResponseModelConfigurationComponentVersionModelAgentConfiguration
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    body = chariot_api._openapi.awm.InputCreateConfigurationRequestModelAgentConfiguration() # InputCreateConfigurationRequestModelAgentConfiguration | Request Body

    try:
        # Creates Agent Configuration Components
        api_response = api_instance.create_agent_configuration(body)
        print("The response of ConfigurationApi->create_agent_configuration:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->create_agent_configuration: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**InputCreateConfigurationRequestModelAgentConfiguration**](InputCreateConfigurationRequestModelAgentConfiguration.md)| Request Body | 

### Return type

[**OutputResponseModelConfigurationComponentVersionModelAgentConfiguration**](OutputResponseModelConfigurationComponentVersionModelAgentConfiguration.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_agent_configuration_stage**
> create_agent_configuration_stage(version_id, body)

Creates a stage for an Agent Configuration Component version

Creates a stage for an Agent Configuration Component version

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_create_configuration_stage_request import InputCreateConfigurationStageRequest
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    version_id = 'version_id_example' # str | Version ID
    body = chariot_api._openapi.awm.InputCreateConfigurationStageRequest() # InputCreateConfigurationStageRequest | Request Body

    try:
        # Creates a stage for an Agent Configuration Component version
        api_instance.create_agent_configuration_stage(version_id, body)
    except Exception as e:
        print("Exception when calling ConfigurationApi->create_agent_configuration_stage: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version_id** | **str**| Version ID | 
 **body** | [**InputCreateConfigurationStageRequest**](InputCreateConfigurationStageRequest.md)| Request Body | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_agent_configuration_version**
> OutputResponseModelConfigurationComponentVersionModelAgentConfiguration create_agent_configuration_version(component_id, body)

Creates a new version of an Agent Configuration Component

Creates a new version of an Agent Configuration Component

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_create_configuration_version_request_model_agent_configuration import InputCreateConfigurationVersionRequestModelAgentConfiguration
from chariot_api._openapi.awm.models.output_response_model_configuration_component_version_model_agent_configuration import OutputResponseModelConfigurationComponentVersionModelAgentConfiguration
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    component_id = 'component_id_example' # str | Component ID
    body = chariot_api._openapi.awm.InputCreateConfigurationVersionRequestModelAgentConfiguration() # InputCreateConfigurationVersionRequestModelAgentConfiguration | Request Body

    try:
        # Creates a new version of an Agent Configuration Component
        api_response = api_instance.create_agent_configuration_version(component_id, body)
        print("The response of ConfigurationApi->create_agent_configuration_version:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->create_agent_configuration_version: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **component_id** | **str**| Component ID | 
 **body** | [**InputCreateConfigurationVersionRequestModelAgentConfiguration**](InputCreateConfigurationVersionRequestModelAgentConfiguration.md)| Request Body | 

### Return type

[**OutputResponseModelConfigurationComponentVersionModelAgentConfiguration**](OutputResponseModelConfigurationComponentVersionModelAgentConfiguration.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_evaluator_configuration**
> OutputResponseModelConfigurationComponentVersionModelEvaluatorConfiguration create_evaluator_configuration(body)

Creates Evaluator Configuration Components

Creates Evaluator Configuration Components

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_create_configuration_request_model_evaluator_configuration import InputCreateConfigurationRequestModelEvaluatorConfiguration
from chariot_api._openapi.awm.models.output_response_model_configuration_component_version_model_evaluator_configuration import OutputResponseModelConfigurationComponentVersionModelEvaluatorConfiguration
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    body = chariot_api._openapi.awm.InputCreateConfigurationRequestModelEvaluatorConfiguration() # InputCreateConfigurationRequestModelEvaluatorConfiguration | Request Body

    try:
        # Creates Evaluator Configuration Components
        api_response = api_instance.create_evaluator_configuration(body)
        print("The response of ConfigurationApi->create_evaluator_configuration:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->create_evaluator_configuration: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**InputCreateConfigurationRequestModelEvaluatorConfiguration**](InputCreateConfigurationRequestModelEvaluatorConfiguration.md)| Request Body | 

### Return type

[**OutputResponseModelConfigurationComponentVersionModelEvaluatorConfiguration**](OutputResponseModelConfigurationComponentVersionModelEvaluatorConfiguration.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_evaluator_configuration_stage**
> create_evaluator_configuration_stage(version_id, body)

Creates a stage for an Evaluator Configuration Component version

Creates a stage for an Evaluator Configuration Component version

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_create_configuration_stage_request import InputCreateConfigurationStageRequest
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    version_id = 'version_id_example' # str | Version ID
    body = chariot_api._openapi.awm.InputCreateConfigurationStageRequest() # InputCreateConfigurationStageRequest | Request Body

    try:
        # Creates a stage for an Evaluator Configuration Component version
        api_instance.create_evaluator_configuration_stage(version_id, body)
    except Exception as e:
        print("Exception when calling ConfigurationApi->create_evaluator_configuration_stage: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version_id** | **str**| Version ID | 
 **body** | [**InputCreateConfigurationStageRequest**](InputCreateConfigurationStageRequest.md)| Request Body | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_evaluator_configuration_version**
> OutputResponseModelConfigurationComponentVersionModelEvaluatorConfiguration create_evaluator_configuration_version(component_id, body)

Creates a new version of an Evaluator Configuration Component

Creates a new version of an Evaluator Configuration Component

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_create_configuration_version_request_model_evaluator_configuration import InputCreateConfigurationVersionRequestModelEvaluatorConfiguration
from chariot_api._openapi.awm.models.output_response_model_configuration_component_version_model_evaluator_configuration import OutputResponseModelConfigurationComponentVersionModelEvaluatorConfiguration
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    component_id = 'component_id_example' # str | Component ID
    body = chariot_api._openapi.awm.InputCreateConfigurationVersionRequestModelEvaluatorConfiguration() # InputCreateConfigurationVersionRequestModelEvaluatorConfiguration | Request Body

    try:
        # Creates a new version of an Evaluator Configuration Component
        api_response = api_instance.create_evaluator_configuration_version(component_id, body)
        print("The response of ConfigurationApi->create_evaluator_configuration_version:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->create_evaluator_configuration_version: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **component_id** | **str**| Component ID | 
 **body** | [**InputCreateConfigurationVersionRequestModelEvaluatorConfiguration**](InputCreateConfigurationVersionRequestModelEvaluatorConfiguration.md)| Request Body | 

### Return type

[**OutputResponseModelConfigurationComponentVersionModelEvaluatorConfiguration**](OutputResponseModelConfigurationComponentVersionModelEvaluatorConfiguration.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_mcp_connection_configuration**
> OutputResponseModelConfigurationComponentVersionModelMCPConnectionConfiguration create_mcp_connection_configuration(body)

Creates MCP Connection Configuration Components

Creates MCP Connection Configuration Components

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_create_configuration_request_model_mcp_connection_configuration import InputCreateConfigurationRequestModelMCPConnectionConfiguration
from chariot_api._openapi.awm.models.output_response_model_configuration_component_version_model_mcp_connection_configuration import OutputResponseModelConfigurationComponentVersionModelMCPConnectionConfiguration
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    body = chariot_api._openapi.awm.InputCreateConfigurationRequestModelMCPConnectionConfiguration() # InputCreateConfigurationRequestModelMCPConnectionConfiguration | Request Body

    try:
        # Creates MCP Connection Configuration Components
        api_response = api_instance.create_mcp_connection_configuration(body)
        print("The response of ConfigurationApi->create_mcp_connection_configuration:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->create_mcp_connection_configuration: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**InputCreateConfigurationRequestModelMCPConnectionConfiguration**](InputCreateConfigurationRequestModelMCPConnectionConfiguration.md)| Request Body | 

### Return type

[**OutputResponseModelConfigurationComponentVersionModelMCPConnectionConfiguration**](OutputResponseModelConfigurationComponentVersionModelMCPConnectionConfiguration.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_mcp_connection_configuration_stage**
> create_mcp_connection_configuration_stage(version_id, body)

Creates a stage for an MCP Connection Configuration Component version

Creates a stage for an MCP Connection Configuration Component version

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_create_configuration_stage_request import InputCreateConfigurationStageRequest
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    version_id = 'version_id_example' # str | Version ID
    body = chariot_api._openapi.awm.InputCreateConfigurationStageRequest() # InputCreateConfigurationStageRequest | Request Body

    try:
        # Creates a stage for an MCP Connection Configuration Component version
        api_instance.create_mcp_connection_configuration_stage(version_id, body)
    except Exception as e:
        print("Exception when calling ConfigurationApi->create_mcp_connection_configuration_stage: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version_id** | **str**| Version ID | 
 **body** | [**InputCreateConfigurationStageRequest**](InputCreateConfigurationStageRequest.md)| Request Body | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_mcp_connection_configuration_version**
> OutputResponseModelConfigurationComponentVersionModelMCPConnectionConfiguration create_mcp_connection_configuration_version(component_id, body)

Creates a new version of an MCP Connection Configuration Component

Creates a new version of an MCP Connection Configuration Component

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_create_configuration_version_request_model_mcp_connection_configuration import InputCreateConfigurationVersionRequestModelMCPConnectionConfiguration
from chariot_api._openapi.awm.models.output_response_model_configuration_component_version_model_mcp_connection_configuration import OutputResponseModelConfigurationComponentVersionModelMCPConnectionConfiguration
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    component_id = 'component_id_example' # str | Component ID
    body = chariot_api._openapi.awm.InputCreateConfigurationVersionRequestModelMCPConnectionConfiguration() # InputCreateConfigurationVersionRequestModelMCPConnectionConfiguration | Request Body

    try:
        # Creates a new version of an MCP Connection Configuration Component
        api_response = api_instance.create_mcp_connection_configuration_version(component_id, body)
        print("The response of ConfigurationApi->create_mcp_connection_configuration_version:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->create_mcp_connection_configuration_version: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **component_id** | **str**| Component ID | 
 **body** | [**InputCreateConfigurationVersionRequestModelMCPConnectionConfiguration**](InputCreateConfigurationVersionRequestModelMCPConnectionConfiguration.md)| Request Body | 

### Return type

[**OutputResponseModelConfigurationComponentVersionModelMCPConnectionConfiguration**](OutputResponseModelConfigurationComponentVersionModelMCPConnectionConfiguration.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_shared_configuration**
> OutputResponseModelConfigurationComponentVersionModelSharedConfiguration create_shared_configuration(body)

Creates Shared Configuration Components

Creates Shared Configuration Components

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_create_configuration_request_model_shared_configuration import InputCreateConfigurationRequestModelSharedConfiguration
from chariot_api._openapi.awm.models.output_response_model_configuration_component_version_model_shared_configuration import OutputResponseModelConfigurationComponentVersionModelSharedConfiguration
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    body = chariot_api._openapi.awm.InputCreateConfigurationRequestModelSharedConfiguration() # InputCreateConfigurationRequestModelSharedConfiguration | Request Body

    try:
        # Creates Shared Configuration Components
        api_response = api_instance.create_shared_configuration(body)
        print("The response of ConfigurationApi->create_shared_configuration:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->create_shared_configuration: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**InputCreateConfigurationRequestModelSharedConfiguration**](InputCreateConfigurationRequestModelSharedConfiguration.md)| Request Body | 

### Return type

[**OutputResponseModelConfigurationComponentVersionModelSharedConfiguration**](OutputResponseModelConfigurationComponentVersionModelSharedConfiguration.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_shared_configuration_stage**
> create_shared_configuration_stage(version_id, body)

Creates a stage for a Shared Configuration Component version

Creates a stage for a Shared Configuration Component version

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_create_configuration_stage_request import InputCreateConfigurationStageRequest
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    version_id = 'version_id_example' # str | Version ID
    body = chariot_api._openapi.awm.InputCreateConfigurationStageRequest() # InputCreateConfigurationStageRequest | Request Body

    try:
        # Creates a stage for a Shared Configuration Component version
        api_instance.create_shared_configuration_stage(version_id, body)
    except Exception as e:
        print("Exception when calling ConfigurationApi->create_shared_configuration_stage: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version_id** | **str**| Version ID | 
 **body** | [**InputCreateConfigurationStageRequest**](InputCreateConfigurationStageRequest.md)| Request Body | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_shared_configuration_version**
> OutputResponseModelConfigurationComponentVersionModelSharedConfiguration create_shared_configuration_version(component_id, body)

Creates a new version of a Shared Configuration Component

Creates a new version of a Shared Configuration Component

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_create_configuration_version_request_model_shared_configuration import InputCreateConfigurationVersionRequestModelSharedConfiguration
from chariot_api._openapi.awm.models.output_response_model_configuration_component_version_model_shared_configuration import OutputResponseModelConfigurationComponentVersionModelSharedConfiguration
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    component_id = 'component_id_example' # str | Component ID
    body = chariot_api._openapi.awm.InputCreateConfigurationVersionRequestModelSharedConfiguration() # InputCreateConfigurationVersionRequestModelSharedConfiguration | Request Body

    try:
        # Creates a new version of a Shared Configuration Component
        api_response = api_instance.create_shared_configuration_version(component_id, body)
        print("The response of ConfigurationApi->create_shared_configuration_version:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->create_shared_configuration_version: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **component_id** | **str**| Component ID | 
 **body** | [**InputCreateConfigurationVersionRequestModelSharedConfiguration**](InputCreateConfigurationVersionRequestModelSharedConfiguration.md)| Request Body | 

### Return type

[**OutputResponseModelConfigurationComponentVersionModelSharedConfiguration**](OutputResponseModelConfigurationComponentVersionModelSharedConfiguration.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_tool_profile_configuration**
> OutputResponseModelConfigurationComponentVersionModelToolProfileConfiguration create_tool_profile_configuration(body)

Creates Tool Profile Configuration Components

Creates Tool Profile Configuration Components

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_create_configuration_request_model_tool_profile_configuration import InputCreateConfigurationRequestModelToolProfileConfiguration
from chariot_api._openapi.awm.models.output_response_model_configuration_component_version_model_tool_profile_configuration import OutputResponseModelConfigurationComponentVersionModelToolProfileConfiguration
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    body = chariot_api._openapi.awm.InputCreateConfigurationRequestModelToolProfileConfiguration() # InputCreateConfigurationRequestModelToolProfileConfiguration | Request Body

    try:
        # Creates Tool Profile Configuration Components
        api_response = api_instance.create_tool_profile_configuration(body)
        print("The response of ConfigurationApi->create_tool_profile_configuration:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->create_tool_profile_configuration: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**InputCreateConfigurationRequestModelToolProfileConfiguration**](InputCreateConfigurationRequestModelToolProfileConfiguration.md)| Request Body | 

### Return type

[**OutputResponseModelConfigurationComponentVersionModelToolProfileConfiguration**](OutputResponseModelConfigurationComponentVersionModelToolProfileConfiguration.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_tool_profile_configuration_stage**
> create_tool_profile_configuration_stage(version_id, body)

Creates a stage for a Tool Profile Configuration Component version

Creates a stage for a Tool Profile Configuration Component version

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_create_configuration_stage_request import InputCreateConfigurationStageRequest
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    version_id = 'version_id_example' # str | Version ID
    body = chariot_api._openapi.awm.InputCreateConfigurationStageRequest() # InputCreateConfigurationStageRequest | Request Body

    try:
        # Creates a stage for a Tool Profile Configuration Component version
        api_instance.create_tool_profile_configuration_stage(version_id, body)
    except Exception as e:
        print("Exception when calling ConfigurationApi->create_tool_profile_configuration_stage: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version_id** | **str**| Version ID | 
 **body** | [**InputCreateConfigurationStageRequest**](InputCreateConfigurationStageRequest.md)| Request Body | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_tool_profile_configuration_version**
> OutputResponseModelConfigurationComponentVersionModelToolProfileConfiguration create_tool_profile_configuration_version(component_id, body)

Creates a new version of a Tool Profile Configuration Component

Creates a new version of a Tool Profile Configuration Component

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_create_configuration_version_request_model_tool_profile_configuration import InputCreateConfigurationVersionRequestModelToolProfileConfiguration
from chariot_api._openapi.awm.models.output_response_model_configuration_component_version_model_tool_profile_configuration import OutputResponseModelConfigurationComponentVersionModelToolProfileConfiguration
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    component_id = 'component_id_example' # str | Component ID
    body = chariot_api._openapi.awm.InputCreateConfigurationVersionRequestModelToolProfileConfiguration() # InputCreateConfigurationVersionRequestModelToolProfileConfiguration | Request Body

    try:
        # Creates a new version of a Tool Profile Configuration Component
        api_response = api_instance.create_tool_profile_configuration_version(component_id, body)
        print("The response of ConfigurationApi->create_tool_profile_configuration_version:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->create_tool_profile_configuration_version: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **component_id** | **str**| Component ID | 
 **body** | [**InputCreateConfigurationVersionRequestModelToolProfileConfiguration**](InputCreateConfigurationVersionRequestModelToolProfileConfiguration.md)| Request Body | 

### Return type

[**OutputResponseModelConfigurationComponentVersionModelToolProfileConfiguration**](OutputResponseModelConfigurationComponentVersionModelToolProfileConfiguration.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_workflow_configuration**
> OutputResponseModelConfigurationComponentVersionModelWorkflowConfiguration create_workflow_configuration(body)

Creates Workflow Configuration Components

Creates Workflow Configuration Components

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_create_workflow_configuration_request import InputCreateWorkflowConfigurationRequest
from chariot_api._openapi.awm.models.output_response_model_configuration_component_version_model_workflow_configuration import OutputResponseModelConfigurationComponentVersionModelWorkflowConfiguration
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    body = chariot_api._openapi.awm.InputCreateWorkflowConfigurationRequest() # InputCreateWorkflowConfigurationRequest | Request Body

    try:
        # Creates Workflow Configuration Components
        api_response = api_instance.create_workflow_configuration(body)
        print("The response of ConfigurationApi->create_workflow_configuration:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->create_workflow_configuration: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**InputCreateWorkflowConfigurationRequest**](InputCreateWorkflowConfigurationRequest.md)| Request Body | 

### Return type

[**OutputResponseModelConfigurationComponentVersionModelWorkflowConfiguration**](OutputResponseModelConfigurationComponentVersionModelWorkflowConfiguration.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_workflow_configuration_stage**
> create_workflow_configuration_stage(version_id, body)

Creates a stage for a Workflow Configuration Component version

Creates a stage for a Workflow Configuration Component version

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_create_configuration_stage_request import InputCreateConfigurationStageRequest
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    version_id = 'version_id_example' # str | Version ID
    body = chariot_api._openapi.awm.InputCreateConfigurationStageRequest() # InputCreateConfigurationStageRequest | Request Body

    try:
        # Creates a stage for a Workflow Configuration Component version
        api_instance.create_workflow_configuration_stage(version_id, body)
    except Exception as e:
        print("Exception when calling ConfigurationApi->create_workflow_configuration_stage: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version_id** | **str**| Version ID | 
 **body** | [**InputCreateConfigurationStageRequest**](InputCreateConfigurationStageRequest.md)| Request Body | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_workflow_configuration_version**
> OutputResponseModelConfigurationComponentVersionModelWorkflowConfiguration create_workflow_configuration_version(component_id, body)

Creates a new version of a Workflow Configuration Component

Creates a new version of a Workflow Configuration Component

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_create_workflow_configuration_version_request import InputCreateWorkflowConfigurationVersionRequest
from chariot_api._openapi.awm.models.output_response_model_configuration_component_version_model_workflow_configuration import OutputResponseModelConfigurationComponentVersionModelWorkflowConfiguration
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    component_id = 'component_id_example' # str | Component ID
    body = chariot_api._openapi.awm.InputCreateWorkflowConfigurationVersionRequest() # InputCreateWorkflowConfigurationVersionRequest | Request Body

    try:
        # Creates a new version of a Workflow Configuration Component
        api_response = api_instance.create_workflow_configuration_version(component_id, body)
        print("The response of ConfigurationApi->create_workflow_configuration_version:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->create_workflow_configuration_version: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **component_id** | **str**| Component ID | 
 **body** | [**InputCreateWorkflowConfigurationVersionRequest**](InputCreateWorkflowConfigurationVersionRequest.md)| Request Body | 

### Return type

[**OutputResponseModelConfigurationComponentVersionModelWorkflowConfiguration**](OutputResponseModelConfigurationComponentVersionModelWorkflowConfiguration.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_agent_configuration_component**
> delete_agent_configuration_component(component_id)

Deletes an Agent Configuration Component

Soft deletes all versions of an Agent Configuration Component and marks the component deleted

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    component_id = 'component_id_example' # str | Component ID

    try:
        # Deletes an Agent Configuration Component
        api_instance.delete_agent_configuration_component(component_id)
    except Exception as e:
        print("Exception when calling ConfigurationApi->delete_agent_configuration_component: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **component_id** | **str**| Component ID | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | No Content |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_agent_configuration_version**
> delete_agent_configuration_version(version_id)

Deletes an Agent Configuration Component version

Soft deletes an Agent Configuration Component version

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    version_id = 'version_id_example' # str | Version ID

    try:
        # Deletes an Agent Configuration Component version
        api_instance.delete_agent_configuration_version(version_id)
    except Exception as e:
        print("Exception when calling ConfigurationApi->delete_agent_configuration_version: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version_id** | **str**| Version ID | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | No Content |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_evaluator_configuration_component**
> delete_evaluator_configuration_component(component_id)

Deletes an Evaluator Configuration Component

Soft deletes all versions of an Evaluator Configuration Component and marks the component deleted

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    component_id = 'component_id_example' # str | Component ID

    try:
        # Deletes an Evaluator Configuration Component
        api_instance.delete_evaluator_configuration_component(component_id)
    except Exception as e:
        print("Exception when calling ConfigurationApi->delete_evaluator_configuration_component: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **component_id** | **str**| Component ID | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | No Content |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_evaluator_configuration_version**
> delete_evaluator_configuration_version(version_id)

Deletes an Evaluator Configuration Component version

Soft deletes an Evaluator Configuration Component version

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    version_id = 'version_id_example' # str | Version ID

    try:
        # Deletes an Evaluator Configuration Component version
        api_instance.delete_evaluator_configuration_version(version_id)
    except Exception as e:
        print("Exception when calling ConfigurationApi->delete_evaluator_configuration_version: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version_id** | **str**| Version ID | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | No Content |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_mcp_connection_configuration_component**
> delete_mcp_connection_configuration_component(component_id)

Deletes an MCP Connection Configuration Component

Soft deletes all versions of an MCP Connection Configuration Component and marks the component deleted

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    component_id = 'component_id_example' # str | Component ID

    try:
        # Deletes an MCP Connection Configuration Component
        api_instance.delete_mcp_connection_configuration_component(component_id)
    except Exception as e:
        print("Exception when calling ConfigurationApi->delete_mcp_connection_configuration_component: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **component_id** | **str**| Component ID | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | No Content |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_mcp_connection_configuration_version**
> delete_mcp_connection_configuration_version(version_id)

Deletes an MCP Connection Configuration Component version

Soft deletes an MCP Connection Configuration Component version

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    version_id = 'version_id_example' # str | Version ID

    try:
        # Deletes an MCP Connection Configuration Component version
        api_instance.delete_mcp_connection_configuration_version(version_id)
    except Exception as e:
        print("Exception when calling ConfigurationApi->delete_mcp_connection_configuration_version: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version_id** | **str**| Version ID | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | No Content |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_shared_configuration_component**
> delete_shared_configuration_component(component_id)

Deletes a Shared Configuration Component

Soft deletes all versions of a Shared Configuration Component and marks the component deleted

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    component_id = 'component_id_example' # str | Component ID

    try:
        # Deletes a Shared Configuration Component
        api_instance.delete_shared_configuration_component(component_id)
    except Exception as e:
        print("Exception when calling ConfigurationApi->delete_shared_configuration_component: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **component_id** | **str**| Component ID | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | No Content |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_shared_configuration_version**
> delete_shared_configuration_version(version_id)

Deletes a Shared Configuration Component version

Soft deletes a Shared Configuration Component version

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    version_id = 'version_id_example' # str | Version ID

    try:
        # Deletes a Shared Configuration Component version
        api_instance.delete_shared_configuration_version(version_id)
    except Exception as e:
        print("Exception when calling ConfigurationApi->delete_shared_configuration_version: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version_id** | **str**| Version ID | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | No Content |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_tool_profile_configuration_component**
> delete_tool_profile_configuration_component(component_id)

Deletes a Tool Profile Configuration Component

Soft deletes all versions of a Tool Profile Configuration Component and marks the component deleted

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    component_id = 'component_id_example' # str | Component ID

    try:
        # Deletes a Tool Profile Configuration Component
        api_instance.delete_tool_profile_configuration_component(component_id)
    except Exception as e:
        print("Exception when calling ConfigurationApi->delete_tool_profile_configuration_component: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **component_id** | **str**| Component ID | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | No Content |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_tool_profile_configuration_version**
> delete_tool_profile_configuration_version(version_id)

Deletes a Tool Profile Configuration Component version

Soft deletes a Tool Profile Configuration Component version

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    version_id = 'version_id_example' # str | Version ID

    try:
        # Deletes a Tool Profile Configuration Component version
        api_instance.delete_tool_profile_configuration_version(version_id)
    except Exception as e:
        print("Exception when calling ConfigurationApi->delete_tool_profile_configuration_version: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version_id** | **str**| Version ID | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | No Content |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_workflow_configuration_component**
> delete_workflow_configuration_component(component_id)

Deletes a Workflow Configuration Component

Soft deletes all versions of a Workflow Configuration Component and marks the component deleted

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    component_id = 'component_id_example' # str | Component ID

    try:
        # Deletes a Workflow Configuration Component
        api_instance.delete_workflow_configuration_component(component_id)
    except Exception as e:
        print("Exception when calling ConfigurationApi->delete_workflow_configuration_component: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **component_id** | **str**| Component ID | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | No Content |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_workflow_configuration_version**
> delete_workflow_configuration_version(version_id)

Deletes a Workflow Configuration Component version

Soft deletes a Workflow Configuration Component version

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    version_id = 'version_id_example' # str | Version ID

    try:
        # Deletes a Workflow Configuration Component version
        api_instance.delete_workflow_configuration_version(version_id)
    except Exception as e:
        print("Exception when calling ConfigurationApi->delete_workflow_configuration_version: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version_id** | **str**| Version ID | 

### Return type

void (empty response body)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | No Content |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_agent_configuration_version**
> OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelAgentConfiguration get_agent_configuration_version(version_id, resolved=resolved)

Gets an Agent Configuration Component version

Gets an Agent Configuration Component version. Pass ?resolved=true to resolve component references.

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_resolved_configuration_response_model_configuration_component_version_model_agent_configuration import OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelAgentConfiguration
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    version_id = 'version_id_example' # str | Version ID
    resolved = True # bool | If true, resolve component references in the config (optional)

    try:
        # Gets an Agent Configuration Component version
        api_response = api_instance.get_agent_configuration_version(version_id, resolved=resolved)
        print("The response of ConfigurationApi->get_agent_configuration_version:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->get_agent_configuration_version: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version_id** | **str**| Version ID | 
 **resolved** | **bool**| If true, resolve component references in the config | [optional] 

### Return type

[**OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelAgentConfiguration**](OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelAgentConfiguration.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_component_by_reference**
> OutputResolvedConfigurationResponseAny get_component_by_reference(component_id, version_or_stage, resolved=resolved)

Gets a Configuration Component by component ID

Gets any configuration component using its component ID and a version or stage. Pass ?resolved=true to resolve component references.

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_resolved_configuration_response_any import OutputResolvedConfigurationResponseAny
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    component_id = 'component_id_example' # str | Component ID
    version_or_stage = 'version_or_stage_example' # str | Version Number or Stage Name
    resolved = True # bool | If true, resolve component references in the config (optional)

    try:
        # Gets a Configuration Component by component ID
        api_response = api_instance.get_component_by_reference(component_id, version_or_stage, resolved=resolved)
        print("The response of ConfigurationApi->get_component_by_reference:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->get_component_by_reference: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **component_id** | **str**| Component ID | 
 **version_or_stage** | **str**| Version Number or Stage Name | 
 **resolved** | **bool**| If true, resolve component references in the config | [optional] 

### Return type

[**OutputResolvedConfigurationResponseAny**](OutputResolvedConfigurationResponseAny.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_configuration_by_reference**
> OutputResolvedConfigurationResponseAny get_configuration_by_reference(project_id, component_type, key, version_or_stage, resolved=resolved)

Gets a Configuration Component by reference

Gets any configuration component using a user defined key. Pass ?resolved=true to resolve component references.

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_resolved_configuration_response_any import OutputResolvedConfigurationResponseAny
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    project_id = 'project_id_example' # str | Project ID
    component_type = 'component_type_example' # str | Component Type
    key = 'key_example' # str | Component Key
    version_or_stage = 'version_or_stage_example' # str | Version Number or Stage Name
    resolved = True # bool | If true, resolve component references in the config (optional)

    try:
        # Gets a Configuration Component by reference
        api_response = api_instance.get_configuration_by_reference(project_id, component_type, key, version_or_stage, resolved=resolved)
        print("The response of ConfigurationApi->get_configuration_by_reference:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->get_configuration_by_reference: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| Project ID | 
 **component_type** | **str**| Component Type | 
 **key** | **str**| Component Key | 
 **version_or_stage** | **str**| Version Number or Stage Name | 
 **resolved** | **bool**| If true, resolve component references in the config | [optional] 

### Return type

[**OutputResolvedConfigurationResponseAny**](OutputResolvedConfigurationResponseAny.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_evaluator_configuration_version**
> OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelEvaluatorConfiguration get_evaluator_configuration_version(version_id, resolved=resolved)

Gets an Evaluator Configuration Component version

Gets an Evaluator Configuration Component version. Pass ?resolved=true to resolve component references.

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_resolved_configuration_response_model_configuration_component_version_model_evaluator_configuration import OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelEvaluatorConfiguration
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    version_id = 'version_id_example' # str | Version ID
    resolved = True # bool | If true, resolve component references in the config (optional)

    try:
        # Gets an Evaluator Configuration Component version
        api_response = api_instance.get_evaluator_configuration_version(version_id, resolved=resolved)
        print("The response of ConfigurationApi->get_evaluator_configuration_version:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->get_evaluator_configuration_version: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version_id** | **str**| Version ID | 
 **resolved** | **bool**| If true, resolve component references in the config | [optional] 

### Return type

[**OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelEvaluatorConfiguration**](OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelEvaluatorConfiguration.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_mcp_connection_configuration_version**
> OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelMCPConnectionConfiguration get_mcp_connection_configuration_version(version_id, resolved=resolved)

Gets an MCP Connection Configuration Component version

Gets an MCP Connection Configuration Component version. Pass ?resolved=true to resolve component references.

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_resolved_configuration_response_model_configuration_component_version_model_mcp_connection_configuration import OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelMCPConnectionConfiguration
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    version_id = 'version_id_example' # str | Version ID
    resolved = True # bool | If true, resolve component references in the config (optional)

    try:
        # Gets an MCP Connection Configuration Component version
        api_response = api_instance.get_mcp_connection_configuration_version(version_id, resolved=resolved)
        print("The response of ConfigurationApi->get_mcp_connection_configuration_version:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->get_mcp_connection_configuration_version: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version_id** | **str**| Version ID | 
 **resolved** | **bool**| If true, resolve component references in the config | [optional] 

### Return type

[**OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelMCPConnectionConfiguration**](OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelMCPConnectionConfiguration.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_shared_configuration_version**
> OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelSharedConfiguration get_shared_configuration_version(version_id, resolved=resolved)

Gets a Shared Configuration Component version

Gets a Shared Configuration Component version. Pass ?resolved=true to resolve component references.

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_resolved_configuration_response_model_configuration_component_version_model_shared_configuration import OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelSharedConfiguration
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    version_id = 'version_id_example' # str | Version ID
    resolved = True # bool | If true, resolve component references in the config (optional)

    try:
        # Gets a Shared Configuration Component version
        api_response = api_instance.get_shared_configuration_version(version_id, resolved=resolved)
        print("The response of ConfigurationApi->get_shared_configuration_version:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->get_shared_configuration_version: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version_id** | **str**| Version ID | 
 **resolved** | **bool**| If true, resolve component references in the config | [optional] 

### Return type

[**OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelSharedConfiguration**](OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelSharedConfiguration.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_tool_profile_configuration_version**
> OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelToolProfileConfiguration get_tool_profile_configuration_version(version_id, resolved=resolved)

Gets a Tool Profile Configuration Component version

Gets a Tool Profile Configuration Component version. Pass ?resolved=true to resolve component references.

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_resolved_configuration_response_model_configuration_component_version_model_tool_profile_configuration import OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelToolProfileConfiguration
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    version_id = 'version_id_example' # str | Version ID
    resolved = True # bool | If true, resolve component references in the config (optional)

    try:
        # Gets a Tool Profile Configuration Component version
        api_response = api_instance.get_tool_profile_configuration_version(version_id, resolved=resolved)
        print("The response of ConfigurationApi->get_tool_profile_configuration_version:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->get_tool_profile_configuration_version: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version_id** | **str**| Version ID | 
 **resolved** | **bool**| If true, resolve component references in the config | [optional] 

### Return type

[**OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelToolProfileConfiguration**](OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelToolProfileConfiguration.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_workflow_configuration_version**
> OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelWorkflowConfiguration get_workflow_configuration_version(version_id, resolved=resolved)

Gets a Workflow Configuration Component version

Gets a Workflow Configuration Component version. Pass ?resolved=true to resolve component references.

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_resolved_configuration_response_model_configuration_component_version_model_workflow_configuration import OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelWorkflowConfiguration
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    version_id = 'version_id_example' # str | Version ID
    resolved = True # bool | If true, resolve component references in the config (optional)

    try:
        # Gets a Workflow Configuration Component version
        api_response = api_instance.get_workflow_configuration_version(version_id, resolved=resolved)
        print("The response of ConfigurationApi->get_workflow_configuration_version:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->get_workflow_configuration_version: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version_id** | **str**| Version ID | 
 **resolved** | **bool**| If true, resolve component references in the config | [optional] 

### Return type

[**OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelWorkflowConfiguration**](OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelWorkflowConfiguration.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_agent_configuration_components**
> OutputPaginatedResponseModelConfigurationComponentSummary list_agent_configuration_components(name=name, project_id=project_id, include_deleted=include_deleted, limit=limit, after_key=after_key, sort_type=sort_type, sort_order=sort_order, version_or_stage=version_or_stage)

Lists Agent Configuration Components

Lists Agent Configuration Components

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_paginated_response_model_configuration_component_summary import OutputPaginatedResponseModelConfigurationComponentSummary
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    name = 'name_example' # str | Name Search (partial match, case-insensitive) (optional)
    project_id = ['project_id_example'] # List[str] | Project ID (optional)
    include_deleted = True # bool | Include Deleted Components (optional)
    limit = 56 # int | Limit (defaults to 10, max 1000) (optional)
    after_key = 'after_key_example' # str | Pagination Key (optional)
    sort_type = 'sort_type_example' # str | Sort Type (default, name) (optional)
    sort_order = 'sort_order_example' # str | Sort asc/desc (defaults to desc for default sort, asc otherwise) (optional)
    version_or_stage = 'version_or_stage_example' # str | Filter to components that have this version or stage; also used for metadata (latest, development, staging, production, or version number; defaults to latest) (optional)

    try:
        # Lists Agent Configuration Components
        api_response = api_instance.list_agent_configuration_components(name=name, project_id=project_id, include_deleted=include_deleted, limit=limit, after_key=after_key, sort_type=sort_type, sort_order=sort_order, version_or_stage=version_or_stage)
        print("The response of ConfigurationApi->list_agent_configuration_components:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->list_agent_configuration_components: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**| Name Search (partial match, case-insensitive) | [optional] 
 **project_id** | [**List[str]**](str.md)| Project ID | [optional] 
 **include_deleted** | **bool**| Include Deleted Components | [optional] 
 **limit** | **int**| Limit (defaults to 10, max 1000) | [optional] 
 **after_key** | **str**| Pagination Key | [optional] 
 **sort_type** | **str**| Sort Type (default, name) | [optional] 
 **sort_order** | **str**| Sort asc/desc (defaults to desc for default sort, asc otherwise) | [optional] 
 **version_or_stage** | **str**| Filter to components that have this version or stage; also used for metadata (latest, development, staging, production, or version number; defaults to latest) | [optional] 

### Return type

[**OutputPaginatedResponseModelConfigurationComponentSummary**](OutputPaginatedResponseModelConfigurationComponentSummary.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_agent_configuration_versions**
> OutputPaginatedResponseModelConfigurationComponentVersionSummary list_agent_configuration_versions(component_id, include_deleted=include_deleted, limit=limit, after_key=after_key, sort_order=sort_order)

Lists Agent Configuration Component versions

Lists Agent Configuration Component versions for a component

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_paginated_response_model_configuration_component_version_summary import OutputPaginatedResponseModelConfigurationComponentVersionSummary
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    component_id = 'component_id_example' # str | Component ID
    include_deleted = True # bool | Include Deleted Versions (optional)
    limit = 56 # int | Limit (defaults to 10, max 1000) (optional)
    after_key = 'after_key_example' # str | Pagination Key (optional)
    sort_order = 'sort_order_example' # str | Sort asc/desc (defaults to desc) (optional)

    try:
        # Lists Agent Configuration Component versions
        api_response = api_instance.list_agent_configuration_versions(component_id, include_deleted=include_deleted, limit=limit, after_key=after_key, sort_order=sort_order)
        print("The response of ConfigurationApi->list_agent_configuration_versions:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->list_agent_configuration_versions: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **component_id** | **str**| Component ID | 
 **include_deleted** | **bool**| Include Deleted Versions | [optional] 
 **limit** | **int**| Limit (defaults to 10, max 1000) | [optional] 
 **after_key** | **str**| Pagination Key | [optional] 
 **sort_order** | **str**| Sort asc/desc (defaults to desc) | [optional] 

### Return type

[**OutputPaginatedResponseModelConfigurationComponentVersionSummary**](OutputPaginatedResponseModelConfigurationComponentVersionSummary.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_evaluator_configuration_components**
> OutputPaginatedResponseModelConfigurationComponentSummary list_evaluator_configuration_components(name=name, project_id=project_id, include_deleted=include_deleted, limit=limit, after_key=after_key, sort_type=sort_type, sort_order=sort_order, version_or_stage=version_or_stage)

Lists Evaluator Configuration Components

Lists Evaluator Configuration Components

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_paginated_response_model_configuration_component_summary import OutputPaginatedResponseModelConfigurationComponentSummary
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    name = 'name_example' # str | Name Search (partial match, case-insensitive) (optional)
    project_id = ['project_id_example'] # List[str] | Project ID (optional)
    include_deleted = True # bool | Include Deleted Components (optional)
    limit = 56 # int | Limit (defaults to 10, max 1000) (optional)
    after_key = 'after_key_example' # str | Pagination Key (optional)
    sort_type = 'sort_type_example' # str | Sort Type (default, name) (optional)
    sort_order = 'sort_order_example' # str | Sort asc/desc (defaults to desc for default sort, asc otherwise) (optional)
    version_or_stage = 'version_or_stage_example' # str | Filter to components that have this version or stage; also used for metadata (latest, development, staging, production, or version number; defaults to latest) (optional)

    try:
        # Lists Evaluator Configuration Components
        api_response = api_instance.list_evaluator_configuration_components(name=name, project_id=project_id, include_deleted=include_deleted, limit=limit, after_key=after_key, sort_type=sort_type, sort_order=sort_order, version_or_stage=version_or_stage)
        print("The response of ConfigurationApi->list_evaluator_configuration_components:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->list_evaluator_configuration_components: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**| Name Search (partial match, case-insensitive) | [optional] 
 **project_id** | [**List[str]**](str.md)| Project ID | [optional] 
 **include_deleted** | **bool**| Include Deleted Components | [optional] 
 **limit** | **int**| Limit (defaults to 10, max 1000) | [optional] 
 **after_key** | **str**| Pagination Key | [optional] 
 **sort_type** | **str**| Sort Type (default, name) | [optional] 
 **sort_order** | **str**| Sort asc/desc (defaults to desc for default sort, asc otherwise) | [optional] 
 **version_or_stage** | **str**| Filter to components that have this version or stage; also used for metadata (latest, development, staging, production, or version number; defaults to latest) | [optional] 

### Return type

[**OutputPaginatedResponseModelConfigurationComponentSummary**](OutputPaginatedResponseModelConfigurationComponentSummary.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_evaluator_configuration_versions**
> OutputPaginatedResponseModelConfigurationComponentVersionSummary list_evaluator_configuration_versions(component_id, include_deleted=include_deleted, limit=limit, after_key=after_key, sort_order=sort_order)

Lists Evaluator Configuration Component versions

Lists Evaluator Configuration Component versions for a component

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_paginated_response_model_configuration_component_version_summary import OutputPaginatedResponseModelConfigurationComponentVersionSummary
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    component_id = 'component_id_example' # str | Component ID
    include_deleted = True # bool | Include Deleted Versions (optional)
    limit = 56 # int | Limit (defaults to 10, max 1000) (optional)
    after_key = 'after_key_example' # str | Pagination Key (optional)
    sort_order = 'sort_order_example' # str | Sort asc/desc (defaults to desc) (optional)

    try:
        # Lists Evaluator Configuration Component versions
        api_response = api_instance.list_evaluator_configuration_versions(component_id, include_deleted=include_deleted, limit=limit, after_key=after_key, sort_order=sort_order)
        print("The response of ConfigurationApi->list_evaluator_configuration_versions:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->list_evaluator_configuration_versions: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **component_id** | **str**| Component ID | 
 **include_deleted** | **bool**| Include Deleted Versions | [optional] 
 **limit** | **int**| Limit (defaults to 10, max 1000) | [optional] 
 **after_key** | **str**| Pagination Key | [optional] 
 **sort_order** | **str**| Sort asc/desc (defaults to desc) | [optional] 

### Return type

[**OutputPaginatedResponseModelConfigurationComponentVersionSummary**](OutputPaginatedResponseModelConfigurationComponentVersionSummary.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_mcp_connection_configuration_components**
> OutputPaginatedResponseModelConfigurationComponentSummary list_mcp_connection_configuration_components(name=name, project_id=project_id, include_deleted=include_deleted, limit=limit, after_key=after_key, sort_type=sort_type, sort_order=sort_order, version_or_stage=version_or_stage)

Lists MCP Connection Configuration Components

Lists MCP Connection Configuration Components

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_paginated_response_model_configuration_component_summary import OutputPaginatedResponseModelConfigurationComponentSummary
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    name = 'name_example' # str | Name Search (partial match, case-insensitive) (optional)
    project_id = ['project_id_example'] # List[str] | Project ID (optional)
    include_deleted = True # bool | Include Deleted Components (optional)
    limit = 56 # int | Limit (defaults to 10, max 1000) (optional)
    after_key = 'after_key_example' # str | Pagination Key (optional)
    sort_type = 'sort_type_example' # str | Sort Type (default, name) (optional)
    sort_order = 'sort_order_example' # str | Sort asc/desc (defaults to desc for default sort, asc otherwise) (optional)
    version_or_stage = 'version_or_stage_example' # str | Filter to components that have this version or stage; also used for metadata (latest, development, staging, production, or version number; defaults to latest) (optional)

    try:
        # Lists MCP Connection Configuration Components
        api_response = api_instance.list_mcp_connection_configuration_components(name=name, project_id=project_id, include_deleted=include_deleted, limit=limit, after_key=after_key, sort_type=sort_type, sort_order=sort_order, version_or_stage=version_or_stage)
        print("The response of ConfigurationApi->list_mcp_connection_configuration_components:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->list_mcp_connection_configuration_components: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**| Name Search (partial match, case-insensitive) | [optional] 
 **project_id** | [**List[str]**](str.md)| Project ID | [optional] 
 **include_deleted** | **bool**| Include Deleted Components | [optional] 
 **limit** | **int**| Limit (defaults to 10, max 1000) | [optional] 
 **after_key** | **str**| Pagination Key | [optional] 
 **sort_type** | **str**| Sort Type (default, name) | [optional] 
 **sort_order** | **str**| Sort asc/desc (defaults to desc for default sort, asc otherwise) | [optional] 
 **version_or_stage** | **str**| Filter to components that have this version or stage; also used for metadata (latest, development, staging, production, or version number; defaults to latest) | [optional] 

### Return type

[**OutputPaginatedResponseModelConfigurationComponentSummary**](OutputPaginatedResponseModelConfigurationComponentSummary.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_mcp_connection_configuration_versions**
> OutputPaginatedResponseModelConfigurationComponentVersionSummary list_mcp_connection_configuration_versions(component_id, include_deleted=include_deleted, limit=limit, after_key=after_key, sort_order=sort_order)

Lists MCP Connection Configuration Component versions

Lists MCP Connection Configuration Component versions for a component

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_paginated_response_model_configuration_component_version_summary import OutputPaginatedResponseModelConfigurationComponentVersionSummary
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    component_id = 'component_id_example' # str | Component ID
    include_deleted = True # bool | Include Deleted Versions (optional)
    limit = 56 # int | Limit (defaults to 10, max 1000) (optional)
    after_key = 'after_key_example' # str | Pagination Key (optional)
    sort_order = 'sort_order_example' # str | Sort asc/desc (defaults to desc) (optional)

    try:
        # Lists MCP Connection Configuration Component versions
        api_response = api_instance.list_mcp_connection_configuration_versions(component_id, include_deleted=include_deleted, limit=limit, after_key=after_key, sort_order=sort_order)
        print("The response of ConfigurationApi->list_mcp_connection_configuration_versions:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->list_mcp_connection_configuration_versions: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **component_id** | **str**| Component ID | 
 **include_deleted** | **bool**| Include Deleted Versions | [optional] 
 **limit** | **int**| Limit (defaults to 10, max 1000) | [optional] 
 **after_key** | **str**| Pagination Key | [optional] 
 **sort_order** | **str**| Sort asc/desc (defaults to desc) | [optional] 

### Return type

[**OutputPaginatedResponseModelConfigurationComponentVersionSummary**](OutputPaginatedResponseModelConfigurationComponentVersionSummary.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_shared_configuration_components**
> OutputPaginatedResponseModelConfigurationComponentSummary list_shared_configuration_components(name=name, project_id=project_id, include_deleted=include_deleted, limit=limit, after_key=after_key, sort_type=sort_type, sort_order=sort_order, version_or_stage=version_or_stage)

Lists Shared Configuration Components

Lists Shared Configuration Components

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_paginated_response_model_configuration_component_summary import OutputPaginatedResponseModelConfigurationComponentSummary
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    name = 'name_example' # str | Name Search (partial match, case-insensitive) (optional)
    project_id = ['project_id_example'] # List[str] | Project ID (optional)
    include_deleted = True # bool | Include Deleted Components (optional)
    limit = 56 # int | Limit (defaults to 10, max 1000) (optional)
    after_key = 'after_key_example' # str | Pagination Key (optional)
    sort_type = 'sort_type_example' # str | Sort Type (default, name) (optional)
    sort_order = 'sort_order_example' # str | Sort asc/desc (defaults to desc for default sort, asc otherwise) (optional)
    version_or_stage = 'version_or_stage_example' # str | Filter to components that have this version or stage; also used for metadata (latest, development, staging, production, or version number; defaults to latest) (optional)

    try:
        # Lists Shared Configuration Components
        api_response = api_instance.list_shared_configuration_components(name=name, project_id=project_id, include_deleted=include_deleted, limit=limit, after_key=after_key, sort_type=sort_type, sort_order=sort_order, version_or_stage=version_or_stage)
        print("The response of ConfigurationApi->list_shared_configuration_components:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->list_shared_configuration_components: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**| Name Search (partial match, case-insensitive) | [optional] 
 **project_id** | [**List[str]**](str.md)| Project ID | [optional] 
 **include_deleted** | **bool**| Include Deleted Components | [optional] 
 **limit** | **int**| Limit (defaults to 10, max 1000) | [optional] 
 **after_key** | **str**| Pagination Key | [optional] 
 **sort_type** | **str**| Sort Type (default, name) | [optional] 
 **sort_order** | **str**| Sort asc/desc (defaults to desc for default sort, asc otherwise) | [optional] 
 **version_or_stage** | **str**| Filter to components that have this version or stage; also used for metadata (latest, development, staging, production, or version number; defaults to latest) | [optional] 

### Return type

[**OutputPaginatedResponseModelConfigurationComponentSummary**](OutputPaginatedResponseModelConfigurationComponentSummary.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_shared_configuration_versions**
> OutputPaginatedResponseModelConfigurationComponentVersionSummary list_shared_configuration_versions(component_id, include_deleted=include_deleted, limit=limit, after_key=after_key, sort_order=sort_order)

Lists Shared Configuration Component versions

Lists Shared Configuration Component versions for a component

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_paginated_response_model_configuration_component_version_summary import OutputPaginatedResponseModelConfigurationComponentVersionSummary
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    component_id = 'component_id_example' # str | Component ID
    include_deleted = True # bool | Include Deleted Versions (optional)
    limit = 56 # int | Limit (defaults to 10, max 1000) (optional)
    after_key = 'after_key_example' # str | Pagination Key (optional)
    sort_order = 'sort_order_example' # str | Sort asc/desc (defaults to desc) (optional)

    try:
        # Lists Shared Configuration Component versions
        api_response = api_instance.list_shared_configuration_versions(component_id, include_deleted=include_deleted, limit=limit, after_key=after_key, sort_order=sort_order)
        print("The response of ConfigurationApi->list_shared_configuration_versions:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->list_shared_configuration_versions: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **component_id** | **str**| Component ID | 
 **include_deleted** | **bool**| Include Deleted Versions | [optional] 
 **limit** | **int**| Limit (defaults to 10, max 1000) | [optional] 
 **after_key** | **str**| Pagination Key | [optional] 
 **sort_order** | **str**| Sort asc/desc (defaults to desc) | [optional] 

### Return type

[**OutputPaginatedResponseModelConfigurationComponentVersionSummary**](OutputPaginatedResponseModelConfigurationComponentVersionSummary.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_tool_profile_configuration_components**
> OutputPaginatedResponseModelConfigurationComponentSummary list_tool_profile_configuration_components(name=name, project_id=project_id, include_deleted=include_deleted, limit=limit, after_key=after_key, sort_type=sort_type, sort_order=sort_order, version_or_stage=version_or_stage)

Lists Tool Profile Configuration Components

Lists Tool Profile Configuration Components

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_paginated_response_model_configuration_component_summary import OutputPaginatedResponseModelConfigurationComponentSummary
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    name = 'name_example' # str | Name Search (partial match, case-insensitive) (optional)
    project_id = ['project_id_example'] # List[str] | Project ID (optional)
    include_deleted = True # bool | Include Deleted Components (optional)
    limit = 56 # int | Limit (defaults to 10, max 1000) (optional)
    after_key = 'after_key_example' # str | Pagination Key (optional)
    sort_type = 'sort_type_example' # str | Sort Type (default, name) (optional)
    sort_order = 'sort_order_example' # str | Sort asc/desc (defaults to desc for default sort, asc otherwise) (optional)
    version_or_stage = 'version_or_stage_example' # str | Filter to components that have this version or stage; also used for metadata (latest, development, staging, production, or version number; defaults to latest) (optional)

    try:
        # Lists Tool Profile Configuration Components
        api_response = api_instance.list_tool_profile_configuration_components(name=name, project_id=project_id, include_deleted=include_deleted, limit=limit, after_key=after_key, sort_type=sort_type, sort_order=sort_order, version_or_stage=version_or_stage)
        print("The response of ConfigurationApi->list_tool_profile_configuration_components:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->list_tool_profile_configuration_components: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**| Name Search (partial match, case-insensitive) | [optional] 
 **project_id** | [**List[str]**](str.md)| Project ID | [optional] 
 **include_deleted** | **bool**| Include Deleted Components | [optional] 
 **limit** | **int**| Limit (defaults to 10, max 1000) | [optional] 
 **after_key** | **str**| Pagination Key | [optional] 
 **sort_type** | **str**| Sort Type (default, name) | [optional] 
 **sort_order** | **str**| Sort asc/desc (defaults to desc for default sort, asc otherwise) | [optional] 
 **version_or_stage** | **str**| Filter to components that have this version or stage; also used for metadata (latest, development, staging, production, or version number; defaults to latest) | [optional] 

### Return type

[**OutputPaginatedResponseModelConfigurationComponentSummary**](OutputPaginatedResponseModelConfigurationComponentSummary.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_tool_profile_configuration_versions**
> OutputPaginatedResponseModelConfigurationComponentVersionSummary list_tool_profile_configuration_versions(component_id, include_deleted=include_deleted, limit=limit, after_key=after_key, sort_order=sort_order)

Lists Tool Profile Configuration Component versions

Lists Tool Profile Configuration Component versions for a component

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_paginated_response_model_configuration_component_version_summary import OutputPaginatedResponseModelConfigurationComponentVersionSummary
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    component_id = 'component_id_example' # str | Component ID
    include_deleted = True # bool | Include Deleted Versions (optional)
    limit = 56 # int | Limit (defaults to 10, max 1000) (optional)
    after_key = 'after_key_example' # str | Pagination Key (optional)
    sort_order = 'sort_order_example' # str | Sort asc/desc (defaults to desc) (optional)

    try:
        # Lists Tool Profile Configuration Component versions
        api_response = api_instance.list_tool_profile_configuration_versions(component_id, include_deleted=include_deleted, limit=limit, after_key=after_key, sort_order=sort_order)
        print("The response of ConfigurationApi->list_tool_profile_configuration_versions:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->list_tool_profile_configuration_versions: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **component_id** | **str**| Component ID | 
 **include_deleted** | **bool**| Include Deleted Versions | [optional] 
 **limit** | **int**| Limit (defaults to 10, max 1000) | [optional] 
 **after_key** | **str**| Pagination Key | [optional] 
 **sort_order** | **str**| Sort asc/desc (defaults to desc) | [optional] 

### Return type

[**OutputPaginatedResponseModelConfigurationComponentVersionSummary**](OutputPaginatedResponseModelConfigurationComponentVersionSummary.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_workflow_configuration_components**
> OutputPaginatedResponseModelConfigurationComponentSummary list_workflow_configuration_components(name=name, project_id=project_id, include_deleted=include_deleted, limit=limit, after_key=after_key, sort_type=sort_type, sort_order=sort_order, version_or_stage=version_or_stage)

Lists Workflow Configuration Components

Lists Workflow Configuration Components

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_paginated_response_model_configuration_component_summary import OutputPaginatedResponseModelConfigurationComponentSummary
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    name = 'name_example' # str | Name Search (partial match, case-insensitive) (optional)
    project_id = ['project_id_example'] # List[str] | Project ID (optional)
    include_deleted = True # bool | Include Deleted Components (optional)
    limit = 56 # int | Limit (defaults to 10, max 1000) (optional)
    after_key = 'after_key_example' # str | Pagination Key (optional)
    sort_type = 'sort_type_example' # str | Sort Type (default, name) (optional)
    sort_order = 'sort_order_example' # str | Sort asc/desc (defaults to desc for default sort, asc otherwise) (optional)
    version_or_stage = 'version_or_stage_example' # str | Filter to components that have this version or stage; also used for metadata (latest, development, staging, production, or version number; defaults to latest) (optional)

    try:
        # Lists Workflow Configuration Components
        api_response = api_instance.list_workflow_configuration_components(name=name, project_id=project_id, include_deleted=include_deleted, limit=limit, after_key=after_key, sort_type=sort_type, sort_order=sort_order, version_or_stage=version_or_stage)
        print("The response of ConfigurationApi->list_workflow_configuration_components:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->list_workflow_configuration_components: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**| Name Search (partial match, case-insensitive) | [optional] 
 **project_id** | [**List[str]**](str.md)| Project ID | [optional] 
 **include_deleted** | **bool**| Include Deleted Components | [optional] 
 **limit** | **int**| Limit (defaults to 10, max 1000) | [optional] 
 **after_key** | **str**| Pagination Key | [optional] 
 **sort_type** | **str**| Sort Type (default, name) | [optional] 
 **sort_order** | **str**| Sort asc/desc (defaults to desc for default sort, asc otherwise) | [optional] 
 **version_or_stage** | **str**| Filter to components that have this version or stage; also used for metadata (latest, development, staging, production, or version number; defaults to latest) | [optional] 

### Return type

[**OutputPaginatedResponseModelConfigurationComponentSummary**](OutputPaginatedResponseModelConfigurationComponentSummary.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_workflow_configuration_versions**
> OutputPaginatedResponseModelConfigurationComponentVersionSummary list_workflow_configuration_versions(component_id, include_deleted=include_deleted, limit=limit, after_key=after_key, sort_order=sort_order)

Lists Workflow Configuration Component versions

Lists Workflow Configuration Component versions for a component

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_paginated_response_model_configuration_component_version_summary import OutputPaginatedResponseModelConfigurationComponentVersionSummary
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    component_id = 'component_id_example' # str | Component ID
    include_deleted = True # bool | Include Deleted Versions (optional)
    limit = 56 # int | Limit (defaults to 10, max 1000) (optional)
    after_key = 'after_key_example' # str | Pagination Key (optional)
    sort_order = 'sort_order_example' # str | Sort asc/desc (defaults to desc) (optional)

    try:
        # Lists Workflow Configuration Component versions
        api_response = api_instance.list_workflow_configuration_versions(component_id, include_deleted=include_deleted, limit=limit, after_key=after_key, sort_order=sort_order)
        print("The response of ConfigurationApi->list_workflow_configuration_versions:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->list_workflow_configuration_versions: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **component_id** | **str**| Component ID | 
 **include_deleted** | **bool**| Include Deleted Versions | [optional] 
 **limit** | **int**| Limit (defaults to 10, max 1000) | [optional] 
 **after_key** | **str**| Pagination Key | [optional] 
 **sort_order** | **str**| Sort asc/desc (defaults to desc) | [optional] 

### Return type

[**OutputPaginatedResponseModelConfigurationComponentVersionSummary**](OutputPaginatedResponseModelConfigurationComponentVersionSummary.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **test_mcp_configuration_connection_from_version**
> OutputResponseModelMCPConnectionTestResult test_mcp_configuration_connection_from_version(version_id)

Test MCP Configuration Connection

Tests the MCP Connection of an MCP Configuration. Returns connected tools on success.

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_response_model_mcp_connection_test_result import OutputResponseModelMCPConnectionTestResult
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    version_id = 'version_id_example' # str | Version ID

    try:
        # Test MCP Configuration Connection
        api_response = api_instance.test_mcp_configuration_connection_from_version(version_id)
        print("The response of ConfigurationApi->test_mcp_configuration_connection_from_version:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->test_mcp_configuration_connection_from_version: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version_id** | **str**| Version ID | 

### Return type

[**OutputResponseModelMCPConnectionTestResult**](OutputResponseModelMCPConnectionTestResult.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**418** | I&#39;m a teapot |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_agent_configuration_component**
> OutputResponseModelConfigurationComponentBase update_agent_configuration_component(component_id, body)

Updates an Agent Configuration Component

Updates an Agent Configuration Component.

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_update_configuration_component_request import InputUpdateConfigurationComponentRequest
from chariot_api._openapi.awm.models.output_response_model_configuration_component_base import OutputResponseModelConfigurationComponentBase
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    component_id = 'component_id_example' # str | Component ID
    body = chariot_api._openapi.awm.InputUpdateConfigurationComponentRequest() # InputUpdateConfigurationComponentRequest | Request Body

    try:
        # Updates an Agent Configuration Component
        api_response = api_instance.update_agent_configuration_component(component_id, body)
        print("The response of ConfigurationApi->update_agent_configuration_component:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->update_agent_configuration_component: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **component_id** | **str**| Component ID | 
 **body** | [**InputUpdateConfigurationComponentRequest**](InputUpdateConfigurationComponentRequest.md)| Request Body | 

### Return type

[**OutputResponseModelConfigurationComponentBase**](OutputResponseModelConfigurationComponentBase.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_evaluator_configuration_component**
> OutputResponseModelConfigurationComponentBase update_evaluator_configuration_component(component_id, body)

Updates an Evaluator Configuration Component

Updates an Evaluator Configuration Component.

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_update_configuration_component_request import InputUpdateConfigurationComponentRequest
from chariot_api._openapi.awm.models.output_response_model_configuration_component_base import OutputResponseModelConfigurationComponentBase
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    component_id = 'component_id_example' # str | Component ID
    body = chariot_api._openapi.awm.InputUpdateConfigurationComponentRequest() # InputUpdateConfigurationComponentRequest | Request Body

    try:
        # Updates an Evaluator Configuration Component
        api_response = api_instance.update_evaluator_configuration_component(component_id, body)
        print("The response of ConfigurationApi->update_evaluator_configuration_component:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->update_evaluator_configuration_component: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **component_id** | **str**| Component ID | 
 **body** | [**InputUpdateConfigurationComponentRequest**](InputUpdateConfigurationComponentRequest.md)| Request Body | 

### Return type

[**OutputResponseModelConfigurationComponentBase**](OutputResponseModelConfigurationComponentBase.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_mcp_connection_configuration_component**
> OutputResponseModelConfigurationComponentBase update_mcp_connection_configuration_component(component_id, body)

Updates an MCP Connection Configuration Component

Updates an MCP Connection Configuration Component.

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_update_configuration_component_request import InputUpdateConfigurationComponentRequest
from chariot_api._openapi.awm.models.output_response_model_configuration_component_base import OutputResponseModelConfigurationComponentBase
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    component_id = 'component_id_example' # str | Component ID
    body = chariot_api._openapi.awm.InputUpdateConfigurationComponentRequest() # InputUpdateConfigurationComponentRequest | Request Body

    try:
        # Updates an MCP Connection Configuration Component
        api_response = api_instance.update_mcp_connection_configuration_component(component_id, body)
        print("The response of ConfigurationApi->update_mcp_connection_configuration_component:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->update_mcp_connection_configuration_component: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **component_id** | **str**| Component ID | 
 **body** | [**InputUpdateConfigurationComponentRequest**](InputUpdateConfigurationComponentRequest.md)| Request Body | 

### Return type

[**OutputResponseModelConfigurationComponentBase**](OutputResponseModelConfigurationComponentBase.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_shared_configuration_component**
> OutputResponseModelConfigurationComponentBase update_shared_configuration_component(component_id, body)

Updates a Shared Configuration Component

Updates a Shared Configuration Component.

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_update_configuration_component_request import InputUpdateConfigurationComponentRequest
from chariot_api._openapi.awm.models.output_response_model_configuration_component_base import OutputResponseModelConfigurationComponentBase
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    component_id = 'component_id_example' # str | Component ID
    body = chariot_api._openapi.awm.InputUpdateConfigurationComponentRequest() # InputUpdateConfigurationComponentRequest | Request Body

    try:
        # Updates a Shared Configuration Component
        api_response = api_instance.update_shared_configuration_component(component_id, body)
        print("The response of ConfigurationApi->update_shared_configuration_component:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->update_shared_configuration_component: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **component_id** | **str**| Component ID | 
 **body** | [**InputUpdateConfigurationComponentRequest**](InputUpdateConfigurationComponentRequest.md)| Request Body | 

### Return type

[**OutputResponseModelConfigurationComponentBase**](OutputResponseModelConfigurationComponentBase.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_tool_profile_configuration_component**
> OutputResponseModelConfigurationComponentBase update_tool_profile_configuration_component(component_id, body)

Updates a Tool Profile Configuration Component

Updates a Tool Profile Configuration Component.

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_update_configuration_component_request import InputUpdateConfigurationComponentRequest
from chariot_api._openapi.awm.models.output_response_model_configuration_component_base import OutputResponseModelConfigurationComponentBase
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    component_id = 'component_id_example' # str | Component ID
    body = chariot_api._openapi.awm.InputUpdateConfigurationComponentRequest() # InputUpdateConfigurationComponentRequest | Request Body

    try:
        # Updates a Tool Profile Configuration Component
        api_response = api_instance.update_tool_profile_configuration_component(component_id, body)
        print("The response of ConfigurationApi->update_tool_profile_configuration_component:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->update_tool_profile_configuration_component: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **component_id** | **str**| Component ID | 
 **body** | [**InputUpdateConfigurationComponentRequest**](InputUpdateConfigurationComponentRequest.md)| Request Body | 

### Return type

[**OutputResponseModelConfigurationComponentBase**](OutputResponseModelConfigurationComponentBase.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_workflow_configuration_component**
> OutputResponseModelConfigurationComponentBase update_workflow_configuration_component(component_id, body)

Updates a Workflow Configuration Component

Updates a Workflow Configuration Component.

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_update_configuration_component_request import InputUpdateConfigurationComponentRequest
from chariot_api._openapi.awm.models.output_response_model_configuration_component_base import OutputResponseModelConfigurationComponentBase
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ConfigurationApi(api_client)
    component_id = 'component_id_example' # str | Component ID
    body = chariot_api._openapi.awm.InputUpdateConfigurationComponentRequest() # InputUpdateConfigurationComponentRequest | Request Body

    try:
        # Updates a Workflow Configuration Component
        api_response = api_instance.update_workflow_configuration_component(component_id, body)
        print("The response of ConfigurationApi->update_workflow_configuration_component:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ConfigurationApi->update_workflow_configuration_component: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **component_id** | **str**| Component ID | 
 **body** | [**InputUpdateConfigurationComponentRequest**](InputUpdateConfigurationComponentRequest.md)| Request Body | 

### Return type

[**OutputResponseModelConfigurationComponentBase**](OutputResponseModelConfigurationComponentBase.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


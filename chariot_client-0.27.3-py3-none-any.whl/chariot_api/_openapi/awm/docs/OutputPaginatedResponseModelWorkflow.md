# OutputPaginatedResponseModelWorkflow


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**after_key** | **str** |  | [optional] 
**data** | [**List[ModelWorkflow]**](ModelWorkflow.md) |  | [optional] 
**metadata** | [**OutputPaginatedMetadata**](OutputPaginatedMetadata.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_paginated_response_model_workflow import OutputPaginatedResponseModelWorkflow

# TODO update the JSON string below
json = "{}"
# create an instance of OutputPaginatedResponseModelWorkflow from a JSON string
output_paginated_response_model_workflow_instance = OutputPaginatedResponseModelWorkflow.from_json(json)
# print the JSON string representation of the object
print(OutputPaginatedResponseModelWorkflow.to_json())

# convert the object into a dict
output_paginated_response_model_workflow_dict = output_paginated_response_model_workflow_instance.to_dict()
# create an instance of OutputPaginatedResponseModelWorkflow from a dict
output_paginated_response_model_workflow_from_dict = OutputPaginatedResponseModelWorkflow.from_dict(output_paginated_response_model_workflow_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



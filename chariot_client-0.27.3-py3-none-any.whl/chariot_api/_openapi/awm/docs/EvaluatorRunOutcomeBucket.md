# EvaluatorRunOutcomeBucket


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**completed** | **int** |  | [optional] 
**errored** | **int** |  | [optional] 
**guardrail_triggered** | **int** |  | [optional] 
**start** | **str** |  | [optional] 
**timed_out** | **int** |  | [optional] 
**total** | **int** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.evaluator_run_outcome_bucket import EvaluatorRunOutcomeBucket

# TODO update the JSON string below
json = "{}"
# create an instance of EvaluatorRunOutcomeBucket from a JSON string
evaluator_run_outcome_bucket_instance = EvaluatorRunOutcomeBucket.from_json(json)
# print the JSON string representation of the object
print(EvaluatorRunOutcomeBucket.to_json())

# convert the object into a dict
evaluator_run_outcome_bucket_dict = evaluator_run_outcome_bucket_instance.to_dict()
# create an instance of EvaluatorRunOutcomeBucket from a dict
evaluator_run_outcome_bucket_from_dict = EvaluatorRunOutcomeBucket.from_dict(evaluator_run_outcome_bucket_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# ModelConfigurationComponentVersionSummary


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**component_id** | **str** |  | [optional] 
**component_type** | **str** |  | [optional] 
**created_at** | **str** |  | [optional] 
**created_by** | **str** |  | [optional] 
**deleted_at** | **str** |  | [optional] 
**deleted_by** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**id** | **str** |  | [optional] 
**key** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**project_id** | **str** |  | [optional] 
**stages** | **List[str]** |  | [optional] 
**version** | **int** |  | [optional] 
**version_changelog** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_configuration_component_version_summary import ModelConfigurationComponentVersionSummary

# TODO update the JSON string below
json = "{}"
# create an instance of ModelConfigurationComponentVersionSummary from a JSON string
model_configuration_component_version_summary_instance = ModelConfigurationComponentVersionSummary.from_json(json)
# print the JSON string representation of the object
print(ModelConfigurationComponentVersionSummary.to_json())

# convert the object into a dict
model_configuration_component_version_summary_dict = model_configuration_component_version_summary_instance.to_dict()
# create an instance of ModelConfigurationComponentVersionSummary from a dict
model_configuration_component_version_summary_from_dict = ModelConfigurationComponentVersionSummary.from_dict(model_configuration_component_version_summary_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



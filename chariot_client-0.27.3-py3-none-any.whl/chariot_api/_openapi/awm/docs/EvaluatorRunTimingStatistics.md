# EvaluatorRunTimingStatistics


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**average** | **float** |  | [optional] 
**p50** | **float** |  | [optional] 
**p95** | **float** |  | [optional] 
**p99** | **float** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.evaluator_run_timing_statistics import EvaluatorRunTimingStatistics

# TODO update the JSON string below
json = "{}"
# create an instance of EvaluatorRunTimingStatistics from a JSON string
evaluator_run_timing_statistics_instance = EvaluatorRunTimingStatistics.from_json(json)
# print the JSON string representation of the object
print(EvaluatorRunTimingStatistics.to_json())

# convert the object into a dict
evaluator_run_timing_statistics_dict = evaluator_run_timing_statistics_instance.to_dict()
# create an instance of EvaluatorRunTimingStatistics from a dict
evaluator_run_timing_statistics_from_dict = EvaluatorRunTimingStatistics.from_dict(evaluator_run_timing_statistics_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



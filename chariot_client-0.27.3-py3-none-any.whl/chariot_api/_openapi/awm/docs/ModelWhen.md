# ModelWhen


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**all** | [**List[ModelCondition]**](ModelCondition.md) |  | [optional] 
**any** | [**List[ModelCondition]**](ModelCondition.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_when import ModelWhen

# TODO update the JSON string below
json = "{}"
# create an instance of ModelWhen from a JSON string
model_when_instance = ModelWhen.from_json(json)
# print the JSON string representation of the object
print(ModelWhen.to_json())

# convert the object into a dict
model_when_dict = model_when_instance.to_dict()
# create an instance of ModelWhen from a dict
model_when_from_dict = ModelWhen.from_dict(model_when_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



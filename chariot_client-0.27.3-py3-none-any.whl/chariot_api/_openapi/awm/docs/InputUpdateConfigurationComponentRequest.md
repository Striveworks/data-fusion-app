# InputUpdateConfigurationComponentRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.input_update_configuration_component_request import InputUpdateConfigurationComponentRequest

# TODO update the JSON string below
json = "{}"
# create an instance of InputUpdateConfigurationComponentRequest from a JSON string
input_update_configuration_component_request_instance = InputUpdateConfigurationComponentRequest.from_json(json)
# print the JSON string representation of the object
print(InputUpdateConfigurationComponentRequest.to_json())

# convert the object into a dict
input_update_configuration_component_request_dict = input_update_configuration_component_request_instance.to_dict()
# create an instance of InputUpdateConfigurationComponentRequest from a dict
input_update_configuration_component_request_from_dict = InputUpdateConfigurationComponentRequest.from_dict(input_update_configuration_component_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



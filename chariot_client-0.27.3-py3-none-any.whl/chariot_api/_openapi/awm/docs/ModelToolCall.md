# ModelToolCall


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**approval_activities** | [**List[ModelActivity]**](ModelActivity.md) |  | [optional] 
**decision_activity** | [**ModelActivity**](ModelActivity.md) |  | [optional] 
**id** | **str** |  | [optional] 
**request_activity** | [**ModelActivity**](ModelActivity.md) |  | [optional] 
**response_activities** | [**List[ModelActivity]**](ModelActivity.md) |  | [optional] 
**workflow_id** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_tool_call import ModelToolCall

# TODO update the JSON string below
json = "{}"
# create an instance of ModelToolCall from a JSON string
model_tool_call_instance = ModelToolCall.from_json(json)
# print the JSON string representation of the object
print(ModelToolCall.to_json())

# convert the object into a dict
model_tool_call_dict = model_tool_call_instance.to_dict()
# create an instance of ModelToolCall from a dict
model_tool_call_from_dict = ModelToolCall.from_dict(model_tool_call_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# ModelToolDisplay


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**deferred** | **str** |  | [optional] 
**executing** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_tool_display import ModelToolDisplay

# TODO update the JSON string below
json = "{}"
# create an instance of ModelToolDisplay from a JSON string
model_tool_display_instance = ModelToolDisplay.from_json(json)
# print the JSON string representation of the object
print(ModelToolDisplay.to_json())

# convert the object into a dict
model_tool_display_dict = model_tool_display_instance.to_dict()
# create an instance of ModelToolDisplay from a dict
model_tool_display_from_dict = ModelToolDisplay.from_dict(model_tool_display_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



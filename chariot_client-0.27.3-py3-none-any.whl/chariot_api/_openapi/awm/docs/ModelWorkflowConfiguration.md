# ModelWorkflowConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**agent_graph** | [**ModelAgentGraphConfiguration**](ModelAgentGraphConfiguration.md) |  | [optional] 
**auth_providers** | **List[str]** |  | [optional] 
**overrides** | [**Dict[str, ModelPublicSettingValue]**](ModelPublicSettingValue.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_workflow_configuration import ModelWorkflowConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of ModelWorkflowConfiguration from a JSON string
model_workflow_configuration_instance = ModelWorkflowConfiguration.from_json(json)
# print the JSON string representation of the object
print(ModelWorkflowConfiguration.to_json())

# convert the object into a dict
model_workflow_configuration_dict = model_workflow_configuration_instance.to_dict()
# create an instance of ModelWorkflowConfiguration from a dict
model_workflow_configuration_from_dict = ModelWorkflowConfiguration.from_dict(model_workflow_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



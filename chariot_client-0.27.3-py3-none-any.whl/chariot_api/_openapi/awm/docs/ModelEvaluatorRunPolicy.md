# ModelEvaluatorRunPolicy


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**evaluator_retries** | **int** |  | [optional] 
**mode** | **str** |  | [optional] 
**timeout_seconds** | **float** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_evaluator_run_policy import ModelEvaluatorRunPolicy

# TODO update the JSON string below
json = "{}"
# create an instance of ModelEvaluatorRunPolicy from a JSON string
model_evaluator_run_policy_instance = ModelEvaluatorRunPolicy.from_json(json)
# print the JSON string representation of the object
print(ModelEvaluatorRunPolicy.to_json())

# convert the object into a dict
model_evaluator_run_policy_dict = model_evaluator_run_policy_instance.to_dict()
# create an instance of ModelEvaluatorRunPolicy from a dict
model_evaluator_run_policy_from_dict = ModelEvaluatorRunPolicy.from_dict(model_evaluator_run_policy_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



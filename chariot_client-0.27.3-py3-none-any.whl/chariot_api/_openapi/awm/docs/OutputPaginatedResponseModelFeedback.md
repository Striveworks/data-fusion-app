# OutputPaginatedResponseModelFeedback


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**after_key** | **str** |  | [optional] 
**data** | [**List[ModelFeedback]**](ModelFeedback.md) |  | [optional] 
**metadata** | [**OutputPaginatedMetadata**](OutputPaginatedMetadata.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_paginated_response_model_feedback import OutputPaginatedResponseModelFeedback

# TODO update the JSON string below
json = "{}"
# create an instance of OutputPaginatedResponseModelFeedback from a JSON string
output_paginated_response_model_feedback_instance = OutputPaginatedResponseModelFeedback.from_json(json)
# print the JSON string representation of the object
print(OutputPaginatedResponseModelFeedback.to_json())

# convert the object into a dict
output_paginated_response_model_feedback_dict = output_paginated_response_model_feedback_instance.to_dict()
# create an instance of OutputPaginatedResponseModelFeedback from a dict
output_paginated_response_model_feedback_from_dict = OutputPaginatedResponseModelFeedback.from_dict(output_paginated_response_model_feedback_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# chariot_api._openapi.awm.WorkApi

All URIs are relative to */api/awm/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**submit_work_result**](WorkApi.md#submit_work_result) | **POST** /work-result | Submit a work result


# **submit_work_result**
> OutputResponseModelActivity submit_work_result(chariot_service_identity, body)

Submit a work result

Currently accepts only evaluator_result from AWE. result is a JSON object whose fields depend on type and are validated by AWM. work_id is the work request activity ID. AWM supplies request metadata from that activity. Identical repeats reuse the saved response; conflicting results return 409. AWM owns the activity ID and routing. A 202 means the response was persisted and queued for the existing activity worker.

### Example


```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_work_result_request import InputWorkResultRequest
from chariot_api._openapi.awm.models.output_response_model_activity import OutputResponseModelActivity
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)


# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.WorkApi(api_client)
    chariot_service_identity = 'chariot_service_identity_example' # str | AWE service identity
    body = chariot_api._openapi.awm.InputWorkResultRequest() # InputWorkResultRequest | Work ID, result type, and result payload

    try:
        # Submit a work result
        api_response = api_instance.submit_work_result(chariot_service_identity, body)
        print("The response of WorkApi->submit_work_result:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling WorkApi->submit_work_result: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **chariot_service_identity** | **str**| AWE service identity | 
 **body** | [**InputWorkResultRequest**](InputWorkResultRequest.md)| Work ID, result type, and result payload | 

### Return type

[**OutputResponseModelActivity**](OutputResponseModelActivity.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**202** | Accepted |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


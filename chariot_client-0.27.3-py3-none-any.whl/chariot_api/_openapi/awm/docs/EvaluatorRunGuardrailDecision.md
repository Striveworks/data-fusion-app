# EvaluatorRunGuardrailDecision


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enforced_action** | **str** |  | [optional] 
**triggered** | **bool** |  | [optional] 
**would_have_triggered** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.evaluator_run_guardrail_decision import EvaluatorRunGuardrailDecision

# TODO update the JSON string below
json = "{}"
# create an instance of EvaluatorRunGuardrailDecision from a JSON string
evaluator_run_guardrail_decision_instance = EvaluatorRunGuardrailDecision.from_json(json)
# print the JSON string representation of the object
print(EvaluatorRunGuardrailDecision.to_json())

# convert the object into a dict
evaluator_run_guardrail_decision_dict = evaluator_run_guardrail_decision_instance.to_dict()
# create an instance of EvaluatorRunGuardrailDecision from a dict
evaluator_run_guardrail_decision_from_dict = EvaluatorRunGuardrailDecision.from_dict(evaluator_run_guardrail_decision_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



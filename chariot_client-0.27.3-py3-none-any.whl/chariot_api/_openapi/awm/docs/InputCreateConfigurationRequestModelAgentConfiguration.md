# InputCreateConfigurationRequestModelAgentConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**config** | **List[int]** |  | 
**description** | **str** |  | [optional] 
**key** | **str** |  | 
**name** | **str** |  | 
**project_id** | **str** |  | 
**stage** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.input_create_configuration_request_model_agent_configuration import InputCreateConfigurationRequestModelAgentConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of InputCreateConfigurationRequestModelAgentConfiguration from a JSON string
input_create_configuration_request_model_agent_configuration_instance = InputCreateConfigurationRequestModelAgentConfiguration.from_json(json)
# print the JSON string representation of the object
print(InputCreateConfigurationRequestModelAgentConfiguration.to_json())

# convert the object into a dict
input_create_configuration_request_model_agent_configuration_dict = input_create_configuration_request_model_agent_configuration_instance.to_dict()
# create an instance of InputCreateConfigurationRequestModelAgentConfiguration from a dict
input_create_configuration_request_model_agent_configuration_from_dict = InputCreateConfigurationRequestModelAgentConfiguration.from_dict(input_create_configuration_request_model_agent_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



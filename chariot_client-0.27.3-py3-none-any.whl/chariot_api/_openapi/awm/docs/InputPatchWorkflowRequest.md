# InputPatchWorkflowRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**paused** | **bool** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.input_patch_workflow_request import InputPatchWorkflowRequest

# TODO update the JSON string below
json = "{}"
# create an instance of InputPatchWorkflowRequest from a JSON string
input_patch_workflow_request_instance = InputPatchWorkflowRequest.from_json(json)
# print the JSON string representation of the object
print(InputPatchWorkflowRequest.to_json())

# convert the object into a dict
input_patch_workflow_request_dict = input_patch_workflow_request_instance.to_dict()
# create an instance of InputPatchWorkflowRequest from a dict
input_patch_workflow_request_from_dict = InputPatchWorkflowRequest.from_dict(input_patch_workflow_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



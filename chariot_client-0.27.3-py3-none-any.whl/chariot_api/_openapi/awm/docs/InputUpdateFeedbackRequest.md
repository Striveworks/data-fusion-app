# InputUpdateFeedbackRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**comment** | **str** |  | [optional] 
**thumbs_up** | **bool** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.input_update_feedback_request import InputUpdateFeedbackRequest

# TODO update the JSON string below
json = "{}"
# create an instance of InputUpdateFeedbackRequest from a JSON string
input_update_feedback_request_instance = InputUpdateFeedbackRequest.from_json(json)
# print the JSON string representation of the object
print(InputUpdateFeedbackRequest.to_json())

# convert the object into a dict
input_update_feedback_request_dict = input_update_feedback_request_instance.to_dict()
# create an instance of InputUpdateFeedbackRequest from a dict
input_update_feedback_request_from_dict = InputUpdateFeedbackRequest.from_dict(input_update_feedback_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



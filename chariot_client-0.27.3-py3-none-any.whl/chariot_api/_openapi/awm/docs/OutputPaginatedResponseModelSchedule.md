# OutputPaginatedResponseModelSchedule


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**after_key** | **str** |  | [optional] 
**data** | [**List[ModelSchedule]**](ModelSchedule.md) |  | [optional] 
**metadata** | [**OutputPaginatedMetadata**](OutputPaginatedMetadata.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_paginated_response_model_schedule import OutputPaginatedResponseModelSchedule

# TODO update the JSON string below
json = "{}"
# create an instance of OutputPaginatedResponseModelSchedule from a JSON string
output_paginated_response_model_schedule_instance = OutputPaginatedResponseModelSchedule.from_json(json)
# print the JSON string representation of the object
print(OutputPaginatedResponseModelSchedule.to_json())

# convert the object into a dict
output_paginated_response_model_schedule_dict = output_paginated_response_model_schedule_instance.to_dict()
# create an instance of OutputPaginatedResponseModelSchedule from a dict
output_paginated_response_model_schedule_from_dict = OutputPaginatedResponseModelSchedule.from_dict(output_paginated_response_model_schedule_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



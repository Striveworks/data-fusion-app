# ModelWorkflowAuthProvider


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**connected** | **bool** |  | [optional] 
**name** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_workflow_auth_provider import ModelWorkflowAuthProvider

# TODO update the JSON string below
json = "{}"
# create an instance of ModelWorkflowAuthProvider from a JSON string
model_workflow_auth_provider_instance = ModelWorkflowAuthProvider.from_json(json)
# print the JSON string representation of the object
print(ModelWorkflowAuthProvider.to_json())

# convert the object into a dict
model_workflow_auth_provider_dict = model_workflow_auth_provider_instance.to_dict()
# create an instance of ModelWorkflowAuthProvider from a dict
model_workflow_auth_provider_from_dict = ModelWorkflowAuthProvider.from_dict(model_workflow_auth_provider_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# InputCreateWorkflowConfigurationRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**config** | **List[int]** |  | 
**description** | **str** |  | [optional] 
**key** | **str** |  | 
**name** | **str** |  | 
**paused** | **bool** |  | [optional] 
**project_id** | **str** |  | 
**stage** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.input_create_workflow_configuration_request import InputCreateWorkflowConfigurationRequest

# TODO update the JSON string below
json = "{}"
# create an instance of InputCreateWorkflowConfigurationRequest from a JSON string
input_create_workflow_configuration_request_instance = InputCreateWorkflowConfigurationRequest.from_json(json)
# print the JSON string representation of the object
print(InputCreateWorkflowConfigurationRequest.to_json())

# convert the object into a dict
input_create_workflow_configuration_request_dict = input_create_workflow_configuration_request_instance.to_dict()
# create an instance of InputCreateWorkflowConfigurationRequest from a dict
input_create_workflow_configuration_request_from_dict = InputCreateWorkflowConfigurationRequest.from_dict(input_create_workflow_configuration_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# ModelThinkingSummarizationSettings


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **bool** |  | [optional] 
**model_settings** | [**ModelModelConfiguration**](ModelModelConfiguration.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_thinking_summarization_settings import ModelThinkingSummarizationSettings

# TODO update the JSON string below
json = "{}"
# create an instance of ModelThinkingSummarizationSettings from a JSON string
model_thinking_summarization_settings_instance = ModelThinkingSummarizationSettings.from_json(json)
# print the JSON string representation of the object
print(ModelThinkingSummarizationSettings.to_json())

# convert the object into a dict
model_thinking_summarization_settings_dict = model_thinking_summarization_settings_instance.to_dict()
# create an instance of ModelThinkingSummarizationSettings from a dict
model_thinking_summarization_settings_from_dict = ModelThinkingSummarizationSettings.from_dict(model_thinking_summarization_settings_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



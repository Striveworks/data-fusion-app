# OutputResponseModelWorkflow


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**ModelWorkflow**](ModelWorkflow.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_response_model_workflow import OutputResponseModelWorkflow

# TODO update the JSON string below
json = "{}"
# create an instance of OutputResponseModelWorkflow from a JSON string
output_response_model_workflow_instance = OutputResponseModelWorkflow.from_json(json)
# print the JSON string representation of the object
print(OutputResponseModelWorkflow.to_json())

# convert the object into a dict
output_response_model_workflow_dict = output_response_model_workflow_instance.to_dict()
# create an instance of OutputResponseModelWorkflow from a dict
output_response_model_workflow_from_dict = OutputResponseModelWorkflow.from_dict(output_response_model_workflow_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



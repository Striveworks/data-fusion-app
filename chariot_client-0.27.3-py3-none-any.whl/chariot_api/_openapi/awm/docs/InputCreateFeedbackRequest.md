# InputCreateFeedbackRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**activity_id** | **str** |  | [optional] 
**comment** | **str** |  | [optional] 
**source** | **str** |  | [optional] [default to 'user']
**thumbs_up** | **bool** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.input_create_feedback_request import InputCreateFeedbackRequest

# TODO update the JSON string below
json = "{}"
# create an instance of InputCreateFeedbackRequest from a JSON string
input_create_feedback_request_instance = InputCreateFeedbackRequest.from_json(json)
# print the JSON string representation of the object
print(InputCreateFeedbackRequest.to_json())

# convert the object into a dict
input_create_feedback_request_dict = input_create_feedback_request_instance.to_dict()
# create an instance of InputCreateFeedbackRequest from a dict
input_create_feedback_request_from_dict = InputCreateFeedbackRequest.from_dict(input_create_feedback_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



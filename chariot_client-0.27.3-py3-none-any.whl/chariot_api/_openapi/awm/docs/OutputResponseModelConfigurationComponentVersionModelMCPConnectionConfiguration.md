# OutputResponseModelConfigurationComponentVersionModelMCPConnectionConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**ModelConfigurationComponentVersionModelMCPConnectionConfiguration**](ModelConfigurationComponentVersionModelMCPConnectionConfiguration.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_response_model_configuration_component_version_model_mcp_connection_configuration import OutputResponseModelConfigurationComponentVersionModelMCPConnectionConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of OutputResponseModelConfigurationComponentVersionModelMCPConnectionConfiguration from a JSON string
output_response_model_configuration_component_version_model_mcp_connection_configuration_instance = OutputResponseModelConfigurationComponentVersionModelMCPConnectionConfiguration.from_json(json)
# print the JSON string representation of the object
print(OutputResponseModelConfigurationComponentVersionModelMCPConnectionConfiguration.to_json())

# convert the object into a dict
output_response_model_configuration_component_version_model_mcp_connection_configuration_dict = output_response_model_configuration_component_version_model_mcp_connection_configuration_instance.to_dict()
# create an instance of OutputResponseModelConfigurationComponentVersionModelMCPConnectionConfiguration from a dict
output_response_model_configuration_component_version_model_mcp_connection_configuration_from_dict = OutputResponseModelConfigurationComponentVersionModelMCPConnectionConfiguration.from_dict(output_response_model_configuration_component_version_model_mcp_connection_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# ModelWorkflow


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**component_id** | **str** |  | [optional] 
**config** | **object** |  | [optional] 
**created_at** | **str** |  | [optional] 
**created_by** | **str** |  | [optional] 
**deleted_at** | **str** |  | [optional] 
**deleted_by** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**id** | **str** |  | [optional] 
**key** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**paused** | **bool** |  | [optional] 
**project_id** | **str** |  | [optional] 
**public_settings** | [**Dict[str, ModelPublicSettingRef]**](ModelPublicSettingRef.md) |  | [optional] 
**updated_at** | **str** |  | [optional] 
**updated_by** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_workflow import ModelWorkflow

# TODO update the JSON string below
json = "{}"
# create an instance of ModelWorkflow from a JSON string
model_workflow_instance = ModelWorkflow.from_json(json)
# print the JSON string representation of the object
print(ModelWorkflow.to_json())

# convert the object into a dict
model_workflow_dict = model_workflow_instance.to_dict()
# create an instance of ModelWorkflow from a dict
model_workflow_from_dict = ModelWorkflow.from_dict(model_workflow_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



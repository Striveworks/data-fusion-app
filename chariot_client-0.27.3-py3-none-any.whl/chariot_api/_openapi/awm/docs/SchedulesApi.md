# chariot_api._openapi.awm.SchedulesApi

All URIs are relative to */api/awm/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create_schedule**](SchedulesApi.md#create_schedule) | **POST** /workflows/{workflowID}/schedules | Create Schedule
[**delete_schedule**](SchedulesApi.md#delete_schedule) | **DELETE** /schedules/{scheduleID} | Delete Schedule
[**get_schedule**](SchedulesApi.md#get_schedule) | **GET** /schedules/{scheduleID} | Get Schedule
[**list_schedules**](SchedulesApi.md#list_schedules) | **GET** /workflows/{workflowID}/schedules | List Schedules
[**update_schedule**](SchedulesApi.md#update_schedule) | **PUT** /schedules/{scheduleID} | Update Schedule


# **create_schedule**
> OutputResponseModelSchedule create_schedule(workflow_id, body)

Create Schedule

Creates a new schedule

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_upsert_schedule_request import InputUpsertScheduleRequest
from chariot_api._openapi.awm.models.output_response_model_schedule import OutputResponseModelSchedule
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.SchedulesApi(api_client)
    workflow_id = 'workflow_id_example' # str | Workflow ID
    body = chariot_api._openapi.awm.InputUpsertScheduleRequest() # InputUpsertScheduleRequest | Request Body

    try:
        # Create Schedule
        api_response = api_instance.create_schedule(workflow_id, body)
        print("The response of SchedulesApi->create_schedule:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SchedulesApi->create_schedule: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_id** | **str**| Workflow ID | 
 **body** | [**InputUpsertScheduleRequest**](InputUpsertScheduleRequest.md)| Request Body | 

### Return type

[**OutputResponseModelSchedule**](OutputResponseModelSchedule.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_schedule**
> str delete_schedule(schedule_id)

Delete Schedule

Deletes a schedule

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.SchedulesApi(api_client)
    schedule_id = 'schedule_id_example' # str | Schedule ID

    try:
        # Delete Schedule
        api_response = api_instance.delete_schedule(schedule_id)
        print("The response of SchedulesApi->delete_schedule:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SchedulesApi->delete_schedule: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **schedule_id** | **str**| Schedule ID | 

### Return type

**str**

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | No Content |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_schedule**
> OutputResponseModelSchedule get_schedule(schedule_id)

Get Schedule

Gets a schedule

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_response_model_schedule import OutputResponseModelSchedule
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.SchedulesApi(api_client)
    schedule_id = 'schedule_id_example' # str | Schedule ID

    try:
        # Get Schedule
        api_response = api_instance.get_schedule(schedule_id)
        print("The response of SchedulesApi->get_schedule:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SchedulesApi->get_schedule: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **schedule_id** | **str**| Schedule ID | 

### Return type

[**OutputResponseModelSchedule**](OutputResponseModelSchedule.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_schedules**
> OutputPaginatedResponseModelSchedule list_schedules(workflow_id, name=name, active=active, agent=agent, limit=limit, after_key=after_key)

List Schedules

Lists schedules

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_paginated_response_model_schedule import OutputPaginatedResponseModelSchedule
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.SchedulesApi(api_client)
    workflow_id = 'workflow_id_example' # str | Workflow ID
    name = 'name_example' # str | Name Search (partial match, case-insensitive) (optional)
    active = True # bool | Active (optional)
    agent = ['agent_example'] # List[str] | Agents (optional)
    limit = 56 # int | Limit (defaults to 10, max 1000) (optional)
    after_key = 'after_key_example' # str | Pagination Key (optional)

    try:
        # List Schedules
        api_response = api_instance.list_schedules(workflow_id, name=name, active=active, agent=agent, limit=limit, after_key=after_key)
        print("The response of SchedulesApi->list_schedules:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SchedulesApi->list_schedules: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_id** | **str**| Workflow ID | 
 **name** | **str**| Name Search (partial match, case-insensitive) | [optional] 
 **active** | **bool**| Active | [optional] 
 **agent** | [**List[str]**](str.md)| Agents | [optional] 
 **limit** | **int**| Limit (defaults to 10, max 1000) | [optional] 
 **after_key** | **str**| Pagination Key | [optional] 

### Return type

[**OutputPaginatedResponseModelSchedule**](OutputPaginatedResponseModelSchedule.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_schedule**
> OutputResponseModelSchedule update_schedule(schedule_id, body)

Update Schedule

Updates a schedule

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_upsert_schedule_request import InputUpsertScheduleRequest
from chariot_api._openapi.awm.models.output_response_model_schedule import OutputResponseModelSchedule
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.SchedulesApi(api_client)
    schedule_id = 'schedule_id_example' # str | Schedule ID
    body = chariot_api._openapi.awm.InputUpsertScheduleRequest() # InputUpsertScheduleRequest | Request Body

    try:
        # Update Schedule
        api_response = api_instance.update_schedule(schedule_id, body)
        print("The response of SchedulesApi->update_schedule:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SchedulesApi->update_schedule: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **schedule_id** | **str**| Schedule ID | 
 **body** | [**InputUpsertScheduleRequest**](InputUpsertScheduleRequest.md)| Request Body | 

### Return type

[**OutputResponseModelSchedule**](OutputResponseModelSchedule.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


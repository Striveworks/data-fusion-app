# OutputPaginatedResponseModelSessionDetails


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**after_key** | **str** |  | [optional] 
**data** | [**List[ModelSessionDetails]**](ModelSessionDetails.md) |  | [optional] 
**metadata** | [**OutputPaginatedMetadata**](OutputPaginatedMetadata.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_paginated_response_model_session_details import OutputPaginatedResponseModelSessionDetails

# TODO update the JSON string below
json = "{}"
# create an instance of OutputPaginatedResponseModelSessionDetails from a JSON string
output_paginated_response_model_session_details_instance = OutputPaginatedResponseModelSessionDetails.from_json(json)
# print the JSON string representation of the object
print(OutputPaginatedResponseModelSessionDetails.to_json())

# convert the object into a dict
output_paginated_response_model_session_details_dict = output_paginated_response_model_session_details_instance.to_dict()
# create an instance of OutputPaginatedResponseModelSessionDetails from a dict
output_paginated_response_model_session_details_from_dict = OutputPaginatedResponseModelSessionDetails.from_dict(output_paginated_response_model_session_details_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



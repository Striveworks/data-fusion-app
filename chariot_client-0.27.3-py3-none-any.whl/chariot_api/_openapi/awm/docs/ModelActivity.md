# ModelActivity


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**body** | **object** |  | [optional] 
**component_id** | **str** |  | [optional] 
**created_at** | **str** |  | [optional] 
**feedback** | [**List[ModelFeedback]**](ModelFeedback.md) | Feedback is the current caller&#39;s own feedback on this activity. Reviewer rows are included only while the caller still has AllSessions read access. | [optional] 
**final** | **bool** |  | [optional] 
**from_agent** | **str** |  | [optional] 
**id** | **str** |  | [optional] 
**processed_at** | **str** |  | [optional] 
**sequence** | **int** |  | [optional] 
**session_context_limit** | **int** |  | [optional] 
**session_context_size** | **int** |  | [optional] 
**session_id** | **str** |  | [optional] 
**to_agent** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**user_id** | **str** |  | [optional] 
**workflow_id** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_activity import ModelActivity

# TODO update the JSON string below
json = "{}"
# create an instance of ModelActivity from a JSON string
model_activity_instance = ModelActivity.from_json(json)
# print the JSON string representation of the object
print(ModelActivity.to_json())

# convert the object into a dict
model_activity_dict = model_activity_instance.to_dict()
# create an instance of ModelActivity from a dict
model_activity_from_dict = ModelActivity.from_dict(model_activity_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



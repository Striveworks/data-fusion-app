# OutputPaginatedResponseModelConfigurationComponentVersionSummary


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**after_key** | **str** |  | [optional] 
**data** | [**List[ModelConfigurationComponentVersionSummary]**](ModelConfigurationComponentVersionSummary.md) |  | [optional] 
**metadata** | [**OutputPaginatedMetadata**](OutputPaginatedMetadata.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_paginated_response_model_configuration_component_version_summary import OutputPaginatedResponseModelConfigurationComponentVersionSummary

# TODO update the JSON string below
json = "{}"
# create an instance of OutputPaginatedResponseModelConfigurationComponentVersionSummary from a JSON string
output_paginated_response_model_configuration_component_version_summary_instance = OutputPaginatedResponseModelConfigurationComponentVersionSummary.from_json(json)
# print the JSON string representation of the object
print(OutputPaginatedResponseModelConfigurationComponentVersionSummary.to_json())

# convert the object into a dict
output_paginated_response_model_configuration_component_version_summary_dict = output_paginated_response_model_configuration_component_version_summary_instance.to_dict()
# create an instance of OutputPaginatedResponseModelConfigurationComponentVersionSummary from a dict
output_paginated_response_model_configuration_component_version_summary_from_dict = OutputPaginatedResponseModelConfigurationComponentVersionSummary.from_dict(output_paginated_response_model_configuration_component_version_summary_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



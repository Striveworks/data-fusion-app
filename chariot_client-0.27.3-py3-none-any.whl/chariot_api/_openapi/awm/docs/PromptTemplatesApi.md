# chariot_api._openapi.awm.PromptTemplatesApi

All URIs are relative to */api/awm/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create_prompt_template**](PromptTemplatesApi.md#create_prompt_template) | **POST** /prompt-templates | Create Prompt Template
[**delete_prompt_template**](PromptTemplatesApi.md#delete_prompt_template) | **DELETE** /prompt-templates/{templateID} | Delete Prompt Template
[**get_prompt_template**](PromptTemplatesApi.md#get_prompt_template) | **GET** /prompt-templates/{templateID} | Get Prompt Template
[**list_prompt_templates**](PromptTemplatesApi.md#list_prompt_templates) | **GET** /prompt-templates | List Prompt Templates
[**update_prompt_template**](PromptTemplatesApi.md#update_prompt_template) | **PATCH** /prompt-templates/{templateID} | Update Prompt Template


# **create_prompt_template**
> OutputResponseModelPromptTemplate create_prompt_template(body)

Create Prompt Template

Creates a public or private prompt template in a project

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_create_prompt_template_request import InputCreatePromptTemplateRequest
from chariot_api._openapi.awm.models.output_response_model_prompt_template import OutputResponseModelPromptTemplate
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.PromptTemplatesApi(api_client)
    body = chariot_api._openapi.awm.InputCreatePromptTemplateRequest() # InputCreatePromptTemplateRequest | Request Body

    try:
        # Create Prompt Template
        api_response = api_instance.create_prompt_template(body)
        print("The response of PromptTemplatesApi->create_prompt_template:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PromptTemplatesApi->create_prompt_template: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**InputCreatePromptTemplateRequest**](InputCreatePromptTemplateRequest.md)| Request Body | 

### Return type

[**OutputResponseModelPromptTemplate**](OutputResponseModelPromptTemplate.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_prompt_template**
> str delete_prompt_template(template_id)

Delete Prompt Template

Permanently deletes a prompt template

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.PromptTemplatesApi(api_client)
    template_id = 'template_id_example' # str | Prompt Template ID

    try:
        # Delete Prompt Template
        api_response = api_instance.delete_prompt_template(template_id)
        print("The response of PromptTemplatesApi->delete_prompt_template:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PromptTemplatesApi->delete_prompt_template: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **template_id** | **str**| Prompt Template ID | 

### Return type

**str**

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | No Content |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_prompt_template**
> OutputResponseModelPromptTemplate get_prompt_template(template_id)

Get Prompt Template

Gets a single prompt template by ID

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_response_model_prompt_template import OutputResponseModelPromptTemplate
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.PromptTemplatesApi(api_client)
    template_id = 'template_id_example' # str | Prompt Template ID

    try:
        # Get Prompt Template
        api_response = api_instance.get_prompt_template(template_id)
        print("The response of PromptTemplatesApi->get_prompt_template:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PromptTemplatesApi->get_prompt_template: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **template_id** | **str**| Prompt Template ID | 

### Return type

[**OutputResponseModelPromptTemplate**](OutputResponseModelPromptTemplate.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_prompt_templates**
> OutputResponseArrayModelPromptTemplate list_prompt_templates(project_id, agent_id=agent_id, visibility=visibility, scope=scope, state=state, sort_type=sort_type, sort_order=sort_order)

List Prompt Templates

Lists prompt templates visible to the caller for the chat picker

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_response_array_model_prompt_template import OutputResponseArrayModelPromptTemplate
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.PromptTemplatesApi(api_client)
    project_id = 'project_id_example' # str | Project ID
    agent_id = 'agent_id_example' # str | Agent configuration component base ID (optional)
    visibility = 'visibility_example' # str | Filter by visibility (public or private) (optional)
    scope = 'scope_example' # str | Filter by scope (agent or global) (optional)
    state = enabled # str | Template state (defaults to enabled) (optional) (default to enabled)
    sort_type = 'sort_type_example' # str | Sort field (created_at or visibility; default created_at) (optional)
    sort_order = 'sort_order_example' # str | Sort order (ASC or DESC) (optional)

    try:
        # List Prompt Templates
        api_response = api_instance.list_prompt_templates(project_id, agent_id=agent_id, visibility=visibility, scope=scope, state=state, sort_type=sort_type, sort_order=sort_order)
        print("The response of PromptTemplatesApi->list_prompt_templates:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PromptTemplatesApi->list_prompt_templates: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_id** | **str**| Project ID | 
 **agent_id** | **str**| Agent configuration component base ID | [optional] 
 **visibility** | **str**| Filter by visibility (public or private) | [optional] 
 **scope** | **str**| Filter by scope (agent or global) | [optional] 
 **state** | **str**| Template state (defaults to enabled) | [optional] [default to enabled]
 **sort_type** | **str**| Sort field (created_at or visibility; default created_at) | [optional] 
 **sort_order** | **str**| Sort order (ASC or DESC) | [optional] 

### Return type

[**OutputResponseArrayModelPromptTemplate**](OutputResponseArrayModelPromptTemplate.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_prompt_template**
> OutputResponseModelPromptTemplate update_prompt_template(template_id, body)

Update Prompt Template

Partially updates mutable fields (name, description, content, enabled, visibility) on an existing prompt template. Omitted keys are left unchanged. Visibility may only be promoted from private to public on agent-scoped templates.

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_update_prompt_template_request import InputUpdatePromptTemplateRequest
from chariot_api._openapi.awm.models.output_response_model_prompt_template import OutputResponseModelPromptTemplate
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.PromptTemplatesApi(api_client)
    template_id = 'template_id_example' # str | Prompt Template ID
    body = chariot_api._openapi.awm.InputUpdatePromptTemplateRequest() # InputUpdatePromptTemplateRequest | Request Body

    try:
        # Update Prompt Template
        api_response = api_instance.update_prompt_template(template_id, body)
        print("The response of PromptTemplatesApi->update_prompt_template:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling PromptTemplatesApi->update_prompt_template: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **template_id** | **str**| Prompt Template ID | 
 **body** | [**InputUpdatePromptTemplateRequest**](InputUpdatePromptTemplateRequest.md)| Request Body | 

### Return type

[**OutputResponseModelPromptTemplate**](OutputResponseModelPromptTemplate.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


# ModelMCPToolConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mcp_connection** | **str** |  | [optional] 
**tools** | [**ModelFilteredListString**](ModelFilteredListString.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_mcp_tool_configuration import ModelMCPToolConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of ModelMCPToolConfiguration from a JSON string
model_mcp_tool_configuration_instance = ModelMCPToolConfiguration.from_json(json)
# print the JSON string representation of the object
print(ModelMCPToolConfiguration.to_json())

# convert the object into a dict
model_mcp_tool_configuration_dict = model_mcp_tool_configuration_instance.to_dict()
# create an instance of ModelMCPToolConfiguration from a dict
model_mcp_tool_configuration_from_dict = ModelMCPToolConfiguration.from_dict(model_mcp_tool_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# OutputResponseModelSchedule


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**ModelSchedule**](ModelSchedule.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_response_model_schedule import OutputResponseModelSchedule

# TODO update the JSON string below
json = "{}"
# create an instance of OutputResponseModelSchedule from a JSON string
output_response_model_schedule_instance = OutputResponseModelSchedule.from_json(json)
# print the JSON string representation of the object
print(OutputResponseModelSchedule.to_json())

# convert the object into a dict
output_response_model_schedule_dict = output_response_model_schedule_instance.to_dict()
# create an instance of OutputResponseModelSchedule from a dict
output_response_model_schedule_from_dict = OutputResponseModelSchedule.from_dict(output_response_model_schedule_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



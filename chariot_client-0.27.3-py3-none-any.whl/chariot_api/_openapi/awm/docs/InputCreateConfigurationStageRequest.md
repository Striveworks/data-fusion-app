# InputCreateConfigurationStageRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**stage** | **str** |  | 

## Example

```python
from chariot_api._openapi.awm.models.input_create_configuration_stage_request import InputCreateConfigurationStageRequest

# TODO update the JSON string below
json = "{}"
# create an instance of InputCreateConfigurationStageRequest from a JSON string
input_create_configuration_stage_request_instance = InputCreateConfigurationStageRequest.from_json(json)
# print the JSON string representation of the object
print(InputCreateConfigurationStageRequest.to_json())

# convert the object into a dict
input_create_configuration_stage_request_dict = input_create_configuration_stage_request_instance.to_dict()
# create an instance of InputCreateConfigurationStageRequest from a dict
input_create_configuration_stage_request_from_dict = InputCreateConfigurationStageRequest.from_dict(input_create_configuration_stage_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# OutputResponseModelConfigurationComponentBase


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**ModelConfigurationComponentBase**](ModelConfigurationComponentBase.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_response_model_configuration_component_base import OutputResponseModelConfigurationComponentBase

# TODO update the JSON string below
json = "{}"
# create an instance of OutputResponseModelConfigurationComponentBase from a JSON string
output_response_model_configuration_component_base_instance = OutputResponseModelConfigurationComponentBase.from_json(json)
# print the JSON string representation of the object
print(OutputResponseModelConfigurationComponentBase.to_json())

# convert the object into a dict
output_response_model_configuration_component_base_dict = output_response_model_configuration_component_base_instance.to_dict()
# create an instance of OutputResponseModelConfigurationComponentBase from a dict
output_response_model_configuration_component_base_from_dict = OutputResponseModelConfigurationComponentBase.from_dict(output_response_model_configuration_component_base_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



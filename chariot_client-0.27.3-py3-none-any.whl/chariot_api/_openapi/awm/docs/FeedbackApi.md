# chariot_api._openapi.awm.FeedbackApi

All URIs are relative to */api/awm/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create_feedback**](FeedbackApi.md#create_feedback) | **POST** /activities/{activityID}/feedback | Create feedback
[**delete_feedback**](FeedbackApi.md#delete_feedback) | **DELETE** /feedback/{feedbackID} | Delete feedback
[**get_feedback_statistics**](FeedbackApi.md#get_feedback_statistics) | **GET** /feedback/statistics | Get feedback statistics
[**list_feedback**](FeedbackApi.md#list_feedback) | **GET** /feedback | List feedback
[**update_feedback**](FeedbackApi.md#update_feedback) | **PATCH** /feedback/{feedbackID} | Update feedback


# **create_feedback**
> OutputResponseModelFeedback create_feedback(activity_id, body)

Create feedback

Creates user or reviewer thumbs up/down feedback with an optional comment of at most 8000 characters on an agent_to_user_message or agent_to_agent_message activity. Reviewer feedback requires AllSessions read access.

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_create_feedback_request import InputCreateFeedbackRequest
from chariot_api._openapi.awm.models.output_response_model_feedback import OutputResponseModelFeedback
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.FeedbackApi(api_client)
    activity_id = 'activity_id_example' # str | Activity ID
    body = chariot_api._openapi.awm.InputCreateFeedbackRequest() # InputCreateFeedbackRequest | Request Body

    try:
        # Create feedback
        api_response = api_instance.create_feedback(activity_id, body)
        print("The response of FeedbackApi->create_feedback:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling FeedbackApi->create_feedback: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **activity_id** | **str**| Activity ID | 
 **body** | [**InputCreateFeedbackRequest**](InputCreateFeedbackRequest.md)| Request Body | 

### Return type

[**OutputResponseModelFeedback**](OutputResponseModelFeedback.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Created |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**409** | Conflict |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_feedback**
> str delete_feedback(feedback_id)

Delete feedback

Deletes the caller's own feedback. Reviewer feedback requires AllSessions read access.

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.FeedbackApi(api_client)
    feedback_id = 'feedback_id_example' # str | Feedback ID

    try:
        # Delete feedback
        api_response = api_instance.delete_feedback(feedback_id)
        print("The response of FeedbackApi->delete_feedback:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling FeedbackApi->delete_feedback: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feedback_id** | **str**| Feedback ID | 

### Return type

**str**

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | No Content |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_feedback_statistics**
> OutputResponseModelFeedbackStatistics get_feedback_statistics(thumbs_up=thumbs_up, agent=agent, workflow_component_id=workflow_component_id, workflow_version_id=workflow_version_id, created_by=created_by, has_comment=has_comment, project_id=project_id, source=source, session_id=session_id, session_created_by=session_created_by, type=type)

Get feedback statistics

Gets feedback totals using the same filters and visibility rules as list feedback. Source defaults to user.

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_response_model_feedback_statistics import OutputResponseModelFeedbackStatistics
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.FeedbackApi(api_client)
    thumbs_up = True # bool | If true, only thumbs up. If false, only thumbs down. (optional)
    agent = ['agent_example'] # List[str] | Agents (optional)
    workflow_component_id = ['workflow_component_id_example'] # List[str] | Workflow component IDs (optional)
    workflow_version_id = ['workflow_version_id_example'] # List[str] | Workflow version IDs (optional)
    created_by = ['created_by_example'] # List[str] | Reporting user IDs (optional)
    has_comment = True # bool | If true, only rows with non-empty comments. If false, only rows without. (optional)
    project_id = ['project_id_example'] # List[str] | Project IDs (optional)
    source = ['source_example'] # List[str] | Feedback sources (defaults to user; reviewer requires AllSessions read access) (optional)
    session_id = ['session_id_example'] # List[str] | Session IDs (optional)
    session_created_by = ['session_created_by_example'] # List[str] | Session owner user IDs (optional)
    type = ['type_example'] # List[str] | Activity types (optional)

    try:
        # Get feedback statistics
        api_response = api_instance.get_feedback_statistics(thumbs_up=thumbs_up, agent=agent, workflow_component_id=workflow_component_id, workflow_version_id=workflow_version_id, created_by=created_by, has_comment=has_comment, project_id=project_id, source=source, session_id=session_id, session_created_by=session_created_by, type=type)
        print("The response of FeedbackApi->get_feedback_statistics:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling FeedbackApi->get_feedback_statistics: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **thumbs_up** | **bool**| If true, only thumbs up. If false, only thumbs down. | [optional] 
 **agent** | [**List[str]**](str.md)| Agents | [optional] 
 **workflow_component_id** | [**List[str]**](str.md)| Workflow component IDs | [optional] 
 **workflow_version_id** | [**List[str]**](str.md)| Workflow version IDs | [optional] 
 **created_by** | [**List[str]**](str.md)| Reporting user IDs | [optional] 
 **has_comment** | **bool**| If true, only rows with non-empty comments. If false, only rows without. | [optional] 
 **project_id** | [**List[str]**](str.md)| Project IDs | [optional] 
 **source** | [**List[str]**](str.md)| Feedback sources (defaults to user; reviewer requires AllSessions read access) | [optional] 
 **session_id** | [**List[str]**](str.md)| Session IDs | [optional] 
 **session_created_by** | [**List[str]**](str.md)| Session owner user IDs | [optional] 
 **type** | [**List[str]**](str.md)| Activity types | [optional] 

### Return type

[**OutputResponseModelFeedbackStatistics**](OutputResponseModelFeedbackStatistics.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_feedback**
> OutputPaginatedResponseModelFeedback list_feedback(thumbs_up=thumbs_up, agent=agent, workflow_component_id=workflow_component_id, workflow_version_id=workflow_version_id, created_by=created_by, has_comment=has_comment, project_id=project_id, source=source, session_id=session_id, session_created_by=session_created_by, type=type, limit=limit, sort_order=sort_order, after_key=after_key, calculate_meta=calculate_meta)

List feedback

Lists feedback visible to the caller. Source defaults to user. Reviewer rows require AllSessions read access and must be requested explicitly; mixed source queries still return user rows from own sessions.

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_paginated_response_model_feedback import OutputPaginatedResponseModelFeedback
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.FeedbackApi(api_client)
    thumbs_up = True # bool | If true, only thumbs up. If false, only thumbs down. (optional)
    agent = ['agent_example'] # List[str] | Agents (optional)
    workflow_component_id = ['workflow_component_id_example'] # List[str] | Workflow component IDs (optional)
    workflow_version_id = ['workflow_version_id_example'] # List[str] | Workflow version IDs (optional)
    created_by = ['created_by_example'] # List[str] | Reporting user IDs (optional)
    has_comment = True # bool | If true, only rows with non-empty comments. If false, only rows without. (optional)
    project_id = ['project_id_example'] # List[str] | Project IDs (optional)
    source = ['source_example'] # List[str] | Feedback sources (defaults to user; reviewer requires AllSessions read access) (optional)
    session_id = ['session_id_example'] # List[str] | Session IDs (optional)
    session_created_by = ['session_created_by_example'] # List[str] | Session owner user IDs (optional)
    type = ['type_example'] # List[str] | Activity types (optional)
    limit = 56 # int | Limit (defaults to 10, max 1000) (optional)
    sort_order = 'sort_order_example' # str | Sort asc/desc (defaults to desc) (optional)
    after_key = 'after_key_example' # str | Pagination key (optional)
    calculate_meta = True # bool | Provide metadata with total counts in the response (optional)

    try:
        # List feedback
        api_response = api_instance.list_feedback(thumbs_up=thumbs_up, agent=agent, workflow_component_id=workflow_component_id, workflow_version_id=workflow_version_id, created_by=created_by, has_comment=has_comment, project_id=project_id, source=source, session_id=session_id, session_created_by=session_created_by, type=type, limit=limit, sort_order=sort_order, after_key=after_key, calculate_meta=calculate_meta)
        print("The response of FeedbackApi->list_feedback:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling FeedbackApi->list_feedback: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **thumbs_up** | **bool**| If true, only thumbs up. If false, only thumbs down. | [optional] 
 **agent** | [**List[str]**](str.md)| Agents | [optional] 
 **workflow_component_id** | [**List[str]**](str.md)| Workflow component IDs | [optional] 
 **workflow_version_id** | [**List[str]**](str.md)| Workflow version IDs | [optional] 
 **created_by** | [**List[str]**](str.md)| Reporting user IDs | [optional] 
 **has_comment** | **bool**| If true, only rows with non-empty comments. If false, only rows without. | [optional] 
 **project_id** | [**List[str]**](str.md)| Project IDs | [optional] 
 **source** | [**List[str]**](str.md)| Feedback sources (defaults to user; reviewer requires AllSessions read access) | [optional] 
 **session_id** | [**List[str]**](str.md)| Session IDs | [optional] 
 **session_created_by** | [**List[str]**](str.md)| Session owner user IDs | [optional] 
 **type** | [**List[str]**](str.md)| Activity types | [optional] 
 **limit** | **int**| Limit (defaults to 10, max 1000) | [optional] 
 **sort_order** | **str**| Sort asc/desc (defaults to desc) | [optional] 
 **after_key** | **str**| Pagination key | [optional] 
 **calculate_meta** | **bool**| Provide metadata with total counts in the response | [optional] 

### Return type

[**OutputPaginatedResponseModelFeedback**](OutputPaginatedResponseModelFeedback.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_feedback**
> OutputResponseModelFeedback update_feedback(feedback_id, body)

Update feedback

Updates the rating and/or comment on the caller's own feedback. Comments are limited to 8000 characters. Reviewer feedback requires AllSessions read access.

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_update_feedback_request import InputUpdateFeedbackRequest
from chariot_api._openapi.awm.models.output_response_model_feedback import OutputResponseModelFeedback
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.FeedbackApi(api_client)
    feedback_id = 'feedback_id_example' # str | Feedback ID
    body = chariot_api._openapi.awm.InputUpdateFeedbackRequest() # InputUpdateFeedbackRequest | Request Body

    try:
        # Update feedback
        api_response = api_instance.update_feedback(feedback_id, body)
        print("The response of FeedbackApi->update_feedback:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling FeedbackApi->update_feedback: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feedback_id** | **str**| Feedback ID | 
 **body** | [**InputUpdateFeedbackRequest**](InputUpdateFeedbackRequest.md)| Request Body | 

### Return type

[**OutputResponseModelFeedback**](OutputResponseModelFeedback.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


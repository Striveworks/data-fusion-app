# ModelPromptTemplate


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**agent_id** | **str** |  | [optional] 
**content** | **str** |  | [optional] 
**created_at** | **str** |  | [optional] 
**created_by** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**enabled** | **bool** |  | [optional] 
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**placeholders** | **List[str]** |  | [optional] 
**project_id** | **str** |  | [optional] 
**scope** | **str** |  | [optional] 
**visibility** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_prompt_template import ModelPromptTemplate

# TODO update the JSON string below
json = "{}"
# create an instance of ModelPromptTemplate from a JSON string
model_prompt_template_instance = ModelPromptTemplate.from_json(json)
# print the JSON string representation of the object
print(ModelPromptTemplate.to_json())

# convert the object into a dict
model_prompt_template_dict = model_prompt_template_instance.to_dict()
# create an instance of ModelPromptTemplate from a dict
model_prompt_template_from_dict = ModelPromptTemplate.from_dict(model_prompt_template_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



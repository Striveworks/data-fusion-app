# InputCreatePromptTemplateRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**agent_id** | **str** |  | [optional] 
**content** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**project_id** | **str** |  | [optional] 
**scope** | **str** |  | [optional] 
**visibility** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.input_create_prompt_template_request import InputCreatePromptTemplateRequest

# TODO update the JSON string below
json = "{}"
# create an instance of InputCreatePromptTemplateRequest from a JSON string
input_create_prompt_template_request_instance = InputCreatePromptTemplateRequest.from_json(json)
# print the JSON string representation of the object
print(InputCreatePromptTemplateRequest.to_json())

# convert the object into a dict
input_create_prompt_template_request_dict = input_create_prompt_template_request_instance.to_dict()
# create an instance of InputCreatePromptTemplateRequest from a dict
input_create_prompt_template_request_from_dict = InputCreatePromptTemplateRequest.from_dict(input_create_prompt_template_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# InputCreateActivityRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**body** | **object** |  | [optional] 
**final** | **bool** |  | [optional] 
**from_agent** | **str** |  | [optional] 
**session_context_limit** | **int** |  | [optional] 
**session_context_size** | **int** |  | [optional] 
**session_id** | **str** |  | [optional] 
**to_agent** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**user_id** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.input_create_activity_request import InputCreateActivityRequest

# TODO update the JSON string below
json = "{}"
# create an instance of InputCreateActivityRequest from a JSON string
input_create_activity_request_instance = InputCreateActivityRequest.from_json(json)
# print the JSON string representation of the object
print(InputCreateActivityRequest.to_json())

# convert the object into a dict
input_create_activity_request_dict = input_create_activity_request_instance.to_dict()
# create an instance of InputCreateActivityRequest from a dict
input_create_activity_request_from_dict = InputCreateActivityRequest.from_dict(input_create_activity_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# ModelSchedule


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**active** | **bool** |  | [optional] 
**component_id** | **str** |  | [optional] 
**created_at** | **str** |  | [optional] 
**created_by** | **str** |  | [optional] 
**expires_at** | **str** |  | [optional] 
**expires_in** | **str** |  | [optional] 
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**prompt** | **str** |  | [optional] 
**schedule** | **str** |  | [optional] 
**to_agent** | **str** |  | [optional] 
**workflow_id** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_schedule import ModelSchedule

# TODO update the JSON string below
json = "{}"
# create an instance of ModelSchedule from a JSON string
model_schedule_instance = ModelSchedule.from_json(json)
# print the JSON string representation of the object
print(ModelSchedule.to_json())

# convert the object into a dict
model_schedule_dict = model_schedule_instance.to_dict()
# create an instance of ModelSchedule from a dict
model_schedule_from_dict = ModelSchedule.from_dict(model_schedule_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# chariot_api._openapi.awm.EvaluatorApi

All URIs are relative to */api/awm/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_evaluator_run_statistics**](EvaluatorApi.md#get_evaluator_run_statistics) | **GET** /evaluator-versions/{evaluatorVersionID}/run-statistics | Get evaluator run statistics
[**list_evaluator_runs**](EvaluatorApi.md#list_evaluator_runs) | **GET** /evaluator-versions/{evaluatorVersionID}/runs | List evaluator runs


# **get_evaluator_run_statistics**
> OutputResponseEvaluatorRunStatistics get_evaluator_run_statistics(evaluator_version_id, workflow_component_id=workflow_component_id, workflow_version_id=workflow_version_id, agent=agent, tool=tool, trigger_event_type=trigger_event_type, status=status, guardrail_triggered=guardrail_triggered, var_from=var_from, to=to)

Get evaluator run statistics

Gets evaluator run statistics for an immutable evaluator version across all users' sessions

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_response_evaluator_run_statistics import OutputResponseEvaluatorRunStatistics
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.EvaluatorApi(api_client)
    evaluator_version_id = 'evaluator_version_id_example' # str | Evaluator version ID
    workflow_component_id = ['workflow_component_id_example'] # List[str] | Workflow component IDs (optional)
    workflow_version_id = ['workflow_version_id_example'] # List[str] | Workflow version IDs (optional)
    agent = ['agent_example'] # List[str] | Agent names (optional)
    tool = ['tool_example'] # List[str] | Tool names (optional)
    trigger_event_type = ['trigger_event_type_example'] # List[str] | Trigger event types (optional)
    status = ['status_example'] # List[str] | Evaluator response statuses (optional)
    guardrail_triggered = True # bool | Whether any guardrail condition matched (optional)
    var_from = 'var_from_example' # str | From (ISO Formatted Date) (optional)
    to = 'to_example' # str | To (ISO Formatted Date) (optional)

    try:
        # Get evaluator run statistics
        api_response = api_instance.get_evaluator_run_statistics(evaluator_version_id, workflow_component_id=workflow_component_id, workflow_version_id=workflow_version_id, agent=agent, tool=tool, trigger_event_type=trigger_event_type, status=status, guardrail_triggered=guardrail_triggered, var_from=var_from, to=to)
        print("The response of EvaluatorApi->get_evaluator_run_statistics:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling EvaluatorApi->get_evaluator_run_statistics: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **evaluator_version_id** | **str**| Evaluator version ID | 
 **workflow_component_id** | [**List[str]**](str.md)| Workflow component IDs | [optional] 
 **workflow_version_id** | [**List[str]**](str.md)| Workflow version IDs | [optional] 
 **agent** | [**List[str]**](str.md)| Agent names | [optional] 
 **tool** | [**List[str]**](str.md)| Tool names | [optional] 
 **trigger_event_type** | [**List[str]**](str.md)| Trigger event types | [optional] 
 **status** | [**List[str]**](str.md)| Evaluator response statuses | [optional] 
 **guardrail_triggered** | **bool**| Whether any guardrail condition matched | [optional] 
 **var_from** | **str**| From (ISO Formatted Date) | [optional] 
 **to** | **str**| To (ISO Formatted Date) | [optional] 

### Return type

[**OutputResponseEvaluatorRunStatistics**](OutputResponseEvaluatorRunStatistics.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_evaluator_runs**
> OutputPaginatedResponseEvaluatorRun list_evaluator_runs(evaluator_version_id, workflow_component_id=workflow_component_id, workflow_version_id=workflow_version_id, agent=agent, tool=tool, trigger_event_type=trigger_event_type, status=status, guardrail_triggered=guardrail_triggered, var_from=var_from, to=to, limit=limit, sort_order=sort_order, after_key=after_key)

List evaluator runs

Lists logical evaluator runs for an immutable evaluator version

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_paginated_response_evaluator_run import OutputPaginatedResponseEvaluatorRun
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.EvaluatorApi(api_client)
    evaluator_version_id = 'evaluator_version_id_example' # str | Evaluator version ID
    workflow_component_id = ['workflow_component_id_example'] # List[str] | Workflow component IDs (optional)
    workflow_version_id = ['workflow_version_id_example'] # List[str] | Workflow version IDs (optional)
    agent = ['agent_example'] # List[str] | Agent names (optional)
    tool = ['tool_example'] # List[str] | Tool names (optional)
    trigger_event_type = ['trigger_event_type_example'] # List[str] | Trigger event types (optional)
    status = ['status_example'] # List[str] | Evaluator response statuses (optional)
    guardrail_triggered = True # bool | Whether any guardrail condition matched (optional)
    var_from = 'var_from_example' # str | From (ISO Formatted Date) (optional)
    to = 'to_example' # str | To (ISO Formatted Date) (optional)
    limit = 56 # int | Limit (defaults to 10, max 1000) (optional)
    sort_order = 'sort_order_example' # str | Sort asc/desc (defaults to desc) (optional)
    after_key = 'after_key_example' # str | Pagination key (optional)

    try:
        # List evaluator runs
        api_response = api_instance.list_evaluator_runs(evaluator_version_id, workflow_component_id=workflow_component_id, workflow_version_id=workflow_version_id, agent=agent, tool=tool, trigger_event_type=trigger_event_type, status=status, guardrail_triggered=guardrail_triggered, var_from=var_from, to=to, limit=limit, sort_order=sort_order, after_key=after_key)
        print("The response of EvaluatorApi->list_evaluator_runs:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling EvaluatorApi->list_evaluator_runs: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **evaluator_version_id** | **str**| Evaluator version ID | 
 **workflow_component_id** | [**List[str]**](str.md)| Workflow component IDs | [optional] 
 **workflow_version_id** | [**List[str]**](str.md)| Workflow version IDs | [optional] 
 **agent** | [**List[str]**](str.md)| Agent names | [optional] 
 **tool** | [**List[str]**](str.md)| Tool names | [optional] 
 **trigger_event_type** | [**List[str]**](str.md)| Trigger event types | [optional] 
 **status** | [**List[str]**](str.md)| Evaluator response statuses | [optional] 
 **guardrail_triggered** | **bool**| Whether any guardrail condition matched | [optional] 
 **var_from** | **str**| From (ISO Formatted Date) | [optional] 
 **to** | **str**| To (ISO Formatted Date) | [optional] 
 **limit** | **int**| Limit (defaults to 10, max 1000) | [optional] 
 **sort_order** | **str**| Sort asc/desc (defaults to desc) | [optional] 
 **after_key** | **str**| Pagination key | [optional] 

### Return type

[**OutputPaginatedResponseEvaluatorRun**](OutputPaginatedResponseEvaluatorRun.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


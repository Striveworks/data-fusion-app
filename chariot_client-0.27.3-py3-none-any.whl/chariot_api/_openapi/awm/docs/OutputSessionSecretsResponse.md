# OutputSessionSecretsResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | **Dict[str, str]** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_session_secrets_response import OutputSessionSecretsResponse

# TODO update the JSON string below
json = "{}"
# create an instance of OutputSessionSecretsResponse from a JSON string
output_session_secrets_response_instance = OutputSessionSecretsResponse.from_json(json)
# print the JSON string representation of the object
print(OutputSessionSecretsResponse.to_json())

# convert the object into a dict
output_session_secrets_response_dict = output_session_secrets_response_instance.to_dict()
# create an instance of OutputSessionSecretsResponse from a dict
output_session_secrets_response_from_dict = OutputSessionSecretsResponse.from_dict(output_session_secrets_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# ModelListToolCallStatisticsResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**by_avg_latency** | [**List[ModelToolCallStatistic]**](ModelToolCallStatistic.md) |  | [optional] 
**by_call_count** | [**List[ModelToolCallStatistic]**](ModelToolCallStatistic.md) |  | [optional] 
**by_error_rate** | [**List[ModelToolCallStatistic]**](ModelToolCallStatistic.md) |  | [optional] 
**metadata** | [**ModelListToolCallStatisticsResponseMetadata**](ModelListToolCallStatisticsResponseMetadata.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_list_tool_call_statistics_response import ModelListToolCallStatisticsResponse

# TODO update the JSON string below
json = "{}"
# create an instance of ModelListToolCallStatisticsResponse from a JSON string
model_list_tool_call_statistics_response_instance = ModelListToolCallStatisticsResponse.from_json(json)
# print the JSON string representation of the object
print(ModelListToolCallStatisticsResponse.to_json())

# convert the object into a dict
model_list_tool_call_statistics_response_dict = model_list_tool_call_statistics_response_instance.to_dict()
# create an instance of ModelListToolCallStatisticsResponse from a dict
model_list_tool_call_statistics_response_from_dict = ModelListToolCallStatisticsResponse.from_dict(model_list_tool_call_statistics_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



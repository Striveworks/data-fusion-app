# ModelEvaluatorPythonCode


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**inline** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_evaluator_python_code import ModelEvaluatorPythonCode

# TODO update the JSON string below
json = "{}"
# create an instance of ModelEvaluatorPythonCode from a JSON string
model_evaluator_python_code_instance = ModelEvaluatorPythonCode.from_json(json)
# print the JSON string representation of the object
print(ModelEvaluatorPythonCode.to_json())

# convert the object into a dict
model_evaluator_python_code_dict = model_evaluator_python_code_instance.to_dict()
# create an instance of ModelEvaluatorPythonCode from a dict
model_evaluator_python_code_from_dict = ModelEvaluatorPythonCode.from_dict(model_evaluator_python_code_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# ModelAgentGraphConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**agent_refs** | [**List[ModelRefAliasConfiguration]**](ModelRefAliasConfiguration.md) |  | [optional] 
**delegation_permissions** | **Dict[str, List[str]]** |  | [optional] 
**mode** | **str** |  | [optional] 
**supported_entry_agents** | **List[str]** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_agent_graph_configuration import ModelAgentGraphConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of ModelAgentGraphConfiguration from a JSON string
model_agent_graph_configuration_instance = ModelAgentGraphConfiguration.from_json(json)
# print the JSON string representation of the object
print(ModelAgentGraphConfiguration.to_json())

# convert the object into a dict
model_agent_graph_configuration_dict = model_agent_graph_configuration_instance.to_dict()
# create an instance of ModelAgentGraphConfiguration from a dict
model_agent_graph_configuration_from_dict = ModelAgentGraphConfiguration.from_dict(model_agent_graph_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# ModelCondition


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**arg** | **str** |  | [optional] 
**meta** | **str** |  | [optional] 
**op** | **str** |  | [optional] 
**value** | **object** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_condition import ModelCondition

# TODO update the JSON string below
json = "{}"
# create an instance of ModelCondition from a JSON string
model_condition_instance = ModelCondition.from_json(json)
# print the JSON string representation of the object
print(ModelCondition.to_json())

# convert the object into a dict
model_condition_dict = model_condition_instance.to_dict()
# create an instance of ModelCondition from a dict
model_condition_from_dict = ModelCondition.from_dict(model_condition_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



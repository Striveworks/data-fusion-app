# ModelConfigurationComponentSummary


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**component_type** | **str** |  | [optional] 
**deleted_at** | **str** |  | [optional] 
**id** | **str** |  | [optional] 
**key** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**paused** | **bool** |  | [optional] 
**project_id** | **str** |  | [optional] 
**selected_version** | [**ModelSelectedVersion**](ModelSelectedVersion.md) |  | [optional] 
**staged_version_ids** | [**ModelStagedVersionIDs**](ModelStagedVersionIDs.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_configuration_component_summary import ModelConfigurationComponentSummary

# TODO update the JSON string below
json = "{}"
# create an instance of ModelConfigurationComponentSummary from a JSON string
model_configuration_component_summary_instance = ModelConfigurationComponentSummary.from_json(json)
# print the JSON string representation of the object
print(ModelConfigurationComponentSummary.to_json())

# convert the object into a dict
model_configuration_component_summary_dict = model_configuration_component_summary_instance.to_dict()
# create an instance of ModelConfigurationComponentSummary from a dict
model_configuration_component_summary_from_dict = ModelConfigurationComponentSummary.from_dict(model_configuration_component_summary_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



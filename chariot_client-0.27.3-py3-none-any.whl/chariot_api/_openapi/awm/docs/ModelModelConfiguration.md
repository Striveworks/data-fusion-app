# ModelModelConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ai_provider** | **str** |  | [optional] 
**api_key** | **str** |  | [optional] 
**api_version** | **str** |  | [optional] 
**azure_endpoint** | **str** |  | [optional] 
**base_url** | **str** |  | [optional] 
**extra_body** | **Dict[str, object]** |  | [optional] 
**model_id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**organization_name** | **str** |  | [optional] 
**project_name** | **str** |  | [optional] 
**reasoning** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_model_configuration import ModelModelConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of ModelModelConfiguration from a JSON string
model_model_configuration_instance = ModelModelConfiguration.from_json(json)
# print the JSON string representation of the object
print(ModelModelConfiguration.to_json())

# convert the object into a dict
model_model_configuration_dict = model_model_configuration_instance.to_dict()
# create an instance of ModelModelConfiguration from a dict
model_model_configuration_from_dict = ModelModelConfiguration.from_dict(model_model_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# ModelRefAliasConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**ref** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_ref_alias_configuration import ModelRefAliasConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of ModelRefAliasConfiguration from a JSON string
model_ref_alias_configuration_instance = ModelRefAliasConfiguration.from_json(json)
# print the JSON string representation of the object
print(ModelRefAliasConfiguration.to_json())

# convert the object into a dict
model_ref_alias_configuration_dict = model_ref_alias_configuration_instance.to_dict()
# create an instance of ModelRefAliasConfiguration from a dict
model_ref_alias_configuration_from_dict = ModelRefAliasConfiguration.from_dict(model_ref_alias_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# ModelWorkflowResourceDetails


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**config_issues** | [**List[ModelWorkflowConfigIssue]**](ModelWorkflowConfigIssue.md) |  | [optional] 
**deployment** | **str** |  | [optional] 
**pods** | [**List[ModelPodDetails]**](ModelPodDetails.md) |  | [optional] 
**valid** | **bool** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_workflow_resource_details import ModelWorkflowResourceDetails

# TODO update the JSON string below
json = "{}"
# create an instance of ModelWorkflowResourceDetails from a JSON string
model_workflow_resource_details_instance = ModelWorkflowResourceDetails.from_json(json)
# print the JSON string representation of the object
print(ModelWorkflowResourceDetails.to_json())

# convert the object into a dict
model_workflow_resource_details_dict = model_workflow_resource_details_instance.to_dict()
# create an instance of ModelWorkflowResourceDetails from a dict
model_workflow_resource_details_from_dict = ModelWorkflowResourceDetails.from_dict(model_workflow_resource_details_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



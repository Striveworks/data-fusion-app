# ModelLocalTool


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**args** | **Dict[str, object]** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_local_tool import ModelLocalTool

# TODO update the JSON string below
json = "{}"
# create an instance of ModelLocalTool from a JSON string
model_local_tool_instance = ModelLocalTool.from_json(json)
# print the JSON string representation of the object
print(ModelLocalTool.to_json())

# convert the object into a dict
model_local_tool_dict = model_local_tool_instance.to_dict()
# create an instance of ModelLocalTool from a dict
model_local_tool_from_dict = ModelLocalTool.from_dict(model_local_tool_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



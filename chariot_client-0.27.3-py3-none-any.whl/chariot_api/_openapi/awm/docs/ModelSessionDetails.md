# ModelSessionDetails


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**agents** | **List[str]** |  | [optional] 
**compacting_threshold** | **float** |  | [optional] 
**context_limit** | **int** |  | [optional] 
**context_size** | **int** |  | [optional] 
**created_at** | **str** |  | [optional] 
**display_name** | **str** |  | [optional] 
**schedule_id** | **str** |  | [optional] 
**session_id** | **str** |  | [optional] 
**status** | **str** |  | [optional] 
**tool_activity_count** | **int** |  | [optional] 
**total_activity_count** | **int** |  | [optional] 
**total_request_duration_micros** | **int** |  | [optional] 
**updated_at** | **str** |  | [optional] 
**user_activity_count** | **int** |  | [optional] 
**user_ids** | **List[str]** |  | [optional] 
**workflow_component_id** | **str** |  | [optional] 
**workflow_version_id** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_session_details import ModelSessionDetails

# TODO update the JSON string below
json = "{}"
# create an instance of ModelSessionDetails from a JSON string
model_session_details_instance = ModelSessionDetails.from_json(json)
# print the JSON string representation of the object
print(ModelSessionDetails.to_json())

# convert the object into a dict
model_session_details_dict = model_session_details_instance.to_dict()
# create an instance of ModelSessionDetails from a dict
model_session_details_from_dict = ModelSessionDetails.from_dict(model_session_details_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



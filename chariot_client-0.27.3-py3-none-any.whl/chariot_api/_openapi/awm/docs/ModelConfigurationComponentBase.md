# ModelConfigurationComponentBase


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**component_type** | **str** |  | [optional] 
**deleted_at** | **str** |  | [optional] 
**id** | **str** |  | [optional] 
**key** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**project_id** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_configuration_component_base import ModelConfigurationComponentBase

# TODO update the JSON string below
json = "{}"
# create an instance of ModelConfigurationComponentBase from a JSON string
model_configuration_component_base_instance = ModelConfigurationComponentBase.from_json(json)
# print the JSON string representation of the object
print(ModelConfigurationComponentBase.to_json())

# convert the object into a dict
model_configuration_component_base_dict = model_configuration_component_base_instance.to_dict()
# create an instance of ModelConfigurationComponentBase from a dict
model_configuration_component_base_from_dict = ModelConfigurationComponentBase.from_dict(model_configuration_component_base_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



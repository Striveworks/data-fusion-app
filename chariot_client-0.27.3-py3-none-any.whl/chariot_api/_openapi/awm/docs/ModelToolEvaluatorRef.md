# ModelToolEvaluatorRef


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**applies_to** | [**ModelToolEvaluatorAppliesTo**](ModelToolEvaluatorAppliesTo.md) |  | [optional] 
**evaluator_ref** | **str** |  | [optional] 
**failure_policy** | **str** |  | [optional] 
**guardrails** | [**List[ModelToolEvaluatorGuardrail]**](ModelToolEvaluatorGuardrail.md) |  | [optional] 
**run_policy** | [**ModelEvaluatorRunPolicy**](ModelEvaluatorRunPolicy.md) |  | [optional] 
**sample_rate** | **float** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_tool_evaluator_ref import ModelToolEvaluatorRef

# TODO update the JSON string below
json = "{}"
# create an instance of ModelToolEvaluatorRef from a JSON string
model_tool_evaluator_ref_instance = ModelToolEvaluatorRef.from_json(json)
# print the JSON string representation of the object
print(ModelToolEvaluatorRef.to_json())

# convert the object into a dict
model_tool_evaluator_ref_dict = model_tool_evaluator_ref_instance.to_dict()
# create an instance of ModelToolEvaluatorRef from a dict
model_tool_evaluator_ref_from_dict = ModelToolEvaluatorRef.from_dict(model_tool_evaluator_ref_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



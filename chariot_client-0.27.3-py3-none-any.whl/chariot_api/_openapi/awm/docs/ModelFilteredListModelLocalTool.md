# ModelFilteredListModelLocalTool


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**exclude** | [**List[ModelLocalTool]**](ModelLocalTool.md) |  | [optional] 
**include** | [**List[ModelLocalTool]**](ModelLocalTool.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_filtered_list_model_local_tool import ModelFilteredListModelLocalTool

# TODO update the JSON string below
json = "{}"
# create an instance of ModelFilteredListModelLocalTool from a JSON string
model_filtered_list_model_local_tool_instance = ModelFilteredListModelLocalTool.from_json(json)
# print the JSON string representation of the object
print(ModelFilteredListModelLocalTool.to_json())

# convert the object into a dict
model_filtered_list_model_local_tool_dict = model_filtered_list_model_local_tool_instance.to_dict()
# create an instance of ModelFilteredListModelLocalTool from a dict
model_filtered_list_model_local_tool_from_dict = ModelFilteredListModelLocalTool.from_dict(model_filtered_list_model_local_tool_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# ModelEvaluatorConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**evaluator_type** | **str** |  | [optional] 
**inputs** | [**ModelEvaluatorInput**](ModelEvaluatorInput.md) |  | [optional] 
**llm_judge** | [**ModelEvaluatorLLMJudge**](ModelEvaluatorLLMJudge.md) |  | [optional] 
**python_code** | [**ModelEvaluatorPythonCode**](ModelEvaluatorPythonCode.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_evaluator_configuration import ModelEvaluatorConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of ModelEvaluatorConfiguration from a JSON string
model_evaluator_configuration_instance = ModelEvaluatorConfiguration.from_json(json)
# print the JSON string representation of the object
print(ModelEvaluatorConfiguration.to_json())

# convert the object into a dict
model_evaluator_configuration_dict = model_evaluator_configuration_instance.to_dict()
# create an instance of ModelEvaluatorConfiguration from a dict
model_evaluator_configuration_from_dict = ModelEvaluatorConfiguration.from_dict(model_evaluator_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



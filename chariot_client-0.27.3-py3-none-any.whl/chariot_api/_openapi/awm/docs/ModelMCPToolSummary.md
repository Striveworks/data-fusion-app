# ModelMCPToolSummary


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**title** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_mcp_tool_summary import ModelMCPToolSummary

# TODO update the JSON string below
json = "{}"
# create an instance of ModelMCPToolSummary from a JSON string
model_mcp_tool_summary_instance = ModelMCPToolSummary.from_json(json)
# print the JSON string representation of the object
print(ModelMCPToolSummary.to_json())

# convert the object into a dict
model_mcp_tool_summary_dict = model_mcp_tool_summary_instance.to_dict()
# create an instance of ModelMCPToolSummary from a dict
model_mcp_tool_summary_from_dict = ModelMCPToolSummary.from_dict(model_mcp_tool_summary_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



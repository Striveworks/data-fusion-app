# InputUpsertScheduleRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**active** | **bool** |  | [optional] 
**expires_at** | **str** | overwritten to match ExpiresIn if both are provided | [optional] 
**expires_in** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**prompt** | **str** |  | [optional] 
**schedule** | **str** |  | [optional] 
**to_agent** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.input_upsert_schedule_request import InputUpsertScheduleRequest

# TODO update the JSON string below
json = "{}"
# create an instance of InputUpsertScheduleRequest from a JSON string
input_upsert_schedule_request_instance = InputUpsertScheduleRequest.from_json(json)
# print the JSON string representation of the object
print(InputUpsertScheduleRequest.to_json())

# convert the object into a dict
input_upsert_schedule_request_dict = input_upsert_schedule_request_instance.to_dict()
# create an instance of InputUpsertScheduleRequest from a dict
input_upsert_schedule_request_from_dict = InputUpsertScheduleRequest.from_dict(input_upsert_schedule_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



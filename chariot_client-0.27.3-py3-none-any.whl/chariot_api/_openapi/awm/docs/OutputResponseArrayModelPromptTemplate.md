# OutputResponseArrayModelPromptTemplate


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**List[ModelPromptTemplate]**](ModelPromptTemplate.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_response_array_model_prompt_template import OutputResponseArrayModelPromptTemplate

# TODO update the JSON string below
json = "{}"
# create an instance of OutputResponseArrayModelPromptTemplate from a JSON string
output_response_array_model_prompt_template_instance = OutputResponseArrayModelPromptTemplate.from_json(json)
# print the JSON string representation of the object
print(OutputResponseArrayModelPromptTemplate.to_json())

# convert the object into a dict
output_response_array_model_prompt_template_dict = output_response_array_model_prompt_template_instance.to_dict()
# create an instance of OutputResponseArrayModelPromptTemplate from a dict
output_response_array_model_prompt_template_from_dict = OutputResponseArrayModelPromptTemplate.from_dict(output_response_array_model_prompt_template_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



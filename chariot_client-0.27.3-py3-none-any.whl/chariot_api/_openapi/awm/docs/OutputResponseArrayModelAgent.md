# OutputResponseArrayModelAgent


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**List[ModelAgent]**](ModelAgent.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_response_array_model_agent import OutputResponseArrayModelAgent

# TODO update the JSON string below
json = "{}"
# create an instance of OutputResponseArrayModelAgent from a JSON string
output_response_array_model_agent_instance = OutputResponseArrayModelAgent.from_json(json)
# print the JSON string representation of the object
print(OutputResponseArrayModelAgent.to_json())

# convert the object into a dict
output_response_array_model_agent_dict = output_response_array_model_agent_instance.to_dict()
# create an instance of OutputResponseArrayModelAgent from a dict
output_response_array_model_agent_from_dict = OutputResponseArrayModelAgent.from_dict(output_response_array_model_agent_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



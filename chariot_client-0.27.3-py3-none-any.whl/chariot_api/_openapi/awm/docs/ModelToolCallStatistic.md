# ModelToolCallStatistic


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**agent** | **str** |  | [optional] 
**avg_latency_micros** | **float** |  | [optional] 
**calls** | **int** |  | [optional] 
**error_calls** | **int** |  | [optional] 
**error_rate** | **float** |  | [optional] 
**tool** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_tool_call_statistic import ModelToolCallStatistic

# TODO update the JSON string below
json = "{}"
# create an instance of ModelToolCallStatistic from a JSON string
model_tool_call_statistic_instance = ModelToolCallStatistic.from_json(json)
# print the JSON string representation of the object
print(ModelToolCallStatistic.to_json())

# convert the object into a dict
model_tool_call_statistic_dict = model_tool_call_statistic_instance.to_dict()
# create an instance of ModelToolCallStatistic from a dict
model_tool_call_statistic_from_dict = ModelToolCallStatistic.from_dict(model_tool_call_statistic_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



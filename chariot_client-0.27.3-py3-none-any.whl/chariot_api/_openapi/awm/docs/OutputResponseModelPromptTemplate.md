# OutputResponseModelPromptTemplate


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**ModelPromptTemplate**](ModelPromptTemplate.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_response_model_prompt_template import OutputResponseModelPromptTemplate

# TODO update the JSON string below
json = "{}"
# create an instance of OutputResponseModelPromptTemplate from a JSON string
output_response_model_prompt_template_instance = OutputResponseModelPromptTemplate.from_json(json)
# print the JSON string representation of the object
print(OutputResponseModelPromptTemplate.to_json())

# convert the object into a dict
output_response_model_prompt_template_dict = output_response_model_prompt_template_instance.to_dict()
# create an instance of OutputResponseModelPromptTemplate from a dict
output_response_model_prompt_template_from_dict = OutputResponseModelPromptTemplate.from_dict(output_response_model_prompt_template_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



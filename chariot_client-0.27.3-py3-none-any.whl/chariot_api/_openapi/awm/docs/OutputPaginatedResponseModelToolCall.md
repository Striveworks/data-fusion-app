# OutputPaginatedResponseModelToolCall


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**after_key** | **str** |  | [optional] 
**data** | [**List[ModelToolCall]**](ModelToolCall.md) |  | [optional] 
**metadata** | [**OutputPaginatedMetadata**](OutputPaginatedMetadata.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_paginated_response_model_tool_call import OutputPaginatedResponseModelToolCall

# TODO update the JSON string below
json = "{}"
# create an instance of OutputPaginatedResponseModelToolCall from a JSON string
output_paginated_response_model_tool_call_instance = OutputPaginatedResponseModelToolCall.from_json(json)
# print the JSON string representation of the object
print(OutputPaginatedResponseModelToolCall.to_json())

# convert the object into a dict
output_paginated_response_model_tool_call_dict = output_paginated_response_model_tool_call_instance.to_dict()
# create an instance of OutputPaginatedResponseModelToolCall from a dict
output_paginated_response_model_tool_call_from_dict = OutputPaginatedResponseModelToolCall.from_dict(output_paginated_response_model_tool_call_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



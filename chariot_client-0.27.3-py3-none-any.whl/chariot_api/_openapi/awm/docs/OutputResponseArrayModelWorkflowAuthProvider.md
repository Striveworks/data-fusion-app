# OutputResponseArrayModelWorkflowAuthProvider


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**List[ModelWorkflowAuthProvider]**](ModelWorkflowAuthProvider.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_response_array_model_workflow_auth_provider import OutputResponseArrayModelWorkflowAuthProvider

# TODO update the JSON string below
json = "{}"
# create an instance of OutputResponseArrayModelWorkflowAuthProvider from a JSON string
output_response_array_model_workflow_auth_provider_instance = OutputResponseArrayModelWorkflowAuthProvider.from_json(json)
# print the JSON string representation of the object
print(OutputResponseArrayModelWorkflowAuthProvider.to_json())

# convert the object into a dict
output_response_array_model_workflow_auth_provider_dict = output_response_array_model_workflow_auth_provider_instance.to_dict()
# create an instance of OutputResponseArrayModelWorkflowAuthProvider from a dict
output_response_array_model_workflow_auth_provider_from_dict = OutputResponseArrayModelWorkflowAuthProvider.from_dict(output_response_array_model_workflow_auth_provider_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# OutputResponseModelActivity


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**ModelActivity**](ModelActivity.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_response_model_activity import OutputResponseModelActivity

# TODO update the JSON string below
json = "{}"
# create an instance of OutputResponseModelActivity from a JSON string
output_response_model_activity_instance = OutputResponseModelActivity.from_json(json)
# print the JSON string representation of the object
print(OutputResponseModelActivity.to_json())

# convert the object into a dict
output_response_model_activity_dict = output_response_model_activity_instance.to_dict()
# create an instance of OutputResponseModelActivity from a dict
output_response_model_activity_from_dict = OutputResponseModelActivity.from_dict(output_response_model_activity_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



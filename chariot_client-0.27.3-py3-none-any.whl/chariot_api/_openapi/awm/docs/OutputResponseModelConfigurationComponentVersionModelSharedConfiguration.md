# OutputResponseModelConfigurationComponentVersionModelSharedConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**ModelConfigurationComponentVersionModelSharedConfiguration**](ModelConfigurationComponentVersionModelSharedConfiguration.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_response_model_configuration_component_version_model_shared_configuration import OutputResponseModelConfigurationComponentVersionModelSharedConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of OutputResponseModelConfigurationComponentVersionModelSharedConfiguration from a JSON string
output_response_model_configuration_component_version_model_shared_configuration_instance = OutputResponseModelConfigurationComponentVersionModelSharedConfiguration.from_json(json)
# print the JSON string representation of the object
print(OutputResponseModelConfigurationComponentVersionModelSharedConfiguration.to_json())

# convert the object into a dict
output_response_model_configuration_component_version_model_shared_configuration_dict = output_response_model_configuration_component_version_model_shared_configuration_instance.to_dict()
# create an instance of OutputResponseModelConfigurationComponentVersionModelSharedConfiguration from a dict
output_response_model_configuration_component_version_model_shared_configuration_from_dict = OutputResponseModelConfigurationComponentVersionModelSharedConfiguration.from_dict(output_response_model_configuration_component_version_model_shared_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# ModelToolEvaluatorGuardrail


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**action** | [**ModelToolEvaluatorGuardrailAction**](ModelToolEvaluatorGuardrailAction.md) |  | [optional] 
**enabled** | **bool** |  | [optional] 
**name** | **str** |  | [optional] 
**when** | [**ModelToolEvaluatorGuardrailWhen**](ModelToolEvaluatorGuardrailWhen.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_tool_evaluator_guardrail import ModelToolEvaluatorGuardrail

# TODO update the JSON string below
json = "{}"
# create an instance of ModelToolEvaluatorGuardrail from a JSON string
model_tool_evaluator_guardrail_instance = ModelToolEvaluatorGuardrail.from_json(json)
# print the JSON string representation of the object
print(ModelToolEvaluatorGuardrail.to_json())

# convert the object into a dict
model_tool_evaluator_guardrail_dict = model_tool_evaluator_guardrail_instance.to_dict()
# create an instance of ModelToolEvaluatorGuardrail from a dict
model_tool_evaluator_guardrail_from_dict = ModelToolEvaluatorGuardrail.from_dict(model_tool_evaluator_guardrail_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



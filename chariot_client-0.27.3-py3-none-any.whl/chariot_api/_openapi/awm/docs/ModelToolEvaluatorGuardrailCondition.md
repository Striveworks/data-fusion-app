# ModelToolEvaluatorGuardrailCondition


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**comparator** | **str** |  | [optional] 
**field_path** | **str** |  | [optional] 
**value** | **object** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_tool_evaluator_guardrail_condition import ModelToolEvaluatorGuardrailCondition

# TODO update the JSON string below
json = "{}"
# create an instance of ModelToolEvaluatorGuardrailCondition from a JSON string
model_tool_evaluator_guardrail_condition_instance = ModelToolEvaluatorGuardrailCondition.from_json(json)
# print the JSON string representation of the object
print(ModelToolEvaluatorGuardrailCondition.to_json())

# convert the object into a dict
model_tool_evaluator_guardrail_condition_dict = model_tool_evaluator_guardrail_condition_instance.to_dict()
# create an instance of ModelToolEvaluatorGuardrailCondition from a dict
model_tool_evaluator_guardrail_condition_from_dict = ModelToolEvaluatorGuardrailCondition.from_dict(model_tool_evaluator_guardrail_condition_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# InputCreateConfigurationVersionRequestModelEvaluatorConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**config** | **List[int]** |  | 
**description** | **str** |  | [optional] 
**stage** | **str** |  | [optional] 
**version_changelog** | **str** |  | 

## Example

```python
from chariot_api._openapi.awm.models.input_create_configuration_version_request_model_evaluator_configuration import InputCreateConfigurationVersionRequestModelEvaluatorConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of InputCreateConfigurationVersionRequestModelEvaluatorConfiguration from a JSON string
input_create_configuration_version_request_model_evaluator_configuration_instance = InputCreateConfigurationVersionRequestModelEvaluatorConfiguration.from_json(json)
# print the JSON string representation of the object
print(InputCreateConfigurationVersionRequestModelEvaluatorConfiguration.to_json())

# convert the object into a dict
input_create_configuration_version_request_model_evaluator_configuration_dict = input_create_configuration_version_request_model_evaluator_configuration_instance.to_dict()
# create an instance of InputCreateConfigurationVersionRequestModelEvaluatorConfiguration from a dict
input_create_configuration_version_request_model_evaluator_configuration_from_dict = InputCreateConfigurationVersionRequestModelEvaluatorConfiguration.from_dict(input_create_configuration_version_request_model_evaluator_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



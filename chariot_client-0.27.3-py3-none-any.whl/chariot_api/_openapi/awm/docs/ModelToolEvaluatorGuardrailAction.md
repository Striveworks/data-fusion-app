# ModelToolEvaluatorGuardrailAction


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **str** |  | [optional] 
**type** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_tool_evaluator_guardrail_action import ModelToolEvaluatorGuardrailAction

# TODO update the JSON string below
json = "{}"
# create an instance of ModelToolEvaluatorGuardrailAction from a JSON string
model_tool_evaluator_guardrail_action_instance = ModelToolEvaluatorGuardrailAction.from_json(json)
# print the JSON string representation of the object
print(ModelToolEvaluatorGuardrailAction.to_json())

# convert the object into a dict
model_tool_evaluator_guardrail_action_dict = model_tool_evaluator_guardrail_action_instance.to_dict()
# create an instance of ModelToolEvaluatorGuardrailAction from a dict
model_tool_evaluator_guardrail_action_from_dict = ModelToolEvaluatorGuardrailAction.from_dict(model_tool_evaluator_guardrail_action_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



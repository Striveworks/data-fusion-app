# InputCreateConfigurationVersionRequestModelToolProfileConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**config** | **List[int]** |  | 
**description** | **str** |  | [optional] 
**stage** | **str** |  | [optional] 
**version_changelog** | **str** |  | 

## Example

```python
from chariot_api._openapi.awm.models.input_create_configuration_version_request_model_tool_profile_configuration import InputCreateConfigurationVersionRequestModelToolProfileConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of InputCreateConfigurationVersionRequestModelToolProfileConfiguration from a JSON string
input_create_configuration_version_request_model_tool_profile_configuration_instance = InputCreateConfigurationVersionRequestModelToolProfileConfiguration.from_json(json)
# print the JSON string representation of the object
print(InputCreateConfigurationVersionRequestModelToolProfileConfiguration.to_json())

# convert the object into a dict
input_create_configuration_version_request_model_tool_profile_configuration_dict = input_create_configuration_version_request_model_tool_profile_configuration_instance.to_dict()
# create an instance of InputCreateConfigurationVersionRequestModelToolProfileConfiguration from a dict
input_create_configuration_version_request_model_tool_profile_configuration_from_dict = InputCreateConfigurationVersionRequestModelToolProfileConfiguration.from_dict(input_create_configuration_version_request_model_tool_profile_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# EvaluatorRunStatistics


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**completed_runs** | **int** |  | [optional] 
**completion_rate** | **float** |  | [optional] 
**error_rate** | **float** |  | [optional] 
**errored_runs** | **int** |  | [optional] 
**guardrail_triggered_rate** | **float** |  | [optional] 
**guardrail_triggered_runs** | **int** |  | [optional] 
**latency_seconds** | [**EvaluatorRunTimingStatistics**](EvaluatorRunTimingStatistics.md) |  | [optional] 
**outcomes_by_day** | [**List[EvaluatorRunOutcomeBucket]**](EvaluatorRunOutcomeBucket.md) |  | [optional] 
**runtime_seconds** | [**EvaluatorRunTimingStatistics**](EvaluatorRunTimingStatistics.md) |  | [optional] 
**timed_out_runs** | **int** |  | [optional] 
**timeout_rate** | **float** |  | [optional] 
**total_runs** | **int** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.evaluator_run_statistics import EvaluatorRunStatistics

# TODO update the JSON string below
json = "{}"
# create an instance of EvaluatorRunStatistics from a JSON string
evaluator_run_statistics_instance = EvaluatorRunStatistics.from_json(json)
# print the JSON string representation of the object
print(EvaluatorRunStatistics.to_json())

# convert the object into a dict
evaluator_run_statistics_dict = evaluator_run_statistics_instance.to_dict()
# create an instance of EvaluatorRunStatistics from a dict
evaluator_run_statistics_from_dict = EvaluatorRunStatistics.from_dict(evaluator_run_statistics_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



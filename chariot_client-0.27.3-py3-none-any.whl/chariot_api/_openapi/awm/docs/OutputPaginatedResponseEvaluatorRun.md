# OutputPaginatedResponseEvaluatorRun


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**after_key** | **str** |  | [optional] 
**data** | [**List[EvaluatorRun]**](EvaluatorRun.md) |  | [optional] 
**metadata** | [**OutputPaginatedMetadata**](OutputPaginatedMetadata.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_paginated_response_evaluator_run import OutputPaginatedResponseEvaluatorRun

# TODO update the JSON string below
json = "{}"
# create an instance of OutputPaginatedResponseEvaluatorRun from a JSON string
output_paginated_response_evaluator_run_instance = OutputPaginatedResponseEvaluatorRun.from_json(json)
# print the JSON string representation of the object
print(OutputPaginatedResponseEvaluatorRun.to_json())

# convert the object into a dict
output_paginated_response_evaluator_run_dict = output_paginated_response_evaluator_run_instance.to_dict()
# create an instance of OutputPaginatedResponseEvaluatorRun from a dict
output_paginated_response_evaluator_run_from_dict = OutputPaginatedResponseEvaluatorRun.from_dict(output_paginated_response_evaluator_run_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



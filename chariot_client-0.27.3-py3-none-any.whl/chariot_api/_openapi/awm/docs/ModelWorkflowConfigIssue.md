# ModelWorkflowConfigIssue


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **str** |  | [optional] 
**ref** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_workflow_config_issue import ModelWorkflowConfigIssue

# TODO update the JSON string below
json = "{}"
# create an instance of ModelWorkflowConfigIssue from a JSON string
model_workflow_config_issue_instance = ModelWorkflowConfigIssue.from_json(json)
# print the JSON string representation of the object
print(ModelWorkflowConfigIssue.to_json())

# convert the object into a dict
model_workflow_config_issue_dict = model_workflow_config_issue_instance.to_dict()
# create an instance of ModelWorkflowConfigIssue from a dict
model_workflow_config_issue_from_dict = ModelWorkflowConfigIssue.from_dict(model_workflow_config_issue_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



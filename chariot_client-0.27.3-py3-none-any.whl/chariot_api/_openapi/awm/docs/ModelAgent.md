# ModelAgent


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**component_id** | **str** |  | [optional] 
**component_name** | **str** |  | [optional] 
**introduction** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**supported_entry_agent** | **bool** |  | [optional] 
**version_id** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_agent import ModelAgent

# TODO update the JSON string below
json = "{}"
# create an instance of ModelAgent from a JSON string
model_agent_instance = ModelAgent.from_json(json)
# print the JSON string representation of the object
print(ModelAgent.to_json())

# convert the object into a dict
model_agent_dict = model_agent_instance.to_dict()
# create an instance of ModelAgent from a dict
model_agent_from_dict = ModelAgent.from_dict(model_agent_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



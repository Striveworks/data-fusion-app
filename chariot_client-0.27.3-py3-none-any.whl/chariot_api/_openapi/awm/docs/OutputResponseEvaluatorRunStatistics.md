# OutputResponseEvaluatorRunStatistics


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**EvaluatorRunStatistics**](EvaluatorRunStatistics.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_response_evaluator_run_statistics import OutputResponseEvaluatorRunStatistics

# TODO update the JSON string below
json = "{}"
# create an instance of OutputResponseEvaluatorRunStatistics from a JSON string
output_response_evaluator_run_statistics_instance = OutputResponseEvaluatorRunStatistics.from_json(json)
# print the JSON string representation of the object
print(OutputResponseEvaluatorRunStatistics.to_json())

# convert the object into a dict
output_response_evaluator_run_statistics_dict = output_response_evaluator_run_statistics_instance.to_dict()
# create an instance of OutputResponseEvaluatorRunStatistics from a dict
output_response_evaluator_run_statistics_from_dict = OutputResponseEvaluatorRunStatistics.from_dict(output_response_evaluator_run_statistics_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



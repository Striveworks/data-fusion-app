# ModelConfigurationComponentMetadata


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**agent_names** | **List[str]** |  | [optional] 
**evaluator_type** | **str** |  | [optional] 
**mcp_tools** | [**List[ModelMCPToolConfiguration]**](ModelMCPToolConfiguration.md) |  | [optional] 
**model_settings** | [**ModelModelConfiguration**](ModelModelConfiguration.md) |  | [optional] 
**transport** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_configuration_component_metadata import ModelConfigurationComponentMetadata

# TODO update the JSON string below
json = "{}"
# create an instance of ModelConfigurationComponentMetadata from a JSON string
model_configuration_component_metadata_instance = ModelConfigurationComponentMetadata.from_json(json)
# print the JSON string representation of the object
print(ModelConfigurationComponentMetadata.to_json())

# convert the object into a dict
model_configuration_component_metadata_dict = model_configuration_component_metadata_instance.to_dict()
# create an instance of ModelConfigurationComponentMetadata from a dict
model_configuration_component_metadata_from_dict = ModelConfigurationComponentMetadata.from_dict(model_configuration_component_metadata_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



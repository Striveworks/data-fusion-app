# ModelStagedVersionIDs


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**development** | **str** |  | [optional] 
**latest** | **str** |  | [optional] 
**production** | **str** |  | [optional] 
**staging** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_staged_version_ids import ModelStagedVersionIDs

# TODO update the JSON string below
json = "{}"
# create an instance of ModelStagedVersionIDs from a JSON string
model_staged_version_ids_instance = ModelStagedVersionIDs.from_json(json)
# print the JSON string representation of the object
print(ModelStagedVersionIDs.to_json())

# convert the object into a dict
model_staged_version_ids_dict = model_staged_version_ids_instance.to_dict()
# create an instance of ModelStagedVersionIDs from a dict
model_staged_version_ids_from_dict = ModelStagedVersionIDs.from_dict(model_staged_version_ids_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



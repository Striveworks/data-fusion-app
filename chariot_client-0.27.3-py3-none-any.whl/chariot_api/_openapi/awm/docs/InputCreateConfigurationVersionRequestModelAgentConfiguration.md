# InputCreateConfigurationVersionRequestModelAgentConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**config** | **List[int]** |  | 
**description** | **str** |  | [optional] 
**stage** | **str** |  | [optional] 
**version_changelog** | **str** |  | 

## Example

```python
from chariot_api._openapi.awm.models.input_create_configuration_version_request_model_agent_configuration import InputCreateConfigurationVersionRequestModelAgentConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of InputCreateConfigurationVersionRequestModelAgentConfiguration from a JSON string
input_create_configuration_version_request_model_agent_configuration_instance = InputCreateConfigurationVersionRequestModelAgentConfiguration.from_json(json)
# print the JSON string representation of the object
print(InputCreateConfigurationVersionRequestModelAgentConfiguration.to_json())

# convert the object into a dict
input_create_configuration_version_request_model_agent_configuration_dict = input_create_configuration_version_request_model_agent_configuration_instance.to_dict()
# create an instance of InputCreateConfigurationVersionRequestModelAgentConfiguration from a dict
input_create_configuration_version_request_model_agent_configuration_from_dict = InputCreateConfigurationVersionRequestModelAgentConfiguration.from_dict(input_create_configuration_version_request_model_agent_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



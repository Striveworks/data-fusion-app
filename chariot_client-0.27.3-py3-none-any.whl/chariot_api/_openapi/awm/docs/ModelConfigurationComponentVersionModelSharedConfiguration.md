# ModelConfigurationComponentVersionModelSharedConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**component_id** | **str** |  | [optional] 
**component_type** | **str** |  | [optional] 
**config** | [**ModelSharedConfiguration**](ModelSharedConfiguration.md) |  | [optional] 
**created_at** | **str** |  | [optional] 
**created_by** | **str** |  | [optional] 
**deleted_at** | **str** |  | [optional] 
**deleted_by** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**id** | **str** |  | [optional] 
**key** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**project_id** | **str** |  | [optional] 
**raw_config** | **List[int]** |  | [optional] 
**stages** | **List[str]** |  | [optional] 
**version** | **int** |  | [optional] 
**version_changelog** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_configuration_component_version_model_shared_configuration import ModelConfigurationComponentVersionModelSharedConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of ModelConfigurationComponentVersionModelSharedConfiguration from a JSON string
model_configuration_component_version_model_shared_configuration_instance = ModelConfigurationComponentVersionModelSharedConfiguration.from_json(json)
# print the JSON string representation of the object
print(ModelConfigurationComponentVersionModelSharedConfiguration.to_json())

# convert the object into a dict
model_configuration_component_version_model_shared_configuration_dict = model_configuration_component_version_model_shared_configuration_instance.to_dict()
# create an instance of ModelConfigurationComponentVersionModelSharedConfiguration from a dict
model_configuration_component_version_model_shared_configuration_from_dict = ModelConfigurationComponentVersionModelSharedConfiguration.from_dict(model_configuration_component_version_model_shared_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# OutputResponseModelListToolCallStatisticsResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**ModelListToolCallStatisticsResponse**](ModelListToolCallStatisticsResponse.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_response_model_list_tool_call_statistics_response import OutputResponseModelListToolCallStatisticsResponse

# TODO update the JSON string below
json = "{}"
# create an instance of OutputResponseModelListToolCallStatisticsResponse from a JSON string
output_response_model_list_tool_call_statistics_response_instance = OutputResponseModelListToolCallStatisticsResponse.from_json(json)
# print the JSON string representation of the object
print(OutputResponseModelListToolCallStatisticsResponse.to_json())

# convert the object into a dict
output_response_model_list_tool_call_statistics_response_dict = output_response_model_list_tool_call_statistics_response_instance.to_dict()
# create an instance of OutputResponseModelListToolCallStatisticsResponse from a dict
output_response_model_list_tool_call_statistics_response_from_dict = OutputResponseModelListToolCallStatisticsResponse.from_dict(output_response_model_list_tool_call_statistics_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



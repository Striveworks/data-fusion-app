# ModelAgentConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**introduction** | **str** |  | [optional] 
**message_compacting_settings** | [**ModelMessageCompactingConfiguration**](ModelMessageCompactingConfiguration.md) |  | [optional] 
**model_settings** | [**ModelModelConfiguration**](ModelModelConfiguration.md) |  | [optional] 
**system_prompt** | **object** |  | [optional] 
**thinking_summarization_settings** | [**ModelThinkingSummarizationSettings**](ModelThinkingSummarizationSettings.md) |  | [optional] 
**tool_profiles** | **List[str]** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_agent_configuration import ModelAgentConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of ModelAgentConfiguration from a JSON string
model_agent_configuration_instance = ModelAgentConfiguration.from_json(json)
# print the JSON string representation of the object
print(ModelAgentConfiguration.to_json())

# convert the object into a dict
model_agent_configuration_dict = model_agent_configuration_instance.to_dict()
# create an instance of ModelAgentConfiguration from a dict
model_agent_configuration_from_dict = ModelAgentConfiguration.from_dict(model_agent_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



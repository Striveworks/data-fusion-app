# chariot_api._openapi.awm.SessionsApi

All URIs are relative to */api/awm/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_session_configuration**](SessionsApi.md#get_session_configuration) | **GET** /sessions/{sessionID}/configuration | Gets a Session configuration
[**get_session_secrets**](SessionsApi.md#get_session_secrets) | **GET** /sessions/{sessionID}/secrets | Gets decrypted session secrets for AP or AWE
[**list_sessions_global**](SessionsApi.md#list_sessions_global) | **GET** /sessions | List Sessions
[**patch_session**](SessionsApi.md#patch_session) | **PATCH** /sessions/{sessionID} | Update session display name


# **get_session_configuration**
> OutputResolvedConfigurationResponseModelWorkflowConfiguration get_session_configuration(session_id)

Gets a Session configuration

Gets the configuration for a particular session (sans secrets)

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_resolved_configuration_response_model_workflow_configuration import OutputResolvedConfigurationResponseModelWorkflowConfiguration
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.SessionsApi(api_client)
    session_id = 'session_id_example' # str | Session ID

    try:
        # Gets a Session configuration
        api_response = api_instance.get_session_configuration(session_id)
        print("The response of SessionsApi->get_session_configuration:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SessionsApi->get_session_configuration: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **session_id** | **str**| Session ID | 

### Return type

[**OutputResolvedConfigurationResponseModelWorkflowConfiguration**](OutputResolvedConfigurationResponseModelWorkflowConfiguration.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_session_secrets**
> OutputSessionSecretsResponse get_session_secrets(session_id)

Gets decrypted session secrets for AP or AWE

Resolves the session configuration and returns a mapping of ::secret macros to decrypted values. AP receives non-evaluator secrets; AWE receives secrets nested under evaluator (llm_judge) configs. Forbidden for all other actors.

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_session_secrets_response import OutputSessionSecretsResponse
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.SessionsApi(api_client)
    session_id = 'session_id_example' # str | Session ID

    try:
        # Gets decrypted session secrets for AP or AWE
        api_response = api_instance.get_session_secrets(session_id)
        print("The response of SessionsApi->get_session_secrets:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SessionsApi->get_session_secrets: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **session_id** | **str**| Session ID | 

### Return type

[**OutputSessionSecretsResponse**](OutputSessionSecretsResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_sessions_global**
> OutputPaginatedResponseModelSessionDetails list_sessions_global(workflow_component_id=workflow_component_id, workflow_version_id=workflow_version_id, session_id=session_id, user_id=user_id, agent=agent, var_from=var_from, to=to, from_schedule=from_schedule, limit=limit, sort_order=sort_order, after_key=after_key, calculate_meta=calculate_meta)

List Sessions

Lists sessions across workflow versions visible to the caller. Optional workflow_component_id and workflow_version_id filters may be combined (AND).

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_paginated_response_model_session_details import OutputPaginatedResponseModelSessionDetails
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.SessionsApi(api_client)
    workflow_component_id = ['workflow_component_id_example'] # List[str] | Workflow component IDs (optional)
    workflow_version_id = ['workflow_version_id_example'] # List[str] | Workflow version IDs (optional)
    session_id = ['session_id_example'] # List[str] | Session ID (optional)
    user_id = ['user_id_example'] # List[str] | User ID (optional)
    agent = ['agent_example'] # List[str] | Agents (optional)
    var_from = 'var_from_example' # str | From (ISO Formatted Date) (optional)
    to = 'to_example' # str | To (ISO Formatted Date) (optional)
    from_schedule = True # bool | If true, only include sessions created by schedules (optional)
    limit = 56 # int | Limit (defaults to 10, max 1000) (optional)
    sort_order = 'sort_order_example' # str | Sort asc/desc (defaults to desc) (optional)
    after_key = 'after_key_example' # str | Pagination Key (optional)
    calculate_meta = True # bool | Provide metadata with total counts in the response (optional)

    try:
        # List Sessions
        api_response = api_instance.list_sessions_global(workflow_component_id=workflow_component_id, workflow_version_id=workflow_version_id, session_id=session_id, user_id=user_id, agent=agent, var_from=var_from, to=to, from_schedule=from_schedule, limit=limit, sort_order=sort_order, after_key=after_key, calculate_meta=calculate_meta)
        print("The response of SessionsApi->list_sessions_global:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SessionsApi->list_sessions_global: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_component_id** | [**List[str]**](str.md)| Workflow component IDs | [optional] 
 **workflow_version_id** | [**List[str]**](str.md)| Workflow version IDs | [optional] 
 **session_id** | [**List[str]**](str.md)| Session ID | [optional] 
 **user_id** | [**List[str]**](str.md)| User ID | [optional] 
 **agent** | [**List[str]**](str.md)| Agents | [optional] 
 **var_from** | **str**| From (ISO Formatted Date) | [optional] 
 **to** | **str**| To (ISO Formatted Date) | [optional] 
 **from_schedule** | **bool**| If true, only include sessions created by schedules | [optional] 
 **limit** | **int**| Limit (defaults to 10, max 1000) | [optional] 
 **sort_order** | **str**| Sort asc/desc (defaults to desc) | [optional] 
 **after_key** | **str**| Pagination Key | [optional] 
 **calculate_meta** | **bool**| Provide metadata with total counts in the response | [optional] 

### Return type

[**OutputPaginatedResponseModelSessionDetails**](OutputPaginatedResponseModelSessionDetails.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **patch_session**
> OutputResponseModelSessionMetadata patch_session(session_id, body)

Update session display name

Sets or updates the display name for a session

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_patch_session_request import InputPatchSessionRequest
from chariot_api._openapi.awm.models.output_response_model_session_metadata import OutputResponseModelSessionMetadata
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.SessionsApi(api_client)
    session_id = 'session_id_example' # str | Session ID
    body = chariot_api._openapi.awm.InputPatchSessionRequest() # InputPatchSessionRequest | Request Body

    try:
        # Update session display name
        api_response = api_instance.patch_session(session_id, body)
        print("The response of SessionsApi->patch_session:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling SessionsApi->patch_session: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **session_id** | **str**| Session ID | 
 **body** | [**InputPatchSessionRequest**](InputPatchSessionRequest.md)| Request Body | 

### Return type

[**OutputResponseModelSessionMetadata**](OutputResponseModelSessionMetadata.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


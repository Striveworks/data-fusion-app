# ModelToolDisplayConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**generate_display_strings** | **bool** |  | [optional] 
**templates** | [**Dict[str, ModelToolDisplay]**](ModelToolDisplay.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_tool_display_configuration import ModelToolDisplayConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of ModelToolDisplayConfiguration from a JSON string
model_tool_display_configuration_instance = ModelToolDisplayConfiguration.from_json(json)
# print the JSON string representation of the object
print(ModelToolDisplayConfiguration.to_json())

# convert the object into a dict
model_tool_display_configuration_dict = model_tool_display_configuration_instance.to_dict()
# create an instance of ModelToolDisplayConfiguration from a dict
model_tool_display_configuration_from_dict = ModelToolDisplayConfiguration.from_dict(model_tool_display_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



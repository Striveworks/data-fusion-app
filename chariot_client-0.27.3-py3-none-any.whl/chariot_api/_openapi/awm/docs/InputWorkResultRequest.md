# InputWorkResultRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | **object** |  | 
**type** | **str** |  | 
**work_id** | **str** |  | 

## Example

```python
from chariot_api._openapi.awm.models.input_work_result_request import InputWorkResultRequest

# TODO update the JSON string below
json = "{}"
# create an instance of InputWorkResultRequest from a JSON string
input_work_result_request_instance = InputWorkResultRequest.from_json(json)
# print the JSON string representation of the object
print(InputWorkResultRequest.to_json())

# convert the object into a dict
input_work_result_request_dict = input_work_result_request_instance.to_dict()
# create an instance of InputWorkResultRequest from a dict
input_work_result_request_from_dict = InputWorkResultRequest.from_dict(input_work_result_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# InputPatchSessionRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**display_name** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.input_patch_session_request import InputPatchSessionRequest

# TODO update the JSON string below
json = "{}"
# create an instance of InputPatchSessionRequest from a JSON string
input_patch_session_request_instance = InputPatchSessionRequest.from_json(json)
# print the JSON string representation of the object
print(InputPatchSessionRequest.to_json())

# convert the object into a dict
input_patch_session_request_dict = input_patch_session_request_instance.to_dict()
# create an instance of InputPatchSessionRequest from a dict
input_patch_session_request_from_dict = InputPatchSessionRequest.from_dict(input_patch_session_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# ModelPodDetails


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**status** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_pod_details import ModelPodDetails

# TODO update the JSON string below
json = "{}"
# create an instance of ModelPodDetails from a JSON string
model_pod_details_instance = ModelPodDetails.from_json(json)
# print the JSON string representation of the object
print(ModelPodDetails.to_json())

# convert the object into a dict
model_pod_details_dict = model_pod_details_instance.to_dict()
# create an instance of ModelPodDetails from a dict
model_pod_details_from_dict = ModelPodDetails.from_dict(model_pod_details_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



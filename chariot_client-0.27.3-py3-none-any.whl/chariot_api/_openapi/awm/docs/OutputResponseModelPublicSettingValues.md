# OutputResponseModelPublicSettingValues


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | **Dict[str, object]** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_response_model_public_setting_values import OutputResponseModelPublicSettingValues

# TODO update the JSON string below
json = "{}"
# create an instance of OutputResponseModelPublicSettingValues from a JSON string
output_response_model_public_setting_values_instance = OutputResponseModelPublicSettingValues.from_json(json)
# print the JSON string representation of the object
print(OutputResponseModelPublicSettingValues.to_json())

# convert the object into a dict
output_response_model_public_setting_values_dict = output_response_model_public_setting_values_instance.to_dict()
# create an instance of OutputResponseModelPublicSettingValues from a dict
output_response_model_public_setting_values_from_dict = OutputResponseModelPublicSettingValues.from_dict(output_response_model_public_setting_values_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



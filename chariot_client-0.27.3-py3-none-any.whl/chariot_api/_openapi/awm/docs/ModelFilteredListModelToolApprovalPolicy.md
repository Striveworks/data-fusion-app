# ModelFilteredListModelToolApprovalPolicy


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**exclude** | [**List[ModelToolApprovalPolicy]**](ModelToolApprovalPolicy.md) |  | [optional] 
**include** | [**List[ModelToolApprovalPolicy]**](ModelToolApprovalPolicy.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_filtered_list_model_tool_approval_policy import ModelFilteredListModelToolApprovalPolicy

# TODO update the JSON string below
json = "{}"
# create an instance of ModelFilteredListModelToolApprovalPolicy from a JSON string
model_filtered_list_model_tool_approval_policy_instance = ModelFilteredListModelToolApprovalPolicy.from_json(json)
# print the JSON string representation of the object
print(ModelFilteredListModelToolApprovalPolicy.to_json())

# convert the object into a dict
model_filtered_list_model_tool_approval_policy_dict = model_filtered_list_model_tool_approval_policy_instance.to_dict()
# create an instance of ModelFilteredListModelToolApprovalPolicy from a dict
model_filtered_list_model_tool_approval_policy_from_dict = ModelFilteredListModelToolApprovalPolicy.from_dict(model_filtered_list_model_tool_approval_policy_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



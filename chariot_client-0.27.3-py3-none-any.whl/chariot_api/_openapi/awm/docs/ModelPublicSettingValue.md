# ModelPublicSettingValue


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**var_schema** | **object** |  | [optional] 
**value** | **object** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_public_setting_value import ModelPublicSettingValue

# TODO update the JSON string below
json = "{}"
# create an instance of ModelPublicSettingValue from a JSON string
model_public_setting_value_instance = ModelPublicSettingValue.from_json(json)
# print the JSON string representation of the object
print(ModelPublicSettingValue.to_json())

# convert the object into a dict
model_public_setting_value_dict = model_public_setting_value_instance.to_dict()
# create an instance of ModelPublicSettingValue from a dict
model_public_setting_value_from_dict = ModelPublicSettingValue.from_dict(model_public_setting_value_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



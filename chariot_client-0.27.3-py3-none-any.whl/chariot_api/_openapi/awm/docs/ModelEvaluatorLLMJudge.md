# ModelEvaluatorLLMJudge


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**model_settings** | [**ModelModelConfiguration**](ModelModelConfiguration.md) |  | [optional] 
**output_schema** | **Dict[str, object]** |  | [optional] 
**prompt** | **str** |  | [optional] 
**rubric** | **Dict[str, object]** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_evaluator_llm_judge import ModelEvaluatorLLMJudge

# TODO update the JSON string below
json = "{}"
# create an instance of ModelEvaluatorLLMJudge from a JSON string
model_evaluator_llm_judge_instance = ModelEvaluatorLLMJudge.from_json(json)
# print the JSON string representation of the object
print(ModelEvaluatorLLMJudge.to_json())

# convert the object into a dict
model_evaluator_llm_judge_dict = model_evaluator_llm_judge_instance.to_dict()
# create an instance of ModelEvaluatorLLMJudge from a dict
model_evaluator_llm_judge_from_dict = ModelEvaluatorLLMJudge.from_dict(model_evaluator_llm_judge_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



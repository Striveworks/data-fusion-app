# OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelAgentConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**ModelConfigurationComponentVersionModelAgentConfiguration**](ModelConfigurationComponentVersionModelAgentConfiguration.md) |  | [optional] 
**overrides** | **object** |  | [optional] 
**resolved** | **object** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_resolved_configuration_response_model_configuration_component_version_model_agent_configuration import OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelAgentConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelAgentConfiguration from a JSON string
output_resolved_configuration_response_model_configuration_component_version_model_agent_configuration_instance = OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelAgentConfiguration.from_json(json)
# print the JSON string representation of the object
print(OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelAgentConfiguration.to_json())

# convert the object into a dict
output_resolved_configuration_response_model_configuration_component_version_model_agent_configuration_dict = output_resolved_configuration_response_model_configuration_component_version_model_agent_configuration_instance.to_dict()
# create an instance of OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelAgentConfiguration from a dict
output_resolved_configuration_response_model_configuration_component_version_model_agent_configuration_from_dict = OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelAgentConfiguration.from_dict(output_resolved_configuration_response_model_configuration_component_version_model_agent_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



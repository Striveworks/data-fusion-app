# ModelToolEvaluatorGuardrailWhen


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**all** | [**List[ModelToolEvaluatorGuardrailCondition]**](ModelToolEvaluatorGuardrailCondition.md) |  | [optional] 
**any** | [**List[ModelToolEvaluatorGuardrailCondition]**](ModelToolEvaluatorGuardrailCondition.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_tool_evaluator_guardrail_when import ModelToolEvaluatorGuardrailWhen

# TODO update the JSON string below
json = "{}"
# create an instance of ModelToolEvaluatorGuardrailWhen from a JSON string
model_tool_evaluator_guardrail_when_instance = ModelToolEvaluatorGuardrailWhen.from_json(json)
# print the JSON string representation of the object
print(ModelToolEvaluatorGuardrailWhen.to_json())

# convert the object into a dict
model_tool_evaluator_guardrail_when_dict = model_tool_evaluator_guardrail_when_instance.to_dict()
# create an instance of ModelToolEvaluatorGuardrailWhen from a dict
model_tool_evaluator_guardrail_when_from_dict = ModelToolEvaluatorGuardrailWhen.from_dict(model_tool_evaluator_guardrail_when_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



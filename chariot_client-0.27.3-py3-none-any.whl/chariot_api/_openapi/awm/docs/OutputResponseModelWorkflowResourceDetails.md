# OutputResponseModelWorkflowResourceDetails


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**ModelWorkflowResourceDetails**](ModelWorkflowResourceDetails.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_response_model_workflow_resource_details import OutputResponseModelWorkflowResourceDetails

# TODO update the JSON string below
json = "{}"
# create an instance of OutputResponseModelWorkflowResourceDetails from a JSON string
output_response_model_workflow_resource_details_instance = OutputResponseModelWorkflowResourceDetails.from_json(json)
# print the JSON string representation of the object
print(OutputResponseModelWorkflowResourceDetails.to_json())

# convert the object into a dict
output_response_model_workflow_resource_details_dict = output_response_model_workflow_resource_details_instance.to_dict()
# create an instance of OutputResponseModelWorkflowResourceDetails from a dict
output_response_model_workflow_resource_details_from_dict = OutputResponseModelWorkflowResourceDetails.from_dict(output_response_model_workflow_resource_details_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



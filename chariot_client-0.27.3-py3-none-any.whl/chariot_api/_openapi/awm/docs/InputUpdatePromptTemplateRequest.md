# InputUpdatePromptTemplateRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**content** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**enabled** | **bool** |  | [optional] 
**name** | **str** |  | [optional] 
**visibility** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.input_update_prompt_template_request import InputUpdatePromptTemplateRequest

# TODO update the JSON string below
json = "{}"
# create an instance of InputUpdatePromptTemplateRequest from a JSON string
input_update_prompt_template_request_instance = InputUpdatePromptTemplateRequest.from_json(json)
# print the JSON string representation of the object
print(InputUpdatePromptTemplateRequest.to_json())

# convert the object into a dict
input_update_prompt_template_request_dict = input_update_prompt_template_request_instance.to_dict()
# create an instance of InputUpdatePromptTemplateRequest from a dict
input_update_prompt_template_request_from_dict = InputUpdatePromptTemplateRequest.from_dict(input_update_prompt_template_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# ModelListToolCallStatisticsResponseMetadata


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total_calls** | **int** |  | [optional] 
**total_tools** | **int** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_list_tool_call_statistics_response_metadata import ModelListToolCallStatisticsResponseMetadata

# TODO update the JSON string below
json = "{}"
# create an instance of ModelListToolCallStatisticsResponseMetadata from a JSON string
model_list_tool_call_statistics_response_metadata_instance = ModelListToolCallStatisticsResponseMetadata.from_json(json)
# print the JSON string representation of the object
print(ModelListToolCallStatisticsResponseMetadata.to_json())

# convert the object into a dict
model_list_tool_call_statistics_response_metadata_dict = model_list_tool_call_statistics_response_metadata_instance.to_dict()
# create an instance of ModelListToolCallStatisticsResponseMetadata from a dict
model_list_tool_call_statistics_response_metadata_from_dict = ModelListToolCallStatisticsResponseMetadata.from_dict(model_list_tool_call_statistics_response_metadata_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



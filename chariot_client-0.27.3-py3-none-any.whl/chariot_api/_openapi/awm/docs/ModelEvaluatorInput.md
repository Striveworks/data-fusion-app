# ModelEvaluatorInput


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**model_context** | **Dict[str, object]** |  | [optional] 
**prior_tool_outputs** | [**ModelEvaluatorInputPriorToolOutputs**](ModelEvaluatorInputPriorToolOutputs.md) |  | [optional] 
**tool_schema** | **Dict[str, object]** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_evaluator_input import ModelEvaluatorInput

# TODO update the JSON string below
json = "{}"
# create an instance of ModelEvaluatorInput from a JSON string
model_evaluator_input_instance = ModelEvaluatorInput.from_json(json)
# print the JSON string representation of the object
print(ModelEvaluatorInput.to_json())

# convert the object into a dict
model_evaluator_input_dict = model_evaluator_input_instance.to_dict()
# create an instance of ModelEvaluatorInput from a dict
model_evaluator_input_from_dict = ModelEvaluatorInput.from_dict(model_evaluator_input_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# ModelFilteredListString


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**exclude** | **List[str]** |  | [optional] 
**include** | **List[str]** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_filtered_list_string import ModelFilteredListString

# TODO update the JSON string below
json = "{}"
# create an instance of ModelFilteredListString from a JSON string
model_filtered_list_string_instance = ModelFilteredListString.from_json(json)
# print the JSON string representation of the object
print(ModelFilteredListString.to_json())

# convert the object into a dict
model_filtered_list_string_dict = model_filtered_list_string_instance.to_dict()
# create an instance of ModelFilteredListString from a dict
model_filtered_list_string_from_dict = ModelFilteredListString.from_dict(model_filtered_list_string_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



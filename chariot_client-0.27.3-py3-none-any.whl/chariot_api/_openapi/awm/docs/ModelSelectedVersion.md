# ModelSelectedVersion


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_at** | **str** |  | [optional] 
**created_by** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**id** | **str** |  | [optional] 
**metadata** | [**ModelConfigurationComponentMetadata**](ModelConfigurationComponentMetadata.md) |  | [optional] 
**session_count** | **int** |  | [optional] 
**version** | **int** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_selected_version import ModelSelectedVersion

# TODO update the JSON string below
json = "{}"
# create an instance of ModelSelectedVersion from a JSON string
model_selected_version_instance = ModelSelectedVersion.from_json(json)
# print the JSON string representation of the object
print(ModelSelectedVersion.to_json())

# convert the object into a dict
model_selected_version_dict = model_selected_version_instance.to_dict()
# create an instance of ModelSelectedVersion from a dict
model_selected_version_from_dict = ModelSelectedVersion.from_dict(model_selected_version_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



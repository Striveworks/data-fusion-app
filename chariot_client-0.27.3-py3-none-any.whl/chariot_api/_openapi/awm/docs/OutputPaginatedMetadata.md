# OutputPaginatedMetadata


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total** | **int** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_paginated_metadata import OutputPaginatedMetadata

# TODO update the JSON string below
json = "{}"
# create an instance of OutputPaginatedMetadata from a JSON string
output_paginated_metadata_instance = OutputPaginatedMetadata.from_json(json)
# print the JSON string representation of the object
print(OutputPaginatedMetadata.to_json())

# convert the object into a dict
output_paginated_metadata_dict = output_paginated_metadata_instance.to_dict()
# create an instance of OutputPaginatedMetadata from a dict
output_paginated_metadata_from_dict = OutputPaginatedMetadata.from_dict(output_paginated_metadata_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



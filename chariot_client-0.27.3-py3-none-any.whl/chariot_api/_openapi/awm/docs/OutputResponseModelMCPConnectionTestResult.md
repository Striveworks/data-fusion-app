# OutputResponseModelMCPConnectionTestResult


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**ModelMCPConnectionTestResult**](ModelMCPConnectionTestResult.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_response_model_mcp_connection_test_result import OutputResponseModelMCPConnectionTestResult

# TODO update the JSON string below
json = "{}"
# create an instance of OutputResponseModelMCPConnectionTestResult from a JSON string
output_response_model_mcp_connection_test_result_instance = OutputResponseModelMCPConnectionTestResult.from_json(json)
# print the JSON string representation of the object
print(OutputResponseModelMCPConnectionTestResult.to_json())

# convert the object into a dict
output_response_model_mcp_connection_test_result_dict = output_response_model_mcp_connection_test_result_instance.to_dict()
# create an instance of OutputResponseModelMCPConnectionTestResult from a dict
output_response_model_mcp_connection_test_result_from_dict = OutputResponseModelMCPConnectionTestResult.from_dict(output_response_model_mcp_connection_test_result_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



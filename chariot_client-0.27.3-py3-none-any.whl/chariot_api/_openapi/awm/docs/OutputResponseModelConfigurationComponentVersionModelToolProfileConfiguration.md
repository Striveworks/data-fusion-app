# OutputResponseModelConfigurationComponentVersionModelToolProfileConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**ModelConfigurationComponentVersionModelToolProfileConfiguration**](ModelConfigurationComponentVersionModelToolProfileConfiguration.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_response_model_configuration_component_version_model_tool_profile_configuration import OutputResponseModelConfigurationComponentVersionModelToolProfileConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of OutputResponseModelConfigurationComponentVersionModelToolProfileConfiguration from a JSON string
output_response_model_configuration_component_version_model_tool_profile_configuration_instance = OutputResponseModelConfigurationComponentVersionModelToolProfileConfiguration.from_json(json)
# print the JSON string representation of the object
print(OutputResponseModelConfigurationComponentVersionModelToolProfileConfiguration.to_json())

# convert the object into a dict
output_response_model_configuration_component_version_model_tool_profile_configuration_dict = output_response_model_configuration_component_version_model_tool_profile_configuration_instance.to_dict()
# create an instance of OutputResponseModelConfigurationComponentVersionModelToolProfileConfiguration from a dict
output_response_model_configuration_component_version_model_tool_profile_configuration_from_dict = OutputResponseModelConfigurationComponentVersionModelToolProfileConfiguration.from_dict(output_response_model_configuration_component_version_model_tool_profile_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



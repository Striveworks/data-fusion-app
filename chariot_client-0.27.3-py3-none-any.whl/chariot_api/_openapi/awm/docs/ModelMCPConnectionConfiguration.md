# ModelMCPConnectionConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**args** | **List[str]** |  | [optional] 
**auth** | **Dict[str, object]** |  | [optional] 
**command** | **str** |  | [optional] 
**endpoint** | **str** |  | [optional] 
**last_connected_at** | **str** |  | [optional] 
**transport** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_mcp_connection_configuration import ModelMCPConnectionConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of ModelMCPConnectionConfiguration from a JSON string
model_mcp_connection_configuration_instance = ModelMCPConnectionConfiguration.from_json(json)
# print the JSON string representation of the object
print(ModelMCPConnectionConfiguration.to_json())

# convert the object into a dict
model_mcp_connection_configuration_dict = model_mcp_connection_configuration_instance.to_dict()
# create an instance of ModelMCPConnectionConfiguration from a dict
model_mcp_connection_configuration_from_dict = ModelMCPConnectionConfiguration.from_dict(model_mcp_connection_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



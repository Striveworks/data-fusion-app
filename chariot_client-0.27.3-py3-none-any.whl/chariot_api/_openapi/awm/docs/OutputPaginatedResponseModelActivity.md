# OutputPaginatedResponseModelActivity


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**after_key** | **str** |  | [optional] 
**data** | [**List[ModelActivity]**](ModelActivity.md) |  | [optional] 
**metadata** | [**OutputPaginatedMetadata**](OutputPaginatedMetadata.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_paginated_response_model_activity import OutputPaginatedResponseModelActivity

# TODO update the JSON string below
json = "{}"
# create an instance of OutputPaginatedResponseModelActivity from a JSON string
output_paginated_response_model_activity_instance = OutputPaginatedResponseModelActivity.from_json(json)
# print the JSON string representation of the object
print(OutputPaginatedResponseModelActivity.to_json())

# convert the object into a dict
output_paginated_response_model_activity_dict = output_paginated_response_model_activity_instance.to_dict()
# create an instance of OutputPaginatedResponseModelActivity from a dict
output_paginated_response_model_activity_from_dict = OutputPaginatedResponseModelActivity.from_dict(output_paginated_response_model_activity_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



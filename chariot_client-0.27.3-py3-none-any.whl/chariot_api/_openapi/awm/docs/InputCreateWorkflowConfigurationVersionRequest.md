# InputCreateWorkflowConfigurationVersionRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**config** | **List[int]** |  | 
**description** | **str** |  | [optional] 
**paused** | **bool** |  | [optional] 
**stage** | **str** |  | [optional] 
**version_changelog** | **str** |  | 

## Example

```python
from chariot_api._openapi.awm.models.input_create_workflow_configuration_version_request import InputCreateWorkflowConfigurationVersionRequest

# TODO update the JSON string below
json = "{}"
# create an instance of InputCreateWorkflowConfigurationVersionRequest from a JSON string
input_create_workflow_configuration_version_request_instance = InputCreateWorkflowConfigurationVersionRequest.from_json(json)
# print the JSON string representation of the object
print(InputCreateWorkflowConfigurationVersionRequest.to_json())

# convert the object into a dict
input_create_workflow_configuration_version_request_dict = input_create_workflow_configuration_version_request_instance.to_dict()
# create an instance of InputCreateWorkflowConfigurationVersionRequest from a dict
input_create_workflow_configuration_version_request_from_dict = InputCreateWorkflowConfigurationVersionRequest.from_dict(input_create_workflow_configuration_version_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# OutputResponseModelFeedbackStatistics


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**ModelFeedbackStatistics**](ModelFeedbackStatistics.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_response_model_feedback_statistics import OutputResponseModelFeedbackStatistics

# TODO update the JSON string below
json = "{}"
# create an instance of OutputResponseModelFeedbackStatistics from a JSON string
output_response_model_feedback_statistics_instance = OutputResponseModelFeedbackStatistics.from_json(json)
# print the JSON string representation of the object
print(OutputResponseModelFeedbackStatistics.to_json())

# convert the object into a dict
output_response_model_feedback_statistics_dict = output_response_model_feedback_statistics_instance.to_dict()
# create an instance of OutputResponseModelFeedbackStatistics from a dict
output_response_model_feedback_statistics_from_dict = OutputResponseModelFeedbackStatistics.from_dict(output_response_model_feedback_statistics_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# ModelToolProfileConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**approval_policy** | [**ModelFilteredListModelToolApprovalPolicy**](ModelFilteredListModelToolApprovalPolicy.md) |  | [optional] 
**artifact_tools** | [**ModelFilteredListString**](ModelFilteredListString.md) |  | [optional] 
**local_tools** | [**ModelFilteredListModelLocalTool**](ModelFilteredListModelLocalTool.md) |  | [optional] 
**mcp_tools** | [**List[ModelMCPToolConfiguration]**](ModelMCPToolConfiguration.md) |  | [optional] 
**redacted_tools** | [**ModelFilteredListString**](ModelFilteredListString.md) |  | [optional] 
**retries** | **int** |  | [optional] 
**timeout_seconds** | **float** |  | [optional] 
**tool_display** | [**ModelToolDisplayConfiguration**](ModelToolDisplayConfiguration.md) |  | [optional] 
**tool_evaluator_refs** | [**List[ModelToolEvaluatorRef]**](ModelToolEvaluatorRef.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_tool_profile_configuration import ModelToolProfileConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of ModelToolProfileConfiguration from a JSON string
model_tool_profile_configuration_instance = ModelToolProfileConfiguration.from_json(json)
# print the JSON string representation of the object
print(ModelToolProfileConfiguration.to_json())

# convert the object into a dict
model_tool_profile_configuration_dict = model_tool_profile_configuration_instance.to_dict()
# create an instance of ModelToolProfileConfiguration from a dict
model_tool_profile_configuration_from_dict = ModelToolProfileConfiguration.from_dict(model_tool_profile_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



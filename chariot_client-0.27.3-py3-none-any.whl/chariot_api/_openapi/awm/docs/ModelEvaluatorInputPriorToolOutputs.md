# ModelEvaluatorInputPriorToolOutputs


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**max_items** | **int** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_evaluator_input_prior_tool_outputs import ModelEvaluatorInputPriorToolOutputs

# TODO update the JSON string below
json = "{}"
# create an instance of ModelEvaluatorInputPriorToolOutputs from a JSON string
model_evaluator_input_prior_tool_outputs_instance = ModelEvaluatorInputPriorToolOutputs.from_json(json)
# print the JSON string representation of the object
print(ModelEvaluatorInputPriorToolOutputs.to_json())

# convert the object into a dict
model_evaluator_input_prior_tool_outputs_dict = model_evaluator_input_prior_tool_outputs_instance.to_dict()
# create an instance of ModelEvaluatorInputPriorToolOutputs from a dict
model_evaluator_input_prior_tool_outputs_from_dict = ModelEvaluatorInputPriorToolOutputs.from_dict(model_evaluator_input_prior_tool_outputs_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# ModelSessionMetadata


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**display_name** | **str** |  | [optional] 
**session_id** | **str** |  | [optional] 
**updated_at** | **str** |  | [optional] 
**updated_by** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_session_metadata import ModelSessionMetadata

# TODO update the JSON string below
json = "{}"
# create an instance of ModelSessionMetadata from a JSON string
model_session_metadata_instance = ModelSessionMetadata.from_json(json)
# print the JSON string representation of the object
print(ModelSessionMetadata.to_json())

# convert the object into a dict
model_session_metadata_dict = model_session_metadata_instance.to_dict()
# create an instance of ModelSessionMetadata from a dict
model_session_metadata_from_dict = ModelSessionMetadata.from_dict(model_session_metadata_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



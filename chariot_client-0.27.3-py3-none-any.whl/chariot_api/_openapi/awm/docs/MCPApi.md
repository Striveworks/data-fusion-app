# chariot_api._openapi.awm.MCPApi

All URIs are relative to */api/awm/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**test_mcp_configuration_connection**](MCPApi.md#test_mcp_configuration_connection) | **POST** /configurations/mcp-connection/test | Test MCP Configuration Connection


# **test_mcp_configuration_connection**
> OutputResponseModelMCPConnectionTestResult test_mcp_configuration_connection(body)

Test MCP Configuration Connection

Tests the MCP Connection of an MCP Configuration. Returns connected tools on success.

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_test_mcp_connection_request import InputTestMCPConnectionRequest
from chariot_api._openapi.awm.models.output_response_model_mcp_connection_test_result import OutputResponseModelMCPConnectionTestResult
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.MCPApi(api_client)
    body = chariot_api._openapi.awm.InputTestMCPConnectionRequest() # InputTestMCPConnectionRequest | Request Body

    try:
        # Test MCP Configuration Connection
        api_response = api_instance.test_mcp_configuration_connection(body)
        print("The response of MCPApi->test_mcp_configuration_connection:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling MCPApi->test_mcp_configuration_connection: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**InputTestMCPConnectionRequest**](InputTestMCPConnectionRequest.md)| Request Body | 

### Return type

[**OutputResponseModelMCPConnectionTestResult**](OutputResponseModelMCPConnectionTestResult.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**418** | I&#39;m a teapot |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


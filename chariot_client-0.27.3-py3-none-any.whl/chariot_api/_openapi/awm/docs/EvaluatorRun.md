# EvaluatorRun


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**agent_name** | **str** |  | [optional] 
**attempts** | **int** |  | [optional] 
**created_at** | **str** |  | [optional] 
**evaluator_response_activity_id** | **str** |  | [optional] 
**guardrail_decision** | [**EvaluatorRunGuardrailDecision**](EvaluatorRunGuardrailDecision.md) |  | [optional] 
**latency_seconds** | **float** |  | [optional] 
**runtime_seconds** | **float** |  | [optional] 
**session_id** | **str** |  | [optional] 
**status** | **str** |  | [optional] 
**tool_name** | **str** |  | [optional] 
**trigger_event_type** | **str** |  | [optional] 
**workflow_component_id** | **str** |  | [optional] 
**workflow_version_id** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.evaluator_run import EvaluatorRun

# TODO update the JSON string below
json = "{}"
# create an instance of EvaluatorRun from a JSON string
evaluator_run_instance = EvaluatorRun.from_json(json)
# print the JSON string representation of the object
print(EvaluatorRun.to_json())

# convert the object into a dict
evaluator_run_dict = evaluator_run_instance.to_dict()
# create an instance of EvaluatorRun from a dict
evaluator_run_from_dict = EvaluatorRun.from_dict(evaluator_run_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



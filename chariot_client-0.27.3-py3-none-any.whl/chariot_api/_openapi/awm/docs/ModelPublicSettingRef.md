# ModelPublicSettingRef


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ref** | **str** |  | [optional] 
**var_schema** | **object** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_public_setting_ref import ModelPublicSettingRef

# TODO update the JSON string below
json = "{}"
# create an instance of ModelPublicSettingRef from a JSON string
model_public_setting_ref_instance = ModelPublicSettingRef.from_json(json)
# print the JSON string representation of the object
print(ModelPublicSettingRef.to_json())

# convert the object into a dict
model_public_setting_ref_dict = model_public_setting_ref_instance.to_dict()
# create an instance of ModelPublicSettingRef from a dict
model_public_setting_ref_from_dict = ModelPublicSettingRef.from_dict(model_public_setting_ref_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



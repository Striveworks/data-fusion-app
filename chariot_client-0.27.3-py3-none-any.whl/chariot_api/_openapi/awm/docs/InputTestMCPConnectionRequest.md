# InputTestMCPConnectionRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**config** | **List[int]** |  | [optional] 
**project_id** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.input_test_mcp_connection_request import InputTestMCPConnectionRequest

# TODO update the JSON string below
json = "{}"
# create an instance of InputTestMCPConnectionRequest from a JSON string
input_test_mcp_connection_request_instance = InputTestMCPConnectionRequest.from_json(json)
# print the JSON string representation of the object
print(InputTestMCPConnectionRequest.to_json())

# convert the object into a dict
input_test_mcp_connection_request_dict = input_test_mcp_connection_request_instance.to_dict()
# create an instance of InputTestMCPConnectionRequest from a dict
input_test_mcp_connection_request_from_dict = InputTestMCPConnectionRequest.from_dict(input_test_mcp_connection_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



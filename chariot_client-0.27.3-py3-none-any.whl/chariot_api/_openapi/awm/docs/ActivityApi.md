# chariot_api._openapi.awm.ActivityApi

All URIs are relative to */api/awm/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_activity**](ActivityApi.md#get_activity) | **GET** /activities/{activityID} | Get an activity
[**list_activity**](ActivityApi.md#list_activity) | **GET** /workflows/{workflowID}/activity | List Activity
[**list_activity_global**](ActivityApi.md#list_activity_global) | **GET** /activity | List Activity
[**list_sessions**](ActivityApi.md#list_sessions) | **GET** /workflows/{workflowID}/sessions | List Activity Session Details
[**list_tool_call_statistics**](ActivityApi.md#list_tool_call_statistics) | **GET** /workflows/{workflowID}/tool-call-statistics | Get Tool Call Statistics
[**list_tool_call_statistics_global**](ActivityApi.md#list_tool_call_statistics_global) | **GET** /tool-calls/statistics | Get Tool Call Statistics
[**list_tool_calls**](ActivityApi.md#list_tool_calls) | **GET** /workflows/{workflowID}/tool-calls | List Tool Calls
[**list_tool_calls_global**](ActivityApi.md#list_tool_calls_global) | **GET** /tool-calls | List Tool Calls
[**send_activity**](ActivityApi.md#send_activity) | **POST** /workflows/{workflowID}/activity | Send Activity


# **get_activity**
> OutputResponseModelActivity get_activity(activity_id)

Get an activity

Gets one activity by ID. The activity includes the current caller's own feedback. Reviewer rows are included only while the caller still has AllSessions read access.

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_response_model_activity import OutputResponseModelActivity
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ActivityApi(api_client)
    activity_id = 'activity_id_example' # str | Activity ID

    try:
        # Get an activity
        api_response = api_instance.get_activity(activity_id)
        print("The response of ActivityApi->get_activity:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ActivityApi->get_activity: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **activity_id** | **str**| Activity ID | 

### Return type

[**OutputResponseModelActivity**](OutputResponseModelActivity.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_activity**
> OutputPaginatedResponseModelActivity list_activity(workflow_id, agent=agent, session_id=session_id, user_id=user_id, type=type, var_from=var_from, to=to, pending_approval=pending_approval, has_artifact=has_artifact, artifact_archived=artifact_archived, from_schedule=from_schedule, limit=limit, sort_order=sort_order, after_key=after_key, calculate_meta=calculate_meta, sort_by=sort_by, after_sequence=after_sequence)

List Activity

Lists activities. Each activity includes the current caller's own feedback. Reviewer rows are included only while the caller still has AllSessions read access. Sequence pagination requires sort_by=sequence and exactly one full session_id. Keep the same filters and sort order when using after_key. after_sequence excludes that sequence and earlier activities, regardless of sort order.

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_paginated_response_model_activity import OutputPaginatedResponseModelActivity
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ActivityApi(api_client)
    workflow_id = 'workflow_id_example' # str | Workflow ID
    agent = ['agent_example'] # List[str] | Agents (optional)
    session_id = ['session_id_example'] # List[str] | Session ID (optional)
    user_id = ['user_id_example'] # List[str] | User ID (optional)
    type = ['type_example'] # List[str] | Activity Types (optional)
    var_from = 'var_from_example' # str | From (ISO Formatted Date) (optional)
    to = 'to_example' # str | To (ISO Formatted Date) (optional)
    pending_approval = True # bool | Only include activities that are pending approval (optional)
    has_artifact = True # bool | Only include activities that contain artifacts (optional)
    artifact_archived = True # bool | Which artifacts should be included based on their archived status. If true, only archived artifacts are returned. If false, only unarchived artifacts are returned. If not provided, all artifacts are returned. (optional)
    from_schedule = True # bool | If true, only include sessions created by schedules. If false, omit sessions created by schedules. If not provided, includes both. (optional)
    limit = 56 # int | Limit (defaults to 10, max 1000) (optional)
    sort_order = 'sort_order_example' # str | Sort asc/desc (defaults to desc) (optional)
    after_key = 'after_key_example' # str | Pagination Key (optional)
    calculate_meta = True # bool | Provide metadata with total counts in the response (optional)
    sort_by = 'sort_by_example' # str | Order by created_at (default) or sequence (optional)
    after_sequence = 56 # int | Exclusive lower sequence bound; requires sort_by=sequence (optional)

    try:
        # List Activity
        api_response = api_instance.list_activity(workflow_id, agent=agent, session_id=session_id, user_id=user_id, type=type, var_from=var_from, to=to, pending_approval=pending_approval, has_artifact=has_artifact, artifact_archived=artifact_archived, from_schedule=from_schedule, limit=limit, sort_order=sort_order, after_key=after_key, calculate_meta=calculate_meta, sort_by=sort_by, after_sequence=after_sequence)
        print("The response of ActivityApi->list_activity:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ActivityApi->list_activity: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_id** | **str**| Workflow ID | 
 **agent** | [**List[str]**](str.md)| Agents | [optional] 
 **session_id** | [**List[str]**](str.md)| Session ID | [optional] 
 **user_id** | [**List[str]**](str.md)| User ID | [optional] 
 **type** | [**List[str]**](str.md)| Activity Types | [optional] 
 **var_from** | **str**| From (ISO Formatted Date) | [optional] 
 **to** | **str**| To (ISO Formatted Date) | [optional] 
 **pending_approval** | **bool**| Only include activities that are pending approval | [optional] 
 **has_artifact** | **bool**| Only include activities that contain artifacts | [optional] 
 **artifact_archived** | **bool**| Which artifacts should be included based on their archived status. If true, only archived artifacts are returned. If false, only unarchived artifacts are returned. If not provided, all artifacts are returned. | [optional] 
 **from_schedule** | **bool**| If true, only include sessions created by schedules. If false, omit sessions created by schedules. If not provided, includes both. | [optional] 
 **limit** | **int**| Limit (defaults to 10, max 1000) | [optional] 
 **sort_order** | **str**| Sort asc/desc (defaults to desc) | [optional] 
 **after_key** | **str**| Pagination Key | [optional] 
 **calculate_meta** | **bool**| Provide metadata with total counts in the response | [optional] 
 **sort_by** | **str**| Order by created_at (default) or sequence | [optional] 
 **after_sequence** | **int**| Exclusive lower sequence bound; requires sort_by&#x3D;sequence | [optional] 

### Return type

[**OutputPaginatedResponseModelActivity**](OutputPaginatedResponseModelActivity.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_activity_global**
> OutputPaginatedResponseModelActivity list_activity_global(workflow_component_id=workflow_component_id, workflow_version_id=workflow_version_id, session_id=session_id, user_id=user_id, agent=agent, type=type, var_from=var_from, to=to, has_artifact=has_artifact, artifact_archived=artifact_archived, pending_approval=pending_approval, from_schedule=from_schedule, limit=limit, sort_order=sort_order, after_key=after_key, calculate_meta=calculate_meta, sort_by=sort_by, after_sequence=after_sequence)

List Activity

Lists activity across workflow versions visible to the caller. Optional workflow_component_id and workflow_version_id filters may be combined (AND). Sequence pagination requires sort_by=sequence and exactly one full session_id. Keep the same filters and sort order when using after_key. after_sequence excludes that sequence and earlier activities, regardless of sort order.

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_paginated_response_model_activity import OutputPaginatedResponseModelActivity
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ActivityApi(api_client)
    workflow_component_id = ['workflow_component_id_example'] # List[str] | Workflow component IDs (optional)
    workflow_version_id = ['workflow_version_id_example'] # List[str] | Workflow version IDs (optional)
    session_id = ['session_id_example'] # List[str] | Session ID (optional)
    user_id = ['user_id_example'] # List[str] | User ID (optional)
    agent = ['agent_example'] # List[str] | Agents (optional)
    type = ['type_example'] # List[str] | Activity types (optional)
    var_from = 'var_from_example' # str | From (ISO Formatted Date) (optional)
    to = 'to_example' # str | To (ISO Formatted Date) (optional)
    has_artifact = True # bool | Only include activities that contain artifacts (optional)
    artifact_archived = True # bool | Which artifacts should be included based on their archived status (optional)
    pending_approval = True # bool | Only include activities that are pending approval (optional)
    from_schedule = True # bool | If true, only include sessions created by schedules (optional)
    limit = 56 # int | Limit (defaults to 10, max 1000) (optional)
    sort_order = 'sort_order_example' # str | Sort asc/desc (defaults to desc) (optional)
    after_key = 'after_key_example' # str | Pagination Key (optional)
    calculate_meta = True # bool | Provide metadata with total counts in the response (optional)
    sort_by = 'sort_by_example' # str | Order by created_at (default) or sequence (optional)
    after_sequence = 56 # int | Exclusive lower sequence bound; requires sort_by=sequence (optional)

    try:
        # List Activity
        api_response = api_instance.list_activity_global(workflow_component_id=workflow_component_id, workflow_version_id=workflow_version_id, session_id=session_id, user_id=user_id, agent=agent, type=type, var_from=var_from, to=to, has_artifact=has_artifact, artifact_archived=artifact_archived, pending_approval=pending_approval, from_schedule=from_schedule, limit=limit, sort_order=sort_order, after_key=after_key, calculate_meta=calculate_meta, sort_by=sort_by, after_sequence=after_sequence)
        print("The response of ActivityApi->list_activity_global:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ActivityApi->list_activity_global: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_component_id** | [**List[str]**](str.md)| Workflow component IDs | [optional] 
 **workflow_version_id** | [**List[str]**](str.md)| Workflow version IDs | [optional] 
 **session_id** | [**List[str]**](str.md)| Session ID | [optional] 
 **user_id** | [**List[str]**](str.md)| User ID | [optional] 
 **agent** | [**List[str]**](str.md)| Agents | [optional] 
 **type** | [**List[str]**](str.md)| Activity types | [optional] 
 **var_from** | **str**| From (ISO Formatted Date) | [optional] 
 **to** | **str**| To (ISO Formatted Date) | [optional] 
 **has_artifact** | **bool**| Only include activities that contain artifacts | [optional] 
 **artifact_archived** | **bool**| Which artifacts should be included based on their archived status | [optional] 
 **pending_approval** | **bool**| Only include activities that are pending approval | [optional] 
 **from_schedule** | **bool**| If true, only include sessions created by schedules | [optional] 
 **limit** | **int**| Limit (defaults to 10, max 1000) | [optional] 
 **sort_order** | **str**| Sort asc/desc (defaults to desc) | [optional] 
 **after_key** | **str**| Pagination Key | [optional] 
 **calculate_meta** | **bool**| Provide metadata with total counts in the response | [optional] 
 **sort_by** | **str**| Order by created_at (default) or sequence | [optional] 
 **after_sequence** | **int**| Exclusive lower sequence bound; requires sort_by&#x3D;sequence | [optional] 

### Return type

[**OutputPaginatedResponseModelActivity**](OutputPaginatedResponseModelActivity.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_sessions**
> OutputPaginatedResponseModelSessionDetails list_sessions(workflow_id, session_id=session_id, user_id=user_id, agent=agent, var_from=var_from, to=to, from_schedule=from_schedule, limit=limit, sort_order=sort_order, after_key=after_key, calculate_meta=calculate_meta)

List Activity Session Details

Lists

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_paginated_response_model_session_details import OutputPaginatedResponseModelSessionDetails
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ActivityApi(api_client)
    workflow_id = 'workflow_id_example' # str | Workflow ID
    session_id = ['session_id_example'] # List[str] | Session ID (optional)
    user_id = ['user_id_example'] # List[str] | User ID (optional)
    agent = ['agent_example'] # List[str] | Agents (optional)
    var_from = 'var_from_example' # str | From (ISO Formatted Date) (optional)
    to = 'to_example' # str | To (ISO Formatted Date) (optional)
    from_schedule = True # bool | If true, only include sessions created by schedules. If false, omit sessions created by schedules. If not provided, includes both. (optional)
    limit = 56 # int | Limit (defaults to 10, max 1000) (optional)
    sort_order = 'sort_order_example' # str | Sort asc/desc (defaults to desc) (optional)
    after_key = 'after_key_example' # str | Pagination Key (optional)
    calculate_meta = True # bool | Provide metadata with total counts in the response (optional)

    try:
        # List Activity Session Details
        api_response = api_instance.list_sessions(workflow_id, session_id=session_id, user_id=user_id, agent=agent, var_from=var_from, to=to, from_schedule=from_schedule, limit=limit, sort_order=sort_order, after_key=after_key, calculate_meta=calculate_meta)
        print("The response of ActivityApi->list_sessions:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ActivityApi->list_sessions: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_id** | **str**| Workflow ID | 
 **session_id** | [**List[str]**](str.md)| Session ID | [optional] 
 **user_id** | [**List[str]**](str.md)| User ID | [optional] 
 **agent** | [**List[str]**](str.md)| Agents | [optional] 
 **var_from** | **str**| From (ISO Formatted Date) | [optional] 
 **to** | **str**| To (ISO Formatted Date) | [optional] 
 **from_schedule** | **bool**| If true, only include sessions created by schedules. If false, omit sessions created by schedules. If not provided, includes both. | [optional] 
 **limit** | **int**| Limit (defaults to 10, max 1000) | [optional] 
 **sort_order** | **str**| Sort asc/desc (defaults to desc) | [optional] 
 **after_key** | **str**| Pagination Key | [optional] 
 **calculate_meta** | **bool**| Provide metadata with total counts in the response | [optional] 

### Return type

[**OutputPaginatedResponseModelSessionDetails**](OutputPaginatedResponseModelSessionDetails.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_tool_call_statistics**
> OutputResponseModelListToolCallStatisticsResponse list_tool_call_statistics(workflow_id, session_id=session_id, agent=agent, tool=tool, var_from=var_from, to=to, from_schedule=from_schedule, limit=limit)

Get Tool Call Statistics

Gets tool call statistics

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_response_model_list_tool_call_statistics_response import OutputResponseModelListToolCallStatisticsResponse
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ActivityApi(api_client)
    workflow_id = 'workflow_id_example' # str | Workflow ID
    session_id = ['session_id_example'] # List[str] | Session ID (optional)
    agent = ['agent_example'] # List[str] | Agents (optional)
    tool = ['tool_example'] # List[str] | Tool name (optional)
    var_from = 'var_from_example' # str | From (ISO Formatted Date) (optional)
    to = 'to_example' # str | To (ISO Formatted Date) (optional)
    from_schedule = True # bool | If true, only include sessions created by schedules. If false, omit sessions created by schedules. If not provided, includes both. (optional)
    limit = 56 # int | Limit (defaults to 10, max 1000) (optional)

    try:
        # Get Tool Call Statistics
        api_response = api_instance.list_tool_call_statistics(workflow_id, session_id=session_id, agent=agent, tool=tool, var_from=var_from, to=to, from_schedule=from_schedule, limit=limit)
        print("The response of ActivityApi->list_tool_call_statistics:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ActivityApi->list_tool_call_statistics: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_id** | **str**| Workflow ID | 
 **session_id** | [**List[str]**](str.md)| Session ID | [optional] 
 **agent** | [**List[str]**](str.md)| Agents | [optional] 
 **tool** | [**List[str]**](str.md)| Tool name | [optional] 
 **var_from** | **str**| From (ISO Formatted Date) | [optional] 
 **to** | **str**| To (ISO Formatted Date) | [optional] 
 **from_schedule** | **bool**| If true, only include sessions created by schedules. If false, omit sessions created by schedules. If not provided, includes both. | [optional] 
 **limit** | **int**| Limit (defaults to 10, max 1000) | [optional] 

### Return type

[**OutputResponseModelListToolCallStatisticsResponse**](OutputResponseModelListToolCallStatisticsResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_tool_call_statistics_global**
> OutputResponseModelListToolCallStatisticsResponse list_tool_call_statistics_global(workflow_component_id=workflow_component_id, workflow_version_id=workflow_version_id, session_id=session_id, agent=agent, tool=tool, var_from=var_from, to=to, from_schedule=from_schedule, limit=limit)

Get Tool Call Statistics

Gets tool call statistics across workflow versions using the same visibility rules as list tool calls.

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_response_model_list_tool_call_statistics_response import OutputResponseModelListToolCallStatisticsResponse
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ActivityApi(api_client)
    workflow_component_id = ['workflow_component_id_example'] # List[str] | Workflow component IDs (optional)
    workflow_version_id = ['workflow_version_id_example'] # List[str] | Workflow version IDs (optional)
    session_id = ['session_id_example'] # List[str] | Session ID (optional)
    agent = ['agent_example'] # List[str] | Agents (optional)
    tool = ['tool_example'] # List[str] | Tool name (optional)
    var_from = 'var_from_example' # str | From (ISO Formatted Date) (optional)
    to = 'to_example' # str | To (ISO Formatted Date) (optional)
    from_schedule = True # bool | If true, only include sessions created by schedules (optional)
    limit = 56 # int | Limit (defaults to 10, max 1000) (optional)

    try:
        # Get Tool Call Statistics
        api_response = api_instance.list_tool_call_statistics_global(workflow_component_id=workflow_component_id, workflow_version_id=workflow_version_id, session_id=session_id, agent=agent, tool=tool, var_from=var_from, to=to, from_schedule=from_schedule, limit=limit)
        print("The response of ActivityApi->list_tool_call_statistics_global:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ActivityApi->list_tool_call_statistics_global: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_component_id** | [**List[str]**](str.md)| Workflow component IDs | [optional] 
 **workflow_version_id** | [**List[str]**](str.md)| Workflow version IDs | [optional] 
 **session_id** | [**List[str]**](str.md)| Session ID | [optional] 
 **agent** | [**List[str]**](str.md)| Agents | [optional] 
 **tool** | [**List[str]**](str.md)| Tool name | [optional] 
 **var_from** | **str**| From (ISO Formatted Date) | [optional] 
 **to** | **str**| To (ISO Formatted Date) | [optional] 
 **from_schedule** | **bool**| If true, only include sessions created by schedules | [optional] 
 **limit** | **int**| Limit (defaults to 10, max 1000) | [optional] 

### Return type

[**OutputResponseModelListToolCallStatisticsResponse**](OutputResponseModelListToolCallStatisticsResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_tool_calls**
> OutputPaginatedResponseModelToolCall list_tool_calls(workflow_id, tool=tool, agent=agent, session_id=session_id, user_id=user_id, pending_approval=pending_approval, has_approval=has_approval, pending_response=pending_response, has_response=has_response, has_artifact=has_artifact, artifact_archived=artifact_archived, from_schedule=from_schedule, limit=limit, sort_order=sort_order, after_key=after_key, calculate_meta=calculate_meta)

List Tool Calls

Lists tool calls

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_paginated_response_model_tool_call import OutputPaginatedResponseModelToolCall
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ActivityApi(api_client)
    workflow_id = 'workflow_id_example' # str | Workflow ID
    tool = ['tool_example'] # List[str] | Tools (optional)
    agent = ['agent_example'] # List[str] | Agents (optional)
    session_id = ['session_id_example'] # List[str] | Session ID (optional)
    user_id = ['user_id_example'] # List[str] | User ID (optional)
    pending_approval = True # bool | Only include tool-call batches that do/don't have approval-gated calls awaiting a decision (optional)
    has_approval = True # bool | Only include tool-call batches that have/don't have at least one approval/rejection response (optional)
    pending_response = True # bool | Only include tool-call batches that are/aren't waiting for one or more currently expected responses (optional)
    has_response = True # bool | Only include tool-call batches that have/don't have at least one response activity (optional)
    has_artifact = True # bool | Only include tool calls that do/don't contain artifacts (optional)
    artifact_archived = True # bool | Which artifacts should be included based on their archived status. If true, only archived artifacts are returned. If false, only unarchived artifacts are returned. If not provided, all artifacts are returned. (optional)
    from_schedule = True # bool | If true, only include sessions created by schedules. If false, omit sessions created by schedules. If not provided, includes both. (optional)
    limit = 56 # int | Limit (defaults to 10, max 1000) (optional)
    sort_order = 'sort_order_example' # str | Sort asc/desc (defaults to desc) (optional)
    after_key = 'after_key_example' # str | Pagination Key (optional)
    calculate_meta = True # bool | Provide metadata with total counts in the response (optional)

    try:
        # List Tool Calls
        api_response = api_instance.list_tool_calls(workflow_id, tool=tool, agent=agent, session_id=session_id, user_id=user_id, pending_approval=pending_approval, has_approval=has_approval, pending_response=pending_response, has_response=has_response, has_artifact=has_artifact, artifact_archived=artifact_archived, from_schedule=from_schedule, limit=limit, sort_order=sort_order, after_key=after_key, calculate_meta=calculate_meta)
        print("The response of ActivityApi->list_tool_calls:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ActivityApi->list_tool_calls: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_id** | **str**| Workflow ID | 
 **tool** | [**List[str]**](str.md)| Tools | [optional] 
 **agent** | [**List[str]**](str.md)| Agents | [optional] 
 **session_id** | [**List[str]**](str.md)| Session ID | [optional] 
 **user_id** | [**List[str]**](str.md)| User ID | [optional] 
 **pending_approval** | **bool**| Only include tool-call batches that do/don&#39;t have approval-gated calls awaiting a decision | [optional] 
 **has_approval** | **bool**| Only include tool-call batches that have/don&#39;t have at least one approval/rejection response | [optional] 
 **pending_response** | **bool**| Only include tool-call batches that are/aren&#39;t waiting for one or more currently expected responses | [optional] 
 **has_response** | **bool**| Only include tool-call batches that have/don&#39;t have at least one response activity | [optional] 
 **has_artifact** | **bool**| Only include tool calls that do/don&#39;t contain artifacts | [optional] 
 **artifact_archived** | **bool**| Which artifacts should be included based on their archived status. If true, only archived artifacts are returned. If false, only unarchived artifacts are returned. If not provided, all artifacts are returned. | [optional] 
 **from_schedule** | **bool**| If true, only include sessions created by schedules. If false, omit sessions created by schedules. If not provided, includes both. | [optional] 
 **limit** | **int**| Limit (defaults to 10, max 1000) | [optional] 
 **sort_order** | **str**| Sort asc/desc (defaults to desc) | [optional] 
 **after_key** | **str**| Pagination Key | [optional] 
 **calculate_meta** | **bool**| Provide metadata with total counts in the response | [optional] 

### Return type

[**OutputPaginatedResponseModelToolCall**](OutputPaginatedResponseModelToolCall.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_tool_calls_global**
> OutputPaginatedResponseModelToolCall list_tool_calls_global(workflow_component_id=workflow_component_id, workflow_version_id=workflow_version_id, tool=tool, agent=agent, session_id=session_id, user_id=user_id, pending_approval=pending_approval, has_approval=has_approval, pending_response=pending_response, has_response=has_response, has_artifact=has_artifact, artifact_archived=artifact_archived, from_schedule=from_schedule, limit=limit, sort_order=sort_order, after_key=after_key, calculate_meta=calculate_meta)

List Tool Calls

Lists tool calls across workflow versions visible to the caller. Optional workflow_component_id and workflow_version_id filters may be combined (AND).

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_paginated_response_model_tool_call import OutputPaginatedResponseModelToolCall
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ActivityApi(api_client)
    workflow_component_id = ['workflow_component_id_example'] # List[str] | Workflow component IDs (optional)
    workflow_version_id = ['workflow_version_id_example'] # List[str] | Workflow version IDs (optional)
    tool = ['tool_example'] # List[str] | Tools (optional)
    agent = ['agent_example'] # List[str] | Agents (optional)
    session_id = ['session_id_example'] # List[str] | Session ID (optional)
    user_id = ['user_id_example'] # List[str] | User ID (optional)
    pending_approval = True # bool | Only include tool-call batches that do/don't have approval-gated calls awaiting a decision (optional)
    has_approval = True # bool | Only include tool-call batches that have/don't have at least one approval/rejection response (optional)
    pending_response = True # bool | Only include tool-call batches that are/aren't waiting for one or more currently expected responses (optional)
    has_response = True # bool | Only include tool-call batches that have/don't have at least one response activity (optional)
    has_artifact = True # bool | Only include tool calls that do/don't contain artifacts (optional)
    artifact_archived = True # bool | Which artifacts should be included based on their archived status (optional)
    from_schedule = True # bool | If true, only include sessions created by schedules (optional)
    limit = 56 # int | Limit (defaults to 10, max 1000) (optional)
    sort_order = 'sort_order_example' # str | Sort asc/desc (defaults to desc) (optional)
    after_key = 'after_key_example' # str | Pagination Key (optional)
    calculate_meta = True # bool | Provide metadata with total counts in the response (optional)

    try:
        # List Tool Calls
        api_response = api_instance.list_tool_calls_global(workflow_component_id=workflow_component_id, workflow_version_id=workflow_version_id, tool=tool, agent=agent, session_id=session_id, user_id=user_id, pending_approval=pending_approval, has_approval=has_approval, pending_response=pending_response, has_response=has_response, has_artifact=has_artifact, artifact_archived=artifact_archived, from_schedule=from_schedule, limit=limit, sort_order=sort_order, after_key=after_key, calculate_meta=calculate_meta)
        print("The response of ActivityApi->list_tool_calls_global:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ActivityApi->list_tool_calls_global: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_component_id** | [**List[str]**](str.md)| Workflow component IDs | [optional] 
 **workflow_version_id** | [**List[str]**](str.md)| Workflow version IDs | [optional] 
 **tool** | [**List[str]**](str.md)| Tools | [optional] 
 **agent** | [**List[str]**](str.md)| Agents | [optional] 
 **session_id** | [**List[str]**](str.md)| Session ID | [optional] 
 **user_id** | [**List[str]**](str.md)| User ID | [optional] 
 **pending_approval** | **bool**| Only include tool-call batches that do/don&#39;t have approval-gated calls awaiting a decision | [optional] 
 **has_approval** | **bool**| Only include tool-call batches that have/don&#39;t have at least one approval/rejection response | [optional] 
 **pending_response** | **bool**| Only include tool-call batches that are/aren&#39;t waiting for one or more currently expected responses | [optional] 
 **has_response** | **bool**| Only include tool-call batches that have/don&#39;t have at least one response activity | [optional] 
 **has_artifact** | **bool**| Only include tool calls that do/don&#39;t contain artifacts | [optional] 
 **artifact_archived** | **bool**| Which artifacts should be included based on their archived status | [optional] 
 **from_schedule** | **bool**| If true, only include sessions created by schedules | [optional] 
 **limit** | **int**| Limit (defaults to 10, max 1000) | [optional] 
 **sort_order** | **str**| Sort asc/desc (defaults to desc) | [optional] 
 **after_key** | **str**| Pagination Key | [optional] 
 **calculate_meta** | **bool**| Provide metadata with total counts in the response | [optional] 

### Return type

[**OutputPaginatedResponseModelToolCall**](OutputPaginatedResponseModelToolCall.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **send_activity**
> OutputResponseModelActivity send_activity(workflow_id, body)

Send Activity

Sends a new activity event

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_create_activity_request import InputCreateActivityRequest
from chariot_api._openapi.awm.models.output_response_model_activity import OutputResponseModelActivity
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.ActivityApi(api_client)
    workflow_id = 'workflow_id_example' # str | Workflow ID
    body = chariot_api._openapi.awm.InputCreateActivityRequest() # InputCreateActivityRequest | Request Body

    try:
        # Send Activity
        api_response = api_instance.send_activity(workflow_id, body)
        print("The response of ActivityApi->send_activity:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling ActivityApi->send_activity: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_id** | **str**| Workflow ID | 
 **body** | [**InputCreateActivityRequest**](InputCreateActivityRequest.md)| Request Body | 

### Return type

[**OutputResponseModelActivity**](OutputResponseModelActivity.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**202** | Accepted |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


# ModelSharedConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | **Dict[str, object]** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_shared_configuration import ModelSharedConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of ModelSharedConfiguration from a JSON string
model_shared_configuration_instance = ModelSharedConfiguration.from_json(json)
# print the JSON string representation of the object
print(ModelSharedConfiguration.to_json())

# convert the object into a dict
model_shared_configuration_dict = model_shared_configuration_instance.to_dict()
# create an instance of ModelSharedConfiguration from a dict
model_shared_configuration_from_dict = ModelSharedConfiguration.from_dict(model_shared_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



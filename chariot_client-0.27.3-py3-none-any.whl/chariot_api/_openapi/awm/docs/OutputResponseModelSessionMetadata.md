# OutputResponseModelSessionMetadata


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**ModelSessionMetadata**](ModelSessionMetadata.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_response_model_session_metadata import OutputResponseModelSessionMetadata

# TODO update the JSON string below
json = "{}"
# create an instance of OutputResponseModelSessionMetadata from a JSON string
output_response_model_session_metadata_instance = OutputResponseModelSessionMetadata.from_json(json)
# print the JSON string representation of the object
print(OutputResponseModelSessionMetadata.to_json())

# convert the object into a dict
output_response_model_session_metadata_dict = output_response_model_session_metadata_instance.to_dict()
# create an instance of OutputResponseModelSessionMetadata from a dict
output_response_model_session_metadata_from_dict = OutputResponseModelSessionMetadata.from_dict(output_response_model_session_metadata_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# ModelFeedback


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**activity_id** | **str** |  | [optional] 
**activity_type** | **str** |  | [optional] 
**agent** | **str** |  | [optional] 
**comment** | **str** |  | [optional] 
**created_at** | **str** |  | [optional] 
**created_by** | **str** |  | [optional] 
**id** | **str** |  | [optional] 
**project_id** | **str** |  | [optional] 
**session_created_by** | **str** |  | [optional] 
**session_display_name** | **str** |  | [optional] 
**session_id** | **str** |  | [optional] 
**source** | **str** |  | [optional] 
**thumbs_up** | **bool** |  | [optional] 
**updated_at** | **str** |  | [optional] 
**workflow_component_id** | **str** |  | [optional] 
**workflow_version_id** | **str** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_feedback import ModelFeedback

# TODO update the JSON string below
json = "{}"
# create an instance of ModelFeedback from a JSON string
model_feedback_instance = ModelFeedback.from_json(json)
# print the JSON string representation of the object
print(ModelFeedback.to_json())

# convert the object into a dict
model_feedback_dict = model_feedback_instance.to_dict()
# create an instance of ModelFeedback from a dict
model_feedback_from_dict = ModelFeedback.from_dict(model_feedback_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



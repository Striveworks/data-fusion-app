# OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelWorkflowConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**ModelConfigurationComponentVersionModelWorkflowConfiguration**](ModelConfigurationComponentVersionModelWorkflowConfiguration.md) |  | [optional] 
**overrides** | **object** |  | [optional] 
**resolved** | **object** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_resolved_configuration_response_model_configuration_component_version_model_workflow_configuration import OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelWorkflowConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelWorkflowConfiguration from a JSON string
output_resolved_configuration_response_model_configuration_component_version_model_workflow_configuration_instance = OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelWorkflowConfiguration.from_json(json)
# print the JSON string representation of the object
print(OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelWorkflowConfiguration.to_json())

# convert the object into a dict
output_resolved_configuration_response_model_configuration_component_version_model_workflow_configuration_dict = output_resolved_configuration_response_model_configuration_component_version_model_workflow_configuration_instance.to_dict()
# create an instance of OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelWorkflowConfiguration from a dict
output_resolved_configuration_response_model_configuration_component_version_model_workflow_configuration_from_dict = OutputResolvedConfigurationResponseModelConfigurationComponentVersionModelWorkflowConfiguration.from_dict(output_resolved_configuration_response_model_configuration_component_version_model_workflow_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# chariot_api._openapi.awm.WorkflowsApi

All URIs are relative to */api/awm/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_workflow**](WorkflowsApi.md#get_workflow) | **GET** /workflows/{workflowID} | Get Workflow
[**get_workflow_auth_providers**](WorkflowsApi.md#get_workflow_auth_providers) | **GET** /workflows/{workflowID}/auth-providers | Get Workflow Auth Providers
[**get_workflow_public_settings**](WorkflowsApi.md#get_workflow_public_settings) | **GET** /workflows/{workflowID}/public-settings | Get Workflow Public Settings
[**get_workflow_resource_details**](WorkflowsApi.md#get_workflow_resource_details) | **GET** /workflows/{workflowID}/resources | Get Workflow Resource Details
[**list_workflow_agents**](WorkflowsApi.md#list_workflow_agents) | **GET** /workflows/{workflowID}/agents | List Workflow Agents
[**list_workflows**](WorkflowsApi.md#list_workflows) | **GET** /workflows | List Workflows
[**patch_workflow**](WorkflowsApi.md#patch_workflow) | **PATCH** /workflows/{workflowID} | Patch Workflow
[**patch_workflow_public_settings**](WorkflowsApi.md#patch_workflow_public_settings) | **PATCH** /workflows/{workflowID}/public-settings | Patch Workflow Public Settings


# **get_workflow**
> OutputResponseModelWorkflow get_workflow(workflow_id)

Get Workflow

Gets a workflow

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_response_model_workflow import OutputResponseModelWorkflow
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.WorkflowsApi(api_client)
    workflow_id = 'workflow_id_example' # str | Workflow ID

    try:
        # Get Workflow
        api_response = api_instance.get_workflow(workflow_id)
        print("The response of WorkflowsApi->get_workflow:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling WorkflowsApi->get_workflow: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_id** | **str**| Workflow ID | 

### Return type

[**OutputResponseModelWorkflow**](OutputResponseModelWorkflow.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_workflow_auth_providers**
> OutputResponseArrayModelWorkflowAuthProvider get_workflow_auth_providers(workflow_id)

Get Workflow Auth Providers

Gets required auth providers and whether the current user has credentials for each

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_response_array_model_workflow_auth_provider import OutputResponseArrayModelWorkflowAuthProvider
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.WorkflowsApi(api_client)
    workflow_id = 'workflow_id_example' # str | Workflow ID

    try:
        # Get Workflow Auth Providers
        api_response = api_instance.get_workflow_auth_providers(workflow_id)
        print("The response of WorkflowsApi->get_workflow_auth_providers:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling WorkflowsApi->get_workflow_auth_providers: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_id** | **str**| Workflow ID | 

### Return type

[**OutputResponseArrayModelWorkflowAuthProvider**](OutputResponseArrayModelWorkflowAuthProvider.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_workflow_public_settings**
> OutputResponseModelPublicSettingValues get_workflow_public_settings(workflow_id)

Get Workflow Public Settings

Gets a workflow's defined public settings

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_response_model_public_setting_values import OutputResponseModelPublicSettingValues
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.WorkflowsApi(api_client)
    workflow_id = 'workflow_id_example' # str | Workflow ID

    try:
        # Get Workflow Public Settings
        api_response = api_instance.get_workflow_public_settings(workflow_id)
        print("The response of WorkflowsApi->get_workflow_public_settings:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling WorkflowsApi->get_workflow_public_settings: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_id** | **str**| Workflow ID | 

### Return type

[**OutputResponseModelPublicSettingValues**](OutputResponseModelPublicSettingValues.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_workflow_resource_details**
> OutputResponseModelWorkflowResourceDetails get_workflow_resource_details(workflow_id)

Get Workflow Resource Details

Gets a workflow's resource details from kubernetes

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_response_model_workflow_resource_details import OutputResponseModelWorkflowResourceDetails
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.WorkflowsApi(api_client)
    workflow_id = 'workflow_id_example' # str | Workflow ID

    try:
        # Get Workflow Resource Details
        api_response = api_instance.get_workflow_resource_details(workflow_id)
        print("The response of WorkflowsApi->get_workflow_resource_details:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling WorkflowsApi->get_workflow_resource_details: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_id** | **str**| Workflow ID | 

### Return type

[**OutputResponseModelWorkflowResourceDetails**](OutputResponseModelWorkflowResourceDetails.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_workflow_agents**
> OutputResponseArrayModelAgent list_workflow_agents(workflow_id)

List Workflow Agents

Lists the agents configured for a workflow

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_response_array_model_agent import OutputResponseArrayModelAgent
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.WorkflowsApi(api_client)
    workflow_id = 'workflow_id_example' # str | Workflow ID

    try:
        # List Workflow Agents
        api_response = api_instance.list_workflow_agents(workflow_id)
        print("The response of WorkflowsApi->list_workflow_agents:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling WorkflowsApi->list_workflow_agents: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_id** | **str**| Workflow ID | 

### Return type

[**OutputResponseArrayModelAgent**](OutputResponseArrayModelAgent.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_workflows**
> OutputPaginatedResponseModelWorkflow list_workflows(name=name, exact_name_match=exact_name_match, component_id=component_id, key=key, var_from=var_from, to=to, project_id=project_id, include_deleted=include_deleted, dirty=dirty, paused=paused, limit=limit, after_key=after_key, sort_type=sort_type, sort_order=sort_order, permission=permission)

List Workflows

Lists workflows

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_paginated_response_model_workflow import OutputPaginatedResponseModelWorkflow
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.WorkflowsApi(api_client)
    name = 'name_example' # str | Name Search (partial match, case-insensitive by default) (optional)
    exact_name_match = True # bool | Exact Name Match (when true, name must match exactly) (optional)
    component_id = 'component_id_example' # str | Component ID (exact match) (optional)
    key = 'key_example' # str | Key Search (partial match, case-insensitive) (optional)
    var_from = 'var_from_example' # str | Created At Start (inclusive lower bound) (optional)
    to = 'to_example' # str | Created At End (inclusive upper bound) (optional)
    project_id = ['project_id_example'] # List[str] | Project ID (optional)
    include_deleted = True # bool | Include Deleted Workflows (optional)
    dirty = True # bool | Is Dirty (Is known to be missing k8s resources) (optional)
    paused = True # bool | Is Paused (optional)
    limit = 56 # int | Limit (defaults to 10, max 50) (optional)
    after_key = 'after_key_example' # str | Pagination Key (optional)
    sort_type = 'sort_type_example' # str | Sort Type (default, creation_timestamp, name) (optional)
    sort_order = 'sort_order_example' # str | Sort asc/desc (defaults to desc for default sort, asc otherwise) (optional)
    permission = 'permission_example' # str | Permission filter (usage filters to workflows the caller can use) (optional)

    try:
        # List Workflows
        api_response = api_instance.list_workflows(name=name, exact_name_match=exact_name_match, component_id=component_id, key=key, var_from=var_from, to=to, project_id=project_id, include_deleted=include_deleted, dirty=dirty, paused=paused, limit=limit, after_key=after_key, sort_type=sort_type, sort_order=sort_order, permission=permission)
        print("The response of WorkflowsApi->list_workflows:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling WorkflowsApi->list_workflows: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**| Name Search (partial match, case-insensitive by default) | [optional] 
 **exact_name_match** | **bool**| Exact Name Match (when true, name must match exactly) | [optional] 
 **component_id** | **str**| Component ID (exact match) | [optional] 
 **key** | **str**| Key Search (partial match, case-insensitive) | [optional] 
 **var_from** | **str**| Created At Start (inclusive lower bound) | [optional] 
 **to** | **str**| Created At End (inclusive upper bound) | [optional] 
 **project_id** | [**List[str]**](str.md)| Project ID | [optional] 
 **include_deleted** | **bool**| Include Deleted Workflows | [optional] 
 **dirty** | **bool**| Is Dirty (Is known to be missing k8s resources) | [optional] 
 **paused** | **bool**| Is Paused | [optional] 
 **limit** | **int**| Limit (defaults to 10, max 50) | [optional] 
 **after_key** | **str**| Pagination Key | [optional] 
 **sort_type** | **str**| Sort Type (default, creation_timestamp, name) | [optional] 
 **sort_order** | **str**| Sort asc/desc (defaults to desc for default sort, asc otherwise) | [optional] 
 **permission** | **str**| Permission filter (usage filters to workflows the caller can use) | [optional] 

### Return type

[**OutputPaginatedResponseModelWorkflow**](OutputPaginatedResponseModelWorkflow.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **patch_workflow**
> str patch_workflow(workflow_id, body)

Patch Workflow

Patches a workflow

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.input_patch_workflow_request import InputPatchWorkflowRequest
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.WorkflowsApi(api_client)
    workflow_id = 'workflow_id_example' # str | Workflow ID
    body = chariot_api._openapi.awm.InputPatchWorkflowRequest() # InputPatchWorkflowRequest | Request Body

    try:
        # Patch Workflow
        api_response = api_instance.patch_workflow(workflow_id, body)
        print("The response of WorkflowsApi->patch_workflow:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling WorkflowsApi->patch_workflow: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_id** | **str**| Workflow ID | 
 **body** | [**InputPatchWorkflowRequest**](InputPatchWorkflowRequest.md)| Request Body | 

### Return type

**str**

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** | No Content |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **patch_workflow_public_settings**
> OutputResponseModelPublicSettingValues patch_workflow_public_settings(workflow_id, body)

Patch Workflow Public Settings

Patches a workflow's defined public settings

### Example

* Api Key Authentication (BearerAuth):

```python
import chariot_api._openapi.awm
from chariot_api._openapi.awm.models.output_response_model_public_setting_values import OutputResponseModelPublicSettingValues
from chariot_api._openapi.awm.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to /api/awm/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = chariot_api._openapi.awm.Configuration(
    host = "/api/awm/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: BearerAuth
configuration.api_key['BearerAuth'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['BearerAuth'] = 'Bearer'

# Enter a context with an instance of the API client
with chariot_api._openapi.awm.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = chariot_api._openapi.awm.WorkflowsApi(api_client)
    workflow_id = 'workflow_id_example' # str | Workflow ID
    body = None # Dict[str, object] | Request Body

    try:
        # Patch Workflow Public Settings
        api_response = api_instance.patch_workflow_public_settings(workflow_id, body)
        print("The response of WorkflowsApi->patch_workflow_public_settings:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling WorkflowsApi->patch_workflow_public_settings: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **workflow_id** | **str**| Workflow ID | 
 **body** | [**Dict[str, object]**](object.md)| Request Body | 

### Return type

[**OutputResponseModelPublicSettingValues**](OutputResponseModelPublicSettingValues.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |
**403** | Forbidden |  -  |
**404** | Not Found |  -  |
**500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


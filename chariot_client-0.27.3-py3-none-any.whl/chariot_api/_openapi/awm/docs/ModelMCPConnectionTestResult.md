# ModelMCPConnectionTestResult


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **str** |  | [optional] 
**status** | **str** |  | [optional] 
**tools** | [**List[ModelMCPToolSummary]**](ModelMCPToolSummary.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_mcp_connection_test_result import ModelMCPConnectionTestResult

# TODO update the JSON string below
json = "{}"
# create an instance of ModelMCPConnectionTestResult from a JSON string
model_mcp_connection_test_result_instance = ModelMCPConnectionTestResult.from_json(json)
# print the JSON string representation of the object
print(ModelMCPConnectionTestResult.to_json())

# convert the object into a dict
model_mcp_connection_test_result_dict = model_mcp_connection_test_result_instance.to_dict()
# create an instance of ModelMCPConnectionTestResult from a dict
model_mcp_connection_test_result_from_dict = ModelMCPConnectionTestResult.from_dict(model_mcp_connection_test_result_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



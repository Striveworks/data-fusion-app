# ModelMessageCompactingConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**context_threshold** | **float** |  | [optional] 
**model_settings** | [**ModelModelConfiguration**](ModelModelConfiguration.md) |  | [optional] 
**user_messages_to_keep** | **int** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_message_compacting_configuration import ModelMessageCompactingConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of ModelMessageCompactingConfiguration from a JSON string
model_message_compacting_configuration_instance = ModelMessageCompactingConfiguration.from_json(json)
# print the JSON string representation of the object
print(ModelMessageCompactingConfiguration.to_json())

# convert the object into a dict
model_message_compacting_configuration_dict = model_message_compacting_configuration_instance.to_dict()
# create an instance of ModelMessageCompactingConfiguration from a dict
model_message_compacting_configuration_from_dict = ModelMessageCompactingConfiguration.from_dict(model_message_compacting_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# ModelToolEvaluatorAppliesTo


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **bool** |  | [optional] 
**event_type** | **str** |  | [optional] 
**tools** | [**ModelFilteredListString**](ModelFilteredListString.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_tool_evaluator_applies_to import ModelToolEvaluatorAppliesTo

# TODO update the JSON string below
json = "{}"
# create an instance of ModelToolEvaluatorAppliesTo from a JSON string
model_tool_evaluator_applies_to_instance = ModelToolEvaluatorAppliesTo.from_json(json)
# print the JSON string representation of the object
print(ModelToolEvaluatorAppliesTo.to_json())

# convert the object into a dict
model_tool_evaluator_applies_to_dict = model_tool_evaluator_applies_to_instance.to_dict()
# create an instance of ModelToolEvaluatorAppliesTo from a dict
model_tool_evaluator_applies_to_from_dict = ModelToolEvaluatorAppliesTo.from_dict(model_tool_evaluator_applies_to_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



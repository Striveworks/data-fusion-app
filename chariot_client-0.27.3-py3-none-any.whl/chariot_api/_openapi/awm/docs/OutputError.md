# OutputError


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | [**OutputErrorWrapper**](OutputErrorWrapper.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_error import OutputError

# TODO update the JSON string below
json = "{}"
# create an instance of OutputError from a JSON string
output_error_instance = OutputError.from_json(json)
# print the JSON string representation of the object
print(OutputError.to_json())

# convert the object into a dict
output_error_dict = output_error_instance.to_dict()
# create an instance of OutputError from a dict
output_error_from_dict = OutputError.from_dict(output_error_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



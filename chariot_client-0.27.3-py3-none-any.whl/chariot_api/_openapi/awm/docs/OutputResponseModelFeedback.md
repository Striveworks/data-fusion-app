# OutputResponseModelFeedback


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**ModelFeedback**](ModelFeedback.md) |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.output_response_model_feedback import OutputResponseModelFeedback

# TODO update the JSON string below
json = "{}"
# create an instance of OutputResponseModelFeedback from a JSON string
output_response_model_feedback_instance = OutputResponseModelFeedback.from_json(json)
# print the JSON string representation of the object
print(OutputResponseModelFeedback.to_json())

# convert the object into a dict
output_response_model_feedback_dict = output_response_model_feedback_instance.to_dict()
# create an instance of OutputResponseModelFeedback from a dict
output_response_model_feedback_from_dict = OutputResponseModelFeedback.from_dict(output_response_model_feedback_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



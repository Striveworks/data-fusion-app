# ModelFeedbackStatistics


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**thumbs_down** | **int** |  | [optional] 
**thumbs_up** | **int** |  | [optional] 
**total** | **int** |  | [optional] 
**with_comments** | **int** |  | [optional] 

## Example

```python
from chariot_api._openapi.awm.models.model_feedback_statistics import ModelFeedbackStatistics

# TODO update the JSON string below
json = "{}"
# create an instance of ModelFeedbackStatistics from a JSON string
model_feedback_statistics_instance = ModelFeedbackStatistics.from_json(json)
# print the JSON string representation of the object
print(ModelFeedbackStatistics.to_json())

# convert the object into a dict
model_feedback_statistics_dict = model_feedback_statistics_instance.to_dict()
# create an instance of ModelFeedbackStatistics from a dict
model_feedback_statistics_from_dict = ModelFeedbackStatistics.from_dict(model_feedback_statistics_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



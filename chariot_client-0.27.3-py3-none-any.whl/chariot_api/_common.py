import sys
from importlib import metadata

try:
    __version__ = metadata.version("chariot-client")
except Exception:
    try:
        __version__ = metadata.version("chariot_api")
    except Exception:
        __version__ = "0.0.0-dev"
del metadata


def getLogger(name):
    """By default use structlog if it has been loaded"""
    if "structlog" in sys.modules:
        import structlog
        return structlog.getLogger(name)
    else:
        import logging
        return logging.getLogger(name)

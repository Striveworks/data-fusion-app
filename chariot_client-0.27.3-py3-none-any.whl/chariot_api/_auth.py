import logging
import time
import json
import urllib3
from urllib.parse import urlencode, urljoin
from contextvars import ContextVar

from chariot_api._common import __version__, getLogger
from chariot_api._settings import Settings


log = getLogger(__name__)

# Disable TLS warnings
urllib3.disable_warnings()

_holder = {"token": None, "expires": None, "static": False}

# Context managed token
_context_token: ContextVar[str] = ContextVar("_context_token", default=None)


def _pool_manager(settings: Settings) -> urllib3.PoolManager:
    return urllib3.PoolManager(
        cert_reqs="CERT_REQUIRED" if settings.verify_ssl else "CERT_NONE",
        cert_file=settings.cert_filename or None,
        key_file=settings.key_filename or None,
        timeout=settings.timeout,
        retries=settings.retries,
    )


def _raise_for_status(resp: urllib3.BaseHTTPResponse) -> None:
    if 400 <= resp.status:
        raise urllib3.exceptions.HTTPError(
            f"HTTP {resp.status} for {resp.geturl()}: {resp.data.decode('utf-8', errors='replace')}"
        )


def _json(resp: urllib3.BaseHTTPResponse):
    return json.loads(resp.data.decode("utf-8"))


def set_bearer_token(token: str) -> None:
    """Set a static non-refreshable bearer token."""
    _holder["token"] = token
    _holder["expires"] = time.time() * 10 # never refresh
    _holder["static"] = True


def get_bearer_token(settings: Settings, refresh: bool = False) -> str:
    """
    Fetch and cache the bearer token used to make authenticated calls to Chariot.

    Returns
    -------
    token : str
        the bearer token
    """
    if _context_token.get() is not None:
        return _context_token.get()

    if (_holder["expires"] and _holder["expires"] > time.time() and not refresh) or _holder["static"]:
        return _holder["token"]

    if not settings.base_url:
        raise ValueError("base_url must be set, perhaps run `chariot init`")

    if not settings.client_id or not settings.client_secret:
        raise ValueError("both client_id and client_secret must be set")

    data = {
        "client_id": settings.client_id,
        "client_secret": settings.client_secret.get_secret_value(),
        "grant_type": "client_credentials",
    }
    if settings.client_scope:
        data["client_scope"] = settings.client_scope
    if settings.expires_in:
        data["expires_in"] = settings.expires_in

    url = settings.login_url()
    resp = _pool_manager(settings).request(
        "POST",
        url,
        body=urlencode(data),
        headers={
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": f"Chariot-API/{__version__}",
        },
    )
    _raise_for_status(resp)
    payload = _json(resp)

    _validate_version(resp.headers.get("X-Chariot-Version", ""))

    _holder["token"] = payload["access_token"]
    _holder["expires"] = time.time() + 59 * payload["expires_in"]

    expiresAt = time.time() + 60 * payload["expires_in"]
    expiresAtStr = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(expiresAt))
    log.debug(f"Chariot Token ID {payload.get('token_id')} expires-at {expiresAtStr}")
    return _holder["token"]


def get_version(settings: Settings, verbose: bool = True, validate: bool = False) -> str:
    """
    Get the version of the Chariot platform.

    :param verbose (bool): print the versions of Chariot and the SDK
    :param validate (bool): raise RuntimeError if versions are incongruent

    Returns
    -------
    version: str
        the version of Chariot
    """
    url = urljoin(settings.base_url, 'version')
    resp = _pool_manager(settings).request(
        "GET",
        url,
        headers={"User-Agent": f"Chariot-API/{__version__}"},
    )
    _raise_for_status(resp)
    version = _json(resp)
    valid = _validate_version(version, verbose)
    if not valid and validate:
        raise RuntimeError(f"Chariot version {version} != SDK version {__version__}")
    return version


def _validate_version(version: str, verbose: bool = False) -> bool:
    def _msg(state):
        return (
            f"Chariot version {version} is {state} than sdk version {__version__}\n\n\033[31m"
            f"\t==========================================================================================\n"
            f"\t== Running with a mismatched SDK != Chariot version may have unexpected results.\n"
            f"\t== Please install \033[1;33mchariot-client=={version}\033[0;31m to avoid aberrant behavior.\n"
            f"\t==========================================================================================\n"
            f"\033[0m"
        )

    def _log(level, msg):
        log.log(level, msg)
        if verbose:
            print(msg)

    if not version:
        _log(logging.WARNING, "Chariot returned no version")
    elif __version__ == "0.0.0.dev0" or __version__ == "0.0.0-dev" or __version__.startswith("0.0.1a20"):
        _log(logging.DEBUG, f"Chariot version {version} with dev sdk {__version__}")
        return True
    elif __version__ < version:
        _log(logging.ERROR, _msg("newer"))
    elif __version__.split("a")[0] != version.split("-")[0]:
        _log(logging.WARNING, _msg("older"))
    else:
        _log(logging.DEBUG, f"Chariot version {version} matches sdk version {__version__}")
        return True
    return False
